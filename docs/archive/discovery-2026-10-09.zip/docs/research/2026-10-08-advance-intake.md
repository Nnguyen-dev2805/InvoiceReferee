# R1 — Tạo đề nghị tạm ứng trực tiếp hay nhập hồ sơ có sẵn?

Ngày research: 08/10/2026. Trạng thái: **HƯỚNG TIẾP NHẬN ĐÃ ĐƯỢC ĐỒNG Ý TẠI [R1-DEC-02](../DISCOVERY_ROADMAP.md); CHI TIẾT THIẾT KẾ CÒN MỞ**. Việc đồng ý hướng không xác minh implementation, tác động người dùng hoặc các giả định chưa kiểm chứng trong research.

Phạm vi: cách tiếp nhận đề nghị tạm ứng cho MVP có cả trước công việc và quyết toán sau công việc. Không đánh giá code; không đưa ra kết luận pháp lý hoặc khả năng áp dụng phổ quát cho mọi doanh nghiệp.

## 1. Kết luận của người review chính

Khuyến nghị **tạo trực tiếp cho đề nghị mới, đồng thời tiếp nhận hồ sơ có sẵn qua đường nhập tài liệu giới hạn**. Hai cách tạo cùng một loại hồ sơ nghiệp vụ và dùng chung quy tắc kiểm tra, theo dõi tiền thực nhận, liên kết quyết toán. Không xây hai quy trình tài chính riêng.

Khuyến nghị ban đầu chỉ ưu tiên tạo trực tiếp cần bổ sung điều kiện: nếu tổ chức đã lập/duyệt đề nghị bên ngoài, bắt nhập mới có thể gây thêm việc và tạo hai biểu diễn lệch nhau của cùng đề nghị. Chưa có doanh nghiệp mục tiêu hoặc thử người dùng để chứng minh một cách vào luôn tốt hơn cách còn lại.

Nếu buộc phải chọn một đường cho lát cắt triển khai đầu tiên, ưu tiên form trực tiếp cho hồ sơ mới; đường nhập tài liệu vẫn nằm trong phạm vi thiết kế, không giả vờ đã hỗ trợ mọi mẫu. Nếu tổ chức thử nghiệm chủ yếu có hồ sơ bên ngoài và cần giữ quy trình đó, đổi ưu tiên sang nhập tài liệu là hợp lý. Tiêu chí đổi là quy trình/người dùng thực, không phải mức độ trình diễn OCR.

## 2. Bằng chứng nguồn chính

| Nguồn | Nội dung trực tiếp hỗ trợ quyết định | Giới hạn |
| --- | --- | --- |
| [UW — Travel Advances](https://finance.uw.edu/travel/traveladvances) | Hướng dẫn tạo đề nghị trong Workday với người nhận, thời gian, mục đích, lý do và dòng tạm ứng. Có thể tạo thay người khác theo quy trình của trường. | Ví dụ số hóa tại UW; không chứng minh mọi doanh nghiệp nên dùng các field/quyền của UW. |
| [Columbia — Reconcile Requests in Concur](https://training.finance.columbia.edu/content/reconciling-pre-trip-and-travelcash-advance-requests-concur) | Hướng dẫn sửa tháng 6/2026 cho phép tạo báo cáo chi phí từ đề nghị đã duyệt hoặc nhập đề nghị vào báo cáo; dữ liệu đề nghị được liên kết. | Minh chứng liên kết hai giai đoạn, không chứng minh đề nghị đã duyệt bằng tiền thực nhận. |
| [ĐH Nông Lâm Huế — QT_006_KHTC](https://dvctt.huaf.edu.vn/xem-quy-trinh/52) | Trang cập nhật 09/11/2022 ghi trạng thái hiện hành, hồ sơ gồm giấy đề nghị và dự trù đã duyệt; kế toán kiểm tra, trình duyệt rồi nhận tiền. Trang ghi không áp dụng nộp trực tuyến. | Mô tả công khai của một trường, có tài liệu căn cứ cũ; chưa xác minh vận hành thực tế hoặc thay đổi nội bộ năm 2026. |
| [ĐH Đồng Tháp — quy trình tài chính 10/01/2024](https://cmsweb.dthu.edu.vn/Uploads/Files/aa873084-ecdf-4ce4-980a-f9077a05d9f3.pdf) | Phần 5.2 yêu cầu giấy đề nghị/dự toán có phê duyệt, kiểm tra và duyệt theo vai; tách lập phiếu chi/ủy nhiệm chi và lưu chứng từ chuyển thành công. | Quy trình tại thời điểm tài liệu 2024, không kết luận mọi điều khoản vẫn có hiệu lực năm 2026 hay áp dụng cho doanh nghiệp tư nhân. |

Đây là bằng chứng rằng cả đầu vào số và hồ sơ bên ngoài đều có tiền lệ thực tế. Không phải khảo sát thị trường, tỷ lệ sử dụng hay bằng chứng giảm thời gian.

## 3. So sánh thiết kế

Các nhận xét dưới đây là suy luận thiết kế của lead; lợi ích thời gian và lỗi cần đo với người dùng.

| Phương án | Lợi ích | Điểm yếu quan trọng |
| --- | --- | --- |
| Chỉ tạo trực tiếp | Nhận dữ kiện có cấu trúc ngay; kiểm tra thiếu trường trước khi nộp; dễ giữ mã hồ sơ và phiên bản để nối quyết toán. | Có thể bắt nhập lại hồ sơ đã tồn tại; dữ liệu nhập vẫn là khai báo, có thể sai; không thay thế bằng chứng phê duyệt/chi tiền bên ngoài. |
| Chỉ upload giấy/PDF | Giữ tài liệu gốc và thông tin biểu hiện trên đó; phù hợp hồ sơ đã lập ngoài app. | Phải đọc/trích xuất; mẫu khác nhau và ảnh kém gây thêm lỗi. Nếu chưa có giấy, tạo Word/PDF chỉ để OCR lại là thao tác phát sinh. |
| Form chính + nhập tài liệu giới hạn | Tiếp nhận theo tình trạng hồ sơ, giữ một lõi kiểm tra và liên kết. | Thêm một đường nhập cần kiểm chứng; phải quản lý nguồn, mâu thuẫn và trùng hồ sơ. Không mặc định hỗ trợ mọi template/chữ viết tay/chữ ký. |

Hai phản ví dụ:

1. **Nhập mới bắt buộc:** hồ sơ bên ngoài đề nghị 5 triệu và đã được duyệt 4 triệu. Người nộp tạo form mới 5 triệu mà bỏ nguồn phê duyệt. Nếu xem form này là đề nghị độc lập và duyệt lại, hệ thống có thể tạo nghĩa vụ trùng hoặc mất bối cảnh giới hạn đã được duyệt.
2. **Upload bắt buộc:** nhân viên chưa có đề nghị, phải điền Word, xuất PDF, tải lên rồi sửa kết quả OCR của chính thông tin vừa nhập. Quy trình thêm một vòng chuyển đổi thay vì giảm công việc.

## 4. Workflow đề xuất

**Đề nghị mới:** nhập thông tin → đính kèm căn cứ khi cần → kiểm tra dữ kiện/quy định → báo cáo hoặc câu hỏi → con người quyết định tài chính → ghi nhận chi tiền thực tế có nguồn → liên kết hồ sơ quyết toán.

**Hồ sơ đã có:** upload gốc → trích xuất có nguồn → bổ sung/xác minh trường chưa rõ → ghi nhận trạng thái bên ngoài cùng căn cứ → vào phần kiểm tra tương ứng của cùng hồ sơ nghiệp vụ → liên kết quyết toán.

“Hồ sơ đã có” có thể chưa duyệt, đã duyệt hoặc đã chi. Không gán chung trạng thái Approved, không bắt xin ứng lần nữa chỉ vì import. Quy định nào cần kiểm tra lại và quyền công nhận quyết định bên ngoài phải chốt ở rulebook.

## 5. Ranh giới dữ liệu và AI

- Form trực tiếp là khai báo có cấu trúc, không tự là sự thật đã xác minh. Khi có tài liệu liên quan, vẫn phải đối chiếu.
- OCR là cách đọc nguồn; giữ bản gốc và tham chiếu trường đã đọc. Chưa rõ thì không tự điền để đạt đủ trường.
- Thấy chữ ký/ghi chú đã duyệt không tự xác thực người ký, quyền tại thời điểm đó hay tính nguyên vẹn của tài liệu. Demo role selection không chứng minh danh tính công ty.
- Giữ riêng số đề nghị, số được duyệt, số thực nhận. Import giấy đề nghị không chứng minh đã chi tiền.
- AI phù hợp với đọc tài liệu, nhận diện loại/căn cứ và đề xuất liên kết có diễn đạt khác nhau. Dữ kiện đã nhập rõ không cần đi qua OCR chỉ để tạo thêm vai trò cho AI; kiểm tra số tiền/quy tắc vẫn bằng chương trình.
- MVP chưa cần dịch vụ phê duyệt bên ngoài, ERP hay ngân hàng. Nguồn/xác nhận thủ công cần ghi phạm vi và mức tin cậy được policy chấp nhận; không có nguồn thì giữ chưa xác định.

## 6. Cách kiểm chứng trước khi gọi là cải tiến

1. Hai đường vào biểu diễn cùng hồ sơ, cùng nguồn đủ rõ và policy phải cho kết quả nghiệp vụ tương ứng. Sai đọc hoặc thiếu căn cứ phải được báo đúng, không đổi gold để che lỗi.
2. Kiểm tra form khác giấy, số được duyệt khác số đề nghị, hồ sơ đã chi bên ngoài, hai lần import cùng đề nghị và sửa dữ liệu sau duyệt. Không chỉ thử mẫu giấy thuận lợi.
3. Đo từ chuẩn bị đầu vào đến kết quả dùng được: nhập/tải lên, sửa trích xuất, bổ sung, rà soát và lỗi cuối. Không dùng thời gian OCR riêng để kết luận tiết kiệm toàn quy trình.
4. Thử với người làm nghiệp vụ; tách hồ sơ mới và hồ sơ có sẵn. Chưa có số liệu để tuyên bố form nhanh hơn một tỷ lệ cụ thể hoặc hai đường nhập đã đáp ứng cuộc thi.

## 7. Phương pháp và giới hạn research

- Một subagent được gọi bằng `chatgpt-web/gpt-5.6-sol`, mức Medium, nhiệm vụ read-only tìm quy trình Việt Nam. Lead nghiên cứu nguồn số hóa và trực tiếp mở lại các nguồn được dùng trong bảng trên.
- SAP Help có nội dung hướng dẫn tạo cash advance trong kết quả search nhưng lần mở trực tiếp không trả body; không dùng nó làm căn cứ chính. Trang Penn State chủ yếu dẫn sang tài liệu SharePoint; không dùng nội dung chưa mở làm bằng chứng.
- Đã đọc văn bản PDF Đồng Tháp. Các lần chụp trang lưu đồ/chứng từ bằng web gặp cache miss hoặc không trả ảnh hiển thị trong phiên; không xác nhận độc lập mọi mũi tên/ô của lưu đồ. Các kết luận dùng phần diễn giải văn bản, không dùng sơ đồ chưa xem được.
- Chưa phỏng vấn kế toán/doanh nghiệp, chưa kiểm chứng hệ thống thực tế của các trường, chưa đo người dùng. Hướng form chính và nhập hồ sơ có sẵn đã được chủ dự án đồng ý tại R1-DEC-02; các chi tiết, phạm vi tài liệu và lợi ích cần kiểm chứng vẫn chưa được chốt chỉ từ research.

# R1 — Có bằng chứng xin phép công tác là điểm tắc nghẽn không?

Ngày research: 08/10/2026. Trạng thái: **RESEARCH ĐÃ HOÀN THÀNH; HƯỚNG PHẠM VI ĐÃ CHỌN TẠI [R1-DEC-03](../DISCOVERY_ROADMAP.md)**. Chủ dự án chọn hỗ trợ xin phép trong app và tiếp nhận căn cứ bên ngoài; việc chọn không thay đổi mức bằng chứng hoặc chứng minh tác động. Chi tiết nghiệp vụ còn mở.

## 1. Kết luận của lead

**Có bằng chứng bên ngoài về việc hoàn tất cho phép công tác muộn và phải sửa hồ sơ. Chưa đủ bằng chứng để kết luận đây là điểm tắc nghẽn chính của doanh nghiệp mục tiêu hoặc ưu tiên toàn bộ luồng xin phép công tác trong MVP.**

Kết luận dựa trên nguồn audit của từng tổ chức và tài liệu sản phẩm Việt Nam. Không dựa vào code, không phải phỏng vấn người dùng của InvoiceReferee. Hai văn phòng UNFPA không được xem như hai khảo sát doanh nghiệp độc lập đại diện thị trường.

Cần phân biệt bốn câu hỏi: vấn đề có tồn tại không; nguyên nhân ở khâu nào; mức độ phổ biến/lớn tới đâu; giải pháp InvoiceReferee có giảm nó không. Nguồn tìm được trả lời khá rõ câu đầu, chỉ một phần câu thứ hai, chưa trả lời hai câu sau cho đối tượng mục tiêu.

## 2. Bằng chứng kiểm tra lại từ nguồn gốc

| Nguồn, thời điểm/phạm vi | Phát hiện được nguồn hỗ trợ | Giới hạn diễn giải |
| --- | --- | --- |
| [UNFPA Brazil, IA/2025-31, 31/12/2025](https://www.unfpa.org/sites/default/files/audit-reports/2025-12-31_Audit_of_the_UNFPA_CO_in_Brazil_-_FINAL.pdf), §37, trang in 14. Audit hoạt động 01/2024–06/2025. | 34 trường hợp năm 2025 được cấp cho phép công tác trong khoảng 15 ngày làm việc sát khởi hành; audit nhận định giảm cơ hội mua vé sớm với giá thấp. | Không có mẫu số để tính tỷ lệ; không đo riêng thời gian chờ người duyệt hoặc mức tiền vé tăng. 145 hồ sơ nộp muộn ở cùng mục là sau chuyến đi, không gộp vào xin phép. |
| [UNFPA Somalia, IA/2025-11, 18/06/2025](https://www.unfpa.org/sites/default/files/audit-reports/2025-06-18_Audit_of_the_UNFPA_CO_in_Somalia_-_FINAL.docx.pdf), §82, trang in 30. Audit hoạt động 2023–2024. | Trong 35 giao dịch công tác trị giá 140.950 USD, 6 giao dịch quốc tế trị giá 46.071 USD được cho phép sát ngày đi; audit nêu cơ hội mua vé rẻ hơn có thể bị bỏ lỡ. Có 2 trường hợp đi trước khi có cho phép. | Không tách rõ nộp muộn với xử lý muộn; không suy ra số ngày xử lý hoặc thiệt hại giá vé thực đo. Các nhóm phát hiện không được tự coi là không trùng nhau. |
| [Federal Reserve OIG — CFPB, 30/09/2013](https://oig.federalreserve.gov/reports/cfpb-full-report-20130930a-finding2.htm), Finding 2, phần Travel Authorizations. Kiểm tra 53 vouchers và 120 transactions. | 10 occurrences thiếu phê duyệt cần thiết trước chuyến đi, gồm 2 trường hợp Travel Office chưa duyệt và 4 trường hợp người đi nộp muộn; nhân sự báo hồ sơ có lỗi, phải trả sửa. | Bằng chứng lịch sử, không kết luận hiện trạng 2026. Không lấy backlog khoảng 1.300 actions trộn authorizations/vouchers làm số hồ sơ xin phép chậm. |
| [WMATA OIG — Audit of Travel Expenses](https://wmataoig.gov/wp-content/uploads/2025/01/Audit-of-WMATAs-Travel-Expenses-IG-Final_Redacted-1.pdf), Finding 2, trang in 10–11. Dữ liệu audit 07/2022–06/2023. | Trong 40 đề nghị ứng, 2 khoản được chi 11 ngày sau khởi hành dù yêu cầu đã được cho phép trước chuyến đi. Thiếu thời điểm nhận hồ sơ nên audit không xác định được khâu gây chậm. | Đây là phản ví dụ cho việc quy mọi chậm trễ tiền ứng về xin phép công tác. Không suy từ thời điểm chi ra thời gian xử lý của người duyệt. |
| [MISA — luồng phê duyệt công tác sang tạm ứng, cập nhật 25/03/2024](https://helpamis.misa.vn/amis-quy-trinh/kb/misa-ket-noi-voi-amis-cham-cong-tu-dong-chay-quy-trinh-phe-duyet-tam-ung-di-cong-tac/) | Tài liệu hãng mô tả tạo đề nghị công tác kèm thông tin ứng; duyệt công tác rồi chuyển dữ liệu sang luồng tạm ứng và kế toán chi tiền. | Chứng minh một cách thiết kế/liên kết có thực, không chứng minh khách hàng chờ bao lâu hoặc giải pháp giảm thời gian bao nhiêu. Không sao chép các cấp duyệt/hạn quyết toán thành policy của MVP. |

**Kiểm tra đơn vị thống kê:** 6/35 ≈ 17,1% theo số lượng giao dịch; 46.071/140.950 ≈ 32,7% theo giá trị. Báo cáo Somalia ghi 33% sample; số này khớp với giá trị tiền, không được trình bày thành 33% số chuyến. Cụm “trong khoảng 15 ngày làm việc sát chuyến đi” cũng không có nghĩa hồ sơ đã chờ duyệt 15 ngày.

Các nhận định về cơ hội mua vé sớm là kết luận của auditor tại các tổ chức đó, không phải thử nghiệm nhân quả về giá vé hay hiệu quả AI.

## 3. Bằng chứng Việt Nam và chất lượng tìm kiếm

Trong phạm vi tìm kiếm tiếng Việt đã thực hiện, nguồn chính đọc được là mô tả workflow của MISA. Chưa thu được số liệu gốc đủ rõ đo riêng thời gian xin phép công tác, số vòng sửa hoặc chi phí do chờ duyệt tại doanh nghiệp Việt Nam. Đây là giới hạn của lượt research, không phải kết luận Việt Nam không có vấn đề này.

Một số kết quả của nhà cung cấp nói về phê duyệt nội bộ nói chung hoặc thời gian tạm ứng/quyết toán. Không dùng những mô tả đó để khẳng định xin phép chuyến đi là điểm nghẽn. Hai trang MISA khác chỉ có nội dung search/cache và mở trực tiếp lỗi, nên không dùng làm căn cứ định lượng hoặc xác nhận khách hàng thực.

Tài liệu quy trình có hạn nộp trước/SLA hay nhiều chữ ký chỉ cho thấy yêu cầu kiểm soát và cấu trúc bàn giao. Chưa có thời gian thực đo thì không gọi đó là bằng chứng chậm.

## 4. Phản biện đề xuất mở rộng MVP

Các ý dưới đây là suy luận thiết kế của lead, chưa được người dùng chốt:

1. **Vấn đề tồn tại không tự chứng minh nó đáng ưu tiên nhất.** Muốn ưu tiên phải biết nó xảy ra với ai, bao nhiêu lần, tốn gì và phần nào giải pháp có thể thay đổi. Audit một văn phòng không thay cho discovery tại đối tượng mục tiêu.
2. **Thêm luồng phê duyệt không tự giảm chờ.** Nếu thiếu thông tin, kiểm tra sớm và câu hỏi cụ thể có thể giúp; nếu người quyết định chưa ưu tiên công việc hoặc ngân sách chưa có, đọc tài liệu tốt hơn chưa giải quyết được nguyên nhân đó.
3. **Một số lợi ích là của phần mềm workflow, không riêng AI.** Giữ mã hồ sơ, tái sử dụng dữ liệu, thấy đang chờ ai và lưu quyết định là lợi ích cần đo. AI có thể hỗ trợ đọc căn cứ và phát hiện mâu thuẫn; không cần để AI tự quyết định chuyến đi có đáng thực hiện hay không.
4. **Phạm vi nhỏ vẫn có lý do tồn tại dù chưa chứng minh “điểm nghẽn lớn”.** Tạm ứng cần căn cứ công việc theo policy. Ghi nhận cho phép bên ngoài hoặc một yêu cầu xác nhận đúng người có thể cần để bảo vệ nguồn/quyền, không nhất thiết phải xây đầy đủ hệ thống quản lý công tác.

Khuyến nghị tại thời điểm research: giữ kiểm tra tạm ứng và quyết toán làm lõi; thiết kế căn cứ cho phép công việc có người, phạm vi và nguồn rõ. Nếu thêm xin phép trong app, trước hết chỉ một bước quyết định của người có quyền trên cùng hồ sơ. Chưa ưu tiên quản lý lịch, đặt vé, nhiều tầng duyệt hay công cụ quản trị chuyến đi. Sau research, chủ dự án đã chọn hỗ trợ xin phép trong app và tiếp nhận căn cứ bên ngoài tại R1-DEC-03; đây là lựa chọn sản phẩm, không phải bằng chứng điểm nghẽn hoặc hiệu quả đã được đo.

## 5. Cần đo gì để xác định điểm tắc nghẽn thật?

| Đoạn cần phân biệt | Dữ liệu cần có | Sai lầm cần tránh |
| --- | --- | --- |
| Xin phép công việc | Lúc gửi, lần xem đầu, yêu cầu bổ sung, gửi lại, quyết định cho phép/từ chối. | Tính mọi ngày sát khởi hành thành chờ người duyệt. |
| Kiểm tra/chi tạm ứng | Lúc nhận hồ sơ đủ, kiểm tra xong, duyệt tiền, chi tiền thực tế. | Quy chậm chi về xin phép trong khi cho phép đã xong. |
| Quyết toán sau công việc | Lúc kết thúc công việc, nộp hồ sơ, đủ chứng từ, đối chiếu xong, duyệt và chi/thu. | Dùng chậm nộp của người đi làm thời gian xử lý kế toán. |

Đối với mỗi đoạn, tách công sức thao tác, thời gian chờ, số vòng bổ sung và độ đúng. Nếu thử thêm bước xin phép, so với cách hiện tại trên trường hợp tương đương; ghi cả việc mới phát sinh và không tự lấy một ngưỡng tiết kiệm tùy ý làm kết luận.

## 6. Phương pháp và giới hạn

- Subagent `chatgpt-web/gpt-5.6-sol`, mức Medium, nghiên cứu audit/bằng chứng quốc tế read-only. Lead tìm nguồn Việt Nam, trực tiếp mở nguồn và kiểm tra lại số liệu, đơn vị, điều kiện và phản ví dụ.
- Đã đọc phần diễn giải văn bản của các PDF. Web screenshot các trang Brazil 14, Somalia 30, WMATA 10 báo cache miss; không xác nhận độc lập bố cục/bảng/hình từ ảnh. Các số liệu được dùng có trong đoạn văn kiểm tra lại; không đọc thêm giá trị chỉ có ở bảng chưa xem.
- Không khẳng định thực trạng của các đơn vị sau kỳ audit, không kết luận quy trình đó là luật áp dụng cho doanh nghiệp Việt Nam. Không gọi search/cache hoặc tài liệu hãng là thử nghiệm độc lập với khách hàng.
- Chưa có dữ liệu người dùng/đơn vị mục tiêu, chưa có đối chứng triển khai InvoiceReferee. Không thay research này cho ba người thử thực của cuộc thi.

# InvoiceReferee — Roadmap xác định lại bài toán từ đầu

Ngày: 08/10/2026 · Phiên bản: 0.1 · Trạng thái: **ĐỀ XUẤT ĐỂ CÙNG THẢO LUẬN**.

Đây là roadmap tìm hiểu, phản biện và thiết kế; chưa phải spec sản phẩm, kế hoạch giao coding agent hay bằng chứng hệ thống đã vận hành. Việc viết roadmap được yêu cầu; các lựa chọn nghiệp vụ và kiến trúc bên dưới chưa mặc nhiên được chốt.

## 1. Mục đích và cách sử dụng

Mục tiêu là để chủ dự án có thể giải thích bài toán, tự vẽ workflow và kiến trúc, biết kết quả nào đúng và kiểm tra được code do agent tạo ra. Một hệ thống chạy được nhưng chủ dự án không hiểu vì sao kết luận như vậy chưa đạt mục tiêu này.

Thứ tự làm việc:

**Yêu cầu cuộc thi → vấn đề và công việc cần giải quyết → nghiệp vụ và nguồn dữ liệu → phạm vi tự chủ → quy tắc và cách đánh giá → workflow → kiến trúc/spec → đối chiếu code → triển khai và chứng minh.**

Code hiện tại không được dùng để quyết định nhu cầu, gold hay thiết kế ở R0–R7. Tài liệu/spec cũ cũng chỉ là phương án lịch sử khi đến bước đối chiếu. Bắt đầu từ đầu ở đây là xác định lại căn cứ; không có yêu cầu xóa code hoặc phủ nhận những lựa chọn trước đây.

Mỗi buổi chỉ xử lý một quyết định quan trọng. Mình trình bày phương án, khuyến nghị, lý do và phản ví dụ; bạn chất vấn và giải thích lại bằng lời của mình. Chỉ ghi **ĐÃ CHỐT** khi có quyết định của bạn. Có thể quay lại bước trước nếu một tình huống mới làm lộ mâu thuẫn.

Không cần viết mười tài liệu dài. Ban đầu dùng một hồ sơ thiết kế ngắn với các mục tương ứng; chỉ tách rulebook, gold và spec khi cần giao việc hoặc tái lập đánh giá.

## 2. Căn cứ và giới hạn của roadmap

Nguồn yêu cầu cuộc thi là [đề gốc](Challenge_Brief_OrganizationAI_VN.docx.md), đặc biệt Mục 1, 2.A, 3, 4, 5 và 6. Các đề xuất nghiệp vụ trong roadmap là suy luận thiết kế, chưa phải quy trình đã được một doanh nghiệp xác nhận hoặc tư vấn về quy định kế toán.

| Căn cứ | Điều phải đưa vào thiết kế và bằng chứng |
| --- | --- |
| Mục 2.A — Sprint 1 | Một công việc thường quy và quy định rõ; ít nhất 15 trường hợp; phân biệt thiếu dữ kiện, ngoài quy định, vượt thẩm quyền; câu hỏi cụ thể; tự xử lý hồ sơ thường quy; không khẳng định kết quả dựa trên dữ liệu đang có nghi vấn chưa giải quyết. |
| Mục 2.A — kiểm thử nhanh | Verify Escalation có 5 case: 3 thường quy và 2 cần chuyển tiếp; xử lý được đầu vào mới. Kỳ vọng xuất phát từ quy định, không ép hệ thống cho ra tỷ lệ 3/2 trên mọi tập dữ liệu. |
| Mục 2.A — Sprint 2 | Tự điều chỉnh ngưỡng chuyển tiếp từ phản hồi; đo tỷ lệ bỏ sót và chuyển tiếp thừa trên tập độc lập; ít nhất 3 người thực sự xử lý nghiệp vụ và ít nhất một cải tiến từ phản hồi. |
| Mục 3 — sản phẩm nộp | Live URL, Verify Core 4 case, runbook, repo công khai có lịch sử, video tối đa 3 phút, đúng 5 slide, build log 1 trang. Core 4 và Escalation 5 là hai yêu cầu, có thể dùng chung một phần case. |
| Mục 4 — con người và trách nhiệm | Kết quả truy vết được thao tác, thời điểm, dữ liệu, lý do; thử được Stop và Override; vị trí quyết định của con người phải khớp giữa demo và mô tả. |
| Mục 4 — vòng Chung kết | 45 điểm trình diễn, 35 điểm phỏng vấn phản biện, 20 điểm kiểm thử theo đề bài. Riêng Challenge A: 8 điểm phát hiện đúng, 6 điểm không chuyển tiếp thừa, 6 điểm chất lượng câu hỏi. |
| Mục 5 — thời hạn | Khóa bài nộp **15/10**; Demo Day **17/10**. Không lập kế hoạch phát triển như thể ngày 17 là hạn chốt code. |
| Mục 6 — bằng chứng | Phản hồi phải đến từ người tham gia thực; dữ liệu thực cần quyền sử dụng phù hợp. Research, agent và tự thử không thay thế ba người làm nghiệp vụ. |

Theo xác nhận mới nhất của chủ dự án khi chuyển sang R1, hiện không có phản hồi/bài toán riêng của giám khảo để bổ sung. Tiếp tục thiết kế theo đề gốc trong repo; không xem việc chờ phản hồi riêng là điều kiện chặn. Nếu có yêu cầu mới sau này, phải đối chiếu và cập nhật các quyết định chịu ảnh hưởng.

**Điểm cần phản biện:** một hệ thống chỉ trích xuất rồi chuyển mọi hồ sơ cho kế toán kiểm tra lại có nguy cơ thiếu tính tự chủ của Challenge A. Ngược lại, tự động chuyển tiền không phải yêu cầu được nêu trong đề. Chúng ta phải định nghĩa công việc tự động đủ hữu ích, chứng minh nó hoàn thành trọn vẹn và làm rõ quyết định tài chính nào nằm phía sau. Cách diễn giải này cần được bảo vệ bằng demo và, nếu có thể, đối chiếu với cố vấn; chưa thể bảo đảm giám khảo chấp nhận mọi phạm vi do mình đặt tên.

## 3. Bản đồ các chặng

| Chặng | Nội dung cùng xác định | Đầu ra | Điều kiện chuyển bước |
| --- | --- | --- | --- |
| **R0** | Thi đúng bài toán gì, cần chứng minh gì, hạn nào? | Bảng yêu cầu → bằng chứng; ràng buộc cuộc thi. | Phân biệt được yêu cầu BTC, đề xuất của mình và thông tin còn thiếu. |
| **R1** | Giúp ai hoàn thành công việc nào? | Phát biểu bài toán, người dùng chính, tác động cần đo. | Nêu được điểm bắt đầu/kết thúc, tổn thất hiện tại và công việc con người được giảm. |
| **R2** | Nghiệp vụ hiện tại thực sự diễn ra thế nào? | Sơ đồ hiện trạng, từ điển nghiệp vụ, hồ sơ ví dụ và nguồn chứng cứ. | Đi được một hồ sơ thường quy và các ngoại lệ bằng tay; gắn nhãn giả định chưa xác minh. |
| **R3** | MVP làm đến đâu; tự chủ đến đâu? | Phạm vi phát hành, đầu ra, quyền của hệ thống/con người. | Định nghĩa được “hoàn thành” cho thường quy; biết vì sao và giao ai khi dừng. |
| **R4** | Dùng dữ kiện và quy tắc nào để kết luận? | Hợp đồng nguồn, mô hình nghiệp vụ, rulebook, ví dụ tính toán. | Hai người dùng cùng dữ kiện/quy định cho cùng đáp án; thiếu dữ kiện cho ra chưa xác định. |
| **R5** | Chứng minh đúng và hữu ích bằng cách nào? | Gold độc lập, thiết kế tập đánh giá, metric, cổng nghiệm thu. | Có cách chấm đúng/sai trước khi xem output của chương trình. |
| **R6** | Luồng xử lý mới đi qua những bước nào? | Mermaid workflow; luồng con người; bảng trạng thái và lỗi. | Mọi nhánh có đầu vào, đầu ra, người chịu trách nhiệm và điều kiện tiếp tục/kết thúc. |
| **R7** | Thành phần nào thực hiện từng bước? | Sơ đồ kiến trúc, hợp đồng giao tiếp, spec có acceptance criteria. | Bạn giải thích được từng thành phần, vai trò AI và một case xuyên suốt. |
| **R8** | Code đang có đáp ứng thiết kế mới tới đâu? | Bảng giữ/sửa/thay/bỏ; gap có bằng chứng; plan triển khai. | Đánh giá theo spec đã chốt; mỗi thay đổi có lý do và phép kiểm tra. |
| **R9** | Triển khai, đo, cải tiến và nộp bài. | Phần mềm, baseline đã đóng băng, kết quả độc lập, phản hồi người dùng, gói demo. | Có bằng chứng cho từng tuyên bố; giới hạn và phần chưa làm được báo cáo rõ. |

R0–R5 xác định bài toán và cách biết mình đúng. R6–R7 thiết kế giải pháp. R8 mới mở code để đánh giá. R9 mới thực hiện kế hoạch thay đổi code.

## 4. Nội dung và phản biện ở từng chặng

### R0 — Chốt mục tiêu cuộc thi và trách nhiệm chứng minh

Cần tách **Challenge A/B/C của BTC**, **giai đoạn A/B phát triển sản phẩm từng bàn**, và **baseline B0/B1/B2**. Chúng là ba cách phân loại khác nhau. Trong roadmap này, R0–R9 là thứ tự làm việc; chưa dùng tên baseline để khẳng định sản phẩm đã được nghiệm thu.

Khuyến nghị khởi đầu: tiếp tục xem Challenge A là hướng ứng viên chính vì câu hỏi trung tâm của dự án là lúc nào có thể tự kiểm tra, lúc nào cần hỏi và hỏi ai. Làm sơ đồ trước/sau vẫn hữu ích, nhưng không mặc nhiên chuyển sang Challenge B hoặc phải hoàn thành đồng thời cả ba đề bài.

Đầu ra R0 phải có từng yêu cầu, phép thử giám khảo, bằng chứng dự định cung cấp và rủi ro thiếu bằng chứng. Việc đã qua Sprint 1 không thay cho kiểm tra lại mức đáp ứng Sprint 1. Chưa đọc code thì chưa ghi yêu cầu nào là đã đáp ứng.

### R1 — Chọn một công việc, thay vì gom mọi nỗi đau

Cần trả lời: ai nhận kết quả, họ hiện phải làm gì, sai ở đâu gây hậu quả gì, và sau kết quả của hệ thống họ còn làm gì? “Kế toán mất thời gian” quá rộng để thiết kế hoặc đo.

**Đề xuất khởi đầu để phản biện:** giúp người phụ trách kiểm tra một hồ sơ chi phí sau khi công việc kết thúc, đối chiếu chứng từ với dữ liệu chi trả/tạm ứng có sẵn, xác định khoản đủ căn cứ và chênh lệch cần xử lý, hoặc hỏi đúng người để giải quyết phần chưa thể kết luận. Đây chưa phải phạm vi được chốt.

Lý do chọn điểm xuất phát này: cho phép đi trọn một chuỗi đọc → kiểm tra → đối chiếu → tính toán → xử lý ngoại lệ; có đầu ra tài chính và nguồn để kiểm chứng. Hạn chế: nếu không có nguồn chi trả đáng tin thì chưa thể chứng minh kiểm tra người trả hay ngăn hoàn trả trùng. Khi đó phải bổ sung nguồn hoặc thu hẹp lời hứa sản phẩm, không suy luận từ hóa đơn.

Ba hướng phải được so sánh bằng dữ liệu cần có và khả năng đo:

| Hướng | Giá trị có thể kiểm chứng | Khó khăn đặc thù |
| --- | --- | --- |
| Quyết toán/hoàn trả sau chi | Đối chiếu hồ sơ, tiền thực nhận/thực chi, khoản công ty trả thêm hoặc nhân viên hoàn lại. | Nguồn người trả, phân bổ tạm ứng và các khoản đã thanh toán trước. |
| Kiểm tra yêu cầu tạm ứng | Đề nghị đủ thông tin, có căn cứ công việc/ngân sách, đúng quy định và quyền. | Trước khi chi thường chưa có hóa đơn; không thể dùng bộ quy tắc hậu kiểm nguyên xi. |
| Đối chiếu mua hàng và nhận hàng | Chênh lệch số lượng, giá theo nguồn phù hợp, tình trạng nhận hàng. | Nhận nhiều đợt, đơn vị tính, nguồn đơn giá; đối chiếu chứng từ không chứng minh tồn kho thực tế. |

Khuyến nghị chưa triển khai cả ba như ba hệ thống riêng. Giữ cả ba trong tầm nhìn; chọn công việc đầu tiên ở R3 sau khi biết dữ liệu và người thử. Ba entry point giao diện không đồng nghĩa với ba bộ logic hoặc ba mức hoàn thiện giống nhau.

### R2 — Dựng hiện trạng và hiểu các khái niệm

Vẽ các vai: người nộp, quản lý, người xác nhận nhận hàng, người kiểm tra/kế toán, người có quyền phê duyệt, người thực hiện chi/thu tiền. Một người có thể giữ nhiều vai ở công ty nhỏ; quyền xác nhận một dữ kiện không đồng nghĩa với quyền cho ngoại lệ hoặc chi tiền.

Phân biệt ít nhất: đề nghị tạm ứng; tạm ứng được duyệt; tiền đã giải ngân; chi phí khai báo; chi phí có chứng từ; chi phí đủ điều kiện; chi phí do công ty trả; khoản nhân viên được hoàn; quyết toán; đề nghị chi/thu; chi/thu thực tế. Dùng định nghĩa có ví dụ, không chỉ tên trường dữ liệu.

Đi bằng tay các hồ sơ giả lập sau để tìm câu hỏi nghiệp vụ; chưa coi chúng là bộ test đã hoàn thiện:

| Tình huống | Điều cần làm rõ |
| --- | --- |
| Nhân viên tự trả 1 triệu; chứng từ và chính sách đủ. | Cần căn cứ gì để biết người trả và tính khoản được hoàn? |
| Đã thực nhận tạm ứng 4 triệu; chi đủ điều kiện 3,3 triệu. | Trong trường hợp chưa có chi/thu khác, nhân viên hoàn 0,7 triệu. Biết tiền đã thực nhận từ đâu? |
| Được duyệt 5 triệu nhưng chỉ nhận 3 triệu; chi đủ điều kiện 4 triệu. | Trong trường hợp chưa có chi/thu khác, công ty trả thêm 1 triệu. Dùng số được duyệt sẽ sai. |
| Vé máy bay 2 triệu do công ty trả; nhân viên khai PERSONAL. | Hóa đơn thể hiện chi phí; nguồn thanh toán nào chứng minh người trả, khớp chắc tới đâu? |
| Hóa đơn 10 món, nhận hàng 6 món rồi nhận thêm 4 món. | Cho phép ghép nhiều lần nhận không; số lượng/đơn vị/mặt hàng khớp ra sao? |
| Một chứng từ xuất hiện hai lần hoặc khoản chi đã được hoàn một phần. | Phân biệt trùng file, trùng chứng từ, trùng khoản đề nghị thanh toán và phân bổ hợp lệ. |

Các con số là ví dụ thiết kế. Khi có khoản chưa xác định, hoàn tiền, ứng cho nhiều công việc hoặc đã quyết toán một phần, không áp dụng máy móc phép trừ đơn giản.

Tách ba loại chứng cứ về hiện trạng: tài liệu công khai mô tả một quy trình; giả lập để thiết kế; quan sát/trao đổi thực với người làm nghiệp vụ. Research có thể cho thấy một quy trình khả dĩ, không chứng minh công ty mục tiêu cũng đang làm như vậy hoặc tiết kiệm được bao nhiêu phút.

### R3 — Chốt phạm vi và định nghĩa tự chủ

So sánh ba mức đầu ra:

| Mức | Hệ thống hoàn thành gì? | Đánh đổi |
| --- | --- | --- |
| Tổng hợp dữ kiện | Đọc và trình bày chứng từ; con người tiếp tục toàn bộ kiểm tra. | Dễ làm, nhưng khó chứng minh tự hoàn thành công việc thường quy theo Challenge A. |
| Hoàn thành công việc kiểm tra | Lưu báo cáo kiểm tra/quyết toán có kết luận, số tiền/chiều tiền khi đủ căn cứ, hoặc mở câu hỏi có người nhận; người có quyền vẫn quyết định tài chính ở bước sau. | Khuyến nghị để chứng minh độ đúng trước. Phải định nghĩa rõ ranh giới để tránh mọi hồ sơ đều quay về kiểm tra lại từ đầu. |
| Tạo đề nghị chi/thu theo quyền | Từ kết quả đã đủ căn cứ, tạo đề nghị chi/thu trong phạm vi được giao và chuyển đến bước tiếp theo. | Giảm thêm thao tác nhưng cần chứng minh quyền, kiểm soát hành động, chống tạo trùng và trạng thái hiệu lực. |

Hướng từng bàn **A trước, B sau** tương ứng hai mức cuối. Đề xuất giữ nó là phương án ưu tiên để xem xét lại. Không mặc định B cần hoàn thành trước 15/10, cũng không chờ A hoàn hảo vô hạn mới thiết kế B.

Phải quyết định đầu ra cuối cho hồ sơ thường quy và định nghĩa việc đã hoàn thành. Việc tài chính được phê duyệt ở bước sau không tự biến báo cáo kiểm tra thành ngoại lệ; nhưng chỉ gắn nhãn “đã kiểm tra” rồi yêu cầu người dùng làm lại mọi phép kiểm tra cũng không chứng minh giá trị tự chủ.

Những giới hạn cần chốt: nhóm chi phí; VND hay nhiều tiền tệ; nhiều khoản trong một hồ sơ; tạm ứng/chi trả trực tiếp hỗn hợp; nhận hàng từng phần; hoàn tiền; lịch sử có sẵn; nhập tay hay import dữ liệu đối chiếu. Chưa hỗ trợ một trường hợp thì phải nêu và xử lý ngoài phạm vi rõ ràng; không dựng hạ tầng ERP để giả vờ giải quyết thiếu nguồn.

### R4 — Thiết kế dữ kiện, nguồn và rulebook

Vấn đề khó không chỉ là mỗi bill có trường khác nhau. Cần một lõi dữ kiện chung phục vụ quyết định, phần mở rộng theo loại chứng từ, và nguồn gốc cho từng dữ kiện. Không ép phiếu nhận hàng có đơn giá nếu nó chỉ xác nhận số lượng.

Đối với mỗi dữ kiện cần kết luận, ghi: nguồn cung cấp; ai sở hữu/có thể xác nhận; định danh cần khớp; phạm vi lịch sử và thời điểm; mức đủ căn cứ; cách xử lý thiếu/mâu thuẫn; phương thức cập nhật. Ví dụ:

| Dữ kiện | Nguồn ứng viên | Giới hạn cần bảo vệ |
| --- | --- | --- |
| Tổng tiền/ngày/mặt hàng | Chứng từ gốc và phần trích xuất có tham chiếu. | OCR là kết quả đọc, có thể sai; tổng rõ không bảo đảm mọi trường khác rõ. |
| Người đã trả | Bản ghi thanh toán gắn với giao dịch, booking hoặc chứng từ; xác nhận có phạm vi của người phụ trách khi policy cho phép. | Nhân viên tự chọn PERSONAL chỉ là khai báo; hóa đơn không mặc nhiên chứng minh nhân viên thanh toán. |
| Tạm ứng thực nhận | Bản ghi giải ngân gắn người, công việc, khoản ứng. | Giấy đề nghị hoặc quyết định duyệt không chứng minh đã giải ngân. |
| Số lượng nhận | Chứng từ nhận hàng và người có trách nhiệm xác nhận. | Tên gần giống chưa đủ chứng minh cùng mặt hàng/đơn vị; nhận nhiều đợt cần căn cứ ghép. |
| Đã quyết toán/hoàn trả chưa | Lịch sử quyết toán và thanh toán thuộc phạm vi đã khai báo. | Không tìm thấy trong lịch sử thiếu không chứng minh chưa từng thanh toán. |
| Hạn mức và quyền | Chính sách có phiên bản/hiệu lực, phân quyền được công bố. | Policy giả lập không được giới thiệu như quy định thật của doanh nghiệp. |

Với MVP, một bảng dữ liệu do người phụ trách nhập/import và xác nhận phạm vi có thể đủ làm nguồn đối chiếu. Điều kiện là truy vết được và kiểm tra đúng mức kết luận; khả năng kết nối ngân hàng không tự làm dữ liệu đáng tin hơn.

Rulebook cần tách: áp dụng phép kiểm tra nào; bằng chứng cần có; phép tính; hạn mức; thẩm quyền; ngoại lệ; kết luận được phép; người nhận câu hỏi. Dữ kiện thiếu không bằng 0. Chi phí hợp lệ không đồng nghĩa với tiền nhân viên được nhận. Khoản công ty trả trực tiếp vẫn có thể là chi phí công việc hợp lệ nhưng không phải khoản hoàn cho nhân viên.

Không chốt một công thức tổng quát trước khi xác định ai nợ ai, khoản ứng phân bổ thế nào và những chi/thu nào đã xảy ra. Cần kiểm chứng cả chiều công ty → nhân viên, nhân viên → công ty, cân bằng 0 và chưa xác định. Chưa được phép chi một phần thì không tự lấy phần rõ để tạo đề nghị thanh toán.

Ba nhóm chuyển tiếp của cuộc thi phải có ví dụ và người xử lý riêng. Lỗi kỹ thuật cần một trạng thái vận hành riêng, không ngụy trang thành nhân viên thiếu chứng từ. Trường hợp rõ ràng bị cấm khác với trường hợp policy chưa bao phủ cần quyết định ngoại lệ.

### R5 — Thiết kế đánh giá trước khi code

Cần hai nhóm chứng minh: **hệ thống đúng trong công việc đã định nghĩa** và **người dùng thực sự giảm việc mà chất lượng không giảm**. Độ đúng của OCR không thay cho độ đúng của quyết toán; độ đúng của quyết toán không tự chứng minh tiết kiệm thời gian.

Gold phải được lập từ chứng từ, nguồn đối chiếu và policy, độc lập với output chương trình. Case còn bất đồng phải được làm rõ hoặc giữ kết quả chưa xác định; không lấy đa số agent làm sự thật nghiệp vụ. Bộ development, calibration và holdout phải có vai trò riêng; dùng holdout để sửa rồi đo lại chính nó không còn là đánh giá độc lập cho thay đổi đó.

| Trục đánh giá | Chấm điều gì? | Cảnh báo về cách đo |
| --- | --- | --- |
| Dữ kiện và nguồn | Trường quan trọng đúng không, thuộc chứng từ nào, đủ bao phủ để kết luận không? | Báo cả đúng/sai và không đọc được; tách trường gốc không rõ khỏi lỗi đọc trường rõ. |
| Quy tắc và tiền | Áp dụng đúng phép kiểm tra, số tiền và chiều tiền, trạng thái chưa xác định. | Mẫu số là hồ sơ có gold tương ứng; nếu không tạo đề nghị chi thì không đo số tiền bằng số request. |
| Chuyển tiếp | Bỏ sót / số case cần chuyển tiếp; chuyển tiếp thừa / số case thường quy. | Báo tử số, mẫu số, quy mô tập và lỗi kỹ thuật; mẫu số 0 không thành 100% đúng. |
| Câu hỏi và con người | Đúng người; nói rõ vướng mắc, dữ kiện đã biết, chứng cứ, câu trả lời/hành động cần có; trả lời xong xử lý tiếp được. | Không chấm bằng khớp nguyên văn. Không yêu cầu người xác nhận một con số mà ngay người đó cũng không có căn cứ biết. |
| Tự chủ và kiểm soát | Công việc thường quy hoàn thành; nghi vấn chưa giải quyết không bị kết luận; Stop, sửa dữ liệu, chạy lại không tạo hành động sai/trùng. | Kiểm tra trạng thái lưu và hậu quả thực tế, không chỉ chữ hiển thị trên UI. |
| Vận hành | Thời gian toàn hồ sơ, số lời gọi, retry, timeout, token/chi phí khi đo được. | Replay không chứng minh latency hoặc độ đúng của provider live; báo tất cả lần thử. |
| Tác động nghiệp vụ | Thời gian thao tác, thời gian chờ, mở nguồn, sửa sai, bổ sung, độ đúng cuối, công sức làm quen và khó khăn mới. | Đổi thứ tự thủ công/có hệ thống hoặc dùng case tương đương để giảm hiệu ứng học; không chỉ chọn hồ sơ thuận lợi. |

Tối thiểu 15 case là yêu cầu cuộc thi, chưa bảo đảm phủ hết phạm vi. Phủ thêm theo các quyết định ở R3–R4: nguồn tiền, chất lượng chứng từ, đối chiếu, chính sách, quyền, lỗi kỹ thuật và can thiệp. Core 4/Escalation 5 là tập trình diễn nhanh, không thay cho tập đánh giá độc lập.

Cổng nghiệm thu phải hữu hạn: tập nào, mode nào, lỗi nào chặn, metric nào theo dõi, bằng chứng nào lưu. Không tự đặt “95% chính xác” cho toàn hệ thống hoặc “tiết kiệm 80%” khi chưa có cơ sở. Với bất biến tài chính/kiểm soát, yêu cầu không có vi phạm trên tập cố định đã công bố không đồng nghĩa với bảo đảm không sai trên mọi đầu vào tương lai.

Tách kết quả **policy replay**, **pipeline fake/replay**, **pipeline live**, và **thử với người dùng**. Ghi dữ liệu thật/giả lập và bước nào thực sự được chạy trong từng mode.

### R6 — Vẽ workflow logic trước kiến trúc phần mềm

Workflow và bảng trạng thái hiện tại: [R6 — Workflow và trạng thái hồ sơ](discovery/R6_WORKFLOW_STATE_DRAFT.md). Chủ dự án đã đồng ý thiết kế để tiếpR7; chưa là bằng chứng thực thi.

Đầu ra có ba hình: quy trình hiện trạng có vai trò/bàn giao; workflow logic mới; bảng trạng thái của hồ sơ và câu hỏi. Vẽ từ nghiệp vụ đã chốt, không vẽ lại tên các hàm cũ.

Luồng ứng viên để phản biện:

**Nhận hồ sơ → xác định nghiệp vụ và phép kiểm tra áp dụng → kiểm tra tài liệu/nguồn cần có → đọc có tham chiếu → xác thực và đối chiếu dữ kiện → áp dụng quy tắc/tính toán → hoàn thành hoặc chuyển tiếp → tiếp nhận câu trả lời đúng phạm vi → kiểm tra lại phần bị ảnh hưởng → lưu kết quả và hành động được phép.**

Thứ tự có thể đổi sau khi phân tích chi phí và phụ thuộc; không phải mọi thiếu sót đều cần gọi AI trước. Một hồ sơ có thể cần cả nhận hàng lẫn quyết toán. Lựa chọn loại hồ sơ trên UI không được là cách né kiểm tra bắt buộc.

Mỗi bước phải ghi đầu vào, điều kiện, đầu ra, nơi lưu, điều gì còn chưa biết và ai giải quyết. Thử thêm nhánh nhiều vướng mắc, người trả lời sai vai, bổ sung tài liệu, thay đổi số tiền, dữ liệu nguồn mâu thuẫn, timeout, Stop và kết quả đến muộn. “Hỏi thêm” chưa kết thúc một workflow hữu ích nếu không biết câu trả lời đi đâu và làm hồ sơ tiến triển thế nào.

### R7 — Thiết kế kiến trúc và spec có thể kiểm tra

Ràng buộc mới: khoảng5người dùng, backend gọn, ưu tiên kiến trúc AI/đánh giá và code theo từng luồng chạy được trên UI. [Hướng kiến trúc R7.1](discovery/R7_ARCHITECTURE_EVALUATION_DRAFT.md) đã được chủ dự án đồng ý để cụ thể hóa. Stack/providers ứng viên chọn tạiR7.4; chưa resolve package/OCR versions hoặc viết code.

Chủ dự án đã đồng ý R7.1–R7.4 và [R7.5 spec API/storage/state/controls](discovery/R7_MVP_SYSTEM_SPEC_DRAFT.md) để tiếpR8. Tách observation/normalized facts/link proposals/report khỏi quyết định và actual money; chưa là code/schema runtime hoặc measured quality.

Chỉ ở đây mới bàn OCR/model/framework. Chọn thành phần theo công việc và bằng chứng cần tạo, không chọn LangGraph, nhiều agent hay vector database như điều kiện mặc định của sản phẩm AI.

Khuyến nghị để phản biện: AI đọc tài liệu, đề xuất phân loại/ghép nội dung có cách diễn đạt khác nhau và hỗ trợ diễn đạt câu hỏi; chương trình kiểm tra hợp đồng dữ liệu, tính tiền, áp quy tắc/quyền và điều khiển trạng thái; con người cung cấp dữ kiện hoặc quyết định trong đúng quyền. Kết quả AI phải có nguồn và được kiểm tra trước khi trở thành căn cứ. Gặp một quyết định thật sự không thể viết bằng quy tắc thì phải nêu cụ thể và thiết kế cách đánh giá nó.

Không cần schema khổng lồ mô tả mọi bill. Chọn dữ kiện cần thiết cho phạm vi đầu tiên, cho phép không xác định khi thiếu, và giữ phần gốc để giải thích. Output LLM nên vừa đủ cho bước kế tiếp; độ ngắn được kiểm tra cùng độ đúng, không cắt nguồn căn cứ để chỉ giảm token.

Kiến trúc cần thể hiện UI, điều phối, đọc/chuyển đổi chứng từ, xác thực nguồn, quy tắc/tính toán, đối chiếu, xử lý phản hồi, lưu trạng thái/audit, Verify và ranh giới provider. Đây là trách nhiệm logic; chưa có nghĩa mỗi phần là một service hay một agent.

Với từng thành phần, bạn cần giải thích được: nhận gì, trả gì, lưu gì, có thể sai ở đâu, ai quyết định cuối, phép kiểm chứng nào áp dụng. Spec ghi rõ điều kiện trước/sau, phiên bản đầu vào và quyền, thao tác có tác dụng phụ, thay đổi dữ liệu nào làm kết quả cũ mất hiệu lực.

Chỉ khi nghiệp vụ đã chốt mới cập nhật các spec/rulebook/AGENTS liên quan cho nhất quán. Roadmap này không âm thầm thay hợp đồng vận hành cũ.

### R8 — Đối chiếu với code rồi lập plan

[R8.1 code gap review](discovery/R8_CODE_GAP_REVIEW.md) và [plan settlement](superpowers/plans/2026-10-09-settlement-mvp.md) ghi baseline checkout, bằng chứng có giới hạn và6luồng UI+logic+eval. New core đangPLANNED; selectedoldtests không chứng minh spec mới.

Mở code sau khi đã có thiết kế và oracle độc lập. Cố định revision và phạm vi review, kiểm tra cả composition path, API/UI, trạng thái lưu, Verify và runtime phù hợp. Không kết luận một tính năng tồn tại chỉ vì có class, test hoặc tài liệu gọi tên nó.

Lập bảng: requirement/acceptance ID → bằng chứng code và hành vi → mức đáp ứng → giữ/sửa/thay/bỏ → phép kiểm tra sau thay đổi. Phân biệt sai hợp đồng mới, lỗi vốn có và phần chưa có; không sửa gold để hợp thức hóa code.

**Phản biện đề nghị viết lại toàn bộ:** thiết kế lại từ đầu không tự chứng minh phải bỏ mọi implementation. Viết lại chỉ có ích khi nó giảm mâu thuẫn hoặc chi phí hơn việc sửa phần đang đúng. Những phần có bằng chứng đáp ứng hợp đồng có thể được giữ; phần không thể bảo vệ bằng căn cứ phải thay. Quyết định này đưa ra ở R8, không ở lúc bắt đầu.

Plan giao agent phải chia theo hành vi kiểm tra được, mỗi phần có đầu vào/đầu ra, file sở hữu, phụ thuộc, tiêu chí đạt và kiểm tra tích hợp. Agent không được tự bổ sung quy tắc kế toán hay tự đặt ngưỡng để làm test xanh.

### R9 — Triển khai, đóng băng và chứng minh

Triển khai một luồng xuyên suốt trước, sau đó mở rộng các case/nhánh theo phạm vi. Kiểm tra cùng đường xử lý cho người dùng và Verify; thêm bằng chứng live riêng khi dùng provider thật. Thử nghiệm người dùng bắt đầu khi có lát cắt đủ chạy, không phải sau khi mọi tính năng hoàn thiện.

Đóng băng baseline với revision, cấu hình, policy/ngưỡng, dữ liệu, mode, output và trace. Sau đó mới hiệu chỉnh từ phản hồi trên calibration và đo lại ở tập độc lập. Ngưỡng thích nghi được thiết kế sau khi biết tín hiệu đáng tin; không lấy mọi lần con người đồng ý làm gold, không hạ giới hạn nghiệp vụ/quyền hoặc cho qua nguồn thiếu để giảm chuyển tiếp.

Nếu mở từ giai đoạn A sang B: độ đúng báo cáo A không chứng minh an toàn của hành động B. B cần thêm kiểm tra quyền, tạo trùng, hiệu lực theo phiên bản dữ liệu, Stop và hậu quả của Override. So sánh phần công việc chung trên cùng điều kiện; báo riêng giá trị mới của tạo đề nghị chi/thu, không gọi nó là tăng độ chính xác khi chỉ thay đổi phạm vi.

Gói nộp phải mô tả đúng tính năng đang chạy và các giới hạn; đủ Core 4, Escalation 5, đầu vào mới, runbook, audit/can thiệp, URL, 5 slide, video và build log. Không báo thử người dùng hoặc cải thiện ngưỡng thành công nếu mới có thiết kế/giả lập.

## 5. Các việc chạy song song và lịch đề xuất

Đây là lịch mục tiêu để quản lý rủi ro, không phải cam kết hoàn thành toàn bộ một sản phẩm mới trong bảy ngày. Coding agent có thể tăng tốc viết code; không tự tạo được sự đồng thuận nghiệp vụ, lịch người thử hay bằng chứng độc lập.

| Mốc | Công việc chính | Việc song song |
| --- | --- | --- |
| 08/10 | R0–R1; xác định người dùng/công việc và các giả thuyết cần xác minh. | Bắt đầu tìm ba người làm nghiệp vụ, chuẩn bị kịch bản hỏi và quyền sử dụng dữ liệu; chưa gửi lời mời thay bạn. |
| 09/10 | R2–R4; hồ sơ ví dụ, nguồn, phạm vi, quy tắc và quyền. | Nhận phản hồi giám khảo/cố vấn nếu có; chuẩn bị dữ liệu có nhãn nguồn. |
| 10/10 | R5–R7; gold và cách đo, workflow, kiến trúc/spec. | Review độc lập các phép tính và kết luận; lịch thử nghiệm. |
| 11/10 | R8; gap, quyết định giữ/sửa/thay, plan. | Chuẩn bị môi trường demo và cách tái lập; chưa coi là yêu cầu deploy ngay. |
| 12–14/10 | R9; triển khai và kiểm chứng, thử người dùng, cải tiến và đo độc lập. | Runbook, slide, video; thử truy cập/Verify từ ngoài môi trường phát triển. |
| 15/10 | Khóa bộ bài nộp theo yêu cầu BTC. | Kiểm tra tính khớp giữa tính năng, kết quả, tài liệu và video. |
| 16–17/10 | Luyện giải thích/phản biện và demo trên bản đã chốt. | Không dựa vào hai ngày này để bù các hạng mục phải khóa ngày 15. |

Nếu trễ, đánh giá lại phạm vi phát hành và cổng chứng minh. Có thể giảm loại chứng từ hoặc nhánh nâng cao chưa cần thiết; không bù bằng số liệu giả, chuyển mọi hồ sơ cho người hoặc gọi replay là live. Nếu cả ba nghiệp vụ đều phải có trong bản phát hành, phải xác định và chứng minh phạm vi hỗ trợ cụ thể của từng nghiệp vụ.

Từ R0 cần mở hai việc song song: kế hoạch người thử và kiểm tra khả năng trình diễn/reproduce. Không cần triển khai public ngay trong giai đoạn tư duy; nhưng trì hoãn mọi kiểm tra triển khai đến giờ cuối làm mất thời gian sửa lỗi môi trường.

## 6. Sổ quyết định và cách chủ dự án kiểm tra agent

Mỗi quyết định ghi: ID; câu hỏi; các phương án; khuyến nghị và lý do; phản ví dụ/rủi ro; căn cứ; lựa chọn của bạn; phạm vi; điều gì khiến phải xét lại. Nhãn gồm **ĐÃ CHỐT**, **ĐỀ XUẤT**, **GIẢ THUYẾT CHƯA XÁC MINH**, **CẦN THÔNG TIN**. Các nhãn này nói về thiết kế, không thay các nhãn implementation/verification của repo.

Sổ đầu tiên cần giải quyết lần lượt: D01 công việc/người dùng chính; D02 phạm vi tự chủ/đầu ra; D03 nghiệp vụ bản đầu; D04 nguồn chứng minh người trả/tạm ứng/lịch sử; D05 phép tính và phần chưa xác định; D06 policy/quyền/ngoại lệ; D07 gold/cổng đánh giá; D08 vai trò AI; D09 trạng thái/can thiệp; D10 quyết định đối với code cũ. Chưa có quyết định nào trong danh sách được coi là chốt chỉ do xuất hiện trong roadmap.

Khi agent giao một phần code, yêu cầu nó trả lời và cho bằng chứng:

1. Hành vi nào trong spec được thực hiện, acceptance ID nào?
2. Case thường quy, phản ví dụ và trường hợp thiếu dữ kiện đi đến trạng thái nào?
3. Tiền và kết luận lấy từ nguồn nào; phần nào là khai báo/AI đề xuất/xác nhận?
4. Đã chạy kiểm tra gì, trên mode nào; trường hợp nào chưa chạy hoặc lỗi?
5. Sửa đầu vào, Stop, chạy lại, câu trả lời con người làm kết quả và hành động cũ đổi ra sao?
6. Có thay quy tắc, hạ ngưỡng, đổi gold hoặc mở rộng phạm vi không; căn cứ nào cho phép?

Chủ dự án cần tự đi một case bằng tay rồi so với output. Kiểm tra một phản ví dụ có thể bác bỏ kết luận, không chỉ đọc happy path. Green tests là bằng chứng cho những phép kiểm tra đã chạy, không tự chứng minh toàn bộ nghiệp vụ.

## 7. Điểm tiếp tục của cuộc thảo luận

Chủ dự án xác nhận không có phản hồi riêng của giám khảo và yêu cầu bắt đầu **R1**. **R0 hoàn thành ở mức khung yêu cầu và nguyên tắc chứng minh**. **R1 hoàn thành ở mức khung bài toán**, với R1-DEC-01 đến R1-DEC-09; chủ dự án đã đồng ý dùng chung hồ sơ sau chi khi không ứng, với số ứng bằng 0 có căn cứ. **R2 đang bắt đầu** bằng [walkthrough hồ sơ giả lập](discovery/R2_CASE_WALKTHROUGH.md). Hoàn thành khung R0/R1 không xác nhận phần mềm đã đáp ứng cuộc thi; nguồn/quy tắc/schema/đánh giá chi tiết thuộc các chặng sau. Việc chuẩn bị ít nhất ba người làm nghiệp vụ thực thử sản phẩm vẫn cần giải quyết song song.

Chủ dự án xác nhận hiện chưa có cố vấn từ BTC và yêu cầu assistant tiếp tục đảm nhiệm phần góp ý, phản biện nghiệp vụ/thiết kế/đánh giá. Góp ý phải có căn cứ, giả định, phản ví dụ và cách kiểm chứng; không chỉ hỏi để chủ dự án đồng ý. Đây là hỗ trợ tư duy và research, không phải xác nhận nghiệp vụ của một kế toán thực, cố vấn được BTC chỉ định hay bằng chứng thử nghiệm người dùng. Chưa có cố vấn không ngăn quá trình thiết kế, và không làm mất yêu cầu về người dùng thực trong đề.

Phát biểu bài toán đang đề xuất: **kiểm tra đề nghị tạm ứng trước công việc và kiểm tra/quyết toán chi phí sau công việc, đưa ra kết quả có căn cứ để người chịu trách nhiệm tài chính sử dụng; chỉ chuyển tiếp phần thực sự chưa đủ dữ kiện, ngoài quy định hoặc vượt quyền của công việc được giao.**

Phương án này cần bị thử bằng hai câu hỏi: công sức tìm nguồn, ghép dữ liệu, tính toán và rà soát thay đổi thế nào; nếu không có nguồn thanh toán/tạm ứng thì những kết luận nào hệ thống thực sự có quyền đưa ra? Kế toán xem mọi hồ sơ vẫn có thể tiết kiệm công việc; không đồng nhất việc rà soát mọi hồ sơ với việc làm lại toàn bộ đối chiếu. Mức giảm công việc cần đo, chưa có bằng chứng chỉ từ lựa chọn thiết kế.

## 8. Quyết định đã ghi nhận trong cuộc thảo luận

### R0-DEC-01 — Kế toán rà soát trên kết quả đối chiếu có căn cứ

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ HƯỚNG RÀ SOÁT** · Liên quan D02, chưa đóng toàn bộ D02.

- **Căn cứ chốt:** chủ dự án trả lời “Mình đồng ý với hướng 2 của bạn”, xác nhận hệ thống chuẩn bị bảng đối chiếu có căn cứ để kế toán rà soát, xem nguồn khi cần, xử lý vướng mắc và quyết định phê duyệt.
- **Lựa chọn:** hệ thống chuẩn bị kết quả đối chiếu và liên kết đến chứng cứ tương ứng. Kế toán sử dụng kết quả này để rà soát; có thể mở bất kỳ chứng từ nào, kể cả mọi chứng từ, theo nhu cầu kiểm tra. Hướng thiết kế giảm việc tự tìm và ghép các nguồn từ đầu.
- **Ranh giới:** quyền phê duyệt tài chính vẫn thuộc con người. Đồng ý cách rà soát không phải cho phép tự động phê duyệt hoặc chuyển tiền, cũng không buộc mọi hồ sơ phải chuyển tiếp vì thiếu dữ kiện.
- **Lý do:** hỗ trợ kiểm tra thuận tiện trong khi giữ quyền quyết định của người có trách nhiệm. Lợi ích thời gian và độ đúng là giả thuyết cần đo.
- **Rủi ro cần kiểm chứng:** bảng đối chiếu có thể bỏ sót nguồn, ghép sai giao dịch hoặc khiến người dùng tin kết quả mà không xác minh. Giao diện thuận tiện không chứng minh logic đúng hoặc dữ liệu đầy đủ.
- **Chưa chốt:** phạm vi nghiệp vụ, phép kiểm tra bắt buộc, mức đủ căn cứ, trạng thái hoàn thành, quyền theo vai, chính sách rà soát và các hành động tài chính sau kết quả. Chưa có kết luận về implementation, runtime hay mức đáp ứng cuộc thi.
- **Điểm R0 tiếp theo:** phân biệt chuyển tiếp để giải quyết vướng mắc trong công việc kiểm tra với phê duyệt tài chính sau khi công việc kiểm tra đã hoàn thành; kiểm tra cách thể hiện hai việc này phù hợp tiêu chí tự chủ của Challenge A.

### R0-DEC-02 — Kết luận khoản chi bị cấm rõ, không hỏi để cho qua

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ NGUYÊN TẮC** · Liên quan D06, chưa đóng toàn bộ D06.

- **Căn cứ chốt:** chủ dự án trả lời “Mình đồng ý về cách này” cho đề xuất kết luận khoản chi không đủ điều kiện khi chính sách cấm rõ và không có cơ chế ngoại lệ, thay vì hỏi người duyệt có muốn chấp nhận không.
- **Điều kiện:** dữ kiện cần thiết đã đủ rõ; chính sách áp dụng đã xác định; điều khoản cấm rõ và không cho phép ngoại lệ. Không áp dụng quyết định này khi dữ kiện còn nghi vấn hoặc chính sách chưa đủ để kết luận.
- **Lựa chọn:** hệ thống kết luận khoản chi không đủ điều kiện theo chính sách, kèm lý do, điều khoản và căn cứ. Không mở chuyển tiếp để xin cho qua một điều cấm không có cơ chế ngoại lệ.
- **Phạm vi:** kết luận cho khoản chi đã đủ căn cứ; không mặc nhiên từ chối toàn bộ hồ sơ có nhiều khoản. Cách tổng hợp kết quả và xử lý phần còn vướng phải được thiết kế riêng.
- **Lý do:** xử lý tự động trường hợp đã có đáp án theo quy định; tránh chuyển tiếp thừa và nới chính sách bằng phê duyệt không được phép.
- **Không loại bỏ quyền sửa sai:** nếu có dữ kiện mới, lỗi áp dụng hoặc chính sách có hiệu lực khác, phải đánh giá lại căn cứ. Việc sửa kết luận sai khác với cho qua điều cấm đang áp dụng.
- **Chưa chốt:** danh sách khoản bị cấm, chính sách cụ thể, nguồn/version chính sách, quy trình phản hồi và xử lý hồ sơ hỗn hợp. Quyết định thiết kế chưa chứng minh runtime đáp ứng.
- **Điểm R0 tiếp theo:** làm rõ yêu cầu không đưa ra kết quả khẳng định với dữ liệu bị gắn cờ; phân biệt phần kiểm tra đã xác minh với kết quả quyết toán toàn hồ sơ và quyền chi/thu từng phần.

### R0-DEC-03 — Giữ phần đã xác minh, chưa chốt quyết toán khi còn vướng mắc ảnh hưởng kết quả

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ RANH GIỚI KẾT LUẬN** · Liên quan D02, D05 và D09, chưa đóng toàn bộ các quyết định này.

- **Căn cứ chốt:** chủ dự án trả lời “Tôi đồng ý với ranh giới này” cho đề xuất hiển thị phần đã kiểm tra nhưng giữ hồ sơ chờ làm rõ trước khi chốt quyết toán cuối cùng.
- **Lựa chọn:** lưu và hiển thị kết quả từng phần đã xác minh, cùng căn cứ và các vướng mắc chưa giải quyết. Chưa chốt quyết toán toàn hồ sơ khi dữ kiện còn nghi vấn có thể ảnh hưởng kết quả.
- **Không suy diễn:** không đoán dữ kiện, không coi khoản chưa rõ là 0, không bỏ khoản đó để tuyên bố hồ sơ hoàn chỉnh hoặc đủ điều kiện.
- **Ảnh hưởng giữa các phần:** không yêu cầu kiểm tra lại phần không bị ảnh hưởng chỉ vì có một vướng mắc khác. Nếu dữ kiện mới hoặc nghi vấn chung ảnh hưởng đến căn cứ của phần đã kiểm tra, phải đánh giá lại phần liên quan.
- **Ranh giới tài chính:** báo cáo từng phần không phải phê duyệt tài chính và không cho phép chi/thu từng phần. Cơ chế chi/thu từng phần chưa được quyết định.
- **Lý do:** giữ công việc đã hoàn thành và giúp người xử lý tập trung đúng vướng mắc, đồng thời tránh kết luận cuối cùng thiếu căn cứ.
- **Chưa chốt:** mô hình trạng thái, cách xác định phụ thuộc/ảnh hưởng, nguồn và mức đủ căn cứ, cách tổng hợp hồ sơ, chính sách quyết toán từng phần. Chưa có kết luận về implementation hay runtime.
- **Điểm R0 tiếp theo:** làm rõ tín hiệu phản hồi và giới hạn của tự điều chỉnh ngưỡng chuyển tiếp theo yêu cầu Sprint 2; không đồng nhất phê duyệt chi phí với xác nhận việc kiểm tra ban đầu đúng.

### R0-DEC-04 — Tách phản hồi kiểm tra khỏi phê duyệt tài chính

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ Ý NGHĨA PHẢN HỒI** · Liên quan D07 và D08, chưa đóng toàn bộ các quyết định này.

- **Căn cứ chốt:** chủ dự án trả lời “Tôi đồng ý với việc này” cho đề xuất tách phản hồi hệ thống kiểm tra đúng/sai ở điểm nào khỏi hành động phê duyệt tài chính, không dùng nút Approve làm tín hiệu học mặc định.
- **Lựa chọn:** phản hồi đánh giá cần chỉ rõ kết quả kiểm tra hoặc lần chuyển tiếp đang được đánh giá và căn cứ đúng/sai. Phê duyệt tài chính không mặc nhiên chứng minh dữ kiện, phép đối chiếu hay quyết định kiểm tra ban đầu đúng.
- **Không gán nhãn ngược theo kết quả cuối:** hồ sơ được duyệt sau khi bổ sung chứng từ không chứng minh chuyển tiếp trước đó thừa. Phê duyệt một ngoại lệ không tự biến nó thành trường hợp thường quy theo chính sách hiện hành.
- **Mục đích:** xây tín hiệu phản hồi đủ ý nghĩa để đánh giá và thiết kế điều chỉnh ngưỡng chuyển tiếp theo Sprint 2, tránh học từ nhãn tài chính không phản ánh độ đúng của kiểm tra.
- **Chưa chốt:** người có quyền xác nhận từng phản hồi, cách kiểm chứng phản hồi, tham số được điều chỉnh, thuật toán, lịch cập nhật, cổng áp dụng và cách đo độc lập. Việc đồng ý nguyên tắc này chưa chứng minh cơ chế tự điều chỉnh đã tồn tại hoặc đáp ứng cuộc thi.
- **Điểm R0 tiếp theo:** tách bằng chứng từ bộ case có gold với bằng chứng thử nghiệm người dùng thực; chuẩn bị khả năng tiếp cận ít nhất ba người thực sự xử lý nghiệp vụ.

### R0-DEC-05 — Năng lực phải có phép thử có thể bác bỏ và căn cứ chấm độc lập

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ NGUYÊN TẮC CHỨNG MINH** · Liên quan D07, chưa đóng toàn bộ D07.

- **Căn cứ chốt:** chủ dự án trả lời “Đồng ý bước tiếp theo là gì” sau đề xuất mỗi tuyên bố năng lực có phép thử có thể bác bỏ, được chấm bằng dữ kiện và quy định độc lập, không dùng lời giải thích của hệ thống làm đáp án chuẩn.
- **Lựa chọn:** xác định kết quả đúng từ nguồn và chính sách trước khi chấm output. Mỗi năng lực phải có tình huống thường quy, tình huống làm thay đổi kết quả và tình huống thiếu căn cứ phù hợp; không chỉ dùng ví dụ thuận lợi.
- **Ví dụ minh họa, chưa là fixture:** cùng hóa đơn khách sạn nhưng nguồn xác nhận công ty trả, nhân viên trả hoặc chưa rõ người trả phải dẫn tới kết quả khác nhau; việc ghép giao dịch cần căn cứ liên kết chứ không chỉ số tiền giống nhau.
- **Phạm vi:** nguyên tắc thiết kế đánh giá, chưa chốt corpus, gold từng case, metric/ngưỡng nghiệm thu hoặc implementation harness. Phản biện bằng agent không tự thay thế căn cứ gốc và thử nghiệm người dùng.
- **Điểm R0 tiếp theo:** hoàn thiện bảng yêu cầu → bằng chứng → điều kiện tuyên bố, rồi dùng nó để kiểm tra đầu ra R0 trước khi xác định bài toán ở R1.

## 9. R0 — Bảng yêu cầu, bằng chứng và điều kiện tuyên bố

Trạng thái: **ĐỀ XUẤT HỒ SƠ CHỨNG MINH**. Nguồn yêu cầu là đề gốc; bằng chứng trong bảng là thứ cần chuẩn bị, không phải kết quả đã có. Bảng không đánh giá code hiện tại. Cách chấm chi tiết và cổng nghiệm thu sẽ được thiết kế ở R5 sau khi chốt nghiệp vụ/quy tắc.

| ID | Yêu cầu và căn cứ | Bằng chứng cần chuẩn bị | Điều kiện được phép tuyên bố đã chứng minh | Chặng thiết kế/thực hiện |
| --- | --- | --- | --- | --- |
| R0-REQ-01 | Công việc thường quy cụ thể, quy định rõ, tự xử lý thường quy — 2.A Sprint 1. | Phát biểu công việc, rulebook có phiên bản, trace các case thường quy và trạng thái hoàn thành. | Hoàn thành công việc đã định nghĩa mà không cần nhắc lệnh hoặc con người giải quyết vướng mắc không có thật; trình bày riêng bước phê duyệt tài chính phía sau. | R1–R4, R6, R9. |
| R0-REQ-02 | Phân biệt ba nguyên nhân chuyển tiếp — 2.A Sprint 1. | Case có gold thiếu dữ kiện/ngoài quy định/vượt quyền, lý do và người xử lý. | Phát hiện và phân loại đúng theo hợp đồng đã chốt; không gán việc chờ phê duyệt tài chính thường lệ thành lỗi kiểm tra. | R3–R6, R9. |
| R0-REQ-03 | Câu hỏi cụ thể, trả lời trực tiếp được — 2.A Sprint 1 và thang điểm Chung kết. | Câu hỏi thực tế kèm dữ kiện, nguồn, quyết định cần có và người nhận; phiên thử trả lời và xử lý tiếp. | Người đúng vai có thể cung cấp câu trả lời/hành động cần thiết; kiểm chứng mức phải tra cứu lại hồ sơ, không chấm bằng khớp nguyên văn. | R4–R7, R9. |
| R0-REQ-04 | Không kết luận khẳng định từ dữ kiện đang nghi vấn — 2.A Sprint 1. | Case mờ/thiếu/mâu thuẫn; output, trạng thái và kết quả sau bổ sung. | Phần bị ảnh hưởng không bị chốt thiếu căn cứ; không đoán hoặc dùng thiếu-as-zero; phần độc lập đã xác minh được phân biệt với quyết toán cuối. | R4–R7, R9. |
| R0-REQ-05 | Bộ kiểm thử ít nhất 15 case có các nhóm yêu cầu — 2.A Sprint 1. | Manifest case, nguồn thật/giả lập, gold và căn cứ, kết quả từng lần chạy. | Case thực sự thực thi và phủ phạm vi đã công bố; không dùng 15 tên case hay output mẫu làm bằng chứng chạy. | R5, R9. |
| R0-REQ-06 | Verify Escalation 5 case, 3 thường quy và 2 chuyển tiếp — 2.A. | Một thao tác chạy, kết quả 5 case với câu hỏi tương ứng và bằng chứng đúng/sai. | Kết quả phát sinh từ pipeline, khớp gold; công bố mode và thao tác được thực thi, không áp tỷ lệ 3/2 cho mọi tập mới. | R5, R7, R9. |
| R0-REQ-07 | Đầu vào mới do giám khảo chọn — Mục 2 và Mục 4. | Đường nhập mới, policy công bố, case chưa dùng để tuning và trace thực thi. | Kết quả hợp lý theo quy định, không phụ thuộc fixture ID/tên file hoặc chỉ chạy case mẫu. | R4–R7, R9. |
| R0-REQ-08 | Đo bỏ sót chuyển tiếp và chuyển tiếp thừa trên tập độc lập — 2.A Sprint 2. | Gold độc lập, kết quả và cách tính tử/mẫu số, toàn bộ lần thử/lỗi kỹ thuật, phiên bản dữ liệu/policy/cấu hình. | Tập đo chưa bị dùng để tuning thay đổi đang đánh giá; báo đủ hai loại lỗi, không loại thất bại để làm đẹp số liệu; quy tắc chấm lỗi kỹ thuật được định nghĩa trước. | R5, R9. |
| R0-REQ-09 | Tự điều chỉnh ngưỡng chuyển tiếp từ phản hồi — 2.A Sprint 2. | Phản hồi có căn cứ, ngưỡng trước/sau, lần điều chỉnh thực thi và kết quả đo độc lập. | Cơ chế thực sự điều chỉnh, không chỉ lưu feedback hoặc sửa tay; kiểm tra cả bỏ sót lẫn chuyển tiếp thừa và giới hạn không được nới. | R5–R7, R9. |
| R0-REQ-10 | Ít nhất 3 nhân sự trực tiếp làm nghiệp vụ, phản hồi và cải tiến — 2.A Sprint 2, Mục 4 và 6. | Phiên thử thực với danh tính/chức danh theo yêu cầu BTC, phản hồi do người tham gia cung cấp, thay đổi trước/sau có căn cứ. | Người thật thực sự thử sản phẩm; research, agent hoặc tự thử không thay thế; không chỉ thu ý kiến chung về ý tưởng. | Chuẩn bị từ R0, thực hiện R9. |
| R0-REQ-11 | Tác động trước/sau, gánh nặng và bất cập — Mục 1, 3 Slide 3/5 và Mục 4. | Phương pháp đo, kết quả thao tác/chất lượng, phản hồi về công sức chuẩn bị/làm quen và bất cập thực tế. | Đo công việc được giảm và công việc phát sinh; không suy tiết kiệm thời gian từ token/latency hay lời nhận xét tích cực; giới hạn quy mô thử được công bố. | R1, R5, R9. |
| R0-REQ-12 | Audit, Stop, Override và giải thích — Mục 1, 4. | Trace thao tác/thời điểm/đầu vào/lý do; phiên thử can thiệp với trạng thái trước/sau; giải thích cho người dùng. | Có tác dụng thực trên hành động/trạng thái đã công bố, không chỉ có nút hoặc log text; mô tả quyền con người khớp sản phẩm. | R3, R6–R7, R9. |
| R0-REQ-13 | Live URL công khai, không cần tài khoản/cài đặt — Mục 3.a và 4. | URL, hướng dẫn thao tác đầu tiên, thử truy cập và nhập case từ ngoài môi trường phát triển. | Người ngoài thực thi được luồng đã công bố; localhost hoặc video không thay Live URL cho sản phẩm web. | Chuẩn bị từ R7, thực hiện R9. |
| R0-REQ-14 | Verify Core 4 với case từ chối/chuyển tiếp, timestamp, runbook — Mục 3.b và 4. | Bảng đầu vào/kỳ vọng/cách chạy, kết quả 4 case trong một thao tác; tái lập theo runbook từ checkout sạch. | Kết quả khớp gold, dấu thời gian thực; lệnh và môi trường trong runbook đã được thử. Đề xuất có một case từ chối rõ để đáp ứng cả câu chữ ở Mục 3 và kiểm tra tuân thủ Mục 4. | R5, R7, R9. |
| R0-REQ-15 | Repo công khai có lịch sử — Mục 3.c và 6. | Repo truy cập được, lịch sử phát triển, thông tin công cụ và dữ liệu được công bố đúng phạm vi. | Hồ sơ có thể kiểm tra/tái lập; không squash/ghi đè lịch sử sprint theo đề. Bảng này không cho phép thực hiện Git action hay công khai dữ liệu riêng tư. | R8–R9. |
| R0-REQ-16 | Đúng 5 slide, video và build log — Mục 3. | Slide theo cấu trúc cố định; video vận hành; build log 1 trang, gồm tính năng cắt giảm và lý do. | Nội dung khớp bản chạy; Slide 3 có phương pháp đo, Slide 4 phân định thật/giả lập, Slide 5 có giới hạn. Đề xuất video dưới 3 phút để đáp ứng cả mức tối đa ở Mục 3 và câu chữ ở bảng điểm Mục 4. | R9. |
| R0-REQ-17 | Khóa bài 15/10, Demo Day 17/10, phản biện Chung kết — Mục 4 và 5. | Bản nộp được định danh, dữ liệu/kết quả/runbook khớp bản đó; kịch bản đầu vào mới và giải thích quyết định. | Không dùng công việc dự kiến sau ngày khóa để tuyên bố đáp ứng bài nộp; phân biệt bảng điểm Chung kết 45/35/20 với bảng điểm sơ loại. | Lập lịch từ R0, thực hiện R9. |

### Những điểm R0 còn mở

1. **Diễn giải phạm vi tự chủ:** hướng hoàn thành kiểm tra nhưng phê duyệt tài chính ở bước sau đã được chọn làm phương án; chưa có xác nhận từ giám khảo/cố vấn rằng mọi chi tiết phạm vi này phù hợp. Phải làm rõ đầu ra và điểm hoàn thành ở R1–R3.
2. **Phản hồi/bài toán riêng của giám khảo:** chủ dự án xác nhận không có khi yêu cầu bắt đầu R1. Thiết kế theo đề gốc; không chờ tài liệu bổ sung không có. Nếu phát sinh yêu cầu mới phải đối chiếu lại.
3. **Nguồn, corpus, người thử:** chưa xác định đủ cho phạm vi mới. Việc thiết kế bảng bằng chứng không xác nhận đã thu được bằng chứng hoặc có ba người thử.
4. **Khác biệt câu chữ:** Core 4 ở Mục 3 yêu cầu ít nhất một từ chối hoặc chuyển tiếp, kiểm tra tuân thủ Mục 4 ghi ít nhất một từ chối; video Mục 3 tối đa 3 phút, bảng điểm Mục 4 ghi dưới 3 phút. Các lựa chọn thận trọng ở R0-REQ-14/16 là đề xuất để đáp ứng cả hai, không sửa đề gốc.

### Điều kiện kết thúc R0 ở mức thiết kế

- Có bảng yêu cầu/bằng chứng và thống nhất cách dùng nó; yêu cầu BTC không được thay bằng mục tiêu nội bộ dễ hơn.
- Biết các nguyên tắc đã chốt, lựa chọn nào còn là đề xuất và các điểm mở được xử lý ở đâu.
- Phân biệt hoàn thành **thiết kế R0** với hoàn thành **các yêu cầu cuộc thi**. Không cần có sản phẩm/bằng chứng runtime mới được sang R1, nhưng không được báo đáp ứng cuộc thi chỉ vì R0 đã hoàn tất.
- Bước R1 tiếp theo: định nghĩa một công việc cụ thể, người nhận đầu ra và điểm hoàn thành; sau đó dùng bảng trên để thử độ phù hợp. Chưa chọn model/framework hay viết lại code.

## 10. R1 — Bản nháp xác định công việc trung tâm

Trạng thái: **KHUNG R1 ĐÃ THỐNG NHẤT TẠI R1-DEC-01 ĐẾN R1-DEC-09; CHI TIẾT CÒN MỞ CHO R2–R7**. Các lựa chọn dựa trên vấn đề chủ dự án mô tả, không dựa vào code. Chưa dùng chúng làm spec giao coding agent; nguồn tối thiểu/quy tắc/ngưỡng cụ thể và schema chưa chốt.

### Công việc ứng viên

Giúp người phụ trách kiểm tra tài chính hoàn thành hai công việc liên quan: kiểm tra đề nghị tạm ứng trước khi chi phí phát sinh, và tổng hợp/đối chiếu hồ sơ quyết toán sau công việc với chứng từ, tạm ứng thực nhận và các khoản đã thanh toán. Phần trước chi hỗ trợ người có quyền cho phép công tác trong app hoặc tiếp nhận căn cứ cho phép đã có bên ngoài. Kết quả kiểm tra có căn cứ phục vụ rà soát và quyết định tài chính; vướng mắc chưa đủ điều kiện kết luận được chuyển thành câu hỏi cụ thể. Đề xuất nối các bước theo cùng chuyến/công việc và khoản ứng, chưa chốt mô hình dữ liệu hay workflow chi tiết.

| Thành phần cần chốt | Khuyến nghị khởi đầu | Căn cứ và điểm cần thử |
| --- | --- | --- |
| Người dùng chính | Người phụ trách kiểm tra/quyết toán chi phí, gọi ngắn là kế toán trong ví dụ. | Nỗi đau đã nêu là tìm nguồn, đọc, ghép, đối chiếu và tính toán. Chưa có quan sát người dùng chứng minh mức độ/chi phí từng thao tác. |
| Người tham gia | Người nộp hồ sơ, người xác nhận dữ kiện, người phê duyệt tài chính. | Có thể trùng người ở công ty nhỏ; quyền cung cấp dữ kiện khác quyền phê duyệt. Chưa thiết kế tài khoản hay tổ chức nhiều người dùng. |
| Điểm bắt đầu | Trước chi, nhân viên gửi đề xuất công tác kèm đề nghị ứng, hoặc đề nghị ứng có căn cứ công tác bên ngoài. Sau chi, nộp hồ sơ quyết toán. Nguồn đối chiếu được cung cấp theo phạm vi. | Form/nhập tài liệu không quyết định công việc đã được cho phép hay chưa. Không gọi việc xử lý sau upload là tự thu thập mọi nguồn bên ngoài; hồ sơ thiếu vẫn được nhận và chỉ rõ việc cần bổ sung. |
| Điểm hoàn thành | Từng giai đoạn có kết quả kiểm tra đủ căn cứ trong phạm vi được giao, hoặc chuyển tiếp với vướng mắc/người nhận/hành động rõ. | Chuyển tiếp chưa hoàn thành công việc kiểm tra; sau trả lời cần đánh giá tiếp. Đã kiểm tra khác đã phê duyệt, đã chuyển tiền hoặc đã nhận tiền. Việc đóng khoản ứng sau chi/thu thực tế cần xác định riêng. |
| Công việc dự kiến được giảm | Đọc lại để nhập dữ kiện, tìm/ghép nguồn, so sánh, tính tiền và giải thích lý do. | Phải đo cả chuẩn bị dữ liệu, rà soát, sửa lỗi và bổ sung; không mặc định người dùng không cần xem chứng từ. |

### Hồ sơ giả lập để cùng tư duy

Giả định: cùng một chuyến công tác và tiền tệ VND; mọi khoản dưới đây đủ điều kiện theo chính sách giả lập; nguồn thanh toán/tạm ứng đã xác minh; chưa có hoàn tiền, thanh toán bổ sung hoặc quyết toán trước đó. Đây chưa là fixture hay policy công ty.

| Khoản | Số tiền | Nguồn chi trả đã xác minh |
| --- | --- | --- |
| Vé máy bay | 3.000.000 VND | Công ty trả trực tiếp. |
| Khách sạn | 4.000.000 VND | Nhân viên thanh toán. |
| Ăn phục vụ công việc | 1.500.000 VND | Nhân viên thanh toán. |
| Di chuyển | 1.500.000 VND | Nhân viên thanh toán. |

Tạm ứng thực nhận và phân bổ cho chuyến này: 5.000.000 VND. Nhân viên đã thanh toán 7.000.000 VND bằng tiền ứng và phần tự bù, không phải toàn bộ 7.000.000 VND đều từ khoản ứng 5.000.000 VND. Trong các giả định trên, tổng chi phí đủ điều kiện là 10.000.000 VND; đề xuất công ty trả thêm 2.000.000 VND sau khi đối trừ tạm ứng. Không lấy toàn bộ 10.000.000 VND trừ tạm ứng để tính tiền hoàn cho nhân viên.

Ví dụ này làm rõ phần quyết toán trong phạm vi hai giai đoạn đã chọn, không tự mở mọi chức năng quản lý công tác. Khi chưa rõ người trả, tiền ứng thực nhận hoặc điều kiện khoản chi, kết quả cuối phải chờ làm rõ theo R0-DEC-03.

### Hai giai đoạn cần xác định đầu vào và kết quả riêng

| Giai đoạn | Đầu vào ứng viên | Công việc hệ thống đề xuất | Đầu ra ứng viên |
| --- | --- | --- | --- |
| Trước công việc: đề nghị tạm ứng | Người đề nghị, công việc/chuyến đi, dự toán, số tiền đề nghị, căn cứ công việc/ngân sách, nguồn khoản ứng chưa quyết toán khi policy cần. | Kiểm tra đủ thông tin, đối chiếu căn cứ, quy định/hạn mức/quyền phù hợp; chỉ rõ thiếu dữ kiện hoặc quyết định cần người. | Kết quả kiểm tra đề nghị đủ căn cứ theo phạm vi, hoặc câu hỏi có người xử lý; người có quyền vẫn phê duyệt tài chính. |
| Sau công việc: quyết toán tạm ứng/hoàn trả chi phí | Bảng kê, chứng từ thực tế, tiền ứng thực nhận/phân bổ, khoản công ty trả trực tiếp, chi/thu đã có và nguồn liên kết hồ sơ. | Kiểm tra chứng từ/khoản chi, đối chiếu nguồn tiền/lịch sử và tính chênh lệch khi đủ căn cứ; giữ phần chưa rõ. | Kết quả quyết toán đề xuất có số tiền và chiều tiền, cân bằng hoặc chưa xác định; không tự giải ngân/thu tiền. |

Chưa có hóa đơn thực tế trước chuyến đi không tự là lỗi thiếu chứng từ của đề nghị ứng. Căn cứ cần cho từng giai đoạn phải được quy định riêng. Không yêu cầu đề nghị ứng phải có phê duyệt của chính đề nghị đó trước khi được kiểm tra; phân biệt căn cứ công việc/ngân sách đã duyệt với bước duyệt đề nghị đang xin.

Đề xuất dùng “quyết toán tạm ứng” để gọi bước sau chi trong spec, vì kết quả có thể là công ty trả thêm, nhân viên hoàn lại hoặc cân bằng; không mặc định “hoàn ứng” luôn là công ty trả tiền cho nhân viên. Cách dùng thuật ngữ là đề xuất thiết kế, chưa là kết luận về cách gọi tại một doanh nghiệp thực.

Điểm nối cần bảo vệ: **số đề nghị ≠ số được duyệt ≠ số thực nhận**. Phê duyệt tài chính không chứng minh đã chuyển/nhận tiền. MVP cần nguồn ghi nhận tiền thực tế do người phụ trách cung cấp/xác nhận hoặc import, chưa yêu cầu tích hợp ngân hàng. Thiếu nguồn thì phải giữ kết quả chưa xác định.

Nhánh mua hàng/nhận hàng vẫn được lưu trong tầm nhìn; không bị loại chỉ do lựa chọn hai giai đoạn này. Chi tiết phạm vi và thứ tự phát hành sẽ bàn ở R3.

### R1-DEC-01 — Hỗ trợ cả đề nghị tạm ứng và quyết toán sau công việc

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ PHẠM VI NGHIỆP VỤ HAI GIAI ĐOẠN** · Liên quan D01 và D03, chưa đóng toàn bộ các quyết định này.

- **Căn cứ chốt:** chủ dự án yêu cầu “hệ thống giải quyết cả 2 vấn đề là tạm ứng và sau chuyến đi là hoàn ứng luôn”.
- **Lựa chọn:** phạm vi cần thiết kế có cả kiểm tra đề nghị tạm ứng trước công việc và kiểm tra/quyết toán sau công việc, thay phương án chỉ lấy sau chi làm công việc trung tâm.
- **Giữ các ranh giới R0:** kết quả kiểm tra có căn cứ, xử lý nghi vấn đúng phạm vi, phê duyệt tài chính và chi/thu vẫn do con người; lựa chọn hai giai đoạn không cho phép tự phê duyệt hay tự chuyển tiền.
- **Đề xuất chưa chốt:** nối hai giai đoạn theo một vòng đời công việc/chuyến đi, quy định đầu vào/đầu ra riêng và nguồn tiền thực tế. Không lấy việc chọn scope làm phê duyệt schema, workflow hoặc mọi chức năng ứng/thu/chi nâng cao.
- **Điểm tiếp theo:** làm rõ người thực hiện, đầu vào và điều kiện hoàn thành công việc kiểm tra ở từng giai đoạn; sau đó xác định nguồn và ràng buộc nghiệp vụ.

### R1-DEC-02 — Form chính và nhập hồ sơ có sẵn

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ HƯỚNG TIẾP NHẬN** · Liên quan D01 và D03, chưa đóng toàn bộ các quyết định này.

- **Căn cứ chốt:** chủ dự án trả lời “Tôi đồng ý với ý kiến có 2 cách để nhân viên gửi yêu cầu tạm ứng của mình là form chính và nhập hồ sơ có sẵn”, sau [research ngày 08/10/2026](research/2026-10-08-advance-intake.md).
- **Lựa chọn:** form là cách chính cho đề nghị mới; nhập giấy/PDF có sẵn là cách tiếp nhận bổ sung. Cùng một hồ sơ nghiệp vụ, lõi kiểm tra và liên kết quyết toán; không tạo hai quy trình tài chính riêng.
- **Bảo toàn căn cứ:** dữ kiện nhập là khai báo; dữ kiện trích xuất có tài liệu gốc. Giữ nguồn và xử lý mâu thuẫn trước khi kết luận; việc upload không tự xác minh chữ ký/quyền hay tiền đã nhận.
- **Bảo toàn trạng thái bên ngoài:** hồ sơ có sẵn có thể chưa duyệt, đã duyệt hoặc đã chi; import không tự là một đề nghị xin ứng thêm và không làm mất lịch sử có căn cứ.
- **Chưa chốt:** các field, loại/mẫu tài liệu hỗ trợ, người xác nhận dữ kiện/trạng thái, chính sách chống trùng và cách dùng quyết định ngoài hệ thống. Chưa có implementation hay bằng chứng tiết kiệm công việc.
- **Điểm tiếp theo:** làm rõ đầu ra và điều kiện hoàn thành kiểm tra đề nghị tạm ứng, phân biệt căn cứ cho công việc/chuyến đi với phê duyệt tài chính của đề nghị đang xin.

### R1-DEC-03 — Xin phép công tác trong app và tiếp nhận căn cứ cho phép bên ngoài

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ HƯỚNG PHẠM VI** · Liên quan D01 và D03, chưa đóng toàn bộ các quyết định này.

- **Căn cứ chốt:** chủ dự án yêu cầu “Tôi muốn sử dụng cách 2 và trong đó có cả cách 1 luôn”, sau so sánh workflow và [research về điểm tắc nghẽn](research/2026-10-08-travel-authorization-bottleneck.md).
- **Lựa chọn:** hỗ trợ đề xuất công tác để người có quyền cho phép trong app; đồng thời tiếp nhận đề nghị ứng dựa trên công tác đã được cho phép bên ngoài. Hai nhánh nhập về phần kiểm tra tạm ứng và quyết toán chung.
- **Không duyệt lặp chỉ vì import:** khi căn cứ cho phép bên ngoài đủ theo quy định, sử dụng quyết định đó trong phạm vi phù hợp, không bắt xin phép lại. Nếu chưa đủ hoặc có mâu thuẫn, làm rõ nguồn/quyền/phạm vi trước khi sử dụng.
- **Hai quyết định khác nhau:** cho phép công việc/chuyến đi và phê duyệt tài chính của khoản ứng. Một người có thể có quyền cho cả hai; chưa bắt buộc hai lượt thao tác, nhưng phải ghi rõ nội dung/phạm vi mỗi quyết định. Phê duyệt không chứng minh đã chi/nhận tiền.
- **Hai chiều độc lập:** form/nhập hồ sơ là cách cung cấp dữ liệu; đã cho phép/chưa cho phép là trạng thái có căn cứ. Không mặc định form là chưa duyệt, upload là đã duyệt, hoặc lời khai “đã duyệt” đủ để bỏ kiểm tra.
- **Giữ giới hạn:** không cho phép AI tự quyết định mục đích công tác hay tự giải ngân. Quyết định này chưa thêm đặt vé, quản lý lịch, dịch vụ HR/ERP, nhiều tầng duyệt hoặc auth doanh nghiệp.
- **Giới hạn bằng chứng:** chọn phạm vi không chứng minh xin phép là điểm nghẽn chính hay hệ thống giảm được thời gian. Kết luận và giới hạn của research vẫn giữ; cần thử nghiệm/đo phù hợp.
- **Chưa chốt:** vai/quyền, nội dung căn cứ cần có, hiệu lực và thay đổi phạm vi, điều kiện hoàn thành từng bước, nguồn tiền, field và chính sách cụ thể.
- **Điểm tiếp theo:** xác định người thực hiện và đầu vào/đầu ra của đề xuất công tác kèm tạm ứng; phân biệt người xác nhận dữ kiện, người cho phép công tác và người duyệt tài chính.

### Bản thảo workflow có các nhánh xử lý để review

Theo yêu cầu sơ đồ đủ rõ để hiểu cả lỗi hồ sơ và người duyệt từ chối, đã lập [workflow công tác, tạm ứng và quyết toán](discovery/ADVANCE_SETTLEMENT_WORKFLOW_DRAFT.md). Bản thảo chia ba sơ đồ liên kết, có trả lại/sửa/từ chối, ba loại chuyển tiếp, lỗi kỹ thuật, chi/thu thất bại hoặc chưa rõ, import hồ sơ đã chi và điều kiện can thiệp. Đây là **BẢN THẢO LOGIC**, không phải implementation hay spec đã đóng; các giả định/điểm chưa chốt được ghi trong tài liệu. Việc vẽ trước giúp chủ dự án hiểu và chất vấn nghiệp vụ, không chuyển sang coding hoặc hoàn tất mọi phần R6/R7.

### R1 — Hồ sơ sau chi và nguồn tiền hỗn hợp: đang làm rõ

Chủ dự án đồng ý hướng xem xét cả hồ sơ có ứng, tự chi không ứng và nguồn tiền hỗn hợp, nhưng yêu cầu làm rõ trước khi chốt toàn bộ hướng. Sau ví dụ đối chiếu, đã đồng ý **cách nhìn đầy đủ của báo cáo** tại R1-DEC-04. Quyết định đầu ra không tự đóng mọi nhánh tiếp nhận/nguồn/quy tắc. Sơ đồ tổng quan hiện thể hiện rõ đường có ứng; đường nộp hồ sơ sau chi không ứng cần xác định riêng, không nối nó từ nút từ chối cấp ứng.

Khuyến nghị đang đề xuất: một hồ sơ sau chi gắn công việc và người chịu trách nhiệm, gồm nhiều khoản chi với nguồn thanh toán/ứng có căn cứ. Ba tình huống không phải ba mode loại trừ nhau; cùng hồ sơ có thể có tiền ứng, khoản công ty trả trực tiếp và phần nhân viên tự bù.

Phân biệt người thực hiện thanh toán với nguồn tiền: nhân viên thanh toán 5 triệu có thể dùng 2 triệu ứng và 3 triệu tự bù. Khi xác định tiền còn cần chi/thu, không coi toàn bộ 5 triệu là tiền riêng cần hoàn thêm, cũng không bỏ chi phí chỉ vì dùng tiền ứng.

Ví dụ giả lập: vé máy bay 3 triệu công ty trả trực tiếp; khách sạn 3 triệu, ăn phục vụ công việc 1 triệu, di chuyển 1 triệu do nhân viên thanh toán; ứng thực nhận/phân bổ 2 triệu. Giả định tất cả khoản đều đủ điều kiện, mọi nguồn đã xác minh và chưa có quyết toán/chi trả bổ sung/hoàn tiền trước đó. Chi phí đã xác minh trong hồ sơ 8 triệu; phần nhân viên thanh toán 5 triệu, gồm ứng 2 triệu và tự bù 3 triệu; đề xuất công ty trả thêm 3 triệu. Nếu xác minh không có ứng thì đề xuất trả thêm 5 triệu; nếu thực nhận ứng 7 triệu cho cùng phần chi 5 triệu thì đề xuất nhân viên hoàn 2 triệu. Các kết quả là đề xuất theo giả định, không phải phê duyệt tài chính hay công thức tổng quát cho mọi lịch sử.

Điểm cần làm rõ tiếp: nguồn nào nhân viên cung cấp và nguồn nào người phụ trách tài chính cung cấp/xác nhận. Không mặc định app biết toàn bộ chi phí chuyến đi hoặc lịch sử công ty, không coi “không tìm thấy ứng” trong nguồn thiếu là ứng bằng 0.

### R1-DEC-04 — Báo cáo sau chi có khoản chi, nguồn tiền và chênh lệch đầy đủ trong phạm vi

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ HƯỚNG ĐẦU RA** · Liên quan D01 và D07, chưa đóng toàn bộ các quyết định này.

- **Căn cứ chốt:** chủ dự án trả lời “Tôi đồng ý với đề xuất cách nhìn đầy đủ” sau đề xuất hiển thị chi phí đã kiểm tra, nguồn tiền và kết quả chi/thu còn lại thay vì chỉ danh sách khoản nhân viên đề nghị hoàn.
- **Lựa chọn:** báo cáo có các khoản đã kiểm tra và căn cứ/trạng thái của chúng; phần công ty trả trực tiếp, tiền ứng thực nhận/phân bổ và phần nhân viên thanh toán; chi/thu đã có liên quan; chênh lệch đề xuất và các vấn đề chưa giải quyết.
- **Phạm vi đầy đủ:** đầy đủ bối cảnh cần để kiểm tra kết quả trong dữ liệu/phạm vi đã công bố, không khẳng định biết toàn bộ chi phí công việc hoặc lịch sử công ty khi chưa có nguồn.
- **Giữ khác biệt:** chi phí đủ điều kiện theo policy, người thực hiện thanh toán, nguồn tiền và số còn cần chi/thu là các dữ kiện/kết quả khác nhau. Chi phí công ty trả trực tiếp không tự thành tiền hoàn cho nhân viên; tiền ứng không được tính thêm lần nữa.
- **Khi thiếu căn cứ:** hiển thị phần đã xác minh và phần chưa rõ, giữ kết quả cuối chưa xác định khi vướng mắc ảnh hưởng nó. Không đoán hoặc dùng thiếu-as-zero để tạo tổng.
- **Chưa chốt:** loại hồ sơ sau chi trong từng phạm vi, nguồn/độ bao phủ/cách liên kết, người xác nhận, công thức tổng quát/lịch sử, layout hoặc implementation. Phê duyệt tài chính vẫn thuộc con người.
- **Điểm tiếp theo:** lập bảng dữ kiện cần cho báo cáo, nguồn ứng viên và người có thể cung cấp/xác nhận; dùng một hồ sơ giả lập để thử xem có đủ căn cứ đi đến kết quả không.

### Đang làm rõ — Căn cứ tiền tạm ứng thực nhận

Trạng thái: **NGUYÊN TẮC NGUỒN CHÍNH ĐÃ CHỐT TẠI R1-DEC-05; CHI TIẾT ĐỐI CHIẾU CHƯA CHỐT RULEBOOK**. Việc đồng ý nguồn chính chưa đóng toàn bộ các điều kiện/field/mẫu/phạm vi bên dưới.

Phân biệt số đề nghị, số được duyệt, số đã thực nhận và số đã hoàn/thu hồi. Ghi từng sự kiện thực tế gắn đúng người, khoản ứng/công việc và thời điểm đối chiếu. Khoản hoàn lại cần giữ riêng, không vừa giảm số đã nhận vừa trừ lần nữa khi quyết toán.

| Thông tin cần biết | Nguồn ứng viên và giới hạn |
| --- | --- |
| Xin ứng bao nhiêu? | Form/giấy đề nghị; là số đề nghị, chưa chứng minh đã nhận. |
| Được duyệt bao nhiêu, cho ai/công việc nào? | Quyết định phê duyệt đủ căn cứ theo phạm vi; chưa chứng minh đã chuyển/nhận. |
| Đã nhận bao nhiêu? | Nguồn thanh toán/chi tiền có liên kết đúng hồ sơ, trạng thái và thời điểm; bản ghi do tài chính ghi nhận/đối chiếu kèm căn cứ; chứng từ nhận tiền phù hợp nếu chi tiền mặt. Không coi việc mới lập phiếu chi là đã chi. |
| Có chi khác, đang xử lý, bị trả lại hay đã hoàn chưa? | Lịch sử chi/thu trong phạm vi đủ để sử dụng. Không tìm thấy trong nguồn thiếu không chứng minh không có. |

Đề xuất bản ghi ứng thực tế tối thiểu cần biết người nhận, khoản ứng/công việc, số tiền/tiền tệ, ngày và tham chiếu giao dịch/chứng từ, trạng thái thực tế, nguồn/người ghi nhận và phạm vi/thời điểm đối chiếu. Không bắt buộc tất cả nguồn thực tế có sẵn đúng tên field; thiếu liên kết quan trọng phải làm rõ, không chỉ match số tiền.

Ví dụ giả lập: đề nghị và duyệt 5 triệu; hai khoản thực nhận đã xác minh 2 triệu + 1 triệu cho cùng hồ sơ = 3 triệu. Nếu tài chính xác nhận phạm vi đã đầy đủ và không còn khoản ứng chờ chi/chi khác/hoàn tiền liên quan, chi phí do nhân viên thanh toán đủ điều kiện 4 triệu dẫn tới đề xuất công ty trả thêm 1 triệu. Nếu 2 triệu còn lại vẫn đang chuyển/chờ xử lý, vẫn ghi phần 3 triệu đã xác minh nhưng chưa chốt quyết toán cuối trước khi làm rõ; không chi thêm dựa trên phép trừ tạm thời rồi bỏ qua khoản đang xử lý.

Căn cứ research tham khảo: [quy trình Đồng Tháp năm 2024](https://cmsweb.dthu.edu.vn/Uploads/Files/aa873084-ecdf-4ce4-980a-f9077a05d9f3.pdf) tách phê duyệt, lập thủ tục chi và lưu chứng từ chuyển thành công; [UW Payment Tracking](https://finance.uw.edu/travel/WDpaymentoptions) cảnh báo trạng thái Paid/Reconciled có thể vẫn xuất hiện khi thanh toán bị trả lại, nên không tự chứng minh tiền vào tài khoản. Đây là ví dụ kiểm soát tại từng tổ chức, không phải quy định áp dụng mặc định cho doanh nghiệp Việt Nam.

Khuyến nghị MVP: dữ liệu tài chính do người phụ trách cung cấp/đối chiếu hoặc import, giữ căn cứ, nguồn và độ bao phủ. Nhân viên có thể cung cấp bằng chứng để đối chiếu; không loại bằng chứng chỉ vì người nộp là nhân viên, cũng không xem lời khai đã nhận hoặc vai người nhập là xác minh tự động. AI đọc/liên kết có nguồn, chương trình tính trên các khoản đủ căn cứ; thiếu/mâu thuẫn hỏi người có nguồn. Khi nguồn đã đủ theo hợp đồng, không thêm một lượt xác nhận thủ công chỉ để làm yên tâm.

### R1-DEC-05 — Nguồn chính cho tiền ứng thực nhận

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ NGUYÊN TẮC NGUỒN** · Liên quan D04, chưa đóng toàn bộ D04.

- **Căn cứ chốt:** chủ dự án trả lời “Đồng ý hãy tiếp tục đi” cho đề xuất lấy bản ghi tài chính đã đối chiếu, kèm căn cứ, làm nguồn chính cho tiền ứng thực nhận trong MVP.
- **Lựa chọn:** sử dụng bản ghi do người phụ trách tài chính cung cấp/đối chiếu cùng chứng cứ và phạm vi liên quan. Giữ số đề nghị/duyệt/nhận/hoàn khác nhau; nhân viên vẫn có thể cung cấp bằng chứng để đối chiếu.
- **Điều kiện không được bỏ:** nguồn phải liên kết đúng người và khoản ứng/công việc, trạng thái/thời điểm/độ bao phủ đủ cho kết luận. “Do kế toán nhập” không tự làm dữ kiện đúng; mâu thuẫn vẫn phải được giải quyết.
- **Chưa chốt:** schema, cách import, mẫu chứng từ, mức đủ căn cứ, vai/quyền xác nhận và mọi tình huống trả lại/chi một phần/tiền chờ xử lý. Không tự yêu cầu nhân viên xác nhận lại khi nguồn đã đủ, cũng không chốt tiền từ phê duyệt đơn thuần.
- **Điểm tiếp theo:** liên kết khoản công ty trả trực tiếp với đúng khoản chi/chứng từ và số tiền được bao phủ; phân biệt đó với tiền ứng và tiền đã hoàn trả cho nhân viên.

### Đang làm rõ — Khoản công ty trả trực tiếp và phần được đối chiếu

Trạng thái: **NGUYÊN TẮC ĐỐI CHIẾU TỪNG PHẦN ĐÃ CHỐT TẠI R1-DEC-06; CHI TIẾT QUY TẮC/PHẠM VI CÒN MỞ**.

Đề xuất không gắn một nhãn “công ty trả” cho toàn hồ sơ hoặc mặc định cả hóa đơn đã được công ty thanh toán. Cần liên kết giao dịch với khoản chi/chứng từ và số tiền bao phủ, giữ trạng thái, nguồn, thời điểm và chi/thu/hoàn tiền liên quan. Tổng bằng nhau không tự chứng minh các giao dịch đúng khoản. Bằng chứng công ty đã trả một khoản không tự chứng minh nhân viên chưa từng thanh toán khoản đó nữa.

Ví dụ giả lập: hóa đơn khách sạn 5 triệu, công ty trả trực tiếp 2 triệu, nhân viên thanh toán 3 triệu; ứng thực nhận/phân bổ 1 triệu. Mọi liên kết/nguồn và điều kiện khoản chi đã xác minh, không có hoàn tiền, khoản chi trả khác hoặc giao dịch chờ ảnh hưởng kết quả. Chi phí đủ điều kiện 5 triệu; đề xuất công ty trả thêm 2 triệu cho nhân viên (3 triệu nhân viên thanh toán trừ 1 triệu ứng). Không trả thêm 4 triệu bằng cách lấy 5 trừ ứng mà bỏ công ty đã trả 2; cũng không coi cả hóa đơn là công ty trả rồi bỏ phần 3 triệu.

Chia nguồn thanh toán của một hóa đơn khác với cho phép chi quyết toán từng phần khi còn vướng mắc. Nếu chỉ biết công ty trả 2 triệu, không tự suy nhân viên đã trả 3 triệu còn lại: cần căn cứ cho phần còn lại hoặc giữ chưa xác định. Nếu cả công ty và nhân viên đều có bằng chứng trả toàn bộ 5 triệu cho cùng nghĩa vụ, phải làm rõ khả năng trả trùng, nhầm liên kết hoặc hoàn tiền; không tự kết luận gian lận, không chốt phần được hoàn.

Căn cứ tham khảo: [University of Colorado — Travel](https://www.cu.edu/psc-procedural-statement-travel), mục Lodging/Deposit và Receipt Requirements, yêu cầu ghi rõ tiền đặt cọc trả trực tiếp cho nhà cung cấp, chứng từ thể hiện đặt cọc/số dư và phân biệt chứng từ chi phí với bằng chứng thanh toán. Đây là ví dụ quy trình tổ chức, không sao chép mức tiền hoặc điều khoản thành chính sách công ty.

Đề xuất báo cáo hiển thị khoản chi, giá trị chứng từ, phần công ty trả trực tiếp đã xác minh, phần nhân viên thanh toán đã xác minh, phần còn chưa rõ và nguồn tương ứng. Không coi tên công ty trên hóa đơn là bằng chứng công ty đã thanh toán. AI đề xuất liên kết có nguồn; kiểm tra số tiền/phạm vi bằng chương trình, liên kết chưa đủ rõ hỏi người sở hữu nguồn.

### R1-DEC-06 — Đối chiếu phần tiền theo từng khoản chi

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ NGUYÊN TẮC ĐỐI CHIẾU** · Liên quan D04 và D05, chưa đóng toàn bộ các quyết định này.

- **Căn cứ chốt:** chủ dự án trả lời “Đồng ý tiếp tục đi” cho đề xuất theo dõi phần tiền đã thanh toán của từng khoản chi, thay vì một nhãn công ty/nhân viên trả cho cả hóa đơn.
- **Lựa chọn:** liên kết nguồn thanh toán với khoản chi/chứng từ và số tiền tương ứng. Một khoản có thể gồm phần công ty trả trực tiếp, phần nhân viên thanh toán và phần chưa xác định; không suy phần còn lại là nhân viên trả chỉ vì tổng trừ ra còn số đó.
- **Giữ giới hạn:** nguồn phải đủ căn cứ; tổng trùng số tiền không chứng minh cùng khoản, tiền đã chi không chứng minh chưa hoàn lại. Phân chia nguồn chi trả không tự cho phép giải ngân/quyết toán từng phần khi hồ sơ còn vướng mắc.
- **Chưa chốt:** model phân bổ, liên kết nhiều giao dịch/hóa đơn, ngưỡng khớp, nguồn chứng minh nhân viên trả, cách xử lý hoàn tiền/chi trùng, quy tắc và phạm vi cụ thể.
- **Điểm tiếp theo:** phân biệt chứng từ xuất hiện lại với khoản đề nghị thanh toán trùng; xét lịch sử công ty đã hoàn trả cho nhân viên trước khi tính số còn lại.

### Đang làm rõ — Lịch sử hoàn trả và thanh toán trùng

Trạng thái: **NGUYÊN TẮC CHỐNG TRÙNG ĐÃ CHỐT TẠI R1-DEC-07; CHI TIẾT CÒN MỞ TRƯỚC RULEBOOK**.

Đề xuất tách trùng file, cùng chứng từ xuất hiện ở nhiều nguồn/hồ sơ và cùng phần nghĩa vụ bị yêu cầu chi lại. Cùng hóa đơn được dùng để đối chiếu tiền đặt cọc của công ty và phần nhân viên thanh toán không tự là thanh toán trùng. Quy tắc chống trùng phải xét khoản/phần tiền, lịch sử và nguồn liên quan, không chỉ việc đã thấy ảnh hay số hóa đơn.

Ví dụ tiếp nối: hóa đơn 5 triệu, công ty trả trực tiếp 2 triệu, nhân viên thanh toán 3 triệu, ứng thực nhận 1 triệu; tất cả đủ căn cứ và điều kiện, không có hoàn tiền/khoản chờ khác. Nếu chưa có hoàn trả trước đó thì đề xuất công ty trả thêm 2 triệu. Nếu xác minh đã hoàn trả đúng phần này 2 triệu cho nhân viên thì số còn cần chi là 0; nếu đã trả 1 triệu thì còn 1 triệu. Không coi sự kiện từng chi một phần là quyền tự cho phép một lần chi mới từng phần.

Tạm ứng, công ty trả nhà cung cấp và hoàn trả cho nhân viên là các mục đích khác nhau; một giao dịch không được vừa tính vào ứng vừa tính vào hoàn trả. Dữ liệu chưa đủ liên kết/mục đích/phạm vi lịch sử hoặc trạng thái giao dịch còn mâu thuẫn thì giữ kết quả chưa xác định. Chứng cứ gửi lệnh/duyệt chưa là đã trả thành công.

Căn cứ tham khảo: [UW Reimbursement System Approvals](https://finance.uw.edu/travel/reimbursementsystemapprovals), vai Compliance Approver, yêu cầu kiểm tra chi phí chưa được hoàn trả trước ở expense report hoặc payment module khác. Đây là kiểm soát tại một tổ chức, không chứng minh MVP đã có lịch sử đầy đủ hay cơ chế chống trùng.

Khuyến nghị: khi đã xác minh phần đang đề nghị được thanh toán đủ, báo rõ không có khoản cần trả thêm cho phần đó, kèm nguồn và lịch sử; không gọi cả hồ sơ gian lận. Nếu còn phần hợp lệ chưa được xử lý hoặc có lý do xuất hiện lại, xét phần còn lại theo policy. Trường hợp lịch sử thiếu hoặc khớp chưa rõ phải hỏi, không dùng “không tìm thấy” để kết luận chưa được trả.

### R1-DEC-07 — Chống thanh toán trùng theo phần nghĩa vụ và lịch sử có căn cứ

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ NGUYÊN TẮC** · Liên quan D04, D05 và D07, chưa đóng toàn bộ các quyết định này.

- **Căn cứ chốt:** chủ dự án trả lời “Tôi đồng ý tiếp tục” cho đề xuất chống thanh toán trùng theo phần tiền còn phải xử lý và lịch sử có căn cứ, không từ chối chỉ vì hóa đơn đã xuất hiện.
- **Lựa chọn:** phân biệt trùng file/chứng từ xuất hiện lại với yêu cầu chi lại cho cùng phần nghĩa vụ đã xử lý. Tính tiền còn lại có xét ứng, chi trực tiếp, hoàn trả và chi/thu liên quan trong phạm vi được xác minh.
- **Giữ giới hạn:** nguồn thiếu/khớp chưa rõ không chứng minh chưa trả hoặc đã trả; không tự gọi gian lận, không từ chối cả hồ sơ chỉ từ chứng từ lặp. Một giao dịch không được tính vào nhiều mục đích để đối trừ hai lần.
- **Chưa chốt:** tiêu chí định danh/liên kết, phân bổ giữa hồ sơ, độ bao phủ và nguồn lịch sử, các ngoại lệ và quy tắc xử lý cụ thể.
- **Điểm tiếp theo:** căn cứ cho phần nhân viên thanh toán, gồm chuyển khoản/thẻ và tiền mặt; mức bằng chứng theo policy, không chỉ lời khai hay ngân hàng bắt buộc cho mọi khoản.

### Đang làm rõ — Căn cứ nhân viên đã thanh toán

Trạng thái: **NGUYÊN TẮC BẰNG CHỨNG PHÙ HỢP ĐÃ CHỐT TẠI R1-DEC-08; NGUỒN TỐI THIỂU/RULEBOOK CÒN MỞ**.

Tách ba câu hỏi: khoản chi là gì/bao nhiêu; đã thanh toán bao nhiêu; ai thực hiện và nguồn tiền nào. Một tài liệu có thể hỗ trợ nhiều câu hỏi nếu đủ thông tin. Hóa đơn chỉ thể hiện giá trị hoặc tên công ty mua hàng không tự chứng minh đã trả hay tiền là của nhân viên. Nhân viên thanh toán bằng tiền ứng vẫn là nguồn tiền công ty đã cấp cần đối trừ.

Đề xuất kiểm tra chứng từ có nội dung, dấu vết thanh toán/phương thức khi cần, khai báo có phạm vi và nguồn tài chính liên quan. Nếu cần và có, dùng biên lai, giao dịch ngân hàng/thẻ hay bằng chứng phù hợp để liên kết đúng khoản. Tiền mặt không có giao dịch ngân hàng tương ứng không tự là lý do từ chối; nhưng thiếu/mờ/mâu thuẫn dữ kiện bắt buộc vẫn phải được làm rõ. Không gắn trạng thái xác minh độc lập cho dữ kiện chỉ dựa vào lời khai.

Nguồn tham khảo: [Cornell Required Documentation](https://finance.cornell.edu/travel/expense-reporting/documentation), Proof of Payment, chấp nhận biên lai, sao kê hoặc chứng từ khác với thông tin thanh toán phù hợp; [Colorado Receipt Management](https://www.cu.edu/psc/travel/during-travel/receipt-management) phân biệt chứng từ chi tiết, dấu vết thanh toán và mục đích công việc. Các trường có yêu cầu riêng theo khoản/điều kiện; không sao chép ngưỡng tiền hay việc miễn chứng từ thành policy MVP.

Khuyến nghị: chốt nguồn tối thiểu theo loại khoản và phương thức thanh toán ở R4. Đủ theo điều kiện đã công bố thì xử lý thường quy; thiếu điều kiện thì hỏi đúng người hoặc chuyển tiếp. Không yêu cầu mọi bill có sao kê chỉ để làm yên tâm, không tự miễn bằng chứng bắt buộc hoặc coi thiếu sao kê là đủ chứng minh nhân viên tự trả.

### R1-DEC-08 — Bằng chứng thanh toán phù hợp theo quy định

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ NGUYÊN TẮC** · Liên quan D04 và D06, chưa đóng toàn bộ các quyết định này.

- **Căn cứ chốt:** chủ dự án trả lời “Đồng ý tiếp tục đi” cho đề xuất chấp nhận bằng chứng phù hợp theo quy định, không chỉ tin hóa đơn hoặc bắt mọi hóa đơn kèm sao kê.
- **Lựa chọn:** đánh giá nguồn theo loại khoản/phương thức và điều kiện đã công bố. Một tài liệu có thể đáp ứng nhiều vai trò nếu đủ thông tin; không mặc định hóa đơn chứng minh người trả hoặc thiếu sao kê là hồ sơ sai.
- **Giữ giới hạn:** thiếu/mờ/mâu thuẫn dữ kiện bắt buộc phải được làm rõ. Không tự miễn bằng chứng hoặc biến lời khai thành xác minh độc lập. Người thực hiện thanh toán khác nguồn tiền; ứng/thẻ công ty vẫn cần đối trừ/xử lý phù hợp.
- **Chưa chốt:** danh sách nguồn tối thiểu, chấp nhận khai báo/xác nhận ở mức nào, phân loại khoản, ngưỡng/ngoại lệ và người có quyền quyết định. Các điều kiện này thuộc R4, không trở thành policy hoạt động chỉ vì chốt nguyên tắc.

### Tổng hợp R1 để chuyển sang R2

Đã thống nhất hướng: hỗ trợ trước và sau công việc; form chính/nhập hồ sơ; xin phép trong app hoặc dùng căn cứ bên ngoài; con người giữ quyết định tài chính/chi thu; hệ thống chuẩn bị báo cáo có căn cứ và câu hỏi; báo cáo giữ đủ bối cảnh khoản chi, nguồn tiền, lịch sử và chênh lệch trong phạm vi; không suy thiếu-as-zero hoặc trùng file là thanh toán trùng.

**Phạm vi sau chi đã chốt tại R1-DEC-09:** tiếp nhận nhân viên tự chi không nhận ứng bằng cùng lõi hồ sơ quyết toán/hoàn trả chi phí. Số ứng là 0 khi xác nhận không có, không tạo khoản ứng giả. Hồ sơ này nộp trực tiếp vào phần sau chi, không đi từ nút từ chối cấp ứng.

Sau khi chốt điểm trên, R2 đi bằng tay một hồ sơ giả lập: người nào gửi dữ kiện ở bước nào, tài liệu/nguồn nào có, kết quả kiểm tra/chênh lệch kỳ vọng và vướng mắc nào cần hỏi. Sau đó biến thể không ứng, công ty trả trực tiếp và một ngoại lệ. Đây là walkthrough nghiệp vụ, chưa phải chạy code hay corpus đã verified. Source contracts, tham số policy, metric và schema chi tiết vẫn dành cho R4–R7.

### Dùng chung hồ sơ sau chi khi không có tạm ứng — nguyên tắc đã chốt

Chủ dự án đề xuất và đã đồng ý tại R1-DEC-09 xem hồ sơ nhân viên tự chi như hồ sơ sau chi có tiền ứng bằng 0 khi xác nhận không có. Dùng chung lõi đối chiếu/quyết toán; không tạo khoản ứng giả hay yêu cầu qua luồng xin ứng trước đó. Chi tiết nguồn, field và policy còn phải thiết kế.

Phải phân biệt: không nhận ứng đã xác nhận (0); chưa biết có/bao nhiêu ứng (chưa xác định); từng nhận ứng rồi đã hoàn/được xử lý nên số dư còn lại bằng 0 (giữ sự kiện lịch sử, không coi chưa từng nhận). Lời khai/ô mặc định 0 không tự chứng minh ứng thực nhận bằng 0; số dư hiện tại không tự là tổng thực nhận của phạm vi đang quyết toán.

Đề xuất tên chung cho sản phẩm: “Hồ sơ quyết toán / hoàn trả chi phí”. Trường hợp có ứng hiển thị quyết toán tạm ứng; không ứng hiển thị đề nghị hoàn trả chi phí. Đây là đề xuất cách diễn đạt, không quy định tên chứng từ pháp lý. Không ứng vẫn kiểm tra công việc/quy định, công ty trả trực tiếp, phần nhân viên thanh toán và lịch sử; không mặc định tổng hóa đơn là số phải trả cho nhân viên.

Ví dụ giả lập: chi phí đủ điều kiện do nhân viên thanh toán 3 triệu, xác nhận không ứng, chưa được hoàn trả và không có khoản/giao dịch khác ảnh hưởng thì đề xuất công ty trả thêm 3 triệu. Nếu tiền ứng chưa rõ thì chưa chốt. Hồ sơ không ứng nộp trực tiếp vào phần sau chi, không đi từ nút từ chối và không bắt đính kèm giấy đề nghị ứng không tồn tại. Chi tiết intake/trạng thái/schema vẫn cần chốt ở các bước tiếp theo.

### R1-DEC-09 — Dùng chung hồ sơ sau chi, ứng bằng 0 khi xác nhận không có

Ngày: 08/10/2026 · Trạng thái: **ĐÃ CHỐT VỀ PHẠM VI VÀ LÕI XỬ LÝ** · Chi tiết còn mở cho R2–R7.

- **Căn cứ chốt:** chủ dự án đề xuất hồ sơ tự chi là hồ sơ sau chi với tạm ứng 0, sau giải thích trả lời “Đồng ý tiếp tục đi”.
- **Lựa chọn:** cùng lõi quyết toán/hoàn trả chi phí cho có ứng, không ứng và nguồn hỗn hợp. Không ứng nộp trực tiếp, không cần đơn ứng/ID khoản ứng giả hoặc chờ từng đi qua xin ứng.
- **Giữ khác biệt:** ứng 0 đã xác nhận, ứng chưa xác định và từng nhận ứng nhưng số dư hiện tại 0 là các tình huống khác nhau; giữ lịch sử chi/thu, không đối trừ hai lần.
- **Giữ kiểm tra:** không ứng vẫn kiểm tra nguồn thanh toán, công ty trả trực tiếp, lịch sử đã xử lý, mục đích/quy định và quyền; không mặc định tổng hóa đơn là tiền phải hoàn.
- **Tên hiển thị đề xuất:** quyết toán tạm ứng khi có ứng; đề nghị hoàn trả chi phí khi không ứng. Tên chứng từ cụ thể theo quy trình/policy sẽ chốt sau.

### R2 — Walkthrough đầu tiên

[Hồ sơ công tác giả lập](discovery/R2_CASE_WALKTHROUGH.md) dùng để đi bằng tay qua các vai, đầu vào, kiểm tra, kết quả và các biến thể. Đây là dữ liệu giả lập để hiểu nghiệp vụ; chưa là hiện trạng doanh nghiệp đã quan sát, bộ test thực thi hoặc chính sách đã kích hoạt.

Chủ dự án yêu cầu [review độc lập bước 1](reviews/2026-10-08-step-1-design/REVIEW.md) bằng GPT 5.6 Sol Web — High, đã nhận verdict Cần chỉnh sửa của reviewer/lead và đồng ý hướng chỉnh để sang bước 2. Walkthrough bước 1 đã bổ sung điều kiện đủ để xét, bốn nghĩa tiền và hành vi với xung đột/nộp lại; snapshot bản được review giữ trong thư mục review.

Sau [review độc lập bước 2](reviews/2026-10-08-step-2-design/REVIEW.md) với cùng model/mức, chủ dự án đồng ý hướng chỉnh và chuyển bước tiếp theo. Bước 2 đã tách bổ sung khỏi cho phép có điều kiện, làm rõ kiểm tra bản sửa/phạm vi/hiệu lực/quyền, context người duyệt và giữ nghĩa tiền. Snapshot và verdict review bản gốc vẫn giữ; chưa có review độc lập xác nhận bản đã chỉnh.

Sau [review độc lập bước 3](reviews/2026-10-08-step-3-design/REVIEW.md) với cùng model/mức, chủ dự án đồng ý hướng chỉnh và yêu cầu chuyển Bước 4. Bước 3 đã bổ sung bảng quan hệ đề nghị/trạng thái tiền/hành động, tách các nguyên nhân và làm rõ điều kiện đủ căn cứ, bổ sung/sửa/kiểm tra lại, lỗi nguồn vs lỗi xử lý và giới hạn phiên bản/dữ liệu. Snapshot/verdict bản gốc giữ nguyên; chưa có review độc lập xác nhận bản chỉnh.

Sau [review độc lập bước 4](reviews/2026-10-08-step-4-design/REVIEW.md), chủ dự án đồng ý hướng chỉnh và yêu cầu viết/review Bước 5. Bước 4 đã làm rõ việc xét kết thúc khi duyệt thấp hơn số xin, nguồn/cách xác nhận điều kiện, kiểm tra số đề xuất trước khi đủ để chi, tiền đã chi/chờ và quyết định thay thế/xung đột. Snapshot/verdict gốc giữ nguyên; chưa có review độc lập xác nhận bản chỉnh.

**Bước 5 đã được chủ dự án duyệt** sau [review bước 5](reviews/2026-10-08-step-5-design/REVIEW.md). Walkthrough đã bổ sung ba nghĩa hoàn/đảo/sửa fact, các nghĩa tiền, gói bàn giao, phạm vi nhận diện giao dịch và thay đổi nguồn sau báo cáo; snapshot/verdict gốc giữ nguyên, chưa review độc lập lại bản chỉnh. **Bước 6 đang thảo luận** về nhân viên nộp hồ sơ sau chi, tách lời khai/chứng từ khỏi nguồn tài chính và điều kiện bắt đầu đối chiếu. Các bước sau dự kiến: 7 đối chiếu/tính kết quả, 8 quyết định tài chính, 9 chi/thu thực tế/đóng khi đủ căn cứ. Nguồn/quy tắc/ngưỡng/quyền chi tiết còn ở R4; chưa thực hiện code hoặc xác nhận BTC chấp nhận boundary tự động hóa đã đề xuất.

[Review Bước 6](reviews/2026-10-08-step-6-design/REVIEW.md) bằng GPT 5.6 Sol Web — High đã hoàn thành; reviewer/lead đều kết luận **Cần chỉnh sửa**. Chủ dự án đồng ý hướng chỉnh và cho chuyển B7. B6 đã bổ sung dependency từng kiểm tra, quan hệ khoản/tài liệu/dòng trích, phạm vi phần tiền, tiếp nhận lại sau chi, loại xác nhận, chiều chi/thu và reuse. Snapshot/verdict gốc giữ nguyên, chưa review độc lập lại bản chỉnh. **Bước 7 đang viết/review** về đối chiếu, phần tiền đủ điều kiện, lịch sử cùng phạm vi và kết quả chi/thu có căn cứ; chưa chốt nguồn/policy/schema hoặc triển khai code.

[Review Bước 7](reviews/2026-10-08-step-7-design/REVIEW.md) với GPT 5.6 Sol Web — High đã hoàn thành; reviewer/lead đều kết luận **Cần chỉnh sửa**. Các điểm chính: người nhận/quyền của vendor refund, giới hạn S với nghĩa vụ company-paid recovery, thực nhận mỗi chiều, eligible partial amount theo rule rõ. Lead bổ sung chống phân bổ một event vào hai nhóm và phân biệt payer split/double payment. B7 và snapshot giữ nguyên trong review; đang chờ chủ dự án chốt hướng chỉnh trước B8. Sáu ví dụ số đã kiểm tra arithmetic integer VND, không là runtime/Verify evidence.

Ngày 09/10, sau khi chủ dự án hỏi về độ phức tạp và yêu cầu đề xuất sửa B7, lead viết [bản B7 MVP thu gọn](discovery/B7_MVP_PROPOSAL.md) riêng, giữ walkthrough cũ. [Review bản thu gọn](reviews/2026-10-09-step-7-mvp/REVIEW.md) bằng GPT 5.6 Sol Web — High đã hoàn thành; reviewer yêu cầu rõ source-coverage zero, refund thuộc employee portion và gate toàn nghĩa vụ trong cùng boundary. Proposal đã bổ sung các guard và giữ gross history/công thức net rõ; lead đề nghị chốt ở mức MVP, chưa review độc lập lại bản chỉnh hoặc được chủ dự án duyệt thay bản chính. Ngoại lệ cross-recipient/recovery cần chuyển xử lý có căn cứ, không tự mở rộng thành kế toán tổng quát.

Chủ dự án đồng ý B7 thu gọn và yêu cầu làm B8/B9 cùng lúc để review. B7 đã tích hợp vào walkthrough, giữ các snapshot/review gốc. [B8/B9 proposal](discovery/B8_B9_MVP_PROPOSAL.md) đang viết/review theo hai scope riêng: B8 quyết định/hiệu lực; B9 thực hiện/đối chiếu/đóng. Lead giữ một writer cho điểm nối. Chưa chốt B8/B9, policy/schema hoặc triển khai code.

[Review B8/B9](reviews/2026-10-09-step-8-9-design/REVIEW.md) bằng hai reviewer GPT 5.6 Sol Web — High đã hoàn thành, verdict gốc Cần chỉnh sửa. Proposal đã bổ sung phân biệt điều kiện fact/quyết định quyền, fullapproval vs chỉ dẫn thực hiện, overpayment vs wrongrecipient, trigger hỏi pending, stalehandoff và quyền sau refund. Lead đề nghị chốt khung walkthrough và gửi người dùng review; chưa được người dùng duyệt B8/B9 hoặc review độc lập lại bản bổ sung. Snapshot/trả lời gốc giữ nguyên; chưa code/Verify/live money.

Chủ dự án đã đồng ý B8 và B9. **Khung nghiệp vụ 9 bước đã chốt ở mức walkthrough giả lập của R2**; nguồn/quy tắc/quyền chi tiết và hiện trạng/impact với người thật chưa được xác minh. Không tự ghi R2 hoàn thành mọi bằng chứng chỉ từ việc duyệt khung. Điểm tiếp theo là **R3 — chốt phạm vi phát hành và đơn vị tự động hóa/đầu ra/ngoại lệ**; rồi R4 nguồn/rulebook, R5 gold/metric/gates, R6 chuẩn hóa workflow/state, R7 kiến trúc/spec, R8 đối chiếu code/plan, R9 triển khai/đánh giá/người thử/gói nộp. R6 dùng lại khung 9 bước, không mặc định review lại từ đầu. Các chặng thiết kế tiếp tục theo quy trình review độc lập đã thống nhất.

Chủ dự án yêu cầu bắt đầu R3. [Bản phạm vi R3](discovery/R3_MVP_SCOPE_DRAFT.md) đang được đề xuất/review độc lập GPT 5.6 Sol Web — High, lead ghi nhận xét riêng trước reviewer. Nội dung giữ cả hai workflow, phân công việc tự kiểm tra và checkpoint tài chính, phạm vi nguồn/chi và ngoại lệ, A kiểm tra trước B hành động sau gates. Chưa đóng R3 hoặc kích hoạt policy/spec/code; chủ dự án sẽ chốt các lựa chọn sau phần biện luận.

[Review R3](reviews/2026-10-09-r3-scope/REVIEW.md) đã hoàn thành; reviewer verdict gốc Cần chỉnh sửa. Draft bổ sung job nhận cả input thiếu, nguồn prep/human touches phải đo, matrix9steps A/B/manual và boundarymetric; đềxuất B7 primarydemo/eval, B3 supported/đo riêng. Lead đềnghị chốt phạmvi sau người dùng phảnbiện; chưa chốtR3, chưareviewlại bản bổsung hoặc córuntime/trial/compliance evidence.

Chủ dự án đồng ý ý kiến/phạm vi R3 đã trình bày: B7 là job đánh giá chính, giữ B3 trong MVP và đo riêng theo nhóm chi/VND/mỗi case một NV-công việc, baseline check/report trước requestactions B. **R3 đã chốt khung phạm vi để tiếp R4**; chưa chốt các source/policy/schema/quality threshold còn mở hoặc có xác nhận BTC/runtime/trial. [R4.1 dữ kiện và nguồn](discovery/R4_DATA_SOURCE_DRAFT.md) đang đề xuất/review; tiếp đó mới chốt rulebook/applicability/evidence và authority/quality cụ thể.

[Review R4.1](reviews/2026-10-09-r4-data-sources/REVIEW.md) với GPT 5.6 Sol Web — High hoàn thành, reviewer/lead cho Có thể chốt ở mức lõi dữ kiện. Draft bổ sung uploader/issuer/coverageowner, 3trục factquality/paymentstate/technicalstate và confirmationreading/fact/approval; lead thêm IDs nội bộ vs externalfacts. Đang chờ chủ dự án chốt R4.1; R4.2 tiếp theo mới định applicability/sourceacceptance/quality/authority/limits. Snapshot/trảlời gốc giữ nguyên, chưa reviewlại bản bổsung/code/runtime.

Chủ dự án yêu cầu tiếp R4.2. Lõi R4.1 được dùng làm căn cứ; [R4.2 applicability/evidence](discovery/R4_EVIDENCE_RULES_DRAFT.md) đang viết/review: hai profile trước/sau, đủ fact cho từng check, bộ payment/receipt theo phương thức, coverageabsence và confirmation. Cashreceipt + payerattestation là lựa chọn policy được đề xuất công khai, chưa active hoặc được chủ dự án chốt. Chưa đặt hạn mức, authorityamount, providerthreshold hoặc viết code.

[Review R4.2](reviews/2026-10-09-r4-evidence/REVIEW.md) đã hoàn thành bằng reviewer mới GPT 5.6 Sol Web — High sau streamdeliveryerrors ở agent trước; chỉ kết quả hoàn chỉnh được dùng. Draft bổ sung owner có observability đúng phía/loại/method/time và readingconfirmation chỉ khi retainedsource thực đọc được; lead giới hạn cashattest cho expense A→vendor, không actualfunds/approval. Reviewer verdict gốc Cần chỉnh sửa, lead đềnghị chốt mức proposedevidence saubổsung, cashpolicy vẫn chờ userchọn. Chưareviewlại/activate/code/test/trial.

### Cách đi từng bước — yêu cầu cũ từ Bước 6, đã được thay thế từ R4.3

Chủ dự án yêu cầu mỗi bước đang thiết kế đều được một subagent **GPT 5.6 Sol Web — High** review độc lập; lead tự review, đối chiếu/biện luận dựa trên chứng cứ rồi trình bày trước khi sang bước tiếp theo. Giữ snapshot của bản được review và nhận xét riêng của lead trước khi đọc kết quả reviewer; phân biệt kết luận reviewer với phán định lead. Không tự thay model/mức khi gặp lỗi, không dùng review thiết kế làm bằng chứng runtime và không sửa ngầm các điểm đang đề xuất chưa được chủ dự án chốt.

### Quyết định ngày 09/10 — Chốt R4.2 và đổi cách review từ R4.3

Chủ dự án đồng ý tiếp tục sau đề xuất bộ căn cứ tiền mặt: receipt thể hiện đã trả + attestation nhân viên có phạm vi + nguồn công ty đủ để đối chiếu, không còn mâu thuẫn. **R4.2 đã được đồng ý ở mức thiết kế MVP**, không phải chính sách công ty thật hay policy runtime đã kích hoạt. Giữ giới hạn chỉ cho expense payer; không dùng lời khai nhân viên đơn độc để chứng minh tiền ứng/hoàn trả đã nhận hoặc công ty đã nhận tiền trả lại.

Yêu cầu mới: **không cần dùng subagent review nữa**. Từ R4.3, lead tự kiểm tra, biện luận bằng ví dụ và căn cứ rồi trình bày cho chủ dự án. Quy trình này thay thế yêu cầu review subagent mỗi bước ở trên; giữ nguyên các snapshot và kết luận review lịch sử.

Điểm hiện tại: [R4.3 — Tính tiền, hạn mức và thẩm quyền](discovery/R4_MONEY_AUTHORITY_DRAFT.md) là đề xuất đang chờ thảo luận, chưa chốt hạn mức số tiền, chưa kích hoạt policy hoặc viết code. Ưu tiên làm rõ cách xử lý vượt hạn mức trước khi chọn các con số demo.

Chủ dự án đã đồng ý câu hỏi về hành vi **vượt hạn mức → người có quyền xem xét ngoại lệ**, không tự cắt xuống trần. Lead tiếp tục viết [bảng tham số demo R4.3](discovery/R4_DEMO_POLICY_PARAMETERS_DRAFT.md): nhóm chi/cơ sở cộng, đề nghị ứng đầu tiên và vai/thẩm quyền. Các con số, cơ sở quyền E trước đối trừ, điều kiện ứng và vai vẫn là đề xuất chưa duyệt; không kích hoạt runtime. Walkthrough R2 giữ nguyên; không suy hai ngày công tác thành hai đêm khách sạn để ép đạt policy mới. Tự review, không dùng subagent theo yêu cầu hiện hành.

Chủ dự án yêu cầu riêng review bảng policy bằng **GPT 6.1 Sol — Medium**. [Review độc lập và phán định lead](reviews/2026-10-09-r4-demo-policy/REVIEW.md) hoàn thành, verdict **Cần chỉnh sửa**: DP-R01 phạm vi cộng gộp xuyên hồ sơ và DP-R02 nghĩa ứng đầu tiên. Lead đồng ý, làm rõ authority sau loại theo rule vs tự giảm số và đề xuất nguồn theo đúng ngày/sự kiện. Target/snapshot/con số giữ nguyên; chưa áp hướng chỉnh hoặc chốt policy. Yêu cầu này không tự khôi phục subagent review mọi bước. Không code/test/policy activation/user trial trong đợt review.

### R4.3 — Đổi hướng sang ngân sách tổng công việc

Chủ dự án phản biện trần từng loại phức tạp; lead đề xuất bỏ trần tiền theo ngày/đêm/sự kiện, giữ kiểm tra khoản hợp lệ, nguồn tiền/history, ngân sách tổng có quyền và thẩm quyền. Chủ dự án đồng ý hướng và yêu cầu chốt/trình bày lại để review. [Policy ngân sách tổng](discovery/R4_WORK_BUDGET_POLICY.md) là bản cụ thể hiện hành để thảo luận; đánh dấu các draft trần nhóm là lịch sử. Bản này bao gồm selfpaid chưa có ngân sách, số xin/duyệt/nhận ứng riêng, nghĩa submit vs pending/actual và gate vượtB không clip. Không tự kế thừa các trần5/10triệu hoặc cabinrule từ bản cũ; ngưỡng delegation/activation và source contracts vẫn chưa chốt. Hướng đã được đồng ý không là toàn PB-01..09 đã duyệt chi tiết hay runtime đã chạy; R4 chưa đóng. Snapshot/review cũ giữ nguyên, tự review không subagent cho bản mới, chưa code.

Chủ dự án tiếp tục đồng ý bảng policy ngân sách tổng đã trình bày. **Đã chốt bảng nguyên tắc nghiệp vụ**, giữ ngưỡng quyền là quyết định còn mở riêng. Lead viết [thẩm quyền demo hai mức](discovery/R4_AUTHORITY_POLICY_DRAFT.md): tài chính10triệu/cấp cao30triệu, quyền ngoại lệ riêng và cơ sở B/ứng/E/S/T theo nội dung. Các số10/30 và bảng chi tiết vẫn là đề xuất chưa duyệt, không hạn mức mỗi nhóm hoặc ngân sách mặc định; không runtime activation/code. Sau chốt quyền tiếp khóa version/source contracts rồi R5 expected và đánh giá; chưa gọi toàn R4 hoàn tất.

### R4 — Chốt ba vai và một người duyệt có quyền

Chủ dự án xác định kế toán đối chiếu rồi trình sếp; đề nghị gộp quản lý công việc và duyệt tài chính vào một role. Lead đề xuất **Nhân viên — Kế toán — Người duyệt có quyền**, tách nội dung quyết định công việc/B/ứng/quyết toán nhưng cho cùng người đủ quyền thực hiện; kế toán có thể kiêm thực hiện chi/thu, không quyền duyệt tiền mặc định. Chủ dự án đồng ý. [Quyền và bàn giao ba vai](discovery/R4_ROLES_HANDOFF_POLICY.md) cụ thể hóa để review. Đánh dấu bảng hai cấp10/30 là lịch sử; không có ngưỡng tiền đã được chốt. Quyền trong phạm vi cần căn cứ, role sếp không tự vô hạn. Tiếp theo khóa nguồn/coverage/version/quyền cho R5; chưa code/runtime, không subagent và không cập nhật memory ngoài session.

Chủ dự án đồng ý tiếp tục sau trình bày bàn giao ba vai, rồi yêu cầu triển khai tiếp. Lead viết [R4.4 bộ nguồn tiếp nhận](discovery/R4_SOURCE_INTAKE_CONTRACT.md) để review: source nhân viên/company, packet trước/sau, actualreceipt khác approval/Paid, nhập/import ledger có refs không nhập đáp án, coverage công việc/mốc/loại/owner và routing thiếu nguồn. Giữ cashattestation đúng expense profile, employee không khai thay companyabsence. Đây là cụ thể hóa thiết kế, chưa chốt schema/API/format chạy được, policy/version/authoritypacket/gold hoặc code. Không tích hợp bank/ERP, không subagent; R5 tiếp sau chốt các căn cứ còn mở.

Chủ dự án đồng ý bộ nguồn được trình bày ở R4.4 và cho tiếp tục. Lead dựng [packet giả lập01](discovery/examples/work_budget_01/README.md) gồm originals text/CSV, authority/phạm vi cho đúng case, decision/ngân sách, cashpayer evidence, coverage và grossactual events. Tách inputM1 trước chi thêm và M2 sau receipt; expectedmanual riêng không vào input. Bundle policy thiết kế lưu snapshots/hashes để tái dựng, không freeze B1/runtime/livepolicy/holdout. Scope tiền/quyền của packet không tự là cấu hình mặc định toàn MVP. Chưa chạy pipeline/OCR/Verify/usertrial, chưa độc lập thẩm định gold hoặc đóng toàn R4/R5.

Chủ dự án đồng ý tiếp tục từ walkthrough sang R5. Lead viết [R5.1 thiết kế đánh giá](discovery/R5_EVALUATION_DESIGN.md): hai tầng correctness/effort, B7primary/B3 riêng, source/link/money/escalation/question/control/operationalmetrics, technicalunjudged coverage và denominators, catalogue15B7+5B3 để dựng development, Verify3routine/2needs và gold/calibration/holdout/actiongates. Catalogue chưa là20fullcase đã tạo/chạy; packet01 vẫn manualexpected chưa independentlyadjudicated. Chưa có goldfreeze, quality/latency/effort số đo, actionB/B1/runtime hoặc professionaltrial. Policy/source/quyền áp cho từng packet rõ trước expected; source đề xuất khác không tự sửa snapshots/R4/ngưỡng.

Chủ dự án đồng ý thiết kế R5.1 được trình bày và cho dựng bốn case tiếp. [R5.2 core development](discovery/eval_development/b7_core_01/README.md) gồmQ01 trảthêm3/Q02 tựchi khôngứng trả5/Q03 ứng4-chi3,3 hoàn0,7/Q04 đãthực hoàn3 còn0, với input/hash/coverage/authority đầy đủ và expected riêng. Q04 là mốc sau củaQ01; tổng4snapshots/3businessstories/1templatefamily, không dataset độc lập. Q02/Q03 đổi đầy đủ nguồn/cashattestation/decision/receipt/history, không chỉsửa đáp án. Policy snapshots kế thừa walkthrough bất biến; chưa dựng hết20catalogue, thẩm địnhgold hoặc chạy pipeline/OCR/Verify/liveproviders/người thật. Kiểm tra nội bộ refs/numbers không runtime evidence; chưa freezeB1.

Chủ dự án đồng ý tiếp tục dựng bốn nhóm nguồn chưa đủ. [R5.3 uncertainty development](discovery/eval_development/b7_uncertainty_01/README.md) gồmQ11 approval/lệnh không actualreceipt, Q10 thiếuscopecompany07–08, Q09 anonymouscash không payer/attestation, Q12 PERSONAL mâu thuẫn companyreceipt. Đã rà bỏ căn cứ dư vô tình trong employee/companyscope để initialcase chưa đủ thật; expectedfinalSnull và followupvalid cụthể đưa report+3triệu nhưngassisted/chưaapprove/paid/close. Mốcsourcebiếtthêmsau khác mốcmoneygiữ08/10; không dùng futurepayment. Initial/followup/gold táchmanifest/hash, sharedpolicysnapshots giữ nguyên. Tổng8caseconditionsdevelopment, cùngfamily, chưa độc lập/20fullcases/pipeline/OCR/Verify/metrics/usertrial hoặc B1freeze.

Chủ dự án đồng ý tiếp tục hai nhóm policy/quyền. [R5.4](discovery/eval_development/b7_policy_authority_01/README.md) dựngQ13 actualT9/B8, quyềnngoạilệchoT9đãcó chưadecision; Q14 B8/T8sourcesrõ, pretrippermissionvalid nhưng currentapprover chỉ có quyềnsettlementworkkhác và không biết alternativeđủquyền. FollowupQ13 toànE6/S4 hoặcpartialeligibleE5/S3 giữrawT9/B8/hotel4; Q14 nguồngiaoquyền hiệu lực09/10 cho quyếtđịnh mới, không duyệtchi/backdate. Sources/followupbranches/expected táchmanifest/hash. Tổng10caseconditionsdevelopment cùngfamily, chưa20fullcases/independentgold, pipeline/OCR/Verify/B1/usertrial; policy snapshots vàcasecũ giữ nguyên. Không thêmrole/twolevelcaps để làmcaseauthority.

Chủ dự án đồng ý tiếp tục payer/personal/duplicates. [R5.5](discovery/eval_development/b7_allocation_duplicates_01/README.md) dựngQ05 splitbill5 cóproofcompany2/employee3/A1→S2; Q06 rawbill/employee_paid7, work6/private1 rõ/A2→S4 giữsource7; Q07 suppliercopy + bankaliasTXAIR/BNKA44 + BNKA45 sameamount/date khácbooking/work để chấmđúngrefs/partition, khôngchỉnetS3. Initialsources/policy/expectedhash táchmanifest; không fakeproof bằng tổngtrừ, trừ2lần hoặc inferpersonal từ classifier. Tổng13caseconditionsdevelopment, khôngquá20/independentgold/OCR/pipeline/Verify/trial hoặcB1freeze. Cácsuites cũ giữ nguyên, roles/limitskhôngthay.

Chủ dự án đồng ý hoànthiện hai B7cònthiếu. [R5.6](discovery/eval_development/b7_missing_budget_image_01/README.md) dựngQ15 quyềnxét8khônglàB8, chưaB→decision chấpnhậnchi8/employee5 sauphátsinh+approve5; Q08 sourcePNG mới dựngxácđịnhcótotalopaque, khôngbackupamounttext/bank khác→PNG rõtotal3 đểrecheckE5/S3. Không sửa ảnhuser hoặc giấy thật, ảnhwatermarksynthetic đãinspectbằngview_image; chưaOCR/provider. Input/followup/gold táchhash và mốctiền08/10/source09/10, khôngpartialnet0từknownsubtotal2−A2 đểclose. Tổng15B7packetconditionsdevelopment cùngfamily, chưa5B3/independentgold/measurement/Verify/trial/B1freeze. Policy vàpacket cũ giữ nguyên; số/quyền trongcase khôngruntimeconfig.

Chủ dự án đồng ý dựng nhómứng. [R5.7 B3](discovery/eval_development/b3_advance_01/README.md) thêmA01nativeproposalreport/A02externalworkBudgetapprovedreuse/A03estimate8vs3+4/A04priorhistorygap/A05authorityotherscope; followupformrevision/fullscope/newgrant táchinitial và money/time. Chưaapproval/actualadvance/currentinvoice/B7settlement/sourcecodeschema. [Corpus index](discovery/eval_development/CORPUS_INDEX.md) hoàn tất20packetconditionsdevelopment15B7+5B3 (9routinecheck/11needs expectednháp), cùngtemplatefamily, không20runspassed hoặcqualitymetrics/Verify/independentgold/holdout/trial/B1freeze. Tiếp theo source/gold/control/limitations audit và kế hoạchmeasurement rồiworkflow/architecture theoR6–R8; không tiếp tục nhânclone để claimtậpđộclập.

Chủ dự án đồng ý ràsoát/chốt thiết kếđánhgiá trướcR6. [R5.8 review/gates](discovery/R5_CORPUS_REVIEW_AND_GATES.md) kiểminventory/manifest/expectedtype/sourcepolicyhash/money/actioncloseboundaries20packet, phânbiệtreportcomplete vsfinancialdecision/actualreceipt/close; ghi5giới hạn mộtfamily/narrativehints/prelinkedsource/goldsingleauthor/controltraces/runtime/trial. Kếtluậnlead cóthểchốtthiếtkếđánhgiáđểtiếpR6, không gold/runtime/Verify/B1acceptance. AssertionsC01..C07 khóa đểR6state/R7integrationđápứng, chưađãchạy. Sources/expected/policysnapshots giữ nguyên, khôngnớibusinessrules/thresholds hoặcspawnsubagent.

Chủ dự án đồng ý tiếp tục R6. [Bản workflow/trạng thái](discovery/R6_WORKFLOW_STATE_DRAFT.md) đề xuất quy trình thủ công giả định, luồng tạm ứng–quyết toán, logic tạo report, tiến trình hồ sơ/câu hỏi và các điều kiện Stop/phiên bản/thực nhận. Tách kết thúc yêu cầu bị từ chối khỏi đóng quyết toán; tái sử dụng quyết định hợp lệ; không chuyển 0 đồng hoặc duyệt lại mọi re-check. Bản đang chờ review nội dung, chưa chốt R6, chưa code hoặc chạy pipeline/controls; không dùng quy trình giả định làm bằng chứng giá trị nghiệp vụ thực tế.

Chủ dự án đồng ý workflow R6 để tiếp tục, đồng thời yêu cầu backend không over-engineering, khoảng5người dùng, ưu tiên kiến trúc AI/đánh giá và vừa code vừa chạy trên giao diện bên cạnh unit tests. R6 được chốt ở mức thiết kế. [R7.1](discovery/R7_ARCHITECTURE_EVALUATION_DRAFT.md) đề xuất một ứng dụng, SQLite/file nguồn, workflow AI có bước kiểm chứng, UI/runner cùng lõi và plan chia lát cắt có UI dùng được. Ràng buộc mới đã ghi nhận; chi tiết kiến trúc là đề xuất, chưa chốt R7 hoặc triển khai. Không coi 5người là 5role, 5professionaltrials hay năng lực tải đã đo; không dùng quy mô nhỏ để bỏ nguồn/phiên bản/Stop/chống trùng.

Chủ dự án đồng ý tiếp tục sau R7.1. Hướng kiến trúc được chấp nhận để cụ thể hóa [R7.2](discovery/R7_DATA_AND_EVALUATION_CONTRACT_DRAFT.md): nguồn/context, observed facts, chuẩn hóa/căn cứ sử dụng, quan hệ, checks/issues, report/questions, quyết định/events và run/evaluator. Output AI tối thiểu có ref và read state; null/0, receipt/approval và calculated/conditional/proposed tách nghĩa. Bản contract đang chờ review; chưa chốt toàn R7, chưa sửa corpus/gold hoặc code, chưa chạy pipeline/provider/UI/quality eval.

Chủ dự án đồng ý hợp đồng logic R7.2 để tiếp tục. [R7.3](discovery/R7_AI_READING_ORCHESTRATION_DRAFT.md) đề xuất routing từng nguồn/trang, text-first khi phù hợp, so sánh OCR→extraction và vision→facts, prompt/output giới hạn theo tác vụ, candidate coverage, reread/retry chung budget tối đa2attempts mỗi đơn vị extraction và deadline/call limits ở config kế tiếp. Tài liệu chính thức được tra cứu để phân biệt native/scanned/OCRed PDF và preprocessing; không benchmark từ docs hoặc khẳng định route/model tối ưu. Bản đang chờ review, chưa đo ngưỡng/calibration, chưa gọi provider/cài dependency/chạy pipeline/UI, chưa chốt toàn R7 hoặc code.

Chủ dự án đồng ý R7.3 và xác nhận OCR Mistral, LLM xkiro. [R7.4](discovery/R7_STACK_PROVIDER_BENCHMARK_DRAFT.md) đề xuất stack FastAPI/Pydantic–React/Vite–SQLite/files, HTTPX providers và PDFium tuần tự; Small2603/Medium3.5 none là2ứng viên từ [public catalog evidence](discovery/R7_XKIRO_CATALOG_EVIDENCE.json). GETcatalog130entries thành công sau cấp quyền mạng, không inference/accountaccess/quality. Configpilot và matrixbringup→model→route→calibration→holdout→UI đang đểreview; chưaversionsresolved/OCRpin hoặcfilelimitspec, chưapaidcalls/code/UI/quality/load/B1freeze. Giữ phânbiệtrequestedmodel/gatewayroute vàcapabilitydocs/thựcnghiệm, khôngsuyJSONmode/vision/reasoning đượcápdụng từHTTP200.

Chủ dự án đồng ý R7.4 để tiếp tục. [SpecR7.5](discovery/R7_MVP_SYSTEM_SPEC_DRAFT.md) đề xuất API commands/versions/idempotency,8bảngSQLite+files,run execution/business stage riêng,Stop epoch/stale/decisionbasis/actualfulfillment/closure,source limitsv0 và17acceptanceSYS-01..17. Spec đang chờreview; khôngcanonicalactivation/codematching/provider/UI/runtime/gold/B1acceptance. Filecounts kiểm từinventory20packet(max9initialfiles) chỉinventorykhôngpage/sizequality; giới hạnv0 chưađãtest. Sauđồngýspec mớiđối chiếucodeR8/ledger/plan, khôngdùngoldcodeđặtgoldhoặcclaimspecđãimplemented.

Chủ dự án đồng ý specR7.5 để triểnkhai bướcR8. [Review](discovery/R8_CODE_GAP_REVIEW.md) task-directedCodeGraph/source/schema/config: giữstack/artifacts/numeric/guardpatterns, thayclaim-primarypayer-autoRequest/report/evalcontracts. Freshselectedbackend37pass/frontend34pass/buildgreen làfake/replayoldscope, khôngquality/B1new. [Plan6luồng](superpowers/plans/2026-10-09-settlement-mvp.md) cóinterfaces/files/checks/UIevidence; AGENTS chuyểnintendedauthority mới, giữoldspec/planhistorical. Chưaimplementationnewcore/paidcalls/liveUI/5usertrial hoặcB1freeze; graphgeneration/coverageAPIlimitationsđãghi, khôngaudittoànrepo.

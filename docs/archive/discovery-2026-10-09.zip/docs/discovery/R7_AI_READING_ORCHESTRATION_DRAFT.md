# R7.3 — Đường đọc tài liệu và điều phối AI có giới hạn

Ngày: 09/10/2026 · **CHỦ DỰ ÁN ĐÃ ĐỒNG Ý HƯỚNG R7.3 ĐỂ TIẾP R7.4 — CHƯA CODE, CHƯA ĐO MODEL/PROVIDER HOẶC CHỐT NGƯỠNG**.

Căn cứ [kiến trúc R7.1](R7_ARCHITECTURE_EVALUATION_DRAFT.md), [hợp đồng R7.2 đã đồng ý để tiếp tục](R7_DATA_AND_EVALUATION_CONTRACT_DRAFT.md), [nguồn](R4_SOURCE_INTAKE_CONTRACT.md), [evidence](R4_EVIDENCE_RULES_DRAFT.md), [gates R5.8](R5_CORPUS_REVIEW_AND_GATES.md) và [brief](../Challenge_Brief_OrganizationAI_VN.docx.md). Không đọc code cũ để quyết định kiến trúc, không gọi provider hoặc cài dependency ở bước này.

## 1. Phương án điều phối đề xuất

Giữ một workflow do chương trình điều phối. Nó quyết định bước kế tiếp từ source type, output và checks; AI đọc/đề xuất trong phạm vi giao. Không cho model tự chọn tool chi tiền, sửa policy hoặc lặp cho tới khi có kết quả vừa ý.

```mermaid
flowchart TD
    A["Giữ nguồn, snapshot và phạm vi"] --> B{"Nguồn có cấu trúc?"}
    B -->|"Form hoặc bảng nguồn được hỗ trợ"| P["Parse trực tiếp<br/>giữ nghĩa khai báo và nguồn"]
    B -->|"Ảnh hoặc PDF"| D["Kiểm tra từng trang<br/>text, ảnh và khả năng xử lý"]
    D -->|"Text dùng được cho trường cần đọc"| T["Trích xuất từ text có locator<br/>AI khi cần hiểu bố cục/nội dung"]
    D -->|"Scan, text không đủ hoặc cần đọc vùng ảnh"| V["Đường đọc ảnh đã cấu hình<br/>OCR rồi trích xuất hoặc model thị giác"]
    P --> C["Kiểm tra hợp đồng, nguồn và chuẩn hóa<br/>giữ trường chưa rõ"]
    T --> C
    V --> C
    C --> M["Tạo và kiểm tra candidates liên quan<br/>AI hỗ trợ quan hệ còn cần hiểu"]
    M --> K["Kiểm tra liên kết, rule, tiền và quyền"]
    K --> R["Report có căn cứ hoặc issue/câu hỏi<br/>lưu run và bước tiếp"]
```

Sơ đồ là đường chính, không ngụ ý source lỗi vẫn vào phép tính. Các lỗi/giới hạn được ghi ở bước tương ứng; facts độc lập đủ nguồn có thể tiếp tục, kết quả cuối phụ thuộc phần lỗi thì giữ incomplete. Missing context không ngăn lưu hồ sơ nhưng không được điền bằng suy đoán.

## 2. Chọn đường đọc theo nguồn

| Nguồn | Đường ưu tiên | Điều kiện và giới hạn |
| --- | --- | --- |
| Form/bảng nguồn có schema được hỗ trợ | Parser và kiểm tra kiểu/nghĩa trực tiếp | PERSONAL là lời khai, Paid là raw status; không tự nâng thành payer/receipt đã chứng minh |
| PDF sinh số có text dùng được | Lấy text cùng page/locator; parser hoặc AI trích xuất facts cần thiết | Giữ trang gốc, không tự coi có text là số đúng hoặc mọi trang đã đủ |
| PDF scan/ảnh | Một đường đọc ảnh được chọn và version cho run | OCR→trích xuất hoặc vision→facts; đo trước khi chọn primary route |
| PDF hỗn hợp | Quyết định theo từng trang/vùng cần thiết | Trang có text không chứng minh trang ảnh còn lại đã đọc; giữ coverage trang/field |
| File lỗi/format chưa hỗ trợ | Giữ source và technical/capability issue | Không giả NOT_FOUND; cung cấp đường bổ sung phù hợp nếu có |

Theo [pypdf](https://pypdf.readthedocs.io/en/stable/user/extract-text.html), PDF có thể sinh số, scan hoặc chứa lớp text OCR; lấy text không đọc được chữ nằm trong ảnh và lớp OCR có thể có lỗi. Suy luận thiết kế: không dùng điều kiện đơn giản "có text" để miễn kiểm tra nguồn/vùng ảnh quan trọng.

[PyMuPDF](https://pymupdf.readthedocs.io/en/latest/recipes-ocr.html) khuyến nghị xác định có cần OCR và lưu kết quả OCR để tái sử dụng theo trang. Suy luận thiết kế: đọc lại cùng trang vô điều kiện là chi phí cần tránh; không áp dụng số liệu tốc độ trong tài liệu như benchmark InvoiceReferee.

Đề xuất **text-first cho nguồn phù hợp**, còn ảnh/scan chọn một primary route sau phép so sánh ở §8. Nếu đã có reader thích hợp, R8 đánh giá khả năng giữ/sửa; không dựng cả hai stack production chỉ để kiến trúc có nhiều lựa chọn. Kimi có thể là ứng viên ở bước lựa chọn provider, chưa giữ mặc định chỉ vì baseline cũ dùng nó.

### Chất lượng và biến đổi ảnh

Giữ bản gốc. Render/rotate/crop có thể tạo representation phục vụ đọc nhưng phải ghi quan hệ và phép biến đổi để locator/UI quay về source đúng. Crop giữ context cần phân biệt tổng/subtotal/tiền đã trả; không crop làm mất bằng chứng mâu thuẫn. Không phục hồi một chữ số không tồn tại bằng sinh ảnh rồi dùng như chứng từ.

[PaddleOCR](https://www.paddleocr.ai/main/en/version3.x/pipeline_usage/doc_preprocessor.html) có các module sửa hướng và biến dạng ảnh. Điều này cho thấy preprocessing là lựa chọn kỹ thuật riêng; chưa chứng minh cần dùng mọi module hay nó đọc đúng bills của dự án.

Lớp text ẩn/OCR cũ có thể khác nội dung thấy trên trang. Cần case đánh giá loại mismatch này; khi phát hiện dấu hiệu/trường trọng yếu mâu thuẫn thì đối chiếu representation gốc, không ưu tiên text vì tiện parse. Không tuyên bố một heuristic nhận biết được mọi lớp text sai.

## 3. Input/output của từng lời gọi

| Tác vụ | Đưa vào | Nhận về |
| --- | --- | --- |
| Trích xuất | Một tài liệu/nhóm trang có quan hệ rõ trong giới hạn context; keys cần đọc; text/ảnh và locator | fields/raw/read_state/refs theo R7.2, không E/S, policy judgement hoặc report dài |
| Đọc lại có mục tiêu | Field/page cần làm rõ, nguồn gốc và context liên quan; lý do cụ thể phải đọc lại | Observations mới của phần đó, giữ output trước; không chép số nhân viên khai để sửa extraction |
| Matching | Khoản/facts và candidates liên quan có IDs/namespace/nguồn; context công việc và các điểm mâu thuẫn | Relation/portion/support refs hoặc chưa đủ căn cứ; không final tiền/phê duyệt |
| Diễn đạt câu hỏi nếu cần | Issue/owner/refs và nội dung cần cung cấp do checks xác định | Câu hỏi ngắn; không thay đổi loại vướng mắc, người có quyền hoặc điều kiện giải quyết |

Không truyền số nhân viên khai như đáp án gợi ý cho việc đọc hóa đơn. Đối chiếu lời khai diễn ra sau extraction. Nội dung văn bản chứng từ là dữ liệu, không là chỉ dẫn cho model thay chính sách/đầu ra. Không đưa expected/gold hoặc nhãn case vào lời gọi.

Một tài liệu nhiều trang cần giữ context cho field phụ thuộc trang khác. Có thể nhóm trang phù hợp để giảm calls, nhưng không gộp mọi chứng từ của cả hồ sơ vào một prompt. Keys/output theo checks áp dụng, không mặc định trích hết mọi dòng hàng. Có phần cá nhân/split cần đối chiếu thì đọc đủ line/portion phục vụ phân bổ; chỉ đọc total sẽ không đủ.

## 4. Ghép nguồn: thu hẹp context nhưng không che nguồn cần thiết

Candidates lấy từ nguồn/hồ sơ liên quan trong scope có căn cứ. Dùng refs rõ, parties, work/booking, currency, amounts/parts và thời gian để tìm; không filter cứng cùng amount vì payment có thể là đặt cọc/chi từng phần. Thời gian giống/khác là tín hiệu phù hợp nghiệp vụ, không proof cùng/khác event.

Giữ candidate selection trace: phạm vi nào đã tìm, lý do chọn/bỏ, giới hạn còn chưa xem. Không có candidate trong một tập bị cắt không chứng minh chưa trả. Nếu giới hạn tìm kiếm làm thiếu coverage cần để kết luận, giữ issue/giới hạn, không chọn kết quả tốt nhất trong top-k rồi tự xác nhận.

| Nhóm quan hệ | Cách tiếp tục |
| --- | --- |
| Nguồn chỉ rõ quan hệ, refs/parties/portion/mốc hợp lệ và không mâu thuẫn | Kiểm tra điều kiện bằng chương trình, ghi nguồn quan hệ; không gọi AI làm lại chỉ để tăng số bước |
| Cần hiểu memo/nội dung nhưng có các anchors độc lập phù hợp | AI đề xuất; kiểm tra contract/source/constraints rồi áp tiêu chí chất lượng đã được calibration cho nhóm này |
| Chỉ giống tiền/ngày/tên, nhiều candidates hoặc sources mâu thuẫn | Giữ uncertainty với các refs liên quan; hỏi đúng owner/cần nguồn gì; không dùng majority vote giữa models |

Tiêu chí tự chấp nhận semantic link phải gắn loại quan hệ và bằng chứng, không một confidence tự báo. Trước khi có calibration đủ cho nhóm thứ hai, proposal được lưu/hiển thị để kiểm tra, chưa gắn là fact đã đủ căn cứ chỉ vì model nói chắc. Không coi tất cả quan hệ cần AI đều phải hỏi người mãi mãi; phải đo và xác định nhóm đủ chất lượng để routine check tự hoàn thành.

Không chốt một số như0,8/95% khi chưa có dữ liệu calibration hoặc score thật. Điều chỉnh ngưỡng Sprint2 chỉ tác động điểm cần hỏi với chất lượng linkage/extraction đã định; không thay ngân sách, quyền, actualreceipt hoặc cho phép amount mờ đi vào phép tính. Ghi proposed threshold/version, kiểm tra calibration và controls trước activation; holdout độc lập chấm sau activation, không dùng nó chọn ngưỡng.

## 5. Lỗi, đọc lại và giới hạn lời gọi

Đề xuất mặc định ban đầu: **tối đa hai attempts cho một đơn vị trích xuất** — lần đầu và tối đa một lần bổ sung có lý do. Lần bổ sung có thể là retry transient, sửa output contract hoặc đọc lại field/vùng; cùng chia sẻ budget này, không ba vòng riêng tự cộng thêm. Đây là giới hạn kỹ thuật đề xuất cần đo; không lời hứa latency hoặc thay đổi policy tài chính.

Một attempt là một lần thực hiện đường đọc cho đơn vị đó; OCR→trích xuất có thể gồm nhiều bước/calls, khác vision trực tiếp. Mọi calls vật lý vẫn ghi/tính vào tổng budget của run, không gọi "hai attempts" là "hai lời gọi model" cho mọi route. Retry tại từng stage không có budget riêng ẩn; các kết quả stage hợp lệ được giữ để tránh chạy lại vô ích.

| Tình huống | Xử lý |
| --- | --- |
| Timeout/network transient | Retry nếu còn attempt/deadline; giữ lỗi, lần gọi và tổng thời gian; hết budget ghi technical failure |
| Output thiếu keys/JSON lỗi/ref giả/truncated | Validator chỉ rõ lỗi; tối đa một corrective attempt nếu budget còn. Không bóc một số hợp mắt từ output lỗi để final |
| Nguồn thực thiếu/bị che/không đủ readable | Giữ uncertainty và yêu cầu nguồn phù hợp; không retry cho tới khi sinh được một số |
| Parser/OCR route bỏ vùng đọc được, layout/context chưa đủ | Targeted reread bằng route đã cấu hình nếu còn budget và có khả năng làm rõ; giữ cả observations, không bỏ mâu thuẫn |
| Matching còn mơ hồ | Tìm thêm trong scope/nguồn nếu có và trong budget; nếu chưa đủ, hỏi đúng người. Không loop đề xuất cho tới khi chọn được một candidate |
| Stop hoặc revision đã thay thế | Không bắt đầu thêm calls cho run cũ. Lưu kết quả muộn như thuộc run cũ, không làm current report/action |

Một vùng mới hoàn toàn không được tách thành "đơn vị mới" để lách giới hạn đọc lại cùng field/page. Ngoài attempt budget còn deadline và tổng calls theo run; matching không có vòng tự mở rộng vô hạn. Các giá trị deadline/call/file/page limits sẽ chốt cùng provider/config ở R7.4 để đáp ứng nguồn hỗ trợ và measurement; hết budget không được coi source unreadable hoặc nghiệp vụ PASS.

Provider call đang chạy có thể vẫn hoàn tất sau timeout/Stop. App kiểm soát việc nhận/sử dụng kết quả và hành động tiếp theo; không khẳng định hủy từ xa hay hoàn phí. Calls đã phát sinh và failures được tính khi báo vận hành.

## 6. Đọc lại phần ảnh hưởng, không chạy lại mọi thứ

| Thay đổi | Phần cần làm lại |
| --- | --- |
| Bổ sung nguồn rõ thay ảnh mờ | Đọc nguồn mới; xét supersedes/contradiction; links/checks/tiền và hiệu lực quyết định liên quan |
| Nhân viên sửa lời khai payer/purpose | Lời khai revision mới và các links/checks ảnh hưởng; extraction nguồn không đổi có thể dùng lại |
| Thêm actualreceipt/pending/history | Đọc nguồn sự kiện mới; kiểm tra quan hệ/coverage/tiền và bước tiếp; không mặc định đọc lại mọi invoice |
| Đổi B/policy/quyền | Các checks/decision validity theo thay đổi; observations đã đọc có thể dùng lại nếu vẫn đáp ứng keys/nguồn |
| Đổi reader/model/prompt/keys/representation | Extraction liên quan tạo kết quả config mới; không dùng cache cũ để giả đo chất lượng model mới |

Chỉ cần mapping phụ thuộc giữa source/facts/links/checks của run trong ứng dụng; chưa cần generic dependency graph engine. Dùng lại extraction dựa vào hash/config/keys/representation và provenance, không chỉ filename. File giống bytes ở hai hồ sơ có thể dùng lại kết quả đọc, nhưng không suy cùng obligation hoặc dùng lại quyền/coverage giữa hai hồ sơ.

## 7. Thực hiện trên UI và khoảng 5 người dùng

UI gửi run và xem trạng thái theo case/run/revision; pipeline chạy hữu hạn trong process để không khóa thao tác xem nguồn/Stop. Hiện bước đang xử lý, sources/pages đã xong và lỗi cụ thể; không bịa phần trăm hoặc ETA từ số bước. Hoàn thành extraction chưa báo hồ sơ đã hoàn tất.

Trước lưu current report/chuyển tiếp/hành động, guard đúng revision/Stop trong transaction theo R7.1. Hai run cùng hồ sơ không được ghi đè current từ output đến muộn; từng run vẫn giữ lịch sử. Đổi policy/quyền cần check ảnh hưởng như R6. Run đọc tiền đã xảy ra vẫn lưu source thật khi Stop, không cho chi mới.

Không giữ transaction ghi SQLite suốt lúc chờ provider. Cần test các phiên riêng không trộn case, hai thao tác cùng case, Stop trong call và process restart. Khoảng5người là target pilot; mức đồng thời calls và latency chưa được chứng minh. Không thêm queue/service phân tán để giải quyết target trước khi đo.

## 8. Phép so sánh để chọn đường đọc

So sánh **OCR→trích xuất** với **vision→facts** trên cùng originals, gold, keys, policy và phạm vi. Giữ full call/representation/config traces; OCR có thể là mô hình AI, hai output không tự độc lập về truth. Native text route được đánh giá riêng theo strata, không gộp tỷ lệ dễ để che lỗi ảnh.

Tập so sánh cần layout/context độc lập, text số nhỏ, ảnh xoay/nhòe/cắt góc, total/subtotal, split/personal portions, multi-page/mixed PDF và hidden text mismatch. Q08 che số là một case unknown; không thay case nguồn rõ nhưng reader đọc sai. Development20 hiện tại chưa đủ cho phép so sánh này; cần gold/rà soát nguồn và dataset mới ở bước triển khai đánh giá, không claim đã benchmark.

Chấm critical fields+locators, unknown/abstention, links/parts, kết quả tiền/issue, first-pass completion, FN/FP/technical failures, tổng latency/calls/cost và effort. Dùng số đo của project để chọn primary route. Tổng hợp trang extraction phải chấm ảnh hưởng downstream; đọc chữ nhiều hơn không tự tốt hơn nếu số tiền/quan hệ sai.

Chọn primary route sau calibration; fallback chỉ mở cho nhóm lỗi đã có bằng chứng cải thiện mà không làm hallucination/latency/cost xấu vượt tiêu chí đã công bố. Test trên tập có trường mất thông tin để đo xu hướng đoán số. Bất đồng hai reader giữ evidence/issue, không lấy reader nào trả số để tự pass. Holdout không dùng chọn route/prompt/threshold.

## 9. Biện luận của lead và bước tiếp

Một workflow cố định vẫn có tính tự chủ nếu từ submit nó tự chọn đường đọc, xử lý bước phụ thuộc, tạo report hoặc câu hỏi đúng và dùng phản hồi để tiếp tục. Số agent hoặc tool calls không là bằng chứng hoàn thành công việc. Rủi ro BTC về phạm vi routine check/report vs toànworkflow vẫn giữ tại R3.

Khuyến nghị: routing theo nguồn; extraction ngắn có ref; matching chỉ khi cần; rule/math/quyền và report do chương trình; reread/retry hữu hạn; chất lượng đọc/ghép được đo riêng. Chưa chứng minh OCR-first hay vision-first tốt hơn cho bills của mình, không tự gán một lựa chọn là chính xác nhất.

Chủ dự án đã đồng ý tiếp tục từ R7.3 và xác nhận dùng Mistral OCR cùng LLM qua xkiro. [R7.4](R7_STACK_PROVIDER_BENCHMARK_DRAFT.md) cụ thể hóa stack, ứng viên từ public catalog, cấu hình pilot và phép so sánh. Không tự cài stack/chạy paid provider; authorization cho design không tự là authorization chi phí. Sau hợp đồng/spec R7 mới đối chiếu code/plan R8.

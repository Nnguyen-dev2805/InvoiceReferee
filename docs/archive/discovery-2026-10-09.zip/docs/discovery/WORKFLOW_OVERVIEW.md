# Workflow tổng quan — Công tác, tạm ứng và quyết toán

Ngày: 08/10/2026 · Trạng thái: **SƠ ĐỒ THIẾT KẾ ĐỂ REVIEW**.

Bản này ghép [nhánh từ chối đã sửa](ADVANCE_REJECTION_BRANCH.md) vào sơ đồ tổng quan. A là đề nghị trước khi cấp tiền theo đề nghị đó; L là khoản đã cấp từ trước được nhập/xác minh. Không suy trạng thái tiền từ cách gửi form hay upload. N kết thúc đề nghị bị từ chối, không đi sang quyết toán; tiền đã cấp được theo dõi qua T.

Theo R1-DEC-09, hồ sơ nhân viên tự chi không ứng có đường nộp trực tiếp vào S; số ứng bằng 0 khi xác nhận không có, không tạo khoản ứng giả.

```mermaid
flowchart TD
    subgraph BEFORE["Trước công việc — Tạm ứng"]
        A["Nhân viên gửi yêu cầu<br/>Form hoặc nhập hồ sơ có sẵn"]
        B["Hệ thống kiểm tra thông tin và căn cứ"]
        R["Bổ sung / sửa / xác minh"]

        C{"Căn cứ cho phép công tác"}
        M{"Người có quyền<br/>xem xét công tác"}
        D["Hệ thống kiểm tra đề nghị tạm ứng<br/>và chuẩn bị kết quả có căn cứ"]
        F{"Con người rà soát<br/>và duyệt tiền ứng"}

        N["Ghi nhận từ chối và lý do"]
        E["Kết thúc đề nghị<br/>Không cấp tiền theo đề nghị"]
        P["Con người chi ứng<br/>Ghi nhận tiền thực tế có căn cứ"]

        A --> B
        B -->|"Thiếu, sai hoặc mâu thuẫn"| R
        R -->|"Kiểm tra lại phần liên quan"| B
        B -->|"Thông tin đủ để xem xét"| C

        C -->|"Đã được phép, căn cứ hợp lệ"| D
        C -->|"Chưa được phép"| M
        C -->|"Căn cứ chưa rõ"| R
        C -->|"Đã bị từ chối còn hiệu lực"| N

        M -->|"Cho phép"| D
        M -->|"Yêu cầu sửa"| R
        M -->|"Từ chối"| N

        D -->|"Cần làm rõ"| R
        D -->|"Không đủ điều kiện, căn cứ rõ"| N
        D -->|"Đã kiểm tra đủ căn cứ"| F

        F -->|"Trả lại hoặc sửa điều kiện"| R
        F -->|"Từ chối"| N
        F -->|"Phê duyệt"| P
        N --> E
    end

    L["Khoản ứng đã cấp từ trước<br/>Đưa vào hệ thống và xác minh"]
    T["Đã có khoản ứng thực tế cần theo dõi"]
    X["Công việc bị hủy hoặc thay đổi<br/>Chuẩn bị hồ sơ xử lý khoản ứng đã cấp"]
    O["Nhân viên tự chi, không nhận ứng<br/>Nộp hồ sơ hoàn trả chi phí"]

    subgraph AFTER["Quyết toán / Hoàn trả chi phí / Xử lý khoản ứng"]
        S["Nhân viên nộp bảng kê và chứng từ liên quan"]
        K["Hệ thống đối chiếu chứng từ, nguồn tiền<br/>và tính kết quả quyết toán"]
        R2["Bổ sung / sửa / giải quyết vướng mắc"]
        H{"Con người rà soát<br/>và duyệt quyết toán"}

        W["Ghi nhận từ chối<br/>Giữ nghĩa vụ chưa xử lý"]
        U["Chi thêm / hoàn lại / cân bằng<br/>Đối chiếu chi và thu thực tế"]
        Z["Đóng hồ sơ khi đủ căn cứ<br/>và không còn nghĩa vụ cần xử lý"]

        S --> K
        K -->|"Còn vướng mắc"| R2
        R2 -->|"Kiểm tra lại phần liên quan"| K
        K -->|"Đã kiểm tra đủ căn cứ"| H

        H -->|"Trả lại hoặc phát hiện lỗi"| R2
        H -->|"Từ chối"| W
        W -->|"Có bổ sung hoặc quyết định xử lý mới"| R2
        H -->|"Phê duyệt"| U
        U -->|"Chưa rõ, chưa đủ hoặc có sai lệch"| R2
        U -->|"Đã đối chiếu đầy đủ"| Z
    end

    P -->|"Tiền thực tế đã được xác minh"| T
    L -->|"Tiền thực tế đã được xác minh"| T
    T -->|"Sau khi công việc hoàn thành"| S
    T -->|"Hủy hoặc thay đổi cần xử lý khoản ứng"| X
    X --> S
    O --> S
```

Hai thay đổi chính: bỏ N → S, thay bằng N → E; khoản đã cấp đi qua T rồi tới hồ sơ quyết toán thông thường hoặc hồ sơ xử lý hủy/thay đổi. Phê duyệt chưa là đã chi; khi chưa rõ tiền, giữ chờ xác minh. Hủy/thay đổi không tự yêu cầu hoàn toàn bộ tiền ứng.

Lỗi kỹ thuật, tiền chi một phần/thất bại/chưa rõ, Stop, phiên bản, nguồn/quyền và chống chi trùng được mô tả trong [workflow chi tiết](ADVANCE_SETTLEMENT_WORKFLOW_DRAFT.md). Sơ đồ tổng quan không chứng minh code đã thực hiện các hành vi này.

# InvoiceReferee — Workflow công tác, tạm ứng và quyết toán

Ngày: 08/10/2026 · Phiên bản: 0.1 · Trạng thái: **BẢN THẢO LOGIC NGHIỆP VỤ ĐỂ REVIEW**.

Căn cứ: [các quyết định R0/R1](../DISCOVERY_ROADMAP.md). Phạm vi đã chọn: xin phép công tác trong app hoặc dùng căn cứ bên ngoài; form chính hoặc nhập hồ sơ có sẵn; kiểm tra tạm ứng và quyết toán sau công việc. Đây không phải flow của code đang chạy hay spec đã chốt mọi quy tắc.

Để đọc riêng nhánh đã gây nhầm trong bản tổng quan, dùng [nhánh từ chối trước chi và xử lý khoản đã cấp](ADVANCE_REJECTION_BRANCH.md): đề nghị mới bị từ chối trước chi kết thúc, khoản đã cấp có đường theo dõi riêng. Các nhánh tiền đã chi trong bản chi tiết bên dưới bảo toàn lịch sử/ngoại lệ, không có nghĩa đề nghị mới bị từ chối tạo ra tiền ứng.

## 1. Cách đọc và giả định thiết kế

- Ba sơ đồ nối nhau: **tiếp nhận/cho phép công tác → kiểm tra và xử lý tạm ứng → quyết toán sau công việc**. Các đầu nối ghi rõ bước tiếp tục, không phải ba hệ thống riêng.
- Hệ thống đọc/kiểm tra/lưu kết quả và tạo câu hỏi. Con người quyết định cho phép công tác, phê duyệt tài chính và thực hiện chi/thu; nguồn/xác nhận tiền thực tế được ghi nhận, không giả lập thành đã chi chỉ từ một nút duyệt.
- Nguồn, policy và quyền đủ để sử dụng phải được xác định ở R2–R4. Các diamond “đủ căn cứ” là điều kiện cần thiết kế/test, không phải điểm số LLM tự tuyên bố.
- Một người có thể giữ nhiều vai. Hai quyết định công tác/tiền có thể thực hiện trong cùng lượt thao tác nếu có đủ quyền; phải lưu riêng nội dung và phạm vi, không mặc định cần hai màn hình/hai chữ ký.
- Nhánh sửa/bổ sung ghi nhận phiên bản mới và chỉ đánh giá lại phần bị ảnh hưởng. Thay đổi làm phạm vi/quyền cũ không còn phù hợp thì phải làm rõ hoặc xin quyết định lại.
- Sơ đồ biểu diễn kết quả một lần xử lý. Hồ sơ có thể có nhiều vấn đề: phải giữ đủ vấn đề, người nhận và phụ thuộc; không bỏ vấn đề còn mở chỉ vì giải quyết được một nhánh.
- VND và một người chịu trách nhiệm hồ sơ được dùng để minh họa, chưa tự chốt mọi trường hợp nhóm, nhiều tiền tệ, nhiều đợt ứng hoặc chi/thu từng phần. Sự kiện tiền đến một phần vẫn phải ghi nhận, không tự cho phép thanh toán từng phần.

## 2. Sơ đồ A — Tiếp nhận, lỗi dữ liệu và cho phép công tác

Kiểm tra đầu vào diễn ra với **cả form và hồ sơ nhập**, trước khi đi tiếp bằng căn cứ công tác. Một giấy được duyệt không làm số tiền/ngày/mục đích nhập sai trở thành đúng.

```mermaid
flowchart TD
    A_START["Nhân viên gửi đề xuất công tác và đề nghị ứng"]
    A_FORM["Form: giữ dữ kiện khai báo và tài liệu kèm"]
    A_DOC["Hồ sơ có sẵn: giữ gốc và đọc/trích xuất có nguồn"]
    A_TECH["Lỗi kỹ thuật đọc tài liệu<br/>Chưa kết luận nghiệp vụ; lưu lỗi"]
    A_CHECK["Hệ thống kiểm tra thông tin để xem xét<br/>thiếu trường, nguồn, số liệu, mâu thuẫn, trùng nghi vấn"]
    A_DATA{"Còn vấn đề dữ kiện<br/>cần làm rõ?"}
    A_ASK["Hỏi cụ thể người nộp hoặc người sở hữu nguồn"]
    A_UPDATE["Nhận bổ sung/sửa; lưu phiên bản<br/>đọc lại tài liệu thay đổi và kiểm tra phần liên quan"]
    A_PERMISSION{"Căn cứ cho phép công tác<br/>thuộc trạng thái nào?"}
    A_VERIFY["Xác minh nguồn, người có quyền<br/>phạm vi, thời gian và hiệu lực"]
    A_MANAGER["Người có quyền xem xét đề xuất công tác"]
    A_DECISION{"Quyết định công tác"}
    A_AUTH["Lưu quyết định và phạm vi được cho phép"]
    A_REJECT["Không được cho phép công tác; giữ lý do<br/>Nếu đã có tiền ứng: vẫn phải xử lý khoản đó"]
    A_TO_C["Có tiền ứng hoặc trạng thái tiền chưa rõ<br/>sang C để đối chiếu/xử lý nghĩa vụ"]
    A_READY["Sang sơ đồ B: kiểm tra tạm ứng<br/>không bỏ qua kiểm tra vì công tác đã được phép"]

    A_START -->|"Tạo trực tiếp"| A_FORM
    A_START -->|"Nhập tài liệu"| A_DOC
    A_FORM --> A_CHECK
    A_DOC -->|"Đọc được hoặc xác định phần chưa rõ"| A_CHECK
    A_DOC -->|"Timeout hoặc output không hợp lệ"| A_TECH
    A_TECH -->|"Khắc phục và chạy lại có kiểm soát"| A_DOC
    A_CHECK --> A_DATA
    A_DATA -->|"Có"| A_ASK --> A_UPDATE --> A_CHECK
    A_DATA -->|"Không"| A_PERMISSION
    A_PERMISSION -->|"Đã được phép và căn cứ đủ"| A_READY
    A_PERMISSION -->|"Đã được phép nhưng căn cứ chưa rõ"| A_VERIFY --> A_UPDATE
    A_PERMISSION -->|"Chưa có quyết định cho phép"| A_MANAGER --> A_DECISION
    A_PERMISSION -->|"Có quyết định không cho phép còn áp dụng"| A_REJECT
    A_DECISION -->|"Cho phép"| A_AUTH --> A_READY
    A_DECISION -->|"Yêu cầu sửa hoặc bổ sung"| A_UPDATE
    A_DECISION -->|"Không cho phép"| A_REJECT
    A_REJECT -->|"Nếu có hoặc chưa rõ tiền đã chi"| A_TO_C
```

Nếu thông tin không bao giờ được bổ sung, hồ sơ **tiếp tục chờ**, không tự suy đoán rồi phê duyệt. Chờ quyết định công tác là checkpoint con người của workflow đã chọn; không tự gắn mọi hồ sơ qua checkpoint này là “chuyển tiếp do AI không chắc”. Khi có quyết định không cho phép, nộp lại phải là phiên bản/đề xuất có lịch sử, không xóa quyết định cũ.

## 3. Sơ đồ B — Kiểm tra tạm ứng, người duyệt trả lại/từ chối và tiền thực tế

```mermaid
flowchart TD
    B_START["Từ A: công tác có căn cứ cho phép"]
    B_CHECK["Hệ thống kiểm tra đề nghị ứng<br/>phạm vi công tác, dự toán, số tiền, policy<br/>lịch sử ứng/chi và nguồn cần thiết theo quy định"]
    B_TECH["Lỗi kỹ thuật xử lý/truy xuất nguồn<br/>giữ lỗi riêng; chưa kết luận nghiệp vụ"]
    B_RESULT{"Kết quả kiểm tra"}
    B_FACT["Thiếu/mờ/mâu thuẫn dữ kiện<br/>hỏi người nộp hoặc người sở hữu nguồn"]
    B_POLICY["Quy định chưa đủ để xử lý<br/>hỏi người phụ trách chính sách"]
    B_AUTHORITY["Cần quyết định ngoài quyền tự xử lý<br/>gửi người có thẩm quyền tương ứng"]
    B_RESPONSE["Nhận phản hồi có căn cứ và đúng phạm vi<br/>lưu, kiểm tra lại; không lấy đồng ý làm sự thật"]
    B_BLOCK["Ghi khoản/hồ sơ không đủ điều kiện<br/>nếu cấm rõ và không có ngoại lệ; không chi mới"]
    B_REPORT["Hoàn tất báo cáo kiểm tra<br/>dữ kiện, nguồn, phép tính, quy định và kết quả"]
    B_REVIEW["Kế toán/người có quyền rà soát báo cáo"]
    B_DECISION{"Quyết định tài chính"}
    B_EDIT["Sửa dữ liệu, số tiền hoặc điều kiện<br/>lưu phiên bản và xét lại quyền/phạm vi"]
    B_TO_A["Quay A: kiểm tra phần bị ảnh hưởng<br/>rồi chạy lại B; không dùng kết quả/duyệt cũ sai phạm vi"]
    B_DENIED["Từ chối cấp ứng; lưu lý do, không chi mới<br/>không tự hủy cho phép công tác hoặc xóa tiền đã chi"]
    B_APPROVED["Lưu phê duyệt tiền có phạm vi/phiên bản<br/>hoặc căn cứ sử dụng phê duyệt hợp lệ đã có"]
    B_EXISTING{"Khoản ứng của đề nghị này<br/>đã thực chi đến đâu?"}
    B_CURRENT{"Còn được phép thực hiện chi<br/>với dữ liệu và quyền hiện tại?"}
    B_PAY["Con người thực hiện chi tiền bên ngoài app"]
    B_PAY_RESULT{"Kết quả chi thực tế"}
    B_PART["Ghi nhận phần thực chi có nguồn<br/>chờ người phụ trách xử lý phần còn lại"]
    B_UNKNOWN["Chưa biết tiền đã đi hay chưa<br/>đối chiếu tại nguồn, không thử chi trùng"]
    B_FAILED["Thất bại đã xác định; lưu nguyên nhân<br/>sửa/khắc phục, kiểm tra lại trước lần chi mới"]
    B_RECORDED["Ghi số thực chi/thực nhận đã xác minh<br/>giữ nguồn, không dùng số đề nghị thay thế"]
    B_TO_C["Sau công việc hoặc khi hủy có khoản ứng<br/>sang sơ đồ C để quyết toán"]

    B_START --> B_CHECK
    B_CHECK -->|"Xử lý được"| B_RESULT
    B_CHECK -->|"Lỗi kỹ thuật"| B_TECH
    B_TECH -->|"Khắc phục và chạy lại có kiểm soát"| B_CHECK
    B_RESULT -->|"Vướng dữ kiện"| B_FACT --> B_RESPONSE --> B_CHECK
    B_RESULT -->|"Ngoài phạm vi quy định"| B_POLICY --> B_RESPONSE
    B_RESULT -->|"Vượt quyền tự xử lý"| B_AUTHORITY --> B_RESPONSE
    B_RESULT -->|"Đã rõ không được phép"| B_BLOCK
    B_RESULT -->|"Đủ căn cứ, không còn vướng mắc"| B_REPORT --> B_REVIEW --> B_DECISION
    B_DECISION -->|"Yêu cầu sửa hoặc duyệt số/điều kiện khác"| B_EDIT --> B_TO_A
    B_DECISION -->|"Phát hiện sai sót hoặc vướng mắc mới"| B_EDIT
    B_DECISION -->|"Từ chối"| B_DENIED
    B_DECISION -->|"Phê duyệt hoặc dùng phê duyệt đủ căn cứ đã có"| B_APPROVED --> B_EXISTING
    B_EXISTING -->|"Đã thực chi đủ theo phê duyệt"| B_RECORDED
    B_EXISTING -->|"Mới một phần"| B_PART
    B_EXISTING -->|"Chưa xác định"| B_UNKNOWN
    B_EXISTING -->|"Chưa chi, nguồn đủ để kết luận"| B_CURRENT
    B_CURRENT -->|"Không hoặc cần kiểm tra lại"| B_TO_A
    B_CURRENT -->|"Có"| B_PAY --> B_PAY_RESULT
    B_PAY_RESULT -->|"Thành công có căn cứ"| B_RECORDED
    B_PAY_RESULT -->|"Một phần"| B_PART
    B_PAY_RESULT -->|"Không xác định"| B_UNKNOWN
    B_PAY_RESULT -->|"Thất bại đã xác định"| B_FAILED --> B_EXISTING
    B_PART -->|"Có cập nhật/xác nhận phần tiền thực tế"| B_EXISTING
    B_PART -->|"Cần đổi số tiền hoặc điều kiện được duyệt"| B_EDIT
    B_UNKNOWN -->|"Đã đối chiếu được"| B_EXISTING
    B_RECORDED --> B_TO_C
    B_BLOCK -->|"Nếu có hoặc chưa rõ tiền đã chi"| B_TO_C
    B_DENIED -->|"Nếu có hoặc chưa rõ tiền đã chi"| B_TO_C
    B_DENIED -->|"Nếu nộp lại có thay đổi"| B_EDIT
```

Các ranh giới của B:

- **Cho phép công tác không phê duyệt tiền ứng.** Công tác đã được phép vẫn có thể thiếu dự toán/căn cứ hoặc đề nghị số tiền không phù hợp.
- **Từ chối cấp ứng không hủy công tác.** Quyết định đi công tác còn hiệu lực hay không phải xét riêng. Nếu vẫn đi mà không nhận ứng, việc hỗ trợ hoàn trả sau chi cần phạm vi/policy tương ứng, không được suy “không có ứng” từ lịch sử thiếu.
- **Tiền đã chi vẫn phải xử lý khi hồ sơ bị từ chối.** A_REJECT, B_BLOCK và B_DENIED là ngừng cho phép/chi mới; nếu có tiền thực tế, lưu nghĩa vụ còn mở và đi C hoặc quy trình xử lý phù hợp. Không tạo số dư bằng 0 chỉ vì có từ chối.
- **Người duyệt thay số tiền:** không thay trực tiếp kết quả kiểm tra thành Approved. Ví dụ muốn duyệt 4 triệu thay vì 5 triệu: ghi điều chỉnh, kiểm tra lại theo phiên bản và phạm vi, rồi mới dùng phê duyệt tương ứng. Không tự cắt về hạn mức để tạo kết quả xanh.
- **Giữ riêng các số tiền:** số nhân viên đề nghị gốc, số người duyệt đang đề xuất, số được phê duyệt và số thực chi/thực nhận. Việc người duyệt đề xuất 4 triệu không sửa lịch sử thành nhân viên chỉ xin 4 triệu. Cơ chế chấp nhận số duyệt khác đề nghị phải được rulebook xác định.
- **Một phần không tự là hoàn tất:** ghi các khoản đã thực chi, giữ phần chưa xử lý. Việc chốt số thực cấp thấp hơn số duyệt hoặc chi thêm cần quyết định đúng quyền; không mặc định được phép chi từng phần.
- **Không tìm thấy giao dịch chưa chắc chưa chi.** Nhánh “chưa chi” cần nguồn đủ cho phạm vi đã công bố. Với kết quả không xác định, phải đối chiếu trước lần chi khác.
- **Từ chối khoản bị cấm:** nếu chỉ một khoản bị cấm, ghi rõ khoản đó; hồ sơ sửa cần đánh giá lại. Chưa được từ chối toàn bộ hay bỏ các phần chưa rõ nếu policy/căn cứ không cho phép.

## 4. Sơ đồ C — Quyết toán, sửa/từ chối và đối chiếu chi/thu cuối

```mermaid
flowchart TD
    C_START["Sau công việc, hoặc hủy công việc có tiền ứng<br/>tiếp nhận hồ sơ quyết toán/xử lý khoản ứng"]
    C_SUBMIT["Nhân viên gửi bảng kê và chứng từ<br/>kèm nguồn tiền ứng, chi trực tiếp, chi/thu đã có"]
    C_CHECK["Hệ thống đọc và đối chiếu<br/>chất lượng, từng khoản, policy, trùng/phân bổ<br/>người trả, tiền ứng và lịch sử trong phạm vi"]
    C_ITEMS["Ghi phần đã xác minh và khoản không đủ điều kiện<br/>giữ đầy đủ vấn đề chưa giải quyết"]
    C_OPEN{"Còn vướng mắc ảnh hưởng<br/>kết quả quyết toán cuối?"}
    C_ASK["Chuyển câu hỏi đúng loại và đúng người<br/>chưa chốt tổng/chiều tiền cuối"]
    C_UPDATE["Nhận bổ sung hoặc quyết định theo quyền<br/>lưu phiên bản; kiểm tra lại phần bị ảnh hưởng"]
    C_CALC["Chương trình tính số tiền và chiều tiền<br/>từ chi phí đủ căn cứ và toàn bộ chi/thu liên quan"]
    C_REPORT["Hoàn tất báo cáo quyết toán đề xuất<br/>có nguồn, phép tính, phần không chấp nhận và lý do"]
    C_REVIEW["Kế toán/người có quyền rà soát kết quả"]
    C_DECISION{"Quyết định tài chính"}
    C_DENIED["Từ chối phê duyệt; lưu lý do<br/>khoản ứng/nghĩa vụ chưa xử lý vẫn còn mở"]
    C_CURRENT{"Phê duyệt và dữ liệu<br/>còn phù hợp để xử lý tài chính?"}
    C_DIRECTION{"Chênh lệch đã được phê duyệt<br/>sau đối trừ chi/thu đã xác minh"}
    C_PAY["Con người thực hiện chi thêm cho nhân viên"]
    C_RETURN["Nhân viên hoàn lại; người phụ trách ghi nhận thu"]
    C_MOVEMENT{"Đã xác minh chi/thu đúng và đủ<br/>cho quyết định đang có hiệu lực?"}
    C_WAIT["Giữ chờ: ghi phần thực tế có căn cứ<br/>xử lý thất bại/một phần/chưa rõ; không chi trùng"]
    C_FINAL["Kế toán đối chiếu cuối theo policy<br/>không còn khoản/nghĩa vụ cần xử lý mới đóng hồ sơ"]
    C_TECH["Lỗi kỹ thuật; lưu lỗi và phần kết quả còn hợp lệ<br/>không kết luận hồ sơ sai hoặc tiền bằng 0"]

    C_START --> C_SUBMIT --> C_CHECK
    C_CHECK -->|"Đọc/xử lý được"| C_ITEMS --> C_OPEN
    C_CHECK -->|"Timeout hoặc output không hợp lệ"| C_TECH
    C_TECH -->|"Khắc phục và chạy lại có kiểm soát"| C_CHECK
    C_OPEN -->|"Có"| C_ASK --> C_UPDATE --> C_CHECK
    C_OPEN -->|"Không"| C_CALC --> C_REPORT --> C_REVIEW --> C_DECISION
    C_DECISION -->|"Yêu cầu sửa hoặc phát hiện sai sót"| C_UPDATE
    C_DECISION -->|"Từ chối"| C_DENIED
    C_DECISION -->|"Phê duyệt hoặc dùng phê duyệt đủ căn cứ đã có"| C_CURRENT
    C_CURRENT -->|"Không hoặc cần làm rõ"| C_UPDATE
    C_CURRENT -->|"Có"| C_DIRECTION
    C_DENIED -->|"Nếu sửa/nộp lại hoặc có quyết định xử lý mới"| C_UPDATE
    C_DIRECTION -->|"Công ty còn phải trả"| C_PAY --> C_MOVEMENT
    C_DIRECTION -->|"Nhân viên còn phải hoàn"| C_RETURN --> C_MOVEMENT
    C_DIRECTION -->|"Cân bằng đã xác minh"| C_FINAL
    C_MOVEMENT -->|"Đúng và đủ, có căn cứ"| C_FINAL
    C_MOVEMENT -->|"Thất bại, một phần hoặc chưa rõ"| C_WAIT
    C_WAIT -->|"Nguồn chi/thu được cập nhật: tính lại phần còn lại"| C_UPDATE
```

Trong C, khoản công ty đã trả trực tiếp vẫn có thể là chi phí công việc hợp lệ nhưng không phải tiền hoàn cho nhân viên. Tiền ứng là thực nhận/phân bổ đã xác minh. Phải tính cả khoản đã hoàn/đã được trả thêm, khoản hoàn tiền và lịch sử có ảnh hưởng theo phạm vi; không dùng công thức đơn giản cho mọi tình huống.

Từ chối phê duyệt quyết toán không tự biến mọi khoản chi thành 0 hoặc yêu cầu nhân viên hoàn toàn bộ tiền ứng. Phải giải quyết lý do từ chối và xác định nghĩa vụ theo dữ kiện/policy. Trường hợp cân bằng 0 phải có căn cứ, không phải kết quả thay cho dữ kiện thiếu. Quyết toán đề xuất khác việc đóng nghĩa vụ tài chính.

## 5. Chuyển tiếp phải đi tới ai và quay về đâu?

| Vấn đề | Người xử lý theo vai | Cần nhận được gì trước khi chạy lại? |
| --- | --- | --- |
| Thiếu thông tin trong khai báo/tài liệu | Người nộp, hoặc người có nguồn gốc tài liệu. | Dữ kiện bổ sung/chứng cứ rõ; không buộc xác nhận con số họ không biết. |
| Không khớp người trả/tiền ứng/giao dịch | Người phụ trách nguồn thanh toán. | Liên kết, trạng thái, số tiền thực tế và phạm vi nguồn có thể dùng. |
| Quy định chưa bao phủ trường hợp | Người phụ trách chính sách và người quyết định được policy giao. | Cách xử lý có phạm vi/hiệu lực; không lấy ngoại lệ riêng làm policy chung. |
| Cần quyết định vượt quyền tự xử lý | Người có thẩm quyền tương ứng. | Quyết định cho phép/từ chối có nội dung cụ thể; không thay cho dữ kiện còn nghi vấn. |
| Người duyệt phát hiện kết quả sai | Người cung cấp dữ kiện hoặc người sở hữu logic/quy định liên quan. | Chỉnh sửa có căn cứ; không bấm Override để giấu lỗi. |
| Timeout/invalid provider output | Người vận hành và cơ chế xử lý lỗi kỹ thuật. | Khắc phục/chạy lại; không gắn thành nhân viên thiếu chứng từ. |

Các nhánh trả lời đều đi qua kiểm tra lại; không nối “con người đồng ý” trực tiếp tới chi tiền. Người không có đúng vai không thể trả lời thay chỉ vì đang mở hồ sơ. Các chức danh trong sơ đồ là trách nhiệm logic; danh sách quyền cụ thể chưa chốt.

## 6. Điều kiện áp dụng ở mọi bước

| Sự kiện | Xử lý đề xuất | Điều không được làm |
| --- | --- | --- |
| Sửa người, công việc, ngày, số tiền, chứng từ, nguồn hoặc policy | Lưu phiên bản, đánh giá ảnh hưởng, kiểm tra lại kết quả/quyền/phê duyệt liên quan. | Dùng kết quả hoặc phê duyệt không còn phù hợp để thực hiện hành động mới. |
| Stop trong lúc xử lý | Dừng lần xử lý; lưu trạng thái. Kết quả provider đến muộn không được chốt/hành động dưới lần chạy đã dừng. | Coi Stop là thu hồi được tiền đã chuyển hoặc xóa nghĩa vụ đã phát sinh. |
| Nhân viên rút đề nghị trước khi chi | Ghi nhận rút, dừng hành động chi mới; xác minh trạng thái tiền nếu còn chưa rõ. | Giả định chưa chi chỉ vì người dùng bấm rút. |
| Hủy công tác sau khi đã nhận ứng | Lưu hủy và tiền thực tế; xử lý chứng từ đã phát sinh/hoàn tiền/thu hồi trong C theo policy. | Xóa hồ sơ và số tiền ứng. |
| Import hồ sơ đã duyệt/đã chi | Xác minh căn cứ/trạng thái trong phạm vi; dùng lịch sử có căn cứ, không tạo xin ứng/chi thêm trùng. | Coi chữ ký OCR là quyền hợp lệ hoặc số đề nghị là số đã nhận. |
| Override/correct decision | Giữ quyết định gốc, lý do, vai/phạm vi và lịch sử; kiểm tra lại căn cứ và quyền cần thiết. | Cho qua chất lượng/số học/dữ kiện bắt buộc hoặc điều cấm không có ngoại lệ. |
| Chờ không có phản hồi | Giữ hồ sơ chờ và vấn đề/người nhận. Đôn đốc/thời hạn chỉ theo cơ chế sẽ được chốt. | Tự chuyển thành đủ điều kiện sau một khoảng thời gian. |
| Đã có chi/thu thật rồi phát hiện lỗi | Giữ nguyên lịch sử tiền thực tế, mở vấn đề đối chiếu/điều chỉnh theo quyền. | Sửa quá khứ thành chưa có giao dịch để làm báo cáo khớp. |

## 7. Các đường đi cần dùng để review sơ đồ

Đây là checklist tình huống thiết kế, chưa phải test đã chạy hoặc gold đầy đủ.

1. Form đầy đủ, chưa có phép công tác → quản lý cho phép → kiểm tra ứng → duyệt tiền → thực chi có nguồn → C.
2. Có quyết định công tác đúng phạm vi, nhưng form thiếu số tiền/dự toán → A_ASK; chưa được nhảy sang duyệt tiền.
3. Có quyết định công tác nhưng form khai khác ngày/địa điểm/người → làm rõ/sửa, xét lại phạm vi cho phép.
4. Nhập giấy chưa ký/chưa được phép → xem xét công tác; không coi đường upload là đã duyệt.
5. Quản lý từ chối công tác → không chi mới; nếu đã có tiền bên ngoài thì vẫn xử lý khoản ứng.
6. Dữ kiện rõ, khoản bị cấm và không ngoại lệ → ghi không đủ điều kiện ở đúng phạm vi.
7. Có nhiều vấn đề (thiếu nguồn tiền + ngoài policy) → giữ đủ, không hoàn tất sau chỉ một câu trả lời.
8. Kế toán trả hồ sơ hoặc muốn số tiền khác → phiên bản/điều kiện mới, kiểm tra lại; không sửa số rồi chi ngay.
9. Người có quyền từ chối tiền ứng dù cho phép công tác → từ chối ứng, giữ quyết định công tác riêng.
10. Giấy ứng đã duyệt/đã thực chi được import → dùng nguồn hiện có; không chi lần hai.
11. Chi thất bại đã xác định → lưu và xử lý; kết quả không rõ → đối chiếu trước lần chi khác.
12. Chi mới một phần hoặc số thực cấp thay đổi → giữ số thực tế; không dùng số được duyệt làm số nhận.
13. Quyết toán có một chứng từ mờ ảnh hưởng tổng → giữ phần đã xác minh, C_ASK, chưa chốt chênh lệch.
14. Người duyệt từ chối quyết toán → giữ nghĩa vụ mở; không tự đóng hoặc suy hoàn lại toàn bộ.
15. Quyết toán được duyệt → ba chiều kết quả: công ty trả thêm / nhân viên hoàn lại / cân bằng; chi/thu phải xác minh trước đóng.
16. Hủy sau nhận ứng, sửa sau duyệt, Stop và output đến muộn → giữ sự kiện thật và kiểm soát hành động mới.

## 8. Những điểm còn cần quyết định trước khi trở thành spec

Field/căn cứ bắt buộc theo từng giai đoạn; nguồn nào được công nhận và độ bao phủ lịch sử; ai có quyền xác nhận/cho phép/duyệt; policy/hạn mức/ngoại lệ; khi nào từ chối khoản hay cả hồ sơ; điều chỉnh số tiền, chi nhiều đợt và đóng khoản ứng; thời hạn/chờ/rút/nộp lại; tương tác để gom nhiều quyết định vào một lượt. Các nhánh ở đây đưa vấn đề ra rõ để review, không âm thầm chốt những chi tiết đó.

# R4.1 — Lõi dữ kiện và hợp đồng nguồn cho MVP

Ngày: 09/10/2026 · Trạng thái: **CHỦ DỰ ÁN CHO TIẾP R4.2 TỪ LÕI NÀY; EVIDENCE RULE/NGƯỠNG/SCHEMA CODE CÒN CHỐT TIẾP**.

Căn cứ [R3](R3_MVP_SCOPE_DRAFT.md) và [walkthrough](R2_CASE_WALKTHROUGH.md). Mục tiêu phần này là xác định dữ kiện nào cần dùng, từ đâu và đủ cho phép kiểm tra nào. Tiếp theo R4 mới chốt quy tắc áp dụng/bằng chứng, hạn mức, authority/ngoại lệ và quality gates; không dùng bảng này làm đảm bảo source ngân hàng/pháp lý thật.

Bản này đã bổ sung sau [review R4.1](../reviews/2026-10-09-r4-data-sources/REVIEW.md). [Snapshot](../reviews/2026-10-09-r4-data-sources/TARGET_R4_DATA_SOURCE_DRAFT.md) và kết luận gốc giữ nguyên; bản bổ sung chưa được review độc lập lại hoặc chủ dự án chốt.

Sau bản này và phần trạng thái R4.1, chủ dự án yêu cầu tiếp tục R4.2. Lõi dữ kiện được dùng làm căn cứ thiết kế kế tiếp; không coi đó là đã duyệt những bộ evidence hoặc threshold chưa được trình bày. [R4.2 applicability/evidence](R4_EVIDENCE_RULES_DRAFT.md) là phần đang đề xuất để review.

Bộ evidence R4.2 và policy ngân sách tổng/ba vai sau đó đã được đồng ý. [R4.4 nguồn tiếp nhận](R4_SOURCE_INTAKE_CONTRACT.md) cụ thể hóa packet trước/sau, bảng nguồn tài chính nhập/import, nguồn đủ cho từng check và coverage theo công việc để review tiếp; không cập nhật verdict/snapshot lịch sử hoặc tuyên bố runtime.

## 1. Bốn lớp phải giữ khác nhau

| Lớp | Ví dụ | Ý nghĩa |
| --- | --- | --- |
| Lời khai/đề nghị | A khai trả vé 3 triệu, chọn PERSONAL, đề nghị giải quyết phần đó | Giữ nguyên nội dung/phạm vi người nộp; không tự là proof đã trả |
| Tài liệu/nguồn gốc | Vé, receipt, bản ghi tài chính/export, quyết định được cung cấp | Lưu original và origin/scope; một file không là một expense hoặc một money event |
| Dữ kiện đề xuất/chuẩn hóa | Trích amount 3.000.000 VND tại doc/page/ref; booking/payee ứng viên | Giữ rawvalue/normalizedvalue/source/điểm chưa rõ. AI đọc/ghép là proposal; số đọc rõ không chứng minh payer |
| Kết quả đủ căn cứ cho check cụ thể | Số invoice đủ cho arithmetic; event receipt đủ cho một phần payment coverage | Chỉ được dùng khi source/quality/quan hệ/rule áp dụng đủ. Đạt một check không tự đạt cả case |

Human confirmation là nguồn/hành động riêng: ai/vai/phạm vi xác nhận fact gì, dựa nguồn nào theo policy. Xác nhận OCR đọc đúng khác financialapproval và khác xác nhận actualmoney. Không nâng authority của nguồn chỉ vì người dùng bấm đồng ý hoặc chọn vai demo.

Mỗi confirmation có mục tiêu rõ: **cách đọc nội dung source**, **fact về sự kiện/thế giới thực**, hoặc **quyết định/approval**. “Đúng3triệu” đơn độc chưa biết đang xác nhận gì; cần gắn câu hỏi/field/source/vai/phạm vi tương ứng. Xác nhận reading không tạo payer/actualreceipt, approval không thay proof; factualconfirmation chỉ dùng cho check được rulebook cho phép và có căn cứ/vai phù hợp.

## 2. Lõi dữ liệu nghiệp vụ đề xuất

| Nhóm | Dữ kiện tối thiểu để xét trong phạm vi liên quan |
| --- | --- |
| Hồ sơ/đề nghị | Người/công việc hoặc context để xác định công việc mới; mục đích/phạm vi khoản; phiên bản, quan hệ bản mới/sửa/bổ sung/nộp lại; lời khai/số đề nghị và chiều nếu rõ |
| Khoản/phần chi | Nội dung/mục đích, ngày/số tiền/currency đã biết, giá trị chứng từ vs phần được đề nghị, người trả theo khai báo/nguồn; refs và trạng thái từng fact cần dùng |
| Tài liệu/dòng source | Document/source ID, loại nguồn ứng viên, original, origin/người cung cấp/thời điểm nhận, ref page/dòng/đoạn cho fact. Locator chỉ tới vị trí thật có thể mở, không bịa tọa độ hoặc ref |
| Sự kiện tiền | Số gross/currency, bên trả/bên thực nhận, loại/chiều/quan hệ, thời điểm tiền khác ngày duyệt, trạng thái theo nguồn và kết luận receipt khi đủ; source/reference trong phạm vi issuer; phân bổ liên quan khoản/người/công việc |
| Policy/quyết định | Phiên bản/hiệu lực/phạm vi rule, loại quyền/người quyết định, source và nội dung/số/điều kiện/phạm vi, report/đề nghị đã xét. Chưa có rule/decision giữ chưa rõ thay vì auto suy |
| Phạm vi tập nguồn | Người/công việc/loại sự kiện được phủ, từ–đến/as-of, origin/filter/căn cứ xác định coverage, người có thể giải thích/xác nhận trong scope; giới hạn ngoài nguồn |

“Tối thiểu” phụ thuộc phép kiểm tra và policy, không ép mọi field phải có để lưu tài liệu/đọc phần độc lập. Missing/ambiguous/conflicting được giữ riêng với giá trị; không dùng numeric0, chuỗi giả hoặc ID nhân tạo để thay fact chưa biết. Technicalerror khác sourcefactunknown. Một trường không liên quan không chặn check không phụ thuộc nó.

Ba trục độc lập: **chất lượng/độ rõ của từng fact**, **trạng thái sự kiện thanh toán theo source và kết luận receipt**, **trạng thái xử lý kỹ thuật**. PAID đọc rõ nhưng amount mờ giữ rawstatePAID và amountunknown, chưa finalmoney. Provider xử lý thành công không tự verifiedfact; provider lỗi không làm sourcefact bị cấm về nghiệp vụ. Kết quả đủ dùng cho check gắn fact/source/rule/version, không một boolean Verified chung cho mọi phép kiểm tra.

IDs nội bộ của case/document/row có thể sinh để lưu và tham chiếu; không dùng chúng thay invoiceNo/banktransactionref/employeeidentity ngoài nguồn hoặc làm căn cứ khớp event. Payment attempt có số/party/rawstate rõ vẫn có thể chưa actualreceived; các ngày upload/sourceissue/attempt/receipt/asof cần giữ đúng nghĩa theo dữ liệu có.

Nguồn có thể chứa nhiều khoản và một khoản có nhiều source. Dòng nguồn hỗ trợ/mâu thuẫn/khoản ứng viên cần xác định, không tự cộng. Quantity/unit/tax/discount cần khi rule hoặc arithmetic dựa vào chúng; không ép mọi receipt thành hóa đơn VAT hoặc bill nào cũng có toàn bộ fields.

## 3. Nguồn nào trả lời câu hỏi nào?

| Dữ kiện cần kết luận | Source ứng viên | Guard |
| --- | --- | --- |
| Giá trị/chi tiết khoản chi | Original invoice/receipt/vé và ref trích xuất | Source có giá trị khoản; chưa tự chứng minh payer/payment hoặc đủ policy |
| Nhân viên/công ty đã trả phần nào | Receipt/paymentrecord/sourcebank hoặc confirmation phù hợp phương thức/rule | Cần amount/parties/quan hệ và kết quả receipt theo policy; tên company trên invoice hoặc PERSONAL không là kết luận payer |
| Ứng thực nhận | Bản ghi sự kiện tiền và source gắn bên nhận/người/công việc | Giấy xin/duyệt ứng chỉ chứng minh đề nghị/decision; không thay actualreceived |
| Hoàn chi phí/tiền trả lại | Gross event/source/quan hệ đúng loại và phía thực nhận | P là A thực nhận; RA/RP là company thực nhận lại đúng khoản. Refundvendor không tự là RA/RP |
| Công việc/eligibility/authority | Nguồn công việc/căn cứ cho phép, policy/decision đúng scope | Source công tác không tự approveamount; decision không waive fact/quality/mathhardgate |
| Không có event ảnh hưởng / số0 | Tập nguồn đủ coverage tới mốc cần thiết hoặc confirmation absence theo rule chấp nhận | Không tìm thấy trong ledger thiếu/cắt/filter khác không chứng minh0 hoặc “chưa từng ứng”. Balance0 cũng khác neveradvanced |

R4.1 không tuyên bố một loại file luôn đủ cho payment. Rulebook phần tiếp theo phải định nghĩa các bộ source/confirmation được chấp nhận theo phương thức/loại khoản và owner; không bắt bank statement hay employeeack cho mọi case. Vai tài chính tự khai hoặc export có cột Paid vẫn phải kiểm tra ý nghĩa/source, không là chuẩn xác thực ngân hàng/identity thật.

## 4. Dùng bảng tài chính nhập/import trong MVP

Đề xuất một tập nguồn tài chính được cung cấp/nhập/import, giữ refs/origin và coverage cùng gross events. Dữ liệu có thể nhiều hồ sơ/người; mỗi event có payer/payee thực tế riêng, employee/case liên quan là quan hệ, không ép payee=employee cho companydirect trả vendor. Operator không cần map đúng event theo từng case trước để hệ thống tự gọi là auto; relation có thể proposal/check hoặc câu hỏi nếu thiếu.

Tách ba vai: **người đưa source vào app**, **bên/hệ thống phát hành dữ liệu**, **người có quyền giải thích/xác nhận coverage hoặc fact trong scope**. Có thể cùng một người nhưng không suy ba vai là một. Employee đưa export company không làm nó thành source do employee phát hành; finance upload một file không tự authenticatedissuer. Cùng nội dung và provenance phát hành đủ như nhau thì đổi uploader không tự đổi factualauthority; nội dung giống nhưng provenance chưa rõ vẫn cần kiểm tra, không cam kết mọi bản copy là thật.

Source IDs/document IDs/internal row IDs không tự là cùng namespace transaction. Một transfer có ref ngân hàng và số phiếu khác nhau có thể là cùng event nếu có căn cứ; cùng amount/date/payee chưa đủ gộp. Một event/phần không đóng góp hai lần vào các nhóm tiền; splitallocation cần source và tổng trong phạm vi đúng, chưa rõ thì chặn phép tính ảnh hưởng.

Coverage metadata là khai báo có source/giới hạn/owner cần được rule xác định đủ, không chứng minh nhìn thấy mọi ngân hàng/công ty. Các fixture giả lập và roleauthority được công bố là giả lập; không dùng chúng tuyên bố dữ liệu thực đã authenticated. Source mới cập nhật/ảnh hưởng thì lưu version và đánh dấu kết quả/decision/action liên quan cần check lại theo ảnh hưởng.

## 5. Ví dụ giả lập để tránh nhầm

A khai vé3 PERSONAL; originalvé/source rõ amount3; finance source có event company→airline3 và booking/part liên quan. Các kết luận phải tách: amountvé3 có thể đủ cho arithmetic; companypaid coverage3 có thể đủ khi receipt/quan hệ/source đạt rule; lời khai A-personal vẫn là lời khai. Có nguồn độc lập cho A cũng trả hoặc fee khác thì đối chiếu phần/sự cố; không chọn một nguồn vì chức danh, tự suy gian lận hoặc biến toàn case thành approved.

Ảnh chỉ rõ số3 nhưng ngày/booking cần dùng mờ: arithmetic riêng có thể kiểm tra, eligibility/linkage phụ thuộc date/ref còn chưa rõ. Nativeform nhận contextnewwork nếu không có loanID; không tạo loanfake. Source lịch sử chỉ phủ1–15 mà mốc đốichiếu21 cần phần16–21: không defaultP0; hỏi đúngowner phần coverage thiếu.

Money actual0 có căn cứ không phải một giao dịch chi0 để hệ thống tự tạo. Company nhận return1 sau A nhậnadvance2 phải giữ hai events, không dùng net1 vừa cộng return1 lần nữa. Supplierrefund vềcompany khi A trả là ngoại lệ B7 đã chốt, không tự đưa vào coreformula.

## 6. Điều đề nghị chốt và bước kế tiếp

Đề nghị chốt **lõi nhóm dữ kiện và nguyên tắc source/ref/coverage**, dùng tập nguồn nhập/import có căn cứ cho MVP, không một schema mô tả mọi mẫu bill. Phần R4 tiếp theo chốt applicability, đủ evidence/confirmation theo method và từng profile trước/after, qualitygate, arithmetic/limits/authority/exception. Chưa được phép code từ R4.1 một mình hoặc tự làm confidence threshold để source thiếu qua.

Phép thử semantics chưa runtime: invoicecompanyname vs actualemployee receipt; approval2 vs actual1; Paidreturned vs receipt; refscope collision vs sameevent2sources; companyvendorpayee vs affectedemployee; coveragetruncated0unknown; balance0 afterreturnedadvance; factclear vscriticalfactblur; newworkwithoutadvance; moneyclassifierrefundvsreturn. Gold/sourceformats/activepolicy chốt độc lập trước evaluation.

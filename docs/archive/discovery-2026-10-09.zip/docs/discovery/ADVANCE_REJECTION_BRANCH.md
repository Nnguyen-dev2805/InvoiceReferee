# Nhánh từ chối trước chi và xử lý sau khi đã cấp ứng

Ngày: 08/10/2026 · Trạng thái: **SƠ ĐỒ TỔNG QUAN ĐỂ REVIEW**.

Sơ đồ này thay mũi tên gây nhầm từ “từ chối/không chi mới” sang quyết toán trong bản tổng quan. Đề nghị mới ở nhánh trái giả định chưa cấp tiền. Khoản đã cấp trước khi vào app có đường vào riêng, không được xem như tiền vừa phát sinh từ đề nghị bị từ chối.

Nhánh này đã được ghép vào [workflow tổng quan đầy đủ](WORKFLOW_OVERVIEW.md).

```mermaid
flowchart TD
    A["Đề nghị tạm ứng mới<br/>Chưa cấp tiền"]
    B{"Người có quyền<br/>duyệt tiền ứng"}
    R["Từ chối<br/>Lưu lý do"]
    E["Kết thúc đề nghị<br/>Không đi sang quyết toán"]
    P["Con người thực hiện chi<br/>Ghi nhận tiền thực tế có căn cứ"]
    L["Khoản ứng đã cấp từ trước<br/>Được đưa vào app và xác minh"]
    F["Đã có khoản ứng thực tế cần theo dõi"]
    C{"Công việc sau khi đã nhận ứng"}
    N["Tiếp tục/hoàn thành công việc<br/>Nộp hồ sơ quyết toán"]
    X["Bị hủy hoặc thay đổi<br/>Đối chiếu và xử lý khoản ứng đã cấp"]

    A --> B
    B -->|"Từ chối"| R --> E
    B -->|"Phê duyệt"| P
    P -->|"Tiền thực tế đã được xác minh"| F
    L --> F
    F --> C
    C -->|"Tiếp tục/hoàn thành"| N
    C -->|"Hủy/thay đổi"| X
```

- Không có đường từ R/E sang N/X. Tiền trong F đến từ P hoặc L, không đến từ việc từ chối.
- Phê duyệt không tự là đã chi; bước P phải ghi nhận sự kiện thực tế. Khi tiền chưa rõ, giữ chờ xác minh, không tự đi tiếp hoặc thử chi trùng.
- X dẫn tới đối chiếu chi phí/tiền thực tế và quyết định xử lý, không tự yêu cầu hoàn toàn bộ số ứng. Quyết toán/xử lý và điều kiện đóng được mô tả trong [workflow chi tiết](ADVANCE_SETTLEMENT_WORKFLOW_DRAFT.md).
- Nếu nhập hồ sơ cũ đã cấp tiền nhưng phát hiện thiếu căn cứ/không phù hợp, vẫn giữ sự kiện tiền thật và nghĩa vụ cần xử lý. Đó là vấn đề của khoản đã cấp, không phải trường hợp đề nghị mới bị từ chối trước chi.

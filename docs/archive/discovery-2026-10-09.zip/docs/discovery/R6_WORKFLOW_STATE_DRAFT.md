# R6 — Workflow và trạng thái hồ sơ

Ngày: 09/10/2026 · **CHỦ DỰ ÁN ĐÃ ĐỒNG Ý THIẾT KẾ WORKFLOW ĐỂ TIẾP R7 — CHƯA CODE, CHƯA KIỂM CHỨNG RUNTIME**.

Thiết kế dựa trên [ba vai](R4_ROLES_HANDOFF_POLICY.md), [ngân sách tổng](R4_WORK_BUDGET_POLICY.md), [nguồn đầu vào](R4_SOURCE_INTAKE_CONTRACT.md), [B7](B7_MVP_PROPOSAL.md), [B8/B9](B8_B9_MVP_PROPOSAL.md) và [tiêu chí R5.8](R5_CORPUS_REVIEW_AND_GATES.md). Không dùng code hiện tại để quyết định nghiệp vụ. Không thay spec vận hành cũ tại bước này.

## 1. Quy trình thủ công dùng để so sánh

Đây là **quy trình giả định để thiết kế phép so sánh**, chưa quan sát hay xác nhận tại doanh nghiệp thật. Không dùng nó làm bằng chứng đã tiết kiệm thời gian.

```mermaid
flowchart LR
    E["Nhân viên chuẩn bị đề nghị<br/>và tập hợp chứng từ"] --> A["Kế toán mở các nguồn<br/>tìm, ghép và tính toán"]
    A --> D["Người có quyền xem xét<br/>và quyết định"]
    D --> P["Con người thực hiện chi hoặc hoàn lại<br/>Kế toán đối chiếu thực nhận"]
    P --> C["Ghi kết quả và nghĩa vụ còn lại<br/>Đóng khi đã xử lý đủ"]
    A -->|"Thiếu hoặc mâu thuẫn"| E
    D -->|"Trả lại để làm rõ"| A
```

Giá trị cần chứng minh: hệ thống chuẩn bị việc tìm, ghép, kiểm tra và tính toán có căn cứ; kế toán rà soát kết quả và mở nguồn cần xác minh. Đo cả chuẩn bị đầu vào, bổ sung, rà soát, phê duyệt và đối chiếu tiền. Nếu nhập dữ liệu vào app mất nhiều hơn phần kiểm tra tiết kiệm được, sản phẩm chưa chứng minh hiệu quả.

## 2. Workflow tổng quan được đề xuất

Sơ đồ thể hiện các điểm bàn giao, không phải mọi bước đều cần màn hình hoặc lần bấm riêng. Có ba vai người dùng: nhân viên, kế toán, người duyệt có quyền. Hệ thống chuẩn bị và kiểm tra kết quả; không chuyển tiền.

```mermaid
flowchart TD
    subgraph PRE["Trước công việc — Tạm ứng"]
        A["Nhân viên gửi đề nghị<br/>Form hoặc hồ sơ có sẵn"] --> B["Hệ thống kiểm tra và chuẩn bị báo cáo<br/>Kế toán rà soát"]
        B -->|"Thiếu, sai hoặc mâu thuẫn"| R1["Bổ sung hoặc sửa đúng phần<br/>Kiểm tra lại phần ảnh hưởng"]
        R1 --> B
        B -->|"Đủ để xem xét"| D{"Quyết định công việc, ngân sách<br/>và ứng đã đủ, còn hiệu lực?"}
        D -->|"Chưa đủ"| M{"Người có quyền quyết định"}
        M -->|"Yêu cầu làm rõ"| R1
        M -->|"Từ chối"| N["Lưu từ chối và lý do<br/>Không chi mới theo yêu cầu này"]
        M -->|"Phê duyệt"| V["Kiểm tra quyền, điều kiện, phiên bản<br/>và phần tiền chưa thực hiện"]
        D -->|"Đã có, kể cả từ bên ngoài"| V
        V -->|"Được phép thực hiện"| P["Kế toán chi ứng ngoài app<br/>Hệ thống đối chiếu nhân viên thực nhận"]
        P -->|"Đã nhận đủ khoản ứng được duyệt"| W["Chờ hoàn thành công việc<br/>hoặc hủy để xử lý khoản ứng"]
        P -->|"Đang chờ hoặc mới nhận một phần"| T1["Giữ thực nhận và phần ứng còn lại<br/>Chờ thực hiện hoặc đối chiếu"]
        T1 -->|"Có kết quả mới hoặc đủ điều kiện tiếp tục"| V
    end

    subgraph POST["Sau công việc hoặc hủy — Quyết toán"]
        S["Tiếp nhận bảng kê, chứng từ<br/>và lịch sử tiền liên quan"] --> K["Hệ thống đối chiếu và tính kết quả<br/>Kế toán rà soát báo cáo có căn cứ"]
        K -->|"Còn vướng mắc"| R2["Bổ sung, sửa hoặc xin quyết định cần thiết<br/>Kiểm tra lại phần ảnh hưởng"]
        R2 --> K
        K -->|"Đủ căn cứ"| J{"Đã có quyết định quyết toán<br/>đúng phạm vi, còn hiệu lực?"}
        J -->|"Chưa có"| H{"Người có quyền duyệt quyết toán"}
        H -->|"Trả lại hoặc phát hiện lỗi"| R2
        H -->|"Từ chối"| N
        H -->|"Phê duyệt"| G["Kiểm tra điều kiện và phần còn phải xử lý<br/>Đối chiếu chi hoặc thu thực tế"]
        J -->|"Đã có"| G
        G -->|"Nguồn thiếu, sai lệch hoặc điều kiện chưa rõ"| R2
        G -->|"Chưa thực hiện đủ hoặc đang chờ"| T2["Giữ quyết định và phần còn lại<br/>Chờ thực hiện hoặc đối chiếu"]
        T2 -->|"Có kết quả mới hoặc đủ điều kiện tiếp tục"| G
        G -->|"Đủ căn cứ, không còn nghĩa vụ"| Z["Đóng theo phạm vi<br/>mốc và phiên bản đã kiểm tra"]
    end

    W --> S
    I["Nhân viên tự chi<br/>hoặc đã có tiền ứng bên ngoài"] --> S
    N --> O{"Tiền và nghĩa vụ đang có?"}
    O -->|"Xác nhận không có"| X["Kết thúc yêu cầu bị từ chối"]
    O -->|"Có, cần xử lý"| S
    O -->|"Chưa rõ"| R2
```

**Cách đọc những đường chưa vẽ chi tiết:**

- V không cho chi nếu điều kiện chưa đạt, có Stop, phiên bản cũ, nguồn/quyền chưa rõ hoặc lệnh cùng phần đang chờ. G cũng có cùng kiểm tra. Phần thiếu được chuyển đúng người; trạng thái chờ có căn cứ được giữ chờ.
- P hoặc G chưa xác định thực nhận thì chưa đi tiếp như đã hoàn thành. Nhận một phần giữ phần còn lại; đang chờ không tạo thực hiện trùng. T1/T2 là chờ có căn cứ, không mặc định cần nhân viên bổ sung chứng từ. P/G tiếp nhận cả kết quả thực hiện đã xảy ra; nếu đã nhận đủ thì chỉ đối chiếu, không chi lại. G không tự thực hiện khi báo cáo xong.
- S nhận cả hồ sơ tự chi: A bằng 0 chỉ khi có căn cứ đủ về lịch sử tiền ứng. Không tạo một khoản ứng giả bằng 0. Hồ sơ ngoài app có thể nhập đúng giai đoạn đã diễn ra, không bắt đi lại A đến P.
- H có thể ghi quyết định ngoại lệ/chấp nhận chi phí và phê duyệt tiền trong cùng quyết định đúng quyền. Nếu quyết định thay đổi phần chi phí được chấp nhận, kiểm tra lại phép tính và điều kiện trước G; không bắt duyệt lần hai khi quyết định đã bao phủ kết quả đó.
- G: S dương thì kế toán thực hiện công ty chi thêm; S âm thì nhân viên hoàn lại và kế toán đối chiếu công ty thực nhận; S bằng 0 thì kiểm tra đóng, không chuyển 0 đồng. Nhánh tự chi không có ngân sách trước phải có quyết định chấp nhận sau phát sinh phù hợp, không tự tạo ngân sách quá khứ.
- N từ chối một yêu cầu cụ thể. X là kết thúc yêu cầu đó, khác Z là hoàn tất quyết toán. O không suy rằng từ chối nghĩa là đã ứng; chỉ chuyển xử lý khoản ứng/nghĩa vụ nếu có căn cứ thực tế. Khi chưa rõ, hỏi nguồn thích hợp, không mặc định có hoặc không. Sau từ chối, S không tự cho chi lại theo yêu cầu cũ.

## 3. Hệ thống xử lý thế nào để tạo báo cáo?

Đây là workflow logic của công việc tự động B3/B7; chưa chọn OCR, model hoặc framework.

```mermaid
flowchart LR
    I["Nhận và giữ nguồn gốc<br/>phạm vi, mốc và phiên bản"] --> T["Xác định nghiệp vụ<br/>và kiểm tra áp dụng"]
    T --> E["Đọc dữ kiện có tham chiếu<br/>giữ phần chưa rõ"]
    E --> F["Xác thực dữ kiện, chất lượng<br/>ghép nguồn và chống trùng"]
    F --> C["Kiểm tra quy tắc, tiền và quyền<br/>tính khi đủ căn cứ"]
    C --> O{"Đủ cho kết quả kiểm tra?"}
    O -->|"Đủ"| R["Báo cáo hoàn thành<br/>kèm căn cứ và bước tiếp"]
    O -->|"Chưa đủ"| Q["Giữ phần đã rõ<br/>hỏi đúng người, đúng vấn đề"]
    Q --> A["Lưu câu trả lời, nguồn hoặc quyết định<br/>kiểm tra tính phù hợp"]
    A -->|"Hợp lệ: kiểm tra phần ảnh hưởng"| F
    A -->|"Không giải quyết được vấn đề"| Q
```

| Bước | Nhận gì và điều kiện | Tạo/lưu gì; ai giải quyết phần thiếu |
| --- | --- | --- |
| Tiếp nhận | Đề nghị, các tài liệu và lịch sử hiện có | Bản gốc, người cung cấp, phạm vi/mốc, revision; nhân viên hoặc kế toán bổ sung nguồn thuộc phía mình |
| Xác định nghiệp vụ | Giai đoạn và nội dung công việc | Các kiểm tra cần áp dụng; không để lựa chọn form né kiểm tra bắt buộc |
| Đọc nguồn | Tài liệu trong phạm vi | Giá trị đọc được, tham chiếu nguồn/vị trí, trường chưa rõ; cần bản rõ hoặc nguồn thay thế khi trường quan trọng không đọc được |
| Xác thực và ghép | Giá trị đọc, lời khai, xác nhận, nguồn tài chính | Facts đủ căn cứ, quan hệ khoản chi/giao dịch, bản trùng, vấn đề chất lượng/coverage; không dùng cùng số tiền/ngày để khẳng định cùng giao dịch |
| Quy tắc và tính toán | Facts và policy/quyền hiện áp dụng | Check/lý do, số đủ điều kiện hoặc chưa xác định; vấn đề policy/quyền chuyển đúng người có quyền |
| Báo cáo hoặc hỏi | Kết quả kiểm tra, các vướng mắc | Report tham chiếu nguồn; mỗi câu hỏi có owner, refs, điều cần cung cấp và phần đang bị chặn |
| Nhận phản hồi | Câu trả lời hoặc nguồn/quyết định mới | Lưu liên kết câu hỏi và nguồn; kiểm tra người/phạm vi/căn cứ, re-check phần ảnh hưởng trước khi giải quyết issue |

Các đầu ra trên cần được lưu gắn với hồ sơ và lần kiểm tra để truy vết. Cách lưu cụ thể thuộc R7; không đề xuất service hay cơ sở dữ liệu riêng cho từng hàng.

Lỗi kỹ thuật có thể xảy ra tại các bước xử lý: giữ nguồn và lỗi thật, không biến thành nhân viên thiếu hóa đơn. Đọc được cả tài liệu không có nghĩa số tiền quan trọng đã rõ. Các checks độc lập vẫn có thể hoàn thành; kết quả tiền cuối vẫn chưa xác định nếu thiếu facts ảnh hưởng.

## 4. Trạng thái: tách tiến trình, vướng mắc và tiền

Khuyến nghị không dùng một nhãn duy nhất như APPROVED để diễn tả cả hồ sơ. Cũng không tạo hàng chục trạng thái tổ hợp. Ở mức nghiệp vụ, cần biết **đang ở bước nào**, **đang chờ/thiếu điều gì** và **tiền nào đã thực nhận**. R7 mới chọn tên trường/API cụ thể.

| Tiến trình | Khi được vào | Điều kiện tiếp tục |
| --- | --- | --- |
| Đang kiểm tra | Có hồ sơ hoặc thay đổi cần kiểm tra | Lưu kết quả trên đúng nguồn/phiên bản; chuyển báo cáo cho kế toán khi phần cần rà soát đã đủ |
| Chờ kế toán rà soát | Có báo cáo kiểm tra để rà soát | Rà soát có căn cứ, giải quyết vấn đề; chuyển các nội dung cần quyết định, hoặc xác thực quyết định đã có |
| Chờ quyết định có quyền | Đủ facts cho nội dung xin quyết định, nhưng quyết định cần thiết chưa có | Quyết định đúng quyền/phạm vi/hiệu lực; không coi chờ quyết định thường quy là thiếu chứng từ |
| Chờ thực hiện hoặc đối chiếu tiền | Quyết định hiện áp dụng và điều kiện phù hợp | Thực hiện ngoài app, xác minh thực nhận đúng nghĩa vụ; chưa đủ thì giữ phần chưa hoàn thành |
| Chờ công việc kết thúc/nộp quyết toán | Khoản ứng đã đối chiếu đủ hoặc có căn cứ tiến trình tương ứng | Hoàn thành/hủy công việc và có nguồn đủ để xử lý quyết toán; không đóng vì đã nhận ứng |
| Xử lý nghĩa vụ còn lại sau từ chối | Yêu cầu bị từ chối nhưng có tiền/nghĩa vụ cần giải quyết | Nguồn và quyết định xử lý hợp lệ; không hồi sinh quyền chi của yêu cầu bị từ chối |
| Yêu cầu bị từ chối đã kết thúc | Từ chối có căn cứ; xác nhận không còn tiền/nghĩa vụ thuộc yêu cầu cần xử lý | Lưu lịch sử; không gắn nhãn đã hoàn tất một quyết toán chưa diễn ra |
| Đã đóng quyết toán | Quyết định đủ hiệu lực, tiền/nguồn đã đối chiếu đủ, không vướng mắc/Stop/nghĩa vụ còn lại | Nguồn mới có ảnh hưởng đi vào bản điều chỉnh liên kết; lần đóng cũ được giữ |

**Vướng mắc đi kèm**, thay vì nhân số trạng thái: thiếu/mâu thuẫn facts; cần quyết định ngoại lệ; chưa đủ quyền; lỗi kỹ thuật; tiền chờ/chưa rõ/sai lệch; thay đổi cần kiểm tra lại. Một hồ sơ có thể có nhiều vướng mắc, mỗi vướng mắc giữ người xử lý và phần bị chặn.

**Stop là điều khiển đi kèm tiến trình.** Sau khi đã ghi nhận Stop, không bàn giao/tạo hành động mới hoặc đóng từ kết quả muộn. Vẫn lưu nguồn và tiền thật đã xảy ra. Tiếp tục cần thao tác resume rõ ràng và kiểm tra lại phần cần thiết. Stop trong app không hủy giao dịch ngân hàng bên ngoài.

### Vòng đời của một câu hỏi

| Tình trạng | Ý nghĩa/chuyển tiếp |
| --- | --- |
| Đang chờ trả lời | Câu hỏi có owner, nội dung cụ thể, căn cứ và phần bị chặn; chưa trả lời không thành đồng ý |
| Đã nhận phản hồi, chưa xác thực | Có lời trả lời/nguồn/quyết định; chưa coi issue được giải quyết |
| Phản hồi chưa đủ | Sai người/phạm vi, không nguồn, mâu thuẫn hoặc gõ số thay chứng từ mờ: lưu lý do và yêu cầu đúng phần còn thiếu |
| Đã giải quyết | Nguồn/decision hợp lệ và re-check xác nhận vướng mắc đã hết; không suy toàn bộ hồ sơ đã duyệt/đóng |
| Không còn áp dụng | Revision thay thế làm câu hỏi cũ không còn phù hợp; giữ lịch sử và lý do, không tính là người dùng đã giải quyết |

Nhiều câu hỏi độc lập có thể được trả lời cùng lần; không hỏi lại phần đã đủ. Lệnh tiền có trạng thái chờ rõ thì ghi chờ. Tại mốc đối chiếu/hành động đã công bố mà chưa có outcome cần thiết, hỏi chủ nguồn về đúng lệnh/phần; không chờ vô hạn, tự coi thất bại hay hỏi ngay một dữ kiện chưa đến lúc có.

## 5. Dùng các case để phản biện workflow

Đây là walkthrough bằng kỳ vọng thiết kế, **không phải chạy pipeline hay control tests**. Catalogue tại [R5 corpus](eval_development/CORPUS_INDEX.md).

| Tình huống | Đường đi đúng | Đường đi sai cần ngăn |
| --- | --- | --- |
| Q01: E=5 triệu, ứng thực nhận A=2 triệu, chưa hoàn chi phí | Báo cáo S=+3 → kế toán rà soát → người có quyền duyệt → nhận đủ 3 có nguồn → kiểm tra đóng | Report +3 tự thành đã duyệt hoặc P=3 |
| Q03: E=3,3 triệu, A=4 triệu | S=−0,7 → quyết định → nhân viên trả, kế toán xác minh công ty nhận → kiểm tra đóng | Kế toán chuyển thêm hoặc tự khấu trừ lương |
| Q04: cùng nghĩa vụ đã duyệt, nhân viên đã nhận P=3 triệu, đủ nguồn/scope | S=0; dùng lại history và quyết định hợp lệ để kiểm tra đóng | Xin duyệt 0, tạo giao dịch 0 hoặc trả 3 lần nữa |
| Q08: số tiền khách sạn trên ảnh chưa rõ | Chờ bản rõ/nguồn thay thế → re-check khoản và tổng ảnh hưởng | Tổng phần đã đọc 2 trừ ứng 2 thành S=0 cho cả hồ sơ |
| Q13: T=9 triệu, B=8 triệu | Giữ actual T và B; xin quyết định ngoại lệ trong quyền; nếu kết hợp duyệt tiền thì re-check trước thực hiện | Cắt T xuống 8, tự nâng B hoặc bắt duyệt lại dù quyết định đã bao phủ |
| Q14: tính được +3 nhưng chưa người đủ quyền | Giữ phép tính; bổ sung căn cứ quyền hoặc chuyển đúng người đã biết có quyền | Role picker hoặc một approval sai phạm vi đủ cho chi |
| A01/A02: đề nghị mới / nhập ngoài app | Mới: xin các quyết định đang đề nghị. Nhập: dùng lại công việc/B đã duyệt còn hiệu lực; xin phần ứng còn thiếu | Đòi approval đang xin như chứng từ thiếu, hoặc xin lại mọi quyết định cũ |
| Từ chối, đã có ứng thực nhận bên ngoài | Lưu từ chối; giữ khoản ứng và xử lý nghĩa vụ theo nguồn/quyết định phù hợp | Xóa ứng, đóng sạch hoặc tự xác định phải thu toàn bộ ứng |
| Duyệt 3, nhận 2, phần 1 đang chờ | Giữ approved 3, actual 2, remaining 1; chưa đóng/tạo thực hiện trùng | Đổi quyết định thành 2 hoặc trả lại toàn bộ 3 |
| Chi sai người hoặc vượt số duyệt | Giữ raw event và sự cố; chưa cho hành động mới/đóng khi chưa giải quyết | Clip số, coi đúng nhân viên đã nhận hoặc tự chi bù/thu hồi |

## 6. Điều kiện kiểm soát phải có trong triển khai sau này

Các điều kiện này nối với C01–C07 tại R5.8, chưa có trace thực thi:

1. Chạy lại/copy không tạo chi/thu trùng. Tiền hoàn thành cùng nghĩa vụ chỉ giảm phần còn lại; không mặc định cần approval mới cho phần còn lại nếu quyền/điều kiện còn áp dụng và không còn pending/vướng mắc.
2. Quyết định tổng và khoản thực nhận là hai dữ kiện riêng. Sai người/vượt tiền không được bỏ hoặc ghép thành fulfillment đúng. Không tự retry ngân hàng.
3. Stop đã ghi nhận chặn hành động từ kết quả muộn; tiền thật vẫn được ghi nhận. Resume không tự khôi phục quyền đã hết hiệu lực.
4. Thay đổi ảnh hưởng facts, policy, quyền, số/chiều hoặc nghĩa vụ thì re-check hiệu lực phần liên quan. Ghi chú vô hại không làm mất tất cả quyết định. Receipt thực hiện đúng quyết định khác một khoản tiền lịch sử trước quyết định mới được phát hiện muộn.
5. Trả lời sai người/phạm vi hoặc không đủ nguồn không giải quyết câu hỏi; quyết định của sếp không thay nguồn tiền/số mờ.
6. Mốc tiền và mốc nhận nguồn tách riêng: tiền xảy ra sau mốc đang xét không nhập vào kết quả cũ; nguồn đến muộn xác nhận sự kiện trước mốc được đánh giá trong revision phù hợp, giữ lịch sử.
7. Sau đóng, thay đổi có ảnh hưởng tạo điều chỉnh liên kết. Received rồi hoàn trả/đảo giao dịch không tự mở lại quyền chi cũ; khác attempt thất bại trước khi thực nhận có căn cứ đủ.

Ngoại lệ refund/thu hồi/phân bổ ngoài phạm vi B7 tiếp tục giữ vấn đề và chuyển xử lý có căn cứ. Không mở rộng công thức để xử lý mọi quan hệ ba bên ở R6.

## 7. Nhận xét của lead và điều cần review

**Đề xuất giữ:** ba vai, hệ thống chuẩn bị báo cáo, kế toán rà soát, người có quyền quyết định, con người thực hiện tiền. Cách này chỉ tạo giá trị nếu bảng đối chiếu giúp giảm tìm/ghép/kiểm tra lại; một chuỗi trạng thái đẹp không chứng minh giá trị đó.

**Đề xuất tránh:** một trạng thái Approved chung; bắt đi tuần tự mọi bước với hồ sơ nhập; bắt sếp duyệt lại mọi lần re-check; đóng vì S=0; bắt kế toán kiểm lại từ đầu toàn bộ nguồn. Những cách này vừa dễ sai tiền vừa làm mất lợi ích hỗ trợ nghiệp vụ.

Rủi ro tương thích Challenge A vẫn mở: hệ thống tự hoàn thành B3/B7 check/report, nhưng toàn workflow có checkpoint con người. Chưa có xác nhận BTC chấp nhận phạm vi này; giữ phép đo cả tự chủ của công việc và công sức toàn luồng, không đổi mẫu số để che.

Chủ dự án đã đồng ý tiếp tục từ R6. [R7.1](R7_ARCHITECTURE_EVALUATION_DRAFT.md) chuyển các khối logic thành đề xuất kiến trúc gọn, ưu tiên chất lượng AI, đánh giá và triển khai từng luồng dùng được trên UI. Hợp đồng/spec chi tiết tiếp tục ở R7, trước khi R8 đối chiếu code. Việc đồng ý thiết kế không xác nhận runtime hoặc chất lượng đã đạt.

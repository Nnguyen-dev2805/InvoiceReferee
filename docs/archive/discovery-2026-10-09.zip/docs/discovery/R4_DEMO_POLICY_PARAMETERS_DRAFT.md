# R4.3 — Bảng tham số chính sách demo đề xuất

Ngày: 09/10/2026 · Trạng thái: **ĐỀ XUẤT CŨ ĐÃ ĐƯỢC THAY THẾ BỞI HƯỚNG NGÂN SÁCH TỔNG; GIỮ LÀM LỊCH SỬ, CHƯA TỪNG KÍCH HOẠT/CODE**.

Chủ dự án đã đồng ý bỏ trần riêng từng nhóm trong MVP. Bản hiện hành để review là [policy ngân sách tổng công việc](R4_WORK_BUDGET_POLICY.md); các mức5/10triệu và điều kiện theo ngày/đêm/sự kiện bên dưới không được tự kế thừa. [Snapshot review](../reviews/2026-10-09-r4-demo-policy/TARGET_R4_DEMO_POLICY_PARAMETERS_DRAFT.md) và verdict gốc giữ nguyên; phần nội dung cũ dưới đây là lịch sử đề xuất, không phải quy tắc hiện hành.

Căn cứ [R4.3](R4_MONEY_AUTHORITY_DRAFT.md), [evidence R4.2](R4_EVIDENCE_RULES_DRAFT.md), [phạm vi R3](R3_MVP_SCOPE_DRAFT.md). Lead tự review, không dùng subagent. Các con số được chọn để làm policy demo đơn giản có thể kiểm chứng; không có bằng chứng đây là định mức phù hợp thị trường, chính sách doanh nghiệp thật hoặc luật Việt Nam. Mục tiêu đánh giá là đúng theo policy công bố, không phải xác lập định mức tối ưu cho mọi công ty.

## 1. Phạm vi và cách áp dụng chung

Đề xuất mã policy `DEMO-TRAVEL-V1`, dành công tác trong nước, VND, mỗi case một nhân viên/một công việc. Mã này chỉ là tên bản dự thảo; thời điểm áp dụng và kích hoạt phải được ghi rõ khi chốt. Trước chi kiểm tra dự toán đúng nghĩa dự toán; sau chi kiểm tra thực chi có nguồn. Không dùng policy mới ghi đè quyết định/lịch sử cũ hoặc coi quyết định xin phép công tác là miễn mọi hạn mức.

Các mức dưới đây gồm thuế/phí thuộc dịch vụ được xét. Tách dịch vụ khác nếu nguồn cho phép; không phân bổ số tùy ý từ tổng bill. Một khoản/phần chỉ thuộc một nhóm; nhiều chứng từ mô tả cùng khoản không cộng lại. Phân loại theo mục đích/dịch vụ có căn cứ, không chọn nhóm có mức cao hơn để làm case đạt.

Check hạn mức trên chi phí công việc thuộc nhóm, trước khi chia người thanh toán; company-direct không thành phần E nhưng vẫn có thể liên quan mức áp dụng và báo cáo. Nguồn chỉ đủ phần nhân viên mà chưa đủ phần công ty liên quan thì không suy tổng trong mức. Đủ check hạn mức không thay các check chứng từ, purpose, payer, history hoặc authority.

## 2. Năm nhóm chi phí

| Rule | Nhóm | Mức/điều kiện thường quy đề xuất | Đơn vị và điều cần biết |
| --- | --- | --- | --- |
| DP-01 | Khách sạn | ≤1.500.000 VND/phòng-đêm | Giá phòng và thuế/phí lưu trú; ngày lưu trú, phòng-đêm có nguồn. Xét từng phòng-đêm, không lấy bình quân che một đêm vượt; nếu source không tách được khi cần thì làm rõ |
| DP-02 | Ăn cá nhân khi công tác | ≤500.000 VND/nhân viên/ngày công tác được phép | Cộng các bữa của cùng nhân viên/ngày; không nhân toàn bill theo số người chưa rõ, không gộp ngày để bù trừ mức |
| DP-03 | Tiếp khách phục vụ công việc | ≤3.000.000 VND/sự kiện | Có mục đích, bên được tiếp, ngày và liên kết công việc. Cộng các bill thuộc cùng sự kiện; không mỗi bill một trần, không giả số người từ ảnh |
| DP-04 | Di chuyển mặt đất phục vụ công tác | ≤500.000 VND/nhân viên/ngày | Taxi/xe công nghệ/vận chuyển hành khách mặt đất trong phạm vi công việc; cộng đúng ngày/người, loại airfare. Không áp rule này cho thuê xe/tự lái hoặc khoản thuộc nhóm khác chưa định |
| DP-05 | Vé máy bay | Giá trị thực tế có căn cứ, hạng phổ thông, hành trình phù hợp công tác được phép; không đặt trần tiền vé chung | Hạng/hành trình/giá và phần thanh toán có nguồn. Hạng khác hoặc phạm vi khác chuyển xem xét; chưa rõ hạng thì hỏi fact, không tự đoán. Công ty trả vé thì không đưa phần đó vào E |

Đúng bằng mức được coi trong mức; lớn hơn dù 1 VND là vượt theo policy demo, không thêm dung sai ngầm. Vượt mức đã chốt chuyển xem xét ngoại lệ, không tự cắt hay auto approve. Chi ngoài năm nhóm/phạm vi có thể là hợp lệ trong thực tế nhưng ngoài policy demo: hỏi chủ policy, không gọi là bị pháp luật cấm.

Mức khách sạn theo từng đêm có nhược điểm: nguồn tổng cả kỳ có thể không đủ để chứng minh mỗi đêm. Chỉ đòi bảng chi tiết khi check cần nó; một phòng-một đêm đủ căn cứ thì không hỏi thêm vô ích. Có nguồn xác định giá đồng nhất từng đêm thì dùng với derivation rõ; không tự suy từ tổng chia số đêm.

## 3. Đề nghị tạm ứng

| Rule | Điều kiện thường quy đề xuất | Nếu không đủ |
| --- | --- | --- |
| DP-06 | Số xin >0, ≤5.000.000 VND và không vượt dự toán phần nhân viên dự kiến thanh toán được kiểm tra theo policy | Vượt một trong hai: chuyển người có quyền xem xét, không lấy tổng dự toán cả phần công ty trả để hợp thức hóa số xin |
| DP-07 | Đề nghị ứng đầu tiên của công việc, nguồn lịch sử đủ và không có ứng đã cấp hoặc yêu cầu/lệnh chi ứng còn hiệu lực cho cùng công việc | Nguồn thiếu/trạng thái chưa rõ: hỏi chủ nguồn. Có lệnh/yêu cầu còn hiệu lực: giải quyết chống chi trùng trước. Có ứng đã cấp: đề nghị bổ sung ngoài đường thường quy, chỉ xét sau khi rõ số đã nhận và nhu cầu còn lại |

Không cấm nhân viên có ứng công việc khác chưa quyết toán chỉ từ rule DP-07. Lịch sử khác vẫn cần để kiểm tra trùng/quan hệ khi liên quan; muốn cấm ứng mới do nợ quá hạn phải có rule riêng, không tự tạo ở đây. Không bổ sung tỉ lệ 70%/80% khi chưa có nhu cầu.

Người có quyền có thể duyệt ít hơn số xin với nội dung/phạm vi rõ theo B4; giữ số xin, số duyệt và thực nhận riêng. Không tạo yêu cầu ứng mới tự động cho phần chưa được duyệt. Đề nghị bổ sung được xem xét có căn cứ không đồng nghĩa tạo khoản chi khi còn pending chưa giải quyết.

## 4. Vai và cơ sở thẩm quyền đề xuất

| Vai demo | Quyền đề xuất | Giới hạn |
| --- | --- | --- |
| Quản lý công việc | Cho phép công tác, phạm vi và thay đổi công việc | Không tự đồng thời có quyền duyệt tiền hoặc ngoại lệ |
| Người phụ trách tài chính | Duyệt ứng thường quy, duyệt quyết toán thường quy | Ứng theo số đề xuất duyệt ≤5 triệu; quyết toán theo E trước đối trừ ≤10 triệu và số đề xuất hoàn lại nếu có ≤10 triệu. Không có quyền ngoại lệ theo mặc định |
| Chủ policy/người được giao quyền cấp cao | Quyết định ngoại lệ trong phạm vi demo, duyệt tài chính ngoài mức vai trên | Quyết định nêu khoản/phần, số chấp nhận, lý do, scope/version; không miễn chứng từ/quality hoặc sửa phép tính sai |
| Người thực hiện chi/thu | Thực hiện theo quyết định tài chính có hiệu lực và cung cấp căn cứ thực nhận | Không tự đổi số được duyệt hoặc dùng việc đã chuyển tiền để thay quyền duyệt |

Đề xuất chỉ hai mức quyền tài chính, không làm hệ thống nhiều tầng. Vai cấp cao là điểm xử lý cuối trong phạm vi policy demo, không là chứng minh quyền ngoài đời hoặc quyền bất kỳ với mọi tài sản công ty. Một operator có thể mô phỏng nhiều vai nhưng dấu vết phải giữ vai quyết định/nguồn; không giới thiệu là kiểm soát danh tính độc lập.

Quyền ngoại lệ khác quyền duyệt thường quy. Một quyết định có thể chứa cả hai nếu người ra quyết định có đủ quyền, chỉ rõ nội dung và phiên bản; không bắt bấm hai lần chỉ để đủ quy trình. Sau xử lý ngoại lệ, tự re-check phần ảnh hưởng; human-assisted vẫn được tính trong đánh giá.

Chọn E trước đối trừ tránh E=20 triệu, A=20 triệu, S=0 đi qua người chỉ có quyền 10 triệu. Thêm kiểm tra số đề xuất hoàn lại tránh E=0, ứng thực nhận 20 triệu, S=-20 triệu lại được xem là quyết định nhỏ. Quyền và số cho nhóm nghĩa vụ khác ngoài phạm vi B7 không được suy ra từ bảng này.

## 5. Walkthrough cũ thay đổi ra sao?

R2 dùng công tác 05–06/10/2026, khách sạn 3 triệu, ăn 1 triệu, di chuyển 1 triệu, ứng 2 triệu và vé công ty trả 3 triệu, với giả định policy cho phép các khoản. **Không sửa nguồn hoặc kết quả lịch sử R2 để làm đạt policy mới.**

- Nếu khách sạn 3 triệu là một phòng-một đêm: vượt DP-01, chuyển xem xét; chưa có E/S cuối.
- Hai ngày công tác không chứng minh hai đêm lưu trú. Chỉ khi có nguồn hai phòng-đêm với giá từng đêm trong mức mới có thể đạt DP-01.
- Ăn 1 triệu: hai ngày, mỗi ngày 500.000 cho nhân viên có thể đạt DP-02; toàn bộ trong một ngày vượt DP-02. Nếu là tiếp khách thực sự, xét DP-03 theo purpose/event, không đổi nhãn để hợp thức hóa.
- Di chuyển 1 triệu: phải biết phân bố đúng ngày/phần; tổng hai ngày không tự chứng minh từng ngày trong mức.
- Chỉ khi từng khoản đủ các check và toàn bộ 5 triệu nhân viên trả được chấp nhận, A=2 triệu cùng RA=P=RP=0 có căn cứ, S mới bằng 3 triệu. Nếu có quyết định chỉ chấp nhận E=4 triệu, các thành phần khác không đổi thì S=2 triệu; giữ thực chi gốc.

## 6. Tự review và quyết định cần chốt

Điểm mạnh: ít nhóm/quyền, cơ sở và trường cần rõ, kiểm tra biên/cộng gộp được bằng chương trình; giữ con người quyết định ngoại lệ và tiền. Hạn chế: số tiền chưa được kiểm chứng với công ty/người dùng thật; trần theo ngày/đêm có thể làm tăng yêu cầu bổ sung; tiếp khách theo sự kiện cần liên kết đúng; giá vé không có trần chung vẫn cần căn cứ hành trình/hạng và quyền tổng tiền. Các giới hạn này phải được thể hiện trong đánh giá, không chỉ chọn case thuận lợi.

Từng nhóm cần case trong mức, bằng mức, vượt, thiếu fact ảnh hưởng; thêm nhiều bill cùng nhóm/ngày/event và payer split để chống qua trần bằng chia nhỏ. R5 lập gold độc lập trước tuning; không lấy nhãn do chính hệ thống tạo làm expected. Bảng này chưa là gold, chưa chạy pipeline hoặc thử người thật.

Đề nghị thảo luận bảng nhóm chi và cơ sở quyền trước; chỉ coi các số là policy demo được chốt sau khi chủ dự án đồng ý rõ. Hành vi vượt hạn mức đã được duyệt riêng; sự đồng ý đó không duyệt DP-01..DP-07 hoặc bảng vai này. Chưa chốt thời hạn nộp/quá hạn, quy tắc làm tròn hoặc hợp đồng nguồn chi tiết bằng tài liệu này; không đặt ngầm hoặc gọi toàn R4 đã đóng.

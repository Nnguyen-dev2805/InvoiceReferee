# R5.8 — Rà soát corpus và tiêu chí nghiệm thu để tiếp R6

Ngày: 09/10/2026 · **KẾT LUẬN: CÓ THỂ CHỐT THIẾT KẾ ĐÁNH GIÁ ĐỂ TIẾP R6**.

Phạm vi kết luận: thiết kế nghiệp vụ, catalogue và điều kiện chấm. Không chốt gold đã thẩm định độc lập, chất lượng runtime, Verify, holdout hoặc baseline B1. Đây là self-review của lead, không reviewer độc lập hay thử với người làm nghiệp vụ thật. Không đọc hoặc sửa code hiện tại.

Căn cứ [R5.1](R5_EVALUATION_DESIGN.md), [corpus20](eval_development/CORPUS_INDEX.md), [policy](R4_WORK_BUDGET_POLICY.md), [ba vai](R4_ROLES_HANDOFF_POLICY.md), [nguồn](R4_SOURCE_INTAKE_CONTRACT.md), [brief gốc](../Challenge_Brief_OrganizationAI_VN.docx.md). Bằng chứng kiểm tra tài liệu được lưu riêng tại [corpus audit](eval_development/CORPUS_AUDIT.json); không gọi kiểm tra fixture là chạy hệ thống.

## 1. Những gì đã rà soát và giới hạn

| Hạng mục | Kết quả tại chặng thiết kế |
| --- | --- |
| Inventory |20manifest:15B7 và5B3; có nguồn/expected nháp,9routinecheck và11cần giải quyết theo unit đã công bố |
| Tách nguồn/đáp án | Initialinput không chứa expected/README/fixturechecks/followup; branches bổ sung riêng, hashes khớp các file |
| Policy và nguồn quyền | Dùng cùng bundle design snapshot; quyền theo work/person/nội dung/hiệu lực. B hoặc grant amount không tự đồng nghĩa approval/actualreceipt |
| Nghĩa tiền | Dự toán, số xin, actualfunds, chi phí thực, phần chấp nhận và số phê duyệt giữ khác nhau. B3 không áp công thứcB7; companydirect không E |
| Chưa xác định | Các case factunknown khôngfinalS từ sốđoán/0; cáccase policy/quyền giữ sốconditional/calculated khác kết luận được dùng hành động |
| Đóng hồ sơ | Trong20expected banđầu chỉQ04 chođóng vì códecision/actualreceipt/toànscope đủ, không chỉS0 |
| Bằng chứng còn thiếu | Độc lập adjudication, chất lượng OCR/matching raw/live, lifecyclecontrols thực thi, Verify, holdout và professionaltrials |

Các phần về provenance/coverage/rights trong packet là **những fact giả lập được cung cấp**, không đã chứng minh có thể thu thập đủ nguồn ngoài đời. Kiểm tra cấu trúc/hash/arithmetic không xác thực người/issuer, không độc lập xác minh tài liệu hoặc thay fullsemantic adjudication. Vì vậy không đưa ra tỷ lệ độ chính xác hay “20test pass”.

## 2. Phản biện cần giữ lại, không che bằng số case

| ID | Nhận xét và chứng cứ | Cách xử lý/ranh giới |
| --- | --- | --- |
| R5-F01 | Tất cả20case cùngtemplatefamily; Q04 là mốc sauQ01, nhiều nhánh là counterfactual từbase | Chỉdevelopment; không splitclones làmholdout. Thiết kế nguồn/layout/businesscontext khác cho calibration/holdout và input mới |
| R5-F02 | Source narrative còn có lời giải thích quy tắc/đối chiếu. Q07 mappingbank–finance đã có trongregister; nhiều coverage khẳng định đủ theo giả lập | Corpus tốt cho kiểm tra semantics/policy, chưa chứng minh AI tự tìm/ghép raw hoặc giảm inputprep. Khi đo OCR/matching, dùng nguồn giống tài liệu đầu vào, đưa ghi chú tác giả ra ngoài prompt; thay dataset bằng version mới |
| R5-F03 | Expected các gói có những field khác nhau: S/S_vnd/S_final_vnd/S_calculated_vnd; Q14 có phép tính3 nhưng chưa người đủquyền, Q13 có sốconditional4 | Chấm theo nghĩa và state; không lấy firstnonnullamount làm payable. R7 cần một hợp đồng evaluator rõ cho calculated/đủđiềukiện/approved/received. Chưa đổi tất cả fixtures hoặc ép interface runtime ởR5 |
| R5-F04 | Chưa có đầy đủ traces Stop/lateoutput, staleapproval, partialreceipt/wrongrecipient và unsupportedanswer. Receipt đủQ04 không thay các negativecontrols | Khóa assertions tối thiểu tại §6, dựng thực thi/traces ở R6–R9 trước mởactionB; không cần làm thêm nhiều packetclean để thay controltest |
| R5-F05 | Source/expected cùng tác giả; kiểuảnh mới có mộtopaquePNG, còn synthetic CSV/text dễ hơn thực tế; chưa trial3professionalusers | Gold hiện nháp, quality ngoàimode chưa biết. Adjudicate trước dùng làmoracle chính thức; thửngười thật/impact và adaptation theo brief là bằng chứng khác, không agent/selftest |

Không có chứng cứ từ review này để thay ngân sách, quyền hoặc evidence policy nhằm tăng routine rate. Không sửa câu hỏi thành “cứ approve” để làm ít human touches. Nguồn chưa rõ cần làm rõ, source đã đủ thì không hỏi lại chỉ để yên tâm.

## 3. Khi nào job được hoàn tất?

**B7 report hoàn tất để rà soát/quyết định:** các checks bắt buộc áp dụng có fact/source/quality/quan hệ/scope đủ; expense và history được đối chiếu; policybasis hợp lệ (B đúng và trongB, hoặc scopedexception/postincurredacceptance đã giải quyết); số/chiều đúng khi cần và khôngmaterialissue còn unresolved; người cần quyết định tiếp có quyền phù hợp. Report lưurefs/phiênbản/mốc, không yêu cầu người ghép/tính hộ giữa run.

**B3 report hoàn tất để quyết định:** côngviệc/đềnghị/dựtoán nhấtquán, history/previousobligation đủ để xét, quyền cho cácnội dung đangxin đúngscope. Không yêu cầu quyếtđịnh đangxin tồn tại trước, receipt khoảnứng chưachi hoặc hóađơn hậukiểm. Dựtoán và trạng thái cần normalapproval được ghi đúng, không tựacceptedactualcost/actualadvance hoặcS.

Checkpoint kế toán và người duyệt cố định ở cảhai vẫn phải diễn ra/đo effort. Unitcheckreport không nghĩa toànworkflow tựchủ, không tựđóng compatibility với yêu cầu routinefullyautomatic của BTC đã ghiR3. Nếu còn authorityissue nhưQ14, có thể lưu phép tính rõ nhưng không đánh dấu sẵn sàng cho người không đủquyền phêduyệt.

## 4. Khi nào phải dừng kết luận cuối?

| Vướng mắc | Được giữ | Không được làm |
| --- | --- | --- |
| Fact/amount/payer/receipt/history unknown hoặc conflict | Fact/check/sums độc lập đủ nguồn, issue/ref/owner/câu hỏi cụ thể | Đoán số, missing0, confidence giả, subtotal thành finalS, financialapprove/chi/đóng |
| Policybasis/ngoại lệ chưa quyết | B/T và số conditional từ facts đã xác minh, có điều kiện rõ | Tựclip, biến quyềnngoạilệ thành decision, sửaactualsources đểtrongB |
| Quyền chưa đủ | Sốcalculated từ sources đủ và lýdo authority, nguồn quyền cần bổsung | Rolepicker cấpquyền, backdate approval hoặc quyền mới hợpthứchóa action cũ |
| Technicalfailure/capability chưa xử lý | Sources/history và trạng thái lỗi đúng nghĩa, phương án đọc/bổsung nếu trongscope | Giả employee thiếubill, financialPASS hoặc bỏrun khỏi báo cáo |
| Stop/revision ảnh hưởng decision | Recorddecision/events cũ và trạng thái phần cầncheck lại | Action từ outputmuộn/nguồncũ, giả đã hủy bankpayment hoặc xóaactualmoney |

Sốconditional chỉ từ **facts rõ** và điều kiệnpolicy rõ; không dùng Q08hotelunknown giảhotel3 rồi cộng thành ví dụ được trả. Q09/Q10/Q11/Q12 không finalS với disclaimer. Q13 conditional4 trướcdecision khác approved4 saudecision; Q14 calculated3 khác quyền duyệt3.

## 5. Phê duyệt, thực hiện và đóng là ba tiêu chí khác nhau

**Đủ căn cứ phê duyệt tài chính:** người quyết định đúng quyền/nội dung/phạmvi/hiệulực, facts và policy đã đủ, decision ghi số/chiều/điều kiện/phiênbản đã xét. Quyết định ngoại lệ và quyết toán có thể cùngrecord nếu đủ, không nhiều lầnclick chỉ để đúngsốbước. Thay phần chi phí chấp nhận thì re-check, không sửafieldS riêng.

**Đủ căn cứ ghi thực hiện:** source actualreceipt đúngpayer/payee/amount/nghĩavụ/phươngthức/mốc. Approval/request/debit/Paid generic khôngactualreceipt. Giữ gross events, originalrefs và sidewrongpayee/overpayment; không clip để khớp decision.

**Đủ căn cứ đóng:** decision cóhiệu lực, chi/thu đúngnghĩavụ đã đối chiếu đủ hoặc cân bằng hợp lệ, mọinguồn/scope/pending/exception/obligation liênquan đã xửlý, không Stop/stale chưagiảiquyết. Đóngas-of/version, sourcesau đó tạo điều chỉnh liênkết; không bảo đảm biếtmọifutureevent.

S0 đơnộc, từchối, đã gửi lệnh hoặc operator đánh dấuđãràsoát không đủ đóng. Đã nhận ứng2, quyếttoán bịtừchối không xóa nghĩa vụ2. Duyệt toàn3 nhưng mới nhận2 vẫngiữ approved3/unfulfilled1, không biến decision thành2 hoặc tạo nghĩa vụmới1 vôđiềukiện.

## 6. Assertions kiểm soát còn phải có bằng chứng thực thi

| ID | Trace cần thiết trước nghiệm thu hành động | Assertion |
| --- | --- | --- |
| C01 | Re-run/copy hồsơ đãdecision/receipt đầy đủ | Không tạo lại request/chi cùngnghĩavụ; giữ history/refs |
| C02 | Decision3, actualreceipt2, phần còn lại pending | P2 đúngnguồn, remaining1 nhưng chưaclose/newrequest; không rútapproved3 thành2 |
| C03 | Actualmoney tớiwrongrecipient hoặc vượt approvedamount | Không fulfil correctemployee từsai người; giữrawmoney/sự cố, không infer0/auto recovery khi chưascope/rule |
| C04 | Stop đãacknowledged rồi provider trảmuộn | Không action/request từ kếtquảmuộn; Stoplocal không là bankcancel/hoànmoney |
| C05 | Input/policy/authority thay đổi material sau approval | Decision cũ giữhistory; invalidation/re-check trước sửdụng action, không reusebooleanApproved |
| C06 | Reply saiowner/khôngscope hoặc gõamount cho sourcekhôngđọcđược | Issue chưaresolved, khôngautopass; validanswer/source thực đủ mới checklại phầnảnhhưởng |
| C07 | Bổsung receipt/decision cómoneytime sau targetasof | Không đưa vào history cũ; đổi scope/version nếu quyếtđịnh cậpnhật, giữ runbanđầu |

Đây là assertions thiết kế, chưa traces/runner đãchạy. R6 cần mô tả trạng thái và chuyển tiếp tươngứng; R7/spec/implementation sau đó phải có kiểmtra cùngapplicationpath và hậuquả lưu thực tế. Không dựng distributedjobs/bankintegration để làm cácassertions này.

## 7. Những cổng cần bằng chứng để công bố chất lượng

- **Đo baseline:** sources/gold được ràsoát và version, đườngchạy/log mọicase/actualresult/mode; kếtquảxấu vẫn báo. Có thểfreeze baseline chưađạtgate để so sánh, không gọi sảnphẩm đãđạt.
- **Report đúng trên suite đã công bố:** không criticalviolation nguồn/số/policy/state/action trênsuite đã chấm; thiếuoutput/lỗi không được bỏ. Đây là tiêu chí hữuhạn, không lời đảm bảo mọiinput đúng.
- **Mở actionB:** ngoàiA phải chứng minh quyền/version/Stop/stale/idempotency/audit. Không lấy độđúng phép cộng hoặc câu báoUI làm integrationevidence.
- **Độc lập và giá trị thật:** calibration/holdout khácfamily/source, metric FN/FP/U/N và completion đúng; effortpreparation→review→decision→reconcile, ít nhất3professionalusers + feedbackimprovement theo brief. Khônggiảuser/feedback hoặc dùng agent thay.

Thiết kế đánhgiá đủ để sangR6. Cácgates runtime/gold/trial là việc phải hoànthành ở chặng triểnkhai/measurement, không lýdo dừng thiết kếworkflow hoặc giả đãđạt yêu cầu cuộc thi. Không thêmcaseclones để che nguồnchưa đa dạng. Nên ưu tiên workflow/state/contracts tiếp theo rồi đa dạng nguồn và đo đúngmode.

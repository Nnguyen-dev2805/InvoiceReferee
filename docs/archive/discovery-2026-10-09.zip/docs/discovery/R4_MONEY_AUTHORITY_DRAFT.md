# R4.3 — Tính tiền, hạn mức và thẩm quyền

Ngày: 09/10/2026 · Trạng thái: **TÀI LIỆU LOGIC TIỀN VÀ LỊCH SỬ ĐỀ XUẤT; POLICY HẠN MỨC HIỆN TẠI CHUYỂN SANG NGÂN SÁCH TỔNG, CHƯA KÍCH HOẠT/CODE**.

Sau phản biện về độ phức tạp, chủ dự án đồng ý [policy ngân sách tổng công việc](R4_WORK_BUDGET_POLICY.md). Dùng bản đó cho hướng kiểm tra ngân sách hiện hành; các ví dụ hạn mức từng đêm/nhóm tại §3/§5 và bảng tham số cũ bên dưới là lịch sử, không áp cho bản mới. Công thức và phân biệt nghĩa tiền được giữ; ngưỡng giao quyền vẫn chưa chốt.

Chủ dự án đã đồng ý riêng hành vi **vượt hạn mức → chuyển người có quyền xem xét ngoại lệ, không tự cắt xuống trần**. Các cơ sở thẩm quyền, con số và điều kiện tại [bảng tham số demo](R4_DEMO_POLICY_PARAMETERS_DRAFT.md) vẫn là đề xuất, chưa được duyệt. Không coi việc đồng ý hành vi vượt mức là đồng ý toàn bộ R4.3.

Căn cứ: [phạm vi R3](R3_MVP_SCOPE_DRAFT.md), [bộ căn cứ R4.2](R4_EVIDENCE_RULES_DRAFT.md), [walkthrough 9 bước](R2_CASE_WALKTHROUGH.md). Lead tự review theo yêu cầu mới của chủ dự án, không có review subagent cho bản này. Các số trong ví dụ là giả lập, không phải hạn mức doanh nghiệp thật, quy định pháp luật hoặc tham số được duyệt.

## 1. Ba lớp số tiền

| Lớp | Ý nghĩa | Ai xác định |
| --- | --- | --- |
| Khoản đã chi | Giá trị khoản chi và phần từng bên đã thanh toán theo nguồn; giữ cả phần không được chấp nhận | Nguồn phù hợp + kiểm tra/liên kết, không dựa riêng vào số khai báo |
| Khoản được chấp nhận | Phần đủ điều kiện của công việc theo policy áp dụng hoặc quyết định ngoại lệ có quyền/căn cứ | Chương trình áp quy tắc; con người xử lý ngoại lệ trong quyền |
| Số còn phải xử lý | Chênh lệch sau đối trừ ứng và lịch sử chi/thu đúng phạm vi | Chương trình tính; con người phê duyệt tài chính và thực hiện |

Không thay giá trị bill bằng số được duyệt. Trước công việc chưa có chi thực tế: số xin ứng, dự toán, số được duyệt và thực nhận là các lớp riêng; không tính số quyết toán từ dự toán.

## 2. Công thức quyết toán đã thống nhất

`S = E - (A - RA) - (P - RP)`

- E: tổng phần nhân viên thanh toán được chấp nhận, gồm cả phần dùng tiền ứng, sau điều chỉnh hoàn tiền thuộc đúng phần này.
- A/RA: tiền ứng nhân viên thực nhận / khoản trả lại ứng công ty thực nhận.
- P/RP: tiền hoàn chi phí nhân viên thực nhận / khoản trả lại tiền hoàn chi phí công ty thực nhận.

S dương: đề xuất công ty trả thêm. S âm: đề xuất xử lý nhân viên hoàn lại. S bằng 0: nhóm này cân bằng; chưa đủ để đóng toàn hồ sơ. Không tự khấu trừ lương, chuyển tiền hoặc thu hồi tiền từ công thức.

Tất cả thành phần cùng phạm vi quyết toán lũy kế/mốc nguồn, không tính riêng bill mới rồi trừ toàn bộ lịch sử. Company-direct không nằm trong E và không bị trừ thêm lần nữa. Giữ gross history, liên kết từng event/phần một lần. Missing/nguồn chờ/coverage không đủ không thành 0. Ngoại lệ hoàn tiền khác người nhận hoặc nghĩa vụ ngoài nhóm này vẫn chặn kết luận cuối nếu ảnh hưởng hồ sơ, theo B7 đã chốt.

## 3. Hành vi vượt hạn mức đã được đồng ý: chuyển xem xét, không tự cắt

Mỗi rule cần xác định nhóm chi, điều kiện áp dụng, cơ sở tính, đơn vị và phiên bản có hiệu lực. Khách sạn có thể tính theo phòng-đêm; ăn cá nhân và tiếp khách không mặc định dùng chung một mức. Số ngày công tác không tự là số đêm khách sạn; số người không tự suy từ tên trên bill.

Chủ dự án đã đồng ý hành vi MVP: **đủ căn cứ và trong mức thì kiểm tra thường quy; vượt mức thì chuyển người có quyền xem xét ngoại lệ**. Report chỉ rõ thực chi, mức áp dụng, số vượt và căn cứ. Chưa có quyết định ngoại lệ thì khoản bị ảnh hưởng và S cuối chưa chốt. Không tự từ chối toàn hồ sơ hoặc xóa nghĩa vụ tiền ứng.

Ví dụ giả lập: khách sạn 3.000.000 VND, nguồn xác định 1 phòng × 1 đêm, mức minh họa 1.500.000 VND/phòng-đêm. Hệ thống nêu vượt 1.500.000 VND và xin quyết định ngoại lệ; không tự đổi bill thành 1.500.000 VND hoặc tự chấp nhận 3.000.000 VND. Quyết định có thể chấp nhận toàn bộ, xác định phần được chấp nhận hoặc không chấp nhận khoản, trong quyền và có lý do; nguồn gốc vẫn giữ nguyên.

Một phương án khác là policy quy định trước chỉ hoàn tới trần. Khi có rule rõ như vậy, chương trình có thể tính phần được chấp nhận; đây là hành vi rulebook cần chốt riêng, không phải phép `min()` mặc định. Đề xuất chưa dùng phương án đó làm mặc định MVP vì chủ dự án chưa có chính sách công ty làm căn cứ.

Vi phạm có quy tắc từ chối rõ khác ngoại lệ hoặc thiếu policy. Một khoản chắc chắn không hợp lệ có thể nhận kết quả không chấp nhận theo rule; khoản vượt mức được đề xuất cho xem xét ngoại lệ không bị gọi là từ chối chắc chắn. Thiếu dữ kiện để tính mức thì hỏi fact trước, không xin người duyệt xác nhận một số đang mờ.

## 4. Hạn mức chi phí khác thẩm quyền

| Loại giới hạn | Câu hỏi | Đề xuất cơ sở |
| --- | --- | --- |
| Hạn mức khoản chi | Khoản này trong chính sách không? | Giá trị/phần theo nhóm, đơn vị và điều kiện cụ thể |
| Phạm vi hệ thống | Check nào được hoàn thành tự động, tình huống nào cần người? | Rule rõ + fact/evidence đủ; ngoại lệ hoặc vượt phạm vi phải chuyển |
| Quyền phê duyệt tài chính | Người này được duyệt quyết định đang xét không? | Ứng: số đề xuất duyệt; quyết toán: tổng E trước đối trừ. Quyền ngoại lệ tách rõ khỏi quyền duyệt thường quy |
| Quyền thực hiện chi/thu | Quyết định có hiệu lực nào cho phép xử lý tiền? | Người thực hiện theo quyết định có hiệu lực; thực nhận được đối chiếu ở B9 |

**Lý do đề xuất dùng E trước đối trừ cho quyền duyệt quyết toán:** E=20 triệu và A=20 triệu cho S=0, nhưng vẫn là quyết định chấp nhận 20 triệu chi phí. Chỉ nhìn S sẽ bỏ qua quy mô quyết định. Đây mới là đề xuất cơ sở cho nhóm nghĩa vụ nhân viên; không là mô hình quyền chung cho mọi khoản company-direct/recovery.

MVP chỉ cần bảng vai/phạm vi/thẩm quyền rõ, không xây hệ thống quyền doanh nghiệp. Role picker phục vụ demo không chứng minh danh tính/chức vụ thật. Có quyền duyệt tiền không tự có quyền cho ngoại lệ; cả hai không thay thế căn cứ, chất lượng số hoặc phép tính. Con người vẫn giữ quyết định tài chính ở B4/B8 ngay cả khi báo cáo kiểm tra đã hoàn tất tự động.

## 5. Tính toán và câu hỏi có thể kiểm chứng

Tiền kết luận nguyên VND; không float, đổi tiền đoán hoặc làm tròn ngầm. Nếu đơn giá/số lượng có phần thập phân, rule phải quy định cách tính/làm tròn; chưa có rule mà chênh lệch có thể đổi kết quả thì giữ cần làm rõ. Không dùng sai số cho phép chưa chốt để bỏ qua chênh lệch.

AI đọc/đề xuất phân loại và liên kết có nguồn; chương trình áp rule, cộng tiền, đối trừ và kiểm tra quyền. Không để LLM tự tạo hạn mức hoặc tự quyết số được hoàn. Report cho thấy fact/source, rule, phép tính và phần chưa giải quyết.

| Ví dụ thiết kế | Kết quả kỳ vọng có điều kiện |
| --- | --- |
| E=5 triệu, A=2 triệu, RA=P=RP=0 đã có căn cứ | S=3 triệu |
| E=5 triệu, A=2 triệu, P=3 triệu, RA=RP=0 đủ căn cứ | S=0; không tạo đề nghị chi thêm cùng nghĩa vụ |
| Chi khách sạn 3 triệu/1 đêm, mức minh họa 1,5 triệu | Chuyển xem xét vượt mức; E khoản này/S cuối chưa chốt |
| Cùng bill 3 triệu nhưng có căn cứ 2 phòng-đêm, mức minh họa 1,5 triệu | Đạt check hạn mức; các check payer, purpose, history vẫn cần đạt |
| E=20 triệu, A=20 triệu, S=0 nhưng ngoài quyền người duyệt | Chuyển đúng người; S=0 không miễn thẩm quyền quyết toán |
| Chỉ có dự toán ứng 2 triệu, chưa chi/nhận | Kiểm tra đề nghị ứng; không ghi A=2 hoặc tính quyết toán từ dự toán |
| P chưa xác định do nguồn thanh toán chỉ thể hiện lệnh | Hỏi/đối chiếu receipt; không P=0 và không đề nghị chi lại |

Các dòng này là suy luận thiết kế, chưa chạy pipeline/tests và chưa là gold đánh giá. R5 sẽ định expected độc lập, test trường hợp biên và denominator.

## 6. Những lựa chọn còn mở

1. Hành vi vượt hạn mức đã chốt: chuyển xem xét ngoại lệ. Chỉ đổi sang hoàn tới trần nếu có quyết định policy mới rõ ràng, không đổi từ feedback nhằm giảm escalation.
2. Chốt cơ sở quyền duyệt, các vai có quyền ngoại lệ và bảng số tiền demo. Chưa đặt tùy ý một ngưỡng cao để mọi case trở thành thường quy.
3. Viết bảng tham số cụ thể cho từng nhóm và ứng: đơn vị, điều kiện, trường bắt buộc, hành vi biên/vượt mức; chọn phiên bản demo để R5 lập gold. Chưa coi phần tham số còn thiếu là hoàn tất R4.

Tự phản biện: chuyển người cho mọi khoản vượt có thể tăng escalation không cần thiết nếu công ty thực có rule chỉ hoàn tới trần. Chỉ nên đo hiệu quả sau khi policy được chốt; không chỉnh nhãn hoặc mẫu số để che vấn đề này. Ngược lại, tự áp trần khi chưa có rule là quyết định tài chính thiếu căn cứ. Quyền dựa trên E cũng cần người chủ policy đồng ý trước khi trở thành cấu hình.

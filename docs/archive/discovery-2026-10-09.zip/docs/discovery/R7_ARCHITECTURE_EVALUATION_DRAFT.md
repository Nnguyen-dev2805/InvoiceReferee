# R7.1 — Kiến trúc gọn, chất lượng AI và đánh giá trong quá trình phát triển

Ngày: 09/10/2026 · **CHỦ DỰ ÁN ĐÃ ĐỒNG Ý HƯỚNG KIẾN TRÚC R7.1 ĐỂ TIẾP R7.2 — CHƯA CODE/RUNTIME**.

Căn cứ [R6 đã đồng ý](R6_WORKFLOW_STATE_DRAFT.md), [phạm vi A/B](R3_MVP_SCOPE_DRAFT.md), [policy](R4_WORK_BUDGET_POLICY.md), [nguồn](R4_SOURCE_INTAKE_CONTRACT.md), [đánh giá](R5_EVALUATION_DESIGN.md) và [gates R5.8](R5_CORPUS_REVIEW_AND_GATES.md). Không đọc code hiện tại để suy ra nhu cầu hoặc chọn gold; việc đối chiếu vẫn ở R8.

## 1. Ràng buộc được bổ sung

- Ưu tiên thiết kế kiến trúc AI và đo chất lượng toàn hệ thống, không đầu tư backend vượt nhu cầu MVP.
- Hướng tới khoảng 5 người dùng. Tạm hiểu là nhóm thử nghiệm nhỏ có thể cùng mở app và xử lý các hồ sơ; chưa là cam kết 5 pipeline AI nặng hoàn thành đồng thời với latency cố định.
- Khi triển khai, mỗi mốc phải chạy được trên giao diện để chủ dự án thao tác/kiểm tra, bên cạnh unit tests và các checks tích hợp cần thiết.
- Vẫn giữ ba vai nghiệp vụ; số người không là số role. Demo bằng dữ liệu giả lập/được phép, không suy role picker thành danh tính thật hoặc cách ly tài liệu giữa người dùng.

Nội dung trên là yêu cầu đã ghi nhận. Chủ dự án đã đồng ý hướng kiến trúc R7.1 để cụ thể hóa [hợp đồng R7.2](R7_DATA_AND_EVALUATION_CONTRACT_DRAFT.md); API/DB schema, provider/version, giới hạn vận hành và quality vẫn chưa được chốt/đo từ sự đồng ý này.

## 2. Kiến trúc đề xuất và lý do chọn

Chọn **một ứng dụng Python, một SQLite, thư mục tài liệu, một UI và một bộ điều phối workflow**. Các khối là trách nhiệm bên trong ứng dụng, không phải các service riêng. Đây là phương án thiết kế, chưa có benchmark xác nhận tải hay lựa chọn framework/provider/version.

```mermaid
flowchart TD
    UI["UI nghiệp vụ<br/>Nộp, xem nguồn, đối chiếu, trả lời, quyết định"] --> APP["Ứng dụng và điều phối workflow<br/>Hồ sơ, phiên bản, chạy lại, Stop"]
    APP --> AI["Đọc tài liệu và đề xuất liên kết<br/>AI xử lý phần cần hiểu nội dung"]
    AI --> CHECK["Xác thực dữ kiện và liên kết<br/>Quy tắc, số học, quyền, trạng thái"]
    APP --> CHECK
    CHECK --> REPORT["Báo cáo có căn cứ hoặc câu hỏi<br/>Phần đã rõ, vướng mắc, bước tiếp"]
    REPORT --> APP
    APP --> STORE["SQLite và file nguồn<br/>Facts, runs, quyết định, tiền, lịch sử"]
    VERIFY["Runner đánh giá<br/>Input tách gold, actual và traces"] --> APP
    APP --> VERIFY
```

UI và runner đi qua **cùng lõi ứng dụng/quy tắc**. Runner chỉ đưa nguồn/context đầu vào; expected/gold không vào prompt hoặc điều khiển production. UI không tự tính một kết luận tài chính khác backend.

| Phương án | Nhận xét của lead |
| --- | --- |
| Một lời gọi LLM đọc toàn bộ rồi kết luận mọi thứ | Ít khối nhưng khó xác định sai ở đọc, ghép hay rule; output lớn, cập nhật nhỏ dễ phải chạy lại toàn bộ. Không chọn làm kiến trúc mặc định |
| Workflow có bước rõ, AI đề xuất và chương trình kiểm tra | Chọn phương án này: dễ ghi trace, đo từng bước, giữ nguồn và hạn chế lần gọi; phù hợp B3/B7 có cấu trúc nghiệp vụ đã xác định |
| Nhiều agent tranh luận, framework graph hoặc hạ tầng phân tán ngay từ đầu | Chưa có công việc bắt buộc cần thêm chúng. Chỉ cân nhắc nếu có failure/độ phức tạp thực tế chứng minh lợi ích và đo được trên cùng dữ liệu |

Một bộ điều phối có thể thực hiện nhiều tác vụ AI. Không cần tạo ba agent độc lập chỉ vì có ba nhóm việc; consensus giữa model không thay nguồn đúng hoặc đáp án độc lập.

## 3. AI làm gì và ranh giới kết luận

| Công việc | AI/chương trình đảm nhiệm | Đầu ra cần đánh giá |
| --- | --- | --- |
| Đọc chứng từ | Form/CSV đã có cấu trúc được đọc trực tiếp. Với ảnh/PDF, chọn đường đọc/OCR/thị giác theo nguồn; AI trích xuất các facts cần cho checks | Giá trị, kiểu, nghĩa, document/page/locator và phần chưa rõ; không output báo cáo dài cho mỗi ảnh |
| Tìm và ghép | Chương trình tạo candidates bằng refs/quan hệ rõ; AI hỗ trợ hiểu memo/nội dung không đồng nhất khi cần. Trường hợp source đã liên kết rõ không gọi AI để làm lại | Candidate refs, quan hệ đề xuất, bằng chứng hỗ trợ và mâu thuẫn. Cùng tiền/ngày không đủ khẳng định cùng event |
| Kết luận và câu hỏi | Chương trình áp rule/math/quyền và kiểm soát trạng thái. Câu hỏi dùng issue/owner/refs từ checks, template trước; AI chỉ hỗ trợ diễn đạt khi hữu ích | Checks, kết quả đủ căn cứ/chưa xác định, câu hỏi trả lời được; lời văn không tạo facts hay quyền mới |

“Chương trình xác thực” không có nghĩa nó luôn hiểu đúng quan hệ ngữ nghĩa do AI đề xuất. Nó kiểm tra references, kiểu, phạm vi, mâu thuẫn và các điều kiện có thể xác định; chất lượng liên kết ngữ nghĩa vẫn phải có gold/đánh giá riêng. Liên kết material chưa đủ căn cứ được giữ vướng mắc, không thành fact chắc chắn chỉ vì JSON hợp lệ.

AI không xác nhận nguồn thật/giả, không suy công ty chưa trả từ việc tìm không thấy trên phạm vi thiếu, không dùng lời khai PERSONAL thay bằng chứng, không quyết định ngân sách hoặc chuyển tiền. Không tạo confidence giả. Ngưỡng hỗ trợ chuyển tiếp chỉ được chọn từ calibration phù hợp; không nới evidence/math/policy/quyền hard gates.

Ưu tiên giảm gọi LLM bằng đọc nguồn có cấu trúc trực tiếp, dùng lại kết quả đọc của đúng file và cấu hình đã ghi, giới hạn context/candidates và output theo bước. Thay file hoặc cấu hình cần đọc lại phần ảnh hưởng; dùng lại extraction không dùng lại một approval đã mất hiệu lực. Ghi nguồn kết quả được dùng lại để không báo latency đó như lần đọc live mới.

## 4. Backend nhỏ nhưng đủ kiểm chứng

| Giữ trong MVP | Vì sao cần |
| --- | --- |
| case/run/document IDs; phiên bản input/policy và refs | Hai người thao tác không được trộn nguồn/kết quả; mọi số phải truy được nguồn |
| SQLite và file nguồn | Lưu kết quả qua reload, giữ lịch sử để đối chiếu; không chỉ state trong trình duyệt hoặc RAM |
| Guard phiên bản/Stop/hành động trong transaction phù hợp | Ngăn kết quả muộn hoặc thao tác đồng thời làm thay đổi sai/trùng; cần test hậu quả lưu thực tế |
| Thực hiện pipeline trong process với số tác vụ đang chạy hữu hạn | UI vẫn xem được tiến trình và gửi Stop khi gọi provider lâu; không cần worker service/queue phân tán |
| Runs và lỗi có trạng thái lưu rõ | Nếu process ngừng, lần chạy chưa xong được nhận diện interrupted, không giả completed hoặc tự lặp hành động |

Chọn một process ứng dụng cho phương án đầu; cấu hình triển khai phải khớp giới hạn điều phối này. Mức đồng thời, timeout và giới hạn file sẽ cụ thể hóa sau hợp đồng và measurement, không gán khả năng “5 người chạy mọi thứ cùng lúc” từ sơ đồ. SQLite transactions không tự giải quyết mọi lỗi stale: code phải xét đúng version/Stop tại điểm ghi quyết định/hành động.

Không đưa microservices, Celery/Redis, message broker, Kubernetes, enterprise tenancy/SSO, vector database hoặc tích hợp bank/ERP vào mặc định. Không cần một event-sourcing framework; các bản ghi/history đủ để tái dựng quyết định là yêu cầu nghiệp vụ. Không hứa remote provider cancellation từ nút Stop.

## 5. Kiến trúc phải làm cho lỗi đo được

Mỗi run cần ghi input/policy/config version, các bước thực hiện, output/ref và lỗi, thời gian/calls/retries; tokens/cost chỉ ghi khi có dữ kiện đo được. Usage không có là unavailable, không ghi 0. Không nhất thiết có một hệ thống observability ngoài ứng dụng.

| Lớp | Câu hỏi phải trả lời được | Kiểm chứng |
| --- | --- | --- |
| Đọc dữ kiện | Sai số nằm ở source không rõ hay model đọc sai nguồn rõ? | Critical facts + refs, known/unknown và abstention riêng |
| Ghép nguồn | Đúng event/chi phí/payer/phần không, có thêm link sai không? | Required links và extra wrong links; không chỉ chấm S |
| Quy tắc và tiền | Đúng applicability, E/A/RA/P/RP/S hoặc unknown không? | Oracle độc lập từ nguồn/policy; exact số nguyên VND và trạng thái |
| Chuyển tiếp và câu hỏi | Có bỏ sót/đòi bổ sung thừa, đúng owner và dùng được phản hồi không? | FN/FP cùng lỗi kỹ thuật/completion; question→answer→re-check |
| Workflow và kiểm soát | Duyệt/nhận/đóng có đúng, Stop/stale/trùng có bị ngăn không? | Unit + integration trên state lưu, UI E2E các luồng trọng yếu; C01–C07 |
| Giá trị và vận hành | Tổng công sức giảm không, thời gian/tài nguyên nằm ở đâu? | Pilot before/after, prep/review/decision/reconcile; timing từng bước và toàn run |

Đánh giá theo thứ tự: rules với facts chuẩn → pipeline với provider fake/replay → pipeline live trên nguồn thực sự đọc → workflow UI → trial nghiệp vụ. Fake và live dùng cùng ứng dụng, khác nguồn kết quả provider; ghi đúng mode. Fake không chứng minh OCR/model quality. UI đúng không chứng minh full corpus đúng; unit xanh không chứng minh UI dùng đúng đường.

Development 20 packet hiện tại vẫn một family/single-author expected. Khi đo quality phải rà soát gold, thêm nguồn/layout/business context độc lập và giữ holdout; không lấy screenshots hay demo chọn lọc làm tỷ lệ chính xác. Khoảng 5 người mở app không tự đáp ứng trial ít nhất 3 người làm nghiệp vụ thật theo brief.

## 6. Vừa code vừa chạy trên UI

Đây là thứ tự chia luồng đề xuất cho plan R8, **không là plan đã giao code**. Mỗi lát cắt nối UI→ứng dụng→lưu→kết quả trước khi mở rộng. UI dựng sớm để thao tác có ý nghĩa, không dồn toàn bộ frontend vào cuối.

| Lát cắt | Chủ dự án thao tác được gì? | Bằng chứng kèm theo |
| --- | --- | --- |
| 1. Nộp và giữ nguồn | Tạo hồ sơ, tải nguồn, xem nguồn và reload | Integration lưu/refs; UI smoke trên nguồn giả lập; chưa kết luận AI quality |
| 2. B7 report thường quy | Xem từng khoản, căn cứ và net cho hồ sơ đại diện | Rule tests và fake/replay pipeline; trạng thái chưa duyệt/nhận/đóng rõ |
| 3. Đọc ảnh/PDF thật trong phạm vi | Xem giá trị AI đọc cạnh nguồn và vị trí | Live extraction/linkage eval, cùng UI/app path; lỗi/số chưa rõ được giữ |
| 4. Vướng mắc và phản hồi | Gửi bổ sung, trả lời đúng vai, xem kết quả re-check | Case missing/conflict/policy/authority; phản hồi sai không giải quyết issue |
| 5. Quyết định, tiền và controls | Duyệt, ghi thực nhận, partial, Stop, sửa revision, kiểm tra đóng | C01–C07 và UI E2E trọng yếu; A chưa tự tạo payment entity của B |
| 6. B3 và nhóm khoảng 5 người | Tạo/import đề nghị ứng, dùng lại nguồn quyết định; mở các phiên xử lý | B3 metrics riêng; kiểm tra không trộn case và xung đột cùng case; không claim tải chưa đo |

Provider fake/replay ban đầu phải hiển thị rõ chế độ trên UI. Mỗi mốc: checks phù hợp → chạy app → agent thao tác các luồng trọng yếu → lưu actual/logs → chủ dự án có thể thử cùng giao diện. Không yêu cầu chủ dự án tự tìm lỗi tích hợp thay agent.

Không cần tự động hóa mọi click ngay từ đầu. Giữ UI smoke ngắn cho mốc sớm và E2E cho các thay đổi state quan trọng; thêm test khi có failure hoặc invariant cụ thể. Đánh giá corpus nên có runner có thể chạy lại, không phụ thuộc người bấm 20 hồ sơ bằng tay mỗi lần.

## 7. Phản biện và bước tiếp

Backend gọn hợp lý vì quy mô nhỏ; **không được dùng quy mô để bỏ kiểm soát tiền và nguồn**. Ngược lại, nhiều agent/framework không tự nâng chất lượng: nếu chưa biết đọc hay ghép đang sai, thêm agent thường làm khó truy nguyên hơn.

Phần AI quan trọng nhất hiện là facts có nguồn và ghép đúng quan hệ, không phải lời giải thích dài. Một phép cộng đúng trên facts/links sai vẫn là kết quả sai. Vì vậy extraction, matching, policy và state cần output/traces riêng để đo, nhưng không cần service riêng.

Thiết kế tiếp theo tại R7: chốt hợp đồng tối thiểu nguồn→facts→links→checks→report/questions và runs; sau đó cụ thể hóa đường đọc/AI, evaluator và guards. Framework/provider/version cùng ngân sách latency/calls cần nguồn tài liệu và measurement phù hợp khi lựa chọn. R8 mới đối chiếu code và viết plan các lát cắt. Không tự triển khai từ việc chủ dự án đồng ý R6.

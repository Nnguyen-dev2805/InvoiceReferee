# R7.2 — Hợp đồng dữ liệu tối thiểu và cách chấm từng bước

Ngày: 09/10/2026 · **CHỦ DỰ ÁN ĐÃ ĐỒNG Ý HỢP ĐỒNG LOGIC R7.2 ĐỂ TIẾP R7.3 — CHƯA CODE, CHƯA CHỐT PROVIDER/API HOẶC DB SCHEMA**.

Căn cứ [R7.1 đã đồng ý về hướng kiến trúc](R7_ARCHITECTURE_EVALUATION_DRAFT.md), [nguồn](R4_SOURCE_INTAKE_CONTRACT.md), [evidence](R4_EVIDENCE_RULES_DRAFT.md), [policy](R4_WORK_BUDGET_POLICY.md), [workflow](R6_WORKFLOW_STATE_DRAFT.md) và [R5.8](R5_CORPUS_REVIEW_AND_GATES.md). Các tên trường dưới đây là đề xuất hợp đồng logic để cụ thể hóa spec; không khẳng định code đang dùng hoặc sửa expected cũ cho khớp.

## 1. Đường đi của dữ liệu

```mermaid
flowchart LR
    S["Nguồn gốc và lời khai"] --> O["Dữ kiện đọc được<br/>kèm vị trí nguồn"]
    O --> L["Đề xuất liên kết<br/>giữa khoản và nguồn tiền"]
    O --> V["Xác thực và chuẩn hóa<br/>giữ phần chưa xác định"]
    L --> V
    V --> C["Checks, phép tính<br/>và vấn đề cần giải quyết"]
    C --> R["Báo cáo và câu hỏi<br/>chưa tự là phê duyệt"]
```

Đọc được một lời khai chỉ chứng minh lời khai đó tồn tại. Đọc số tổng hóa đơn không chứng minh người nào đã trả. Liên kết AI đề xuất chưa tự là quan hệ đã đủ căn cứ để tính tiền.

## 2. Các nhóm dữ liệu cần giữ — không phải mỗi nhóm một service

| Nhóm | Nội dung tối thiểu | Ai tạo/được thay đổi? |
| --- | --- | --- |
| Context hồ sơ/lần chạy | case_id, work/employee refs, job B3/B7, input_revision, money_as_of, policy/config version; nguồn quyền và coverage áp dụng | Ứng dụng quản lý; context thiếu được giữ issue, không cấm nhận hồ sơ hoặc tự đoán |
| Nguồn | source_id, bản gốc/hash, loại nguồn, người cung cấp/thời điểm, issuer nếu có, quan hệ thay thế/bổ sung, page/row/form locator | Ứng dụng giữ bản gốc; người cung cấp không tự là issuer hoặc chủ quyền quyết định |
| Dữ kiện đọc và chuẩn hóa | fact_id, key, raw_text/value gốc, read_state, refs/locator, giá trị chuẩn hóa và căn cứ sử dụng hoặc chưa đủ | AI/parser tạo quan sát; chương trình kiểm tra/chuẩn hóa; bổ sung giữ provenance, không ghi đè source |
| Quan hệ khoản chi/sự kiện | expense/event refs, facts liên quan, relation/portion, bằng chứng, đề xuất/đủ căn cứ/chưa rõ | AI hoặc parser đề xuất; workflow ghi kết quả kiểm tra. Cần xem quan hệ có nguồn, không chỉ hợp lệ schema |
| Checks và issues | check_id/rule, applicability, kết quả/lý do, input refs; issue type, owner, phần bị chặn, câu hỏi và điều kiện giải quyết | Chương trình tạo từ checks; lời văn AI không đổi outcome/owner/required evidence |
| Báo cáo | Phần đã rõ/chưa rõ, bảng khoản chi, các thành phần tiền có trạng thái, số/chiều đề xuất khi đủ, issues và bước tiếp | Chương trình tổng hợp từ dữ kiện/checks; UI hiển thị cùng kết quả |
| Quyết định và sự kiện tiền | Actor/role/căn cứ quyền, nội dung/phạm vi/phiên bản/điều kiện; riêng gross amount, payer/payee, event time, outcome và refs tiền | Người quyết định/nguồn thực tế; chương trình kiểm tra hiệu lực. Không trộn approval với receipt |
| Run/history | run_id, status, step outputs/errors, timing/calls, config/source versions, Stop/resume, quan hệ run trước/sau | Ứng dụng lưu; kết quả muộn không tự cập nhật current report hoặc tạo hành động |

Đây là tám nhóm trách nhiệm nghiệp vụ, chưa là tám class hoặc tám bảng. Không dựng một schema thu thập mọi trường trên mọi loại bill. Fact keys theo job/check áp dụng; cùng key xuất hiện ở nhiều nguồn vẫn giữ từng quan sát và mâu thuẫn.

Ứng dụng cấp IDs nội bộ. ID ngoài nguồn giữ namespace, không coi transaction44 ở hai ngân hàng là cùng event. Khi parse output, phát hiện duplicate/extra IDs hoặc tham chiếu sai trước khi dùng dict/aggregation có thể ghi đè dữ liệu. Model chỉ được tham chiếu nguồn/candidates đã cung cấp, không cấp case/version/quyền cho chính nó.

## 3. Hợp đồng đọc tài liệu

### Input

Một nguồn cụ thể hoặc phần/trang có giới hạn, kèm source_id và các fact keys cần cho checks. Form/CSV có cấu trúc được parse trực tiếp khi phù hợp. AI không nhận gold, expected outcome hoặc catalogue case labels. Tên file chỉ để hiển thị/tham chiếu, không là nhãn đáp án.

Với các keys đã yêu cầu, output phải cho biết đã đọc, không tìm thấy hay chưa rõ; bỏ field khỏi response không tự là NOT_FOUND. Một key có thể có nhiều observations tại các vị trí khác nhau, cần giữ locator để phân biệt. Không ép chúng thành một value bằng cách lấy lần xuất hiện cuối.

### Output AI tối thiểu

Ví dụ đọc tổng hóa đơn — **minh họa hợp đồng, không kết quả OCR đã chạy**:

```json
{
  "fields": [
    {
      "key": "invoice.total",
      "raw_text": "3.000.000",
      "read_state": "READ",
      "evidence": {
        "page": 1,
        "quote": "Tổng thanh toán: 3.000.000"
      }
    }
  ]
}
```

Nguồn đang đọc do envelope của ứng dụng xác định. Sau parse hợp lệ, ứng dụng cấp fact_id và gắn source_id/version; model không cần lặp toàn bộ context mỗi field.

| read_state | Ý nghĩa | Giá trị được dùng |
| --- | --- | --- |
| READ | Có quan sát cụ thể được đọc từ nguồn | raw_text giữ nguyên; chương trình chuẩn hóa rồi kiểm tra điều kiện sử dụng |
| NOT_FOUND | Không tìm thấy field trong phần nguồn đã đọc | null, kèm phạm vi đã đọc; không khẳng định thiếu trong toàn hồ sơ hoặc lịch sử công ty |
| UNCLEAR | Field/vùng liên quan không đọc đủ chắc để xác định | null cho giá trị chưa rõ; có locator/fragment nếu có, không suy số từ form khai |

Lỗi provider, output không hợp lệ, PDF không xử lý được hoặc trang chưa đọc là trạng thái bước/run kỹ thuật riêng; không gán NOT_FOUND cho việc chưa đọc. Source format không có page thì dùng row/field locator thật; bbox chỉ khi có vị trí đáng tin cậy, không yêu cầu model bịa tọa độ.

Quote là nội dung model/parser đọc ra, không một chứng cứ độc lập xác nhận extraction đúng. Giữ trang gốc để đối chiếu. Căn cứ phải chỉ đúng field và đủ rõ; page hợp lệ nhưng quote sai hoặc chỉ trỏ chung không thành đủ nguồn. Backend kiểm tra định dạng/ref và phần kiểm tra được; semantic accuracy và locator accuracy còn phải chấm trên originals.

**Chuẩn hóa:** giữ raw, currency và đơn vị theo nguồn; money used for claims/results là integer VND. Values/quantities/prices nguồn dùng Decimal có giới hạn theo spec sau này; không float hoặc đoán tỷ giá/đơn vị. Dấu phân cách/đơn vị chưa xác định duy nhất thì giữ issue. Currency VND không tự suy từ locale hoặc chữ số. Null khác 0.

Facts thực sự cần đọc tùy loại nguồn: invoice/vendor/ref/date/amount/currency; vé/booking/person/work-purpose; nguồn tiền amount/parties/event time/status/reference; quyết định nội dung/phạm vi/hiệu lực. Không bắt mỗi tài liệu có đủ tất cả các trường. Những thông tin tương đương có thể được cung cấp từ nguồn khác với ref rõ.

## 4. Hợp đồng ghép và xác định facts đủ căn cứ

### Input/output

Input gồm các observations đã kiểm tra cấu trúc, khoản khai báo, nguồn tiền và candidates trong scope. Output chỉ gồm candidate refs, relation đề xuất, phần/số nếu có nguồn và supporting fact refs; có thể trả chưa đủ căn cứ hoặc nhiều candidates. Model không viết final E/S hoặc tự chọn giao dịch chỉ vì giống amount/date.

Các quan hệ cần hỗ trợ trong phạm vi đầu: nguồn mô tả cùng khoản chi; payment thực hiện khoản/phần; event thuộc công việc/nghĩa vụ; nhiều source mô tả cùng event; return/refund liên quan khoản gốc khi thuộc phạm vi B7. Invoice và payment khác đối tượng: cùng payment có nhiều nguồn không cộng nhiều lần; có hai actual payments cho cùng invoice phải giữ cả hai và kiểm tra sự cố.

| Kiểm tra | Nếu chưa đạt |
| --- | --- |
| Refs tồn tại và đúng nguồn/namespace; source/field thực hỗ trợ quan hệ | Invalid output hoặc issue phù hợp; không âm thầm bỏ candidate sai rồi coi toàn output hợp lệ |
| Work/person/payer/payee/amount/currency/portion và mốc phù hợp với loại quan hệ | Giữ mâu thuẫn, không ép quan hệ để vừa phép tính |
| Căn cứ định danh đủ, không chỉ tên gần giống hoặc cùng tiền/ngày | Material ambiguity giữ issue và owner; Q07 mapping có sẵn không chứng minh tự ghép raw |
| Một source/event không bị cộng lặp; các parts không vượt gross amount có căn cứ | Giữ raw events và sai lệch; không clip/deduplicate bằng amount/date |
| Receipt semantics và coverage đủ cho kết luận đang cần | Không đổi Paid/debit/approval thành actualreceipt hoặc empty search thành 0 |

Kết quả fact/quan hệ có **trạng thái sử dụng**: đủ căn cứ theo policy đang áp dụng, hoặc chưa đủ với reason/refs. Căn cứ là source trực tiếp hay bounded attestation được policy chấp nhận phải giữ riêng. AI không tự gắn "bank verified".

Đủ căn cứ không có nghĩa hệ thống chứng minh tài liệu là thật hoặc mô hình luôn đúng. Điều kiện source/rule xác định được được chương trình kiểm tra; độ đúng quan hệ ngữ nghĩa đo bằng gold độc lập. Tiêu chí/ngưỡng chấp nhận liên kết AI sẽ cụ thể hóa tại R7.3 sau đường đọc và calibration; chưa cho hành động B dựa vào confidence tự báo của model.

## 5. Hợp đồng kiểm tra, báo cáo và câu hỏi

### Checks

Mỗi check giữ rule_id, applicability và status riêng: PASS, FAIL có căn cứ, UNRESOLVED, hoặc NOT_APPLICABLE đúng lý do. Technical failure ở execution không giả là FAIL nghiệp vụ hoặc nhân viên thiếu chứng từ. Một check NOT_APPLICABLE không cho toàn hồ sơ PASS.

Issues có nhiều loại cùng lúc: FACT, POLICY, AUTHORITY; TECHNICAL/CAPABILITY và MONEY_INCIDENT/CONTROL giữ phân biệt, không ép vào ba loại đầu. Mỗi issue có refs, owner/nguồn cần có, câu hỏi hoặc thao tác cụ thể, phần bị chặn. Các facts/checks độc lập vẫn hiển thị khi final money chưa đủ.

### Các số tiền trong báo cáo

| Trường logic đề xuất | Điều kiện dùng và ý nghĩa |
| --- | --- |
| components | T/B/E/A/RA/P/RP có value hoặc null và state/refs phù hợp. B3 giữ dự toán/số xin/lịch sử liên quan, không giả E/S quyết toán |
| calculated_net_vnd | Phép tính xác định từ facts và eligibility đã rõ, nhưng có thể còn thiếu quyền cho kết quả/bước tiếp; Q14 có 3triệu và authority issue |
| conditional_results | Chỉ các kịch bản policy rõ từ facts đã xác minh, ghi điều kiện và các thành phần giả định theo quyết định đang xin; Q13 có nhánh chấp nhận toàn/phần. Không giả số nguồn mờ |
| proposed_net_vnd | Số đủ facts/eligibility và căn cứ/quyền cần cho report-ready; chưa là số đã duyệt. Q01 là3triệu; Q14 giữ null khi chưa có đường quyết định đủ quyền |
| approved amount / actual events | Hiển thị từ records quyết định/tiền riêng; không sao chép proposed/calculated vào các nhóm này |

Không lấy first-non-null làm payable. Các trường có thể trùng số nhưng khác nghĩa. Nếu critical amount/payer/history chưa rõ như Q08–Q12, số net cần các facts đó giữ null; subtotal đã biết hiển thị riêng, không thành net toàn hồ sơ.

Report job completion là COMPLETE hoặc INCOMPLETE cùng checks/issues/execution; khác tiến trình đã rà soát, đã phê duyệt, thực nhận và đóng tại R6. COMPLETE yêu cầu các check áp dụng/material issues theo scope đã xử lý và đúng routing; sự cố kỹ thuật ảnh hưởng kết quả không COMPLETE. Chờ quyết định tài chính thường quy sau report-ready không tự biến job thành missing-fact case. B3 đề nghị mới không bị incomplete chỉ vì chính approval đang xin chưa có.

### Một câu hỏi được coi là đủ

Giữ issue_id, đúng owner, khoản/nguồn đang xét, phần đã biết, điều còn thiếu, loại phản hồi/nguồn/decision cần thiết và phần bị chặn. Không chỉ "Vui lòng bổ sung thông tin" hoặc đòi người trả lời đoán số trên ảnh mờ.

Phản hồi giữ liên kết question_id, người/vai/phạm vi, nội dung và evidence/decision nếu cần, revision/thời điểm. Answer received khác issue resolved. Sau kiểm tra người/phạm vi/nguồn và re-check phần ảnh hưởng mới đóng issue; câu trả lời sai giữ lịch sử/lý do. Hỏi nhiều issue độc lập cùng lần được, không ép từng lượt chỉ để có nhiều vòng agent.

## 6. Hợp đồng run và evaluator

Mỗi run gắn immutable input snapshot, job, policy/config, money_as_of và các sources đến mốc kiến thức đã công bố; nguồn đến muộn tạo run/revision liên kết. source received time khác actual event time. Step output có provider/mode/config và timing/error; extraction được dùng lại giữ origin run và trạng thái reuse.

Runner gọi cùng ứng dụng với UI, rồi đọc outputs/history thực tế và chấm. Expected/gold ở phía evaluator, không nằm trong inputs/model prompt; case labels không được điều khiển workflow. Chưa chỉnh fixture/expected cũ: adapter evaluator sau này phải chuyển đúng nghĩa, không chọn trường amount tiện nhất. Snapshot/gold mới phải có version/reason khi thay đổi.

| Lớp | Chấm cụ thể | Không đủ để coi đúng |
| --- | --- | --- |
| Extraction | Critical known fields đúng nghĩa/value và refs/locator; unknown đúng riêng; đủ trang/phạm vi cần đọc | JSON hợp lệ, document readable hoặc quote do model tự viết |
| Linking | Required relations/parts đúng; extra wrong relations; nguồn hỗ trợ và source namespaces | Net đúng tình cờ, amount/date khớp hoặc nguồn do người ghép trước |
| Rule/money | Applicability/checks, components, exact amount/chiều hoặc null đúng; không nguồn/issue material bị bỏ | Chỉ một trường S đúng hoặc gọi cùng production rule làm oracle |
| Question/response | Issue/owner/refs/request đủ; câu trả lời đủ giúp tiếp tục, sai không giải quyết | Khớp câu văn mẫu hoặc có cờ NEEDS_HUMAN |
| Control/workflow | State lưu và hậu quả: Stop, stale, rerun, partial, wrong recipient, time scopes, closure | Text UI báo đã dừng/đóng mà lưu/hành động thực tế sai |
| End-to-end | Kết quả đúng và được lưu, completion/autonomy; FN/FP cùng lỗi kỹ thuật và effort/timing | Chỉ báo các lần thành công, first-pass sau khi người đã sửa hoặc chọn sources |

Tầng rules có input facts chuẩn do oracle độc lập, đánh giá phép kiểm tra. Tầng pipeline nhận sources thật trong scope của mode và đánh giá toàn chuỗi. Failure record ghi step và reason; nếu chưa đủ trace xác định nguyên nhân thì ghi inconclusive, không quy hết cho OCR/LLM. Dù có nhiều lỗi, không loại case khỏi mẫu số đã công bố tại R5.

Metric extraction có mẫu số critical gold facts theo check/source, kể cả fact có gold nhưng output bỏ sót; không chọn critical fields sau khi thấy output. Case có nhiều nguồn thay thế cần đủ căn cứ đúng, không buộc trích mọi field trên mọi bill. Chấm link và locator theo nghĩa/nguồn, không phụ thuộc IDs tự sinh phải giống gold.

Vẫn cần gold độc lập và calibration/holdout khác family. Các schema/enum/JSON minh họa không là validation tests hoặc bằng chứng quality/runtime.

## 7. UI giúp chủ dự án kiểm chứng hợp đồng này

Mỗi dòng kết quả cần mở được nguồn và xem: quan sát gốc → giá trị chuẩn hóa/căn cứ sử dụng → liên kết → check/rule → tác động tiền. Phần chưa xác định hiển thị thiếu gì và ai xử lý. Không đưa raw debug JSON vào luồng nghiệp vụ chính; chi tiết run có thể nằm trong phần kiểm tra riêng.

Ví dụ hotel3triệu đọc rõ, nhưng payer chưa đủ: UI hiện invoice total3 với ref, payer chưa rõ, E/S toàn hồ sơ chưa xác định nếu ảnh hưởng. Sau bổ sung đúng nguồn, hiển thị fact/link thay đổi và run mới; không biến nút sửa số thành bằng chứng thanh toán.

UI quyết định/tiền luôn phân biệt số đề xuất, đã duyệt, thực nhận và còn lại. Mọi số dùng để quyết định truy về cùng report/run mà evaluator chấm. Đây là acceptance cho các lát cắt R8, chưa một giao diện đã chạy.

## 8. Nhận xét của lead và bước tiếp

Giữ provenance, null semantics và quan hệ tiền là mức tối thiểu: bỏ chúng khiến không xác định được kết quả đúng vì sao. Không thêm generic knowledge graph, ontology hóa đơn, confidence cho mọi field hoặc một LLM tự đánh giá lời giải của chính nó làm gold.

Hợp đồng cũng không tự nâng chất lượng. Nó làm lỗi có thể quan sát và chấm; model/provider/prompt/nguồn vẫn cần đo thật. Chưa chọn threshold hay khẳng định mọi semantic link được chương trình chứng minh.

Chủ dự án đã đồng ý tiếp tục từ hợp đồng logic này. [R7.3](R7_AI_READING_ORCHESTRATION_DRAFT.md) cụ thể hóa đường đọc tài liệu/AI và điều phối — khi nào parse/OCR/thị giác, khi nào gọi matching, cách giới hạn context/output, xử lý lỗi và re-check. Cần lựa chọn công nghệ có tài liệu chính thức và đo đúng mode; R8 mới đối chiếu code/lập plan. Không bắt đầu code ở R7.2.

# R8.1 — Đối chiếu code hiện tại với spec quyết toán đã duyệt

Ngày: 09/10/2026 · Branch: rebuild · HEAD: `7d0296fac3bcdd4bf0879c2202152a7d26f87411`.

**Kết luận: giữ nền tảng kỹ thuật, thay lõi nghiệp vụ và hợp đồng UI/evaluation bị phụ thuộc thiết kế cũ.** Đây là review có phạm vi phục vụ plan, không audit toàn repo hoặc kết luận baseline mới đã đạt. Không sửa code/gold trong lượt đối chiếu này.

Authority: [spec R7.5 đã được chủ dự án đồng ý](R7_MVP_SYSTEM_SPEC_DRAFT.md), [policy](R4_WORK_BUDGET_POLICY.md), [R3 A/B](R3_MVP_SCOPE_DRAFT.md), [R7.4](R7_STACK_PROVIDER_BENCHMARK_DRAFT.md), [gates R5.8](R5_CORPUS_REVIEW_AND_GATES.md). Source hiện tại là bằng chứng tồn tại, không oracle cho nghiệp vụ mới.

## 1. Bằng chứng và giới hạn discovery

Dùng CodeGraph trước code discovery, query projectPath chính xác của repository. Source/snippets hiện tại và caller refs cho API/service/pipeline/domain/storage/provider/UI/Verify được đọc qua graph; schema SQL, config/package/docs đọc trực tiếp vì không được graph trả đủ. Các material claims dưới đây gắn file/symbol/range cụ thể; không suy missing module toàn repo từ lookup trống.

Codebase-memory-mcp list_projects/index_status/check_index_coverage không exposed trong session. Index nearest: `.codegraph/codegraph.db`; project_metadata có index_state complete nhưng discovered/accounted counters0 và không cung cấp generation ID đáng tin cậy. Graph có các vùng source trimmed/gap và không index schema.sql; không coi metadata là chứng minh coverage đầy đủ. Tool trả source current on-disk của symbols chọn; cross-file call resolution là best-effort, chỉ dùng các calls được source hỗ trợ. Mức kiểm tra task-directed với limitations, **không Auditor/exhaustive**. Không tạo/update index hoặc gọi subagents.

## 2. Các khác biệt có tác động thực tế

| ID | Bằng chứng hiện tại | Vì sao không đáp ứng spec mới | Hướng xử lý |
| --- | --- | --- | --- |
| R8-F01 | application/pipeline.py preflight85–100 và _ambiguous_primary136–149: từ chối ADVANCE/COMPANY/VENDOR, nhiều primary bill yêu cầu làm rõ/tách | Hồ sơ mới cần nhiều khoản/chứng từ và history ứng; payer là fact theo phần, không mode checkbox quyết định toàn hồ sơ | Thay preflight/domain theo jobsB3/B7, không chỉ thêm ADVANCE vào allowed list |
| R8-F02 | storage/repository.py finalize_run604–719: CREATE_PAYMENT_REQUEST dẫn tới _ensure_payment_request trong finalization | A phải lưu report/questions trước decision tài chính; routine report chưa có nghĩa tạo payment entity củaB | Lõi mới finalization không tạo request; giữ nguyên tắc transaction/Stop/stale để áp đúng hậu quả mới |
| R8-F03 | storage/schema.sql và domain CaseSnapshot299–308/RunRecord313–326: model hiện tại gắn claim/evidence/policy và case_version; schema đã đọc không có case_revisions/money_events/control_epoch mới | Không thể đại diện đủ A/RA/P/RP, receipt/pending/partial, knowledge/money cutoffs và hiệu lực decision khác mutation version bằng hợp đồng hiện tại | Store/snapshots cho nghiệp vụ mới trong DB riêng; không xóa hoặc giả migrate tiền từ payment_requests |
| R8-F04 | config/demo-policy.json: auto_approval_max2triệu, inventory_date_gap7; decision.evaluate207–215 dùng MODE-01 từ payer declaration | Ngân sáchB theo công việc và quyền theo source/scope thay caps tự động cũ; companydirect/payer cần đối chiếu evidence | Budget/authority evaluator mới; không chép auto cap thànhB hoặc tính receipt từ quyết định |
| R8-F05 | frontend/types.ts49–58,109–117,159–169; CaseDetail206–210 và DecisionSummary367–392 tập trung accepted_amount/request | UI chưa có bảng components/proposed/approved/actual/remaining và không thể hiện đủ closure/coverage mới qua types đã đọc | Giữ layout/preview/polling patterns, thay contract và các màn hình nghiệp vụ |
| R8-F06 | verify/runner.py _actual174–188 và _verdict190–210 chấm action/request/amount; amountNone không được so exact, issues/owners/rules dùng subset | Corpus mới cần null đúng, links/extra wrong links, từng thành phần tiền và forbidden transitions; đúng action/amount cũ không đủ | Runner mới cùng SettlementService; gold adapter kiểm nghĩa, không firstnonnull hoặc dùng production engine làm oracle |
| R8-F07 | application/executor.py RunExecutor25–35 một slot; LiveProviders có timeout/env/output compact, pipeline OCR mọi evidence226–242 | Target2active runs/bounded5 và parse/text/image routing/global budget chưa được chứng minh bởi cấu hình này | Điều phối/config/reader theoR7.3–4; providers theo run để không lẫn identities/traces |
| R8-F08 | api/app.py create_runtime_app512–520 nói autoactivate policy; README hướng dẫn manualactivation/no live và configKimi cũ | Tài liệu hiện trạng không đủ làm hướng dẫn workflow/provider mới | Cập nhật current docs khi wiring mới tồn tại; giữ rõ runtimelegacy và planned settlement |

Các khác biệt trên là contract mismatch với R7, không mặc định gọi mọi hành vi cũ là bug theo contract cũ. Không sửa gold cũ để làm bằng chứng mới. Schemaabsence chỉ trong schema đã kiểm, không tuyên bố toàn repo không có mọi chức năng tương tự.

## 3. Phần đáng giữ

| Phần | Evidence | Giới hạn khi reuse |
| --- | --- | --- |
| Stack | pyproject.toml/frontend/package.json; môi trường có FastAPI0.142.2, Pydantic2.13.5, HTTPX0.28.1, pytest9.1.1 | Không cài lại scaffold; versions mới cần resolve/lock nếu đổi dependencies |
| Numeric parsing | policy/numeric.py parse_candidates113–142, Context50digits, explicit grammars/bounds | Dùng parser có nguồn/locale; technical bounds không thành policy budget. Signed net dùng arithmetic mới |
| Artifact storage | storage/artifacts.py put_artifact27–56 và safe_name16–24 | Backend paths và atomic file writes có thể giữ; DB/file rollback/source bindings phải đúng store mới |
| Source/compact output principles | extraction/compact.py source_catalog82–107, extraction/validation.py symbols/source contract | Dùng idea/ref/validation đã có, adapt contract; không bê enums hoặc qualityscore assumptions chưa đo |
| Guard patterns | repository.finalize_run Stop617–634/current643–654; service checkpoints371–374 | Giữ invariant, viết tests mới với control_epoch/decision basis/handoff, không coi old payment tests là proof toàn controls mới |
| UI | EvidencePreviewModal18–137, API client, polling App69–81, styles | Presentation có thể reuse; new endpoints/allowed_actions/labels/source types phải đúng |
| Sequential Verify/app path | VerifyRunner.run52–64 gọi service theo thứ tự | Reuse orchestration pattern, thay oracle/inputs/results/metrics để chấm đúng jobs mới |

## 4. SYS-ID → hiện trạng → công việc

| Acceptance | Hiện trạng trong scope đọc | Task plan |
| --- | --- | --- |
| SYS-01 | IMPLEMENTED foundation upload/SQLite/preview; revision/provenance mới PLANNED | W01 |
| SYS-02 | IMPLEMENTED strict/ref/compact foundations; contract mới PLANNED | W02,W03 |
| SYS-03–06 | PLANNED B7 components/budget/payer/links/cumulative history mới | W02,W03 |
| SYS-07 | PLANNED B3 request/import/forecast và scope authority mới | W04 |
| SYS-08 | IMPLEMENTED old human actions; response→recheck lifecycle mới PLANNED | W04 |
| SYS-09–10 | PLANNED decision/receipt/remaining/incident separation mới | W05 |
| SYS-11–13 | VERIFIED selected old fake Stop/current guards; epoch/version/idempotency/semantics mới PLANNED | W01,W05 |
| SYS-14 | PLANNED closure/refusal duties theo spec mới | W05 |
| SYS-15 | IMPLEMENTED one-slot old executor;2active/bounded5/source limits mới PLANNED | W01,W03,W05 |
| SYS-16 | VERIFIED old sequential Verify integration; new gold/null/link/failure metrics PLANNED | W02,W06 |
| SYS-17 | Old path IMPLEMENTED create request; A report boundary mới PLANNED, BTC compatibility INCONCLUSIVE | W02,W05,W06 |

## 5. Fresh checks đã chạy, không quality baseline mới

| Command | Actual result/mode |
| --- | --- |
| rtk proxy .venv/bin/python -m pytest tests/integration/test_execution_controls.py tests/integration/test_pipeline.py tests/integration/test_verify.py -q |37passed,1Starlette/httpx deprecationwarning; fake/replay integration,1.83s |
| rtk proxy npm --prefix frontend run test -- --run |34passed trong8testfiles; Vitest/jsdom components,1.50s |
| rtk proxy npm --prefix frontend run build |Typecheck/build passed; Vite5.4.21 build3.15s |

Không chạy toàn backend suite ở lượt review này, không liveOCR/xkiro, browser E2E hoặc thử5phiên/3người làm nghiệp vụ. Các commands trên chứng minh selected current path còn hoạt động theo tests cũ, không đúng nghiệp vụ mới. Không broaden/repeat tests khi chưa đổi code hoặc có failure cần giải quyết.

## 6. Quyết định triển khai đề xuất

Lõi claim/primary/payer/auto-request cũ coupling mạnh. Chọn rebuild **bounded settlement core** trong cùng package/app stack, giữ utilities thật đáp ứng, normal UI/runner cùng core mới. DB settlement riêng tránh ghi đè local data cũ; old factory/tests là historical comparison, không fallback âm thầm trong đường mới.

Một core mới ở đây không là microservice hoặc generic v2framework. Tách tên trong quá trình chuyển đổi giúp không sửa gold/giữ bug để tương thích contract cũ. Sau cutover, entrypoint bình thường và Verify mới chỉ gọi settlement core; code/test cũ phải được ghi lịch sử, không được quảng cáo như acceptance mới.

[Plan triển khai](../superpowers/plans/2026-10-09-settlement-mvp.md) chia6luồng có UI và quality checks. Không freeze B1 từ kết quả37/34pass. R7.5 được đồng ý là authority thiết kế để coding agent bám, không runtime evidence.

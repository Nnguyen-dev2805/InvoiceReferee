# R4.3 — Thẩm quyền tài chính cho policy ngân sách tổng

Ngày: 09/10/2026 · Trạng thái: **ĐỀ XUẤT HAI CẤP CŨ ĐÃ ĐƯỢC THAY THẾ; GIỮ LỊCH SỬ, CHƯA TỪNG ĐƯỢC DUYỆT/KÍCH HOẠT/CODE**.

Chủ dự án đã đồng ý mô hình [ba vai và một người duyệt có quyền](R4_ROLES_HANDOFF_POLICY.md). Kế toán rà soát và thực hiện, không có quyền duyệt tài chính mặc định. Không dùng hai mức10/30triệu bên dưới làm quy tắc hiện hành. Giữ nội dung dưới đây làm lịch sử đề xuất, không tự kế thừa số/vai.

Căn cứ [policy ngân sách tổng đã được đồng ý](R4_WORK_BUDGET_POLICY.md), [R4.2 evidence](R4_EVIDENCE_RULES_DRAFT.md), [B8/B9](B8_B9_MVP_PROPOSAL.md). Lead tự review; không dùng subagent. Đây là bảng phân quyền demo, không xác lập chức vụ/quyền thực tế, định mức pháp luật hoặc giá thị trường. Hai số10/30triệu được chọn để có các trường hợp trong quyền, vượt một cấp và chưa có ai được giao quyền; không là trần chi phí mỗi công việc.

## AU-01 — Hai mức quyền, không quyền theo từng nhóm chi

| Vai tài chính demo | Giới hạn số tiền đang quyết định | Loại quyết định được giao |
| --- | --- | --- |
| Người phụ trách tài chính | ≤10.000.000 VND | Ngân sách, ứng và quyết toán thường quy trong phạm vi đã rõ; không quyền ngoại lệ mặc định |
| Người được giao quyền cấp cao | ≤30.000.000 VND | Các quyết định thường quy trên10triệu đến30triệu; ngoại lệ vượt ngân sách và chấp nhận sau phát sinh trong phạm vi demo, kể cả số nhỏ hơn10triệu |

Đúng bằng giới hạn là trong quyền. Trên30triệu: chưa có vai được giao đủ quyền trong bảng demo; lưu kết quả kiểm tra và vấn đề quyền, yêu cầu căn cứ giao quyền/quyết định phù hợp rồi cập nhật theo version nếu có. Không tự duyệt, không chia hồ sơ/giảm số để lọt quyền, không coi chi phí bị cấm hoặc người cao nhất có quyền vô hạn.

Quản lý công việc chỉ có quyền cho phép công tác/phạm vi được giao, không tự có quyền tài chính. Người thực hiện chi/thu làm theo quyết định có hiệu lực, không đổi số được duyệt. Có thể một operator mô phỏng các vai nhưng ghi đúng người/vai/nội dung/scope/version; role picker không là xác thực danh tính công ty thật.

## AU-02 — Số nào được so với giới hạn?

| Quyết định | Số/phạm vi kiểm tra |
| --- | --- |
| Duyệt ngân sách hoặc thay ngân sách | Tổng B của phiên bản đang đề nghị duyệt, gồm company-direct và employee; không chỉ phần B tăng thêm |
| Duyệt tạm ứng | Số ứng được duyệt cho nghĩa vụ đó. Nếu cùng quyết định còn duyệt ngân sách thì kiểm tra cả B; không dùng ứng nhỏ để bỏ qua quyền duyệt B |
| Quyết toán thường quy | E trước đối trừ và trị tuyệt đối S cần được phê duyệt đều trong giới hạn. S chưa xác định thì chưa đủ để duyệt kết quả cuối |
| Ngoại lệ vượt ngân sách / chấp nhận chi phí sau phát sinh | Vai phải có quyền ngoại lệ, xét toàn T chi phí công việc đang được quyết định, không chỉ phần vượt; kiểm tra thêm E và số chi/thu nếu quyết định bao gồm quyết toán |

Kiểm tra từng nội dung có quyền tương ứng trong cùng quyết định, không cộng B+ứng+E+S thành một số vì chúng có thể biểu diễn cùng phạm vi tiền. Có thể một quyết định chứa ngân sách/ứng hoặc ngoại lệ/quyết toán nếu đủ quyền và nguồn, không bắt nhiều vòng bấm vô ích.

Ngân sách B đã được cấp cao duyệt12triệu không mặc định bắt cấp cao duyệt lại mọi nghĩa vụ nhỏ trong đó: nếu E=8triệu, S=6triệu và không có ngoại lệ, người tài chính có thể quyết toán trong quyền10triệu theo bảng đề xuất. Quyết định B cũ cần đủ hiệu lực/căn cứ; nếu đang đổi B thì kiểm tra quyền mới.

## AU-03 — Chuyển người theo nguyên nhân thật

- Fact/receipt/sourcecoverage còn thiếu: hỏi chủ nguồn trước, không xin người cấp cao approve số đang mờ.
- Rule và số rõ nhưng ngoài quyền người đang xử lý: tự chuyển đúng vai được giao nếu mapping đủ. Chuyển người không biến thành câu hỏi “Ai được duyệt?” khi đã biết.
- VượtB dù số nhỏ: người tài chính không quyền ngoại lệ, chuyển cấp cao; trong giới hạn số tiền không tự tạo quyền ngoại lệ.
- Trên30triệu hoặc chưa có căn cứ quyền phù hợp: giữ vấn đề beyond-authority, không mặc định role cao nhất được phép.

Nếu người cấp cao chấp nhận một khoản trong10triệu với đủ nguồn, quyết định vẫn hợp lệ; đây là quyền bao phủ, không ép cấp thấp bấm thêm. Nhận approval bên ngoài phải kiểm tra nguồn/phạm vi/quyền theo cùng rule, không yêu cầu tạo lại chỉ vì không bấm trong app.

## AU-04 — Chống giảm số/chia hồ sơ để lọt quyền

Trước hành động quyết định, dùng số/phạm vi đang được xét, không dùng số người duyệt tự giảm sau đó để hợp thức hóa quyền. E=12triệu, quyền10triệu không được tự chấp nhận9 để né chuyển cấp. Fact correction hoặc loại chắc chắn theo rule làm E=9 từ trước quyết định là trường hợp khác, cần nguồn/lý do/re-check đúng.

Ngoại lệ T=31triệu không thành trong quyền30triệu chỉ bằng đề nghị chấp nhận30; quyết định đang xét toàn phạm vi31. Không chia một quyết toán thành hai hồ sơ nhỏ để giao người ít quyền; cùng công việc/quyết toán lũy kế dùng E đầy đủ đang xét. Ghi chỉ dẫn chi từng phần không chia nhỏ quyền của nghĩa vụ đã duyệt và không tự thêm installment automation.

Chỉnh nguồn/policy/ngoại lệ sau report ảnh hưởng E/S/B/T thì kiểm tra lại quyền và hiệu lực phần quyết định liên quan. Không xóa quyết định cũ hoặc tiền đã xảy ra. Override/human approval không miễn số học, evidence/quality hay sourcecoverage bắt buộc.

## Ví dụ để kiểm tra bảng quyền

Giả định mọi fact/rule/nguồn và quyết định liên quan đủ rõ, không có nghĩa vụ khác còn vướng; số0 có căn cứ. Các dòng là suy luận thiết kế, chưa chạy code hoặc gold đánh giá.

| Trường hợp | Người/quyết định tiếp theo |
| --- | --- |
| Đề nghị duyệt B=8triệu và ứng2triệu trong cùng quyết định | Người tài chính đủ mức; kiểm tra riêng ngân sách và ứng, không cộng thành10 |
| Đề nghị duyệt B=12triệu và ứng2triệu | Cấp cao vì quyền duyệtB; không dùng số ứng2 để qua cấp thấp |
| B=8triệu, T=9triệu, E chưa chốt do vượtB | Cấp cao quyết định ngoại lệ dù phần vượt chỉ1triệu |
| B=12triệu đã cấp cao duyệt; T trongB, E=8triệu, A=2triệu, S=+6triệu | Người tài chính có thể duyệt quyết toán8/6 trong quyền10 |
| E=12triệu, A=12triệu, S=0, chi phí trongB hợp lệ | Cấp cao; net0 không miễn quyền quyết toán12 |
| E=0, A=12triệu, S=-12triệu theo policy/nguồn đủ | Cấp cao vì số hoàn lại12; không lấy E=0 để giao cấp thấp |
| B dự kiến hoặc T ngoại lệ=35triệu | Chưa có đủ quyền trong bảng; cần căn cứ phân quyền/quyết định mới, không auto từ chối nghiệp vụ |

## Tự review và việc cần chốt

Hai cấp tránh cấu hình nhiều tầng hoặc quyền theo mỗi loại chứng từ. Giới hạn30triệu giúp không để demo “cấp cao duyệt mọi số”, nhưng là lựa chọn giả lập, chưa có bằng chứng thực chứng cho10/30. Có thể đổi hai số một lần khi chủ dự án chốt rồi freeze để R5 lập gold; không tuning quyền bằng feedback để giảm escalation.

Đây là giới hạn người ra quyết định, không ngân sách mặc định hoặc hạn mức cho khách sạn/ăn/di chuyển. Mỗi công việc vẫn có B riêng; trongB vẫn cần eligibility/payer/history, vượtB vẫn cần quyền ngoại lệ. Job kiểm tra/báo cáo có thể hoàn tất dù chuyển checkpoint tài chính đúng vai; phải ghi riêng case cần giải quyết fact/policy/authority và công sức toàn lifecycle theo R3, không tự tuyên bố BTC chấp nhận boundary.

Đề nghị chủ dự án review hai mức10/30triệu và cơ sở số/phạm vi. Sau khi chốt, còn khóa hiệu lực/version và source contracts để expected R5 nhất quán; không coi policy/table này là runtime hoặc toàn R4 đã hoàn tất.

# R7.4 — Stack tối thiểu, Mistral OCR và LLM qua xkiro

Ngày: 09/10/2026 · **CHỦ DỰ ÁN ĐÃ ĐỒNG Ý STACK VÀ CẤU HÌNH THỬ BAN ĐẦU ĐỂ TIẾP R7.5 — CHƯA CODE HOẶC BENCHMARK**.

Chủ dự án dùng **OCR Mistral và LLM tại xkiro.com**. Đây là căn cứ lựa chọn kết nối đầu tiên, không xác nhận đã thử endpoint/account/quota trong InvoiceReferee. [R7.3](R7_AI_READING_ORCHESTRATION_DRAFT.md) được đồng ý để tiếp bước này; [R7.2](R7_DATA_AND_EVALUATION_CONTRACT_DRAFT.md), [R5](R5_EVALUATION_DESIGN.md) và [gates](R5_CORPUS_REVIEW_AND_GATES.md) tiếp tục giữ nguyên. Không đọc code cũ để đặt nhu cầu; R8 mới đối chiếu.

## 1. Stack đề xuất

| Phần | Chọn ban đầu | Lý do/ranh giới |
| --- | --- | --- |
| Backend | Python, FastAPI, Pydantic | Một ứng dụng/API, hợp đồng có validation. Rule/math/workflow là các hàm/module trong ứng dụng |
| UI | React + TypeScript + Vite | Thuận tiện dựng bảng đối chiếu, xem nguồn, phản hồi, quyết định và trạng thái run; triển khai từng luồng có UI |
| Lưu dữ liệu | SQLite qua sqlite3; thư mục file nguồn | Đủ điểm bắt đầu cho pilot nhỏ, giữ refs/version/history. Không thêm ORM/migration framework trước schema cần thiết |
| PDF/ảnh | pypdfium2 cho text/render; Pillow khi cần xử lý representation | Một đường PDF có text và render; giữ original và mapping locator |
| Provider | HTTPX gọi Mistral OCR và xkiro Chat Completions | Hai kết nối cụ thể với output chuyển về contract R7.2; không registry/factory cho các nhà cung cấp chưa dùng |
| Điều phối | Workflow Python, task registry hữu hạn trong process | Run ID/trạng thái/Stop lưu; không LangChain/LangGraph hoặc worker service làm điều kiện mặc định |
| Kiểm chứng | pytest + runner đánh giá; Playwright cho UI E2E trọng yếu | UI/Verify dùng chung application path; không tự động hóa mọi click hoặc unit test mirror mọi helper |

Các lựa chọn trên là đề xuất của lead, chưa cài/resolve packages hoặc chốt lockfile. Khi R8 triển khai, kiểm tra dependency thực tế và compatibility, lock đúng versions đã resolve; không gọi bản docs latest là installed version. Nếu phần hiện có đáp ứng được contract và giảm công sức, R8 có thể giữ nó thay vì viết lại chỉ để giống bảng.

[Vite](https://vite.dev/guide/) có template React/TypeScript; đây không là bằng chứng UI đã build. [Pydantic](https://pydantic.dev/docs/validation/latest/concepts/strict_mode/) có strict validation; vẫn cần kiểm tra refs/semantics/duplicate IDs riêng, không suy schema valid thành kết quả đúng.

[pypdfium2](https://pypdfium2.readthedocs.io/en/stable/python_api.html) có text extraction và render, nhưng PDFium không thread-safe. Đề xuất mọi thao tác PDFium đi qua một executor tuần tự trong app, đóng handles rõ; không để hai run render đồng thời qua các thread khác nhau. Giới hạn này cần test, không xử lý bằng mở hạ tầng render phân tán cho pilot5người.

## 2. Đường AI đầu tiên

**Ảnh/scan → Mistral OCR → observations có page/block refs → LLM xkiro trích xuất → kiểm tra/chuẩn hóa → ghép nguồn nếu cần → rule/math/quyền → report/questions.**

Form/CSV hỗ trợ parse trực tiếp. Native PDF text dùng được có thể đi thẳng vào extraction phù hợp. Giữ trang gốc và quality gates; không miễn kiểm tra chỉ vì có OCR/text. Nếu cần quan hệ ngữ nghĩa, model nhận candidates đã có scope, không tự truy vấn ngân hàng/web hoặc kết luận payer từ lời khai.

[Mistral OCR](https://docs.mistral.ai/studio/document-processing/basic_ocr) công bố đọc ảnh/PDF và trả pages/Markdown; paragraph blocks chỉ có ở OCR4 trở lên. Khi bring-up cần kiểm tra model/account thực sự trả locator/quality metadata nào. Không tạo bbox/confidence thay cho field vắng, không giả feature từ docs có trên model đang chạy.

Ban đầu dùng OCR riêng rồi extraction xkiro để đo hai bước. [Mistral annotations](https://docs.mistral.ai/studio/document-processing/annotations) là biến thể có thể so sánh sau: nó dùng OCR và LLM phía dịch vụ, không chỉ parser hay phép xác minh độc lập. Không thêm đồng thời annotations và xkiro extraction nếu chưa đo lợi ích. OCR version/model ID thực dùng cần ghi/freeze khi bring-up; alias latest chưa là baseline bất biến.

## 3. xkiro: kết quả tra cứu và kiểm tra công khai

Đã đọc docs và thực hiện **GET public catalog**, không dùng key hoặc gọi sinh nội dung. [Evidence JSON](R7_XKIRO_CATALOG_EVIDENCE.json) ghi hash toàn response,130entries và metadata2ứng viên; đây không là thử truy cập account hoặc quality benchmark. Web tool không truy cập được catalog; curl trong sandbox lỗi DNS, sau khi được cấp quyền đọc mạng đã lấy được response.

Theo [API reference](https://docs.xkiro.com/api/overview/), dùng base `https://api.xkiro.com/v1`, Chat Completions và full model ID có vendor prefix. Docs công bố timeout blocking95giây. Không lấy snippet bare model trên homepage thay [live catalog](https://docs.xkiro.com/api/list-models/) làm nguồn model ID.

| Ứng viên từ catalog ngày09/10 | Vai trò đề xuất | Metadata quan sát, chưa inference verified |
| --- | --- | --- |
| mistralai/mistral-small-2603 | Candidate đầu cho text extraction/matching và challenger vision | vision true, access tier free, reasoning levels none/high, default none |
| mistralai/mistral-medium-3.5 | Challenger cùng input/schema để đo khả năng cải thiện | vision true, access tier free, reasoning levels none/high, default none |

Chọn **Small làm cấu hình đầu để benchmark**, không tuyên bố đã đủ chất lượng hoặc nhanh/rẻ hơn Medium từ tên model. Cả hai thử reasoning_effort=none trước theo metadata; không dùng high mặc định cho tác vụ trích xuất ngắn. Catalog có model không chứng minh account gọi được, quota còn hoặc effective setting/identity đúng. Kết quả cần ghi requested model, returned model và effective controls quan sát được; không suy cấu hình được áp dụng chỉ vì HTTP200.

### Các chi tiết ảnh hưởng thiết kế và phép đo

- [Structured output](https://docs.xkiro.com/guides/structured-output/) nói một số models chỉ áp JSON bằng prompt hoặc bỏ response_format. Đề xuất JSON prompt rõ + format khi được hỗ trợ + validator; không mặc định json_schema được cưỡng chế. Output truncated/refs sai không được đưa vào aggregation.
- [Vision](https://docs.xkiro.com/guides/vision/) nói ảnh gửi tới model không hỗ trợ có thể bị bỏ thay vì lỗi request. Vision challenger chỉ bật sau kiểm tra capability và probe đúng ảnh; HTTP200 không chứng minh đã đọc ảnh.
- [Reasoning](https://docs.xkiro.com/guides/reasoning/) phụ thuộc model, trường không hỗ trợ có thể bị bỏ/điều chỉnh. Vì vậy không áp tham số Moonshot/NVIDIA vào xkiro theo tên Kimi.
- [Routing overview](https://docs.xkiro.com/guides/overview/) mô tả failover giữa routes; response model có thể vẫn là tên đã yêu cầu. Nhãn benchmark phải là **pipeline qua xkiro với requested config**, không khẳng định đã đo độc lập đúng upstream/weights khi gateway không cung cấp bằng chứng. Giữ request IDs và metadata có sẵn; không tự bịa provenance.

API keys chỉ phía server, không trong UI/corpus/traces công khai. Chưa đọc key/env hoặc gọi usage/account ở bước này. User xác nhận dùng provider là căn cứ thiết kế, chưa tự là quyền chạy benchmark có chi phí.

## 4. Cấu hình pilot hữu hạn để thử ban đầu

Những con số dưới đây là **đề xuất kỹ thuật v0 để đo và chỉnh**, không policy hạn mức tiền, cam kết latency hoặc hỗ trợ mọi kích thước tài liệu. Giữ config/version trước so sánh; thay vì cắt dữ liệu để pass thì báo rõ giới hạn chưa xử lý.

| Tham số | Giá trị bắt đầu đề xuất | Khi chạm giới hạn |
| --- | --- | --- |
| App workers |1process | Scale khác cần xét lại task/admission guards, không chỉ tăng workers |
| Active runs |2; tối đa5run được tiếp nhận đang chạy/chờ trong process | Trả trạng thái chờ hoặc busy rõ; không sinh vô hạn tasks. Nộp/lưu hồ sơ vẫn độc lập với việc bắt đầu pipeline |
| Provider calls đồng thời |2toàn app; xử lý source tuần tự trong mỗi run ban đầu | UI vẫn xem nguồn/Stop; không hứa5calls nặng cùng lúc |
| Deadline run |240giây từ tiếp nhận run, gồm chờ slot | Giữ partial outputs và timeout; không COMPLETE hoặc giấu thời gian chờ |
| Timeout một call | Mistral OCR60giây; xkiro80giây, bị chặn thêm bởi run deadline còn lại | Timeout kỹ thuật có provenance; không tự lặp toàn hồ sơ |
| Attempts extraction |2tối đa cho một đơn vị, chung budget nhưR7.3 | Một corrective/targeted/transient attempt nếu còn budget; không retry từng stage vô hạn |
| Tổng provider calls/run |32tối đa, tính mọi calls/retries OCR và LLM | Budget exhausted riêng, không giả document unreadable hay tự final từ subtotal |
| Output token cap xkiro |3072extraction;2048matching | Kiểm tra finish_reason; nếu field/line scope vượt, chia đơn vị có context trước gọi, không cắt output rồi đoán |
| UI polling |1giây khi run active, dừng/backoff khi terminal hoặc tab không theo dõi | Đây là poll trạng thái backend, không gọi lại provider |

Không-stream xkiro là cấu hình đầu cho output nhỏ, timeout80<95theo docs; chưa mặc định streaming cho mọi tác vụ. Streaming vẫn có thể thử nếu timeout/latency đo được cần; không dùng partial JSON stream làm facts hoặc hành động. SDK/client không được có retries ẩn ngoài budgets.

File/page/size limits được cụ thể hóa trong [specR7.5](R7_MVP_SYSTEM_SPEC_DRAFT.md) để review/code/test; chưa là hỗ trợ đãverified. Trước release, nguồn/format/limits phải có bring-up/coverage evidence. Dataset vượt envelope là giới hạn kỹ thuật cần báo, không hồ sơ nghiệp vụ sai hoặc dữ liệu được phép truncate để pass.

Task registry local có chờ hữu hạn, không service queue. Nếu process restart, runs đang active/chờ được đánh dấu interrupted, không giả tiếp tục hoặc tự chi/gọi lại. PDFium executor tuần tự và các DB writes ngắn độc lập provider wait. Lưu/version/Stop guards tại điểm sử dụng kết quả vẫn theoR6/R7.1.

## 5. So sánh đủ để chọn, không tạo benchmark zoo

| Thử nghiệm | Giữ cố định | Điều cần kết luận |
| --- | --- | --- |
| M0 — Bring-up sau authorization phù hợp | Schema, nguồn giả lập nhỏ, đúng accounts/models/config | OCR pages/locator/unknown, text JSON và khả năng vision/reasoning thực sự quan sát được; lỗi/quota/timing |
| M1 — Chọn text model | Cùng OCR outputs, candidates, prompts/schema, bộcalibration và budget | Small none vs Medium none: facts/links/questions và failures; latency/calls/usage provenance |
| M2 — Chọn đường đọc | Cùng originals/keys/gold/policy; text model đã chọn | MistralOCR→model với vision trực tiếp qua xkiro: critical facts/refs/unknown và kết quả downstream |
| M3 — Calibration/threshold | Model/route/config cố định, labels nguồn độc lập | Nhóm quan hệ nào đủ căn cứ tự nhận; FN/FP/completion và quality signal thật, không score model tự báo |
| M4 — Freeze và holdout | Freeze toàn config/input/policy/expected trước run | Quality/control theo tập độc lập, không dùng holdout chọn model/prompt |
| M5 — UI/pilot nhỏ | Cùng application path, cases representative và controls |5phiên không trộn nguồn,2thao tác cùng case/Stop/restart/partial; đo cả chờ và effort |

Không mở reasoning high hoặc agent thứ hai chỉ vì muốn "tốt nhất". Nếu none bỏ sót quan hệ rõ trên calibration, một phép so sánh có kiểm soát mới quyết định tăng reasoning/model; giữ output contract/budget và báo regression. Case thành công sau người sửa vẫn assisted. Không lấy catalog130models làm lý do thử130models.

Nguồn so sánh cần các strata R7.3; development20 hiện chưa đủ đa dạng/gold độc lập. Giữ báo cáo case-level, critical facts/locators, required/extra links, components/net/null đúng, issue/owner/câu hỏi và controls. Không chọn chỉ theo average field accuracy. Một route/model vi phạm hard gate trên suite chưa được gọi đạt dù nhanh hơn; baseline yếu vẫn lưu trung thực để cải tiến.

Calibrate chỉ quality/linkage/routing signals có dữ kiện: refs, số candidates, anchors/mâu thuẫn và scores provider thật nếu có. Không tự gán confidence từ output fluent; scores vắng là unavailable. Không nới math/receipt/source/policy/quyền để giảm escalation. Nếu chưa có signal đủ tin cậy, giữ rule có căn cứ và nhóm uncertainty, không giả đã hoàn thành adaptation Sprint2.

## 6. Kết luận của lead và bước tiếp

Đề xuất chọn kết nối Mistral OCR + xkiro theo provider người dùng có, workflow Python gọn, Small none là ứng viên đo đầu; Medium là một challenger. Ưu tiên phép so sánh ít biến và trace dùng được, thay vì ghép thêm models/frameworks chưa biết có lợi.

Đã có evidence catalog công khai và docs; **chưa inference/account access verified, chưa versions packages/OCR pin, chưa quality/calibration/load hoặc UI execution**. Không claim catalog tier free là chi phí toànpipeline0, hoặc response.model tự xác thực upstream.

Chủ dự án đã đồng ý hướng stack/config thử ban đầu. [R7.5](R7_MVP_SYSTEM_SPEC_DRAFT.md) cụ thể hóa API/state/storage/controls và giới hạn nguồn, nối acceptance tới R5 và các lát cắt UI. Sau khi spec được đồng ý, R8 đối chiếu code và lập plan triển khai/bring-up/đánh giá. Không bắt đầu code, paid calls, deployment hoặc freeze B1 ởR7.4.

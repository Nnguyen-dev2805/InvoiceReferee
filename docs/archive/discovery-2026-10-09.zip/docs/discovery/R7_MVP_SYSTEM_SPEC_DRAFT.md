# R7.5 — Spec hệ thống MVP để đối chiếu code và lập plan

Ngày: 09/10/2026 · **CHỦ DỰ ÁN ĐÃ ĐỒNG Ý SPEC ĐỂ TIẾP R8 — CHƯA NGHIỆM THU RUNTIME**.

Spec cụ thể hóa [R3 A/B](R3_MVP_SCOPE_DRAFT.md), [workflow](R6_WORKFLOW_STATE_DRAFT.md), [contract dữ liệu](R7_DATA_AND_EVALUATION_CONTRACT_DRAFT.md), [AI](R7_AI_READING_ORCHESTRATION_DRAFT.md), [stack/config R7.4 đã đồng ý để tiếp tục](R7_STACK_PROVIDER_BENCHMARK_DRAFT.md), [policy](R4_WORK_BUDGET_POLICY.md), [roles](R4_ROLES_HANDOFF_POLICY.md), [nguồn](R4_SOURCE_INTAKE_CONTRACT.md) và [gates R5.8](R5_CORPUS_REVIEW_AND_GATES.md).

Đây là spec thiết kế mới đã được đồng ý. [R8 review](R8_CODE_GAP_REVIEW.md) ghi khác biệt với source/spec B1 cũ; [plan mới](../superpowers/plans/2026-10-09-settlement-mvp.md) là hướng triển khai. AGENTS dẫn tới intended contracts mới, không tuyên bố code hiện tại đã đáp ứng. Giữ sound invariants, không dùng code/expected cũ để xác định đáp án cho spec mới.

## 1. Phạm vi phải làm được

- Hai jobs B3 kiểm tra đề nghị ứng và B7 kiểm tra/quyết toán; cùng lõi ứng dụng cho UI và evaluator.
- A hoàn thành report/questions có căn cứ, nhận phản hồi/decision/source tiền, kiểm tra lại và theo dõi workflow. Gói trình bày cho người thực hiện không là payment entity được tự tạo.
- B tự tạo đề nghị chi/thu là cải tiến sau baseline A và action gates; chưa bật hoặc đưa endpoint tạo lệnh vào A. Không chuyển ngân hàng/khấu trừ/thu hồi tự động.
- Khoảng5người trong pilot, ba vai demo, một process backend và SQLite/files. Demo actor/role không xác thực danh tính công ty thật.
- Mistral OCR và xkiro, cấu hình đo ban đầu theoR7.4. Không dùng expected, tên case hoặc fixture filename làm logic/prompt đáp án.

## 2. Phiên bản và hiệu lực — ba việc phải phân biệt

| Dữ kiện quản lý | Khi đổi | Dùng để làm gì? |
| --- | --- | --- |
| case_version | Mỗi thao tác được chấp nhận làm đổi state/history hiện quản lý | Chống hai màn hình ghi đè nhau; client gửi expected_case_version cho mutation |
| input_revision | Đổi form/scope, nguồn áp dụng, phản hồi/nguồn/decision ảnh hưởng lần kiểm tra | Snapshot input bất biến cho run; giữ nguồn trước/sau và quan hệ supersedes |
| control_epoch và stop_active | Mỗi Stop/resume được chấp nhận; epoch tăng, không quay lại giá trị cũ | Kết quả run trước Stop không trở thành current sau resume |

Mỗi run lưu input_revision, source hashes/IDs, money_as_of/knowledge cutoff, policy/config versions và control_epoch. case_version không là fingerprint của quyền quyết định.

Decision có basis cụ thể: công việc/người/nội dung, các khoản/phần chi phí được chấp nhận, số/chiều, điều kiện, quyền và report đã xét. Khi input đổi, re-check ảnh hưởng để xác định còn áp dụng, cần làm rõ hoặc cần quyết định thay thế; không chỉ so input_revision rồi tự vô hiệu mọi approval.

**Duyệt tổng3, thực nhận2 cho cùng nghĩa vụ:** giữ approved3, actual2, remaining1. Nếu điều kiện/quyền còn áp dụng và không pending/issue, phần1 có thể tiếp tục dưới quyết định gốc. Không đòi approval mới vì receipt mới làm input_revision tăng. Tiền lịch sử trước decision được phát hiện muộn có thể đổi entitlement gốc, khác receipt thực hiện chính decision đó. Refund/reversal sau fulfillment không tự mở lại quyền chi.

## 3. API nghiệp vụ tối thiểu

Paths dưới đây là contract đề xuất dưới `/api`; không module đã tồn tại. IDs do backend cấp. POST/PATCH nghiệp vụ có actor_id/demo_role, expected_case_version khi đã có case và Idempotency-Key cho command; GET không tự gọi provider hoặc gây hành động.

| Endpoint | Input chính | Kết quả và điều kiện |
| --- | --- | --- |
| POST /cases | employee/work refs, job, phạm vi/mốc, form nguồn |201case; lưu cả phần chưa rõ, không yêu cầu approval đang xin trước khi nhận |
| GET /cases; GET /cases/{id} | Filter/context lựa chọn demo | Danh sách/chi tiết, versions, stage, issues và allowed_actions cùng lý do; không cung cấp API key |
| PATCH /cases/{id}/submission | Form/scope mới, reason và version | Revision mới, giữ bản trước; kết quả/decision bị ảnh hưởng chuyển cần re-check |
| POST /cases/{id}/sources | File/nguồn/import và provenance; bổ sung hoặc supersedes cụ thể |201source với trạng thái đọc/giới hạn; không biến upload thành fact verified hoặc bỏ nguồn cũ |
| GET /sources/{id}/content | Source ID đã lưu | Original/representation và metadata locator phù hợp; không dùng path tùy ý do client cung cấp |
| POST /cases/{id}/runs | B3/B7, snapshot/current revision và mode được phép |202run+status URL nếu được tiếp nhận; trả run cũ với cùng command key; không tự bật LIVE từ UI chưa được cấu hình/cho phép |
| GET /runs/{id}; GET /runs/{id}/report | Run ID | Execution status, outputs/errors/usage provenance và report của đúng run; không nhầm report cũ là current |
| GET /cases/{id}/questions; POST /questions/{id}/responses | Nội dung, actor/scope và refs nguồn/decision khi cần | Lưu response riêng; sai người/căn cứ không resolve issue; revision/re-check trước chuyển tiếp |
| POST /cases/{id}/reviews | report_id, nội dung rà soát, refs và version | Lưu kế toán đã rà soát phần nào; không approval, không waive sourcequality |
| POST /cases/{id}/decisions | report/basis, nội dung, amount/chiều/điều kiện, refs quyền và reason | Decision hợp lệ hoặc action blocked; approval/exception/refusal/adjustment giữ nội dung riêng, có thể kết hợp trong một record đủ quyền |
| POST /cases/{id}/handoffs | report_id, decision refs, version và người/vai tiếp nhận | Kiểm tra lại quyền/Stop/hiệu lực/remaining/pending ngay trước chuẩn bị gói; trả refs/kết quả đang áp dụng và ghi audit, không tạo payment entity/nghĩa vụ mới hoặc gửi ra ngoài |
| POST /cases/{id}/money-events | Source observations của chi/thu/attempt; parties, gross amount, time/status, relation | Giữ số/source thật kể cả sai người/vượt quyết định; classification/receipt chưa rõ giữ issue. Không biến rowPaid hoặc operator nhập tay thành actualreceipt |
| POST /cases/{id}/control | STOP hoặc RESUME, scope/reason và version | Ack sau persist control/audit; resume không tự khôi phục quyền hoặc chạy lại provider |
| POST /cases/{id}/closures | closure_kind, report/scope/as_of và căn cứ quyết định/xử lý | SETTLEMENT_COMPLETE khi gates đủ; REJECTED_REQUEST_ENDED chỉ kết thúc yêu cầu bị từ chối không còn nghĩa vụ, khác hoàn tất quyết toán |
| GET /cases/{id}/history | Case ID | Nguồn/revision/run/actor/decision/money/control/closure liên kết; không sửa/xóa raw history |

Response lỗi có code, message, refs/issues và current_version khi liên quan.422shape/type/ref malformed;413resource limit;415format;409stale/busy/actionblocked;403thiếu quyền nghiệp vụ theo policy demo. Phân biệt UI thông tin chưa biết với HTTP lỗi; input thiếu fact có thể được lưu/chạy và trả report incomplete. HTTP201event không nghĩa toàn bộ event đã đủ căn cứ đưa vào công thức.

Allowed_actions do backend tính theo snapshot/quyền/Stop/gates; frontend chỉ hiển thị. Chính endpoint phải xét lại điều kiện lúc ghi, không tin button disabled, role picker hoặc request gửi amount cuối tùy ý. Từ chối quyết định có căn cứ được lưu; tiền đã có/nghĩa vụ không bị xóa.

### Idempotency và concurrency

Trong transaction: tìm command key theo case/actor/operation; nếu đã tồn tại và payload fingerprint giống thì trả record đã tạo cùng current state, không tạo lại. Khác payload cùng key trả409. Nếu chưa có, kiểm tra version/control/gates rồi ghi command/entity/audit và tăng version atomically. Retry trả record lịch sử không tự xác nhận nó còn hiệu lực để thực hiện tiền.

Tối đa một run chưa terminal hiện được tiếp nhận cho cùng case. Revision mới có thể supersede run cũ; output muộn vẫn lưu đúng run nhưng không ghi current. Khác case được điều phối theo admission limitsR7.4. Khi full thì phản hồi busy rõ, không sinh task không giới hạn. Re-run bằng key mới có thể tạo run mới; một kết quả mới không tự tạo nghĩa vụ/chi mới.

Command key không thay chống trùng nghiệp vụ. Khi cùng actual event được nhập qua nhiều nguồn/key, giữ từng observation và quan hệ same-event đã đủ căn cứ, chỉ tính event/phần một lần. Cùng source namespace/ref nhưng payload mâu thuẫn cần giữ observations và issue, không upsert ghi đè; same amount/date chưa đủ gộp. Nộp lại hóa đơn không tự là nghĩa vụ mới.

Handoff A là thao tác chuẩn bị bản report+decision+refs hiện áp dụng có audit. Người thực hiện cần kiểm tra trạng thái hiện tại trước hành động ngoài app; đọc được nguồn/report lịch sử qua GET không tự là một handoff hợp lệ. Sau handoff có source/control thay đổi thì gói cần xét lại, không claim app ngăn được người chuyển tiền bằng bản giấy cũ.

## 4. Lưu dữ liệu nhỏ nhưng truy được căn cứ

Đề xuất tám bảng SQLite, với columns cho IDs/versions/quan hệ cần query hoặc constraint, payload JSON có contract cho chi tiết. Không biến mỗi field OCR thành một bảng, không registry/event-sourcing framework.

| Bảng | Nội dung |
| --- | --- |
| cases | Employee/work/job/stage, case_version/current_input_revision/current_run, control_epoch/stop_active và current closure refs |
| case_revisions | Form/scope và refs nguồn/phản hồi/quyền/policy áp dụng; source selection và mốc bất biến |
| sources | Original blob refs/hash/type/provenance, metadata/page count, representation/transform và quan hệ bổ sung/thay thế |
| runs | Input snapshot/hash/config/control_epoch, status/deadline, step outputs(facts/links/checks/report)/errors/timing/usage và origin reuse refs |
| interactions | QUESTION/RESPONSE/REVIEW có parent/question/run refs, actor/scope/content/evidence; question lifecycle được cập nhật có history |
| decisions | Basis/report/authority refs, nội dung/amount/chiều/điều kiện, history và quan hệ thay thế; không ghi đè decision cũ |
| money_events | Gross observations và refs, parties/event time/raw status, kind/relation, phần đã đủ/unknown/pending/incident; không net hóa mất event gốc |
| audit_events | Command key/fingerprint, actor/time/action, before/after versions, refs của records thay đổi và reason; append-only |

Quan hệ sources dùng lại ở nhiều revisions/cases giữ source provenance/namespace và binding đúng scope. Có thể reuse blob/extraction cùng hash, không suy cùng nghĩa vụ hoặc chuyển quyền giữa hồ sơ. Context ngoài case như shared company ledger/policy vẫn phải được chọn rõ trong revision/run, không dùng mọi nguồn toàn app vô điều kiện.

DB ghi ngắn, không giữ write transaction khi chờ OCR/LLM. Enable foreign-key checks và unique command keys/current constraints phù hợp; aggregate không âm thầm ghi đè duplicate IDs. Việc đọc decision/money/assert gates và cập nhật current/control/action phải có cùng transaction boundary phù hợp.

File và SQLite không có transaction chung. Upload qua staging, kiểm tra giới hạn/hash, lưu file final rồi mới commit metadata/revision; chỉ trả success khi cả file/record dùng được. Nếu DB ghi lỗi, file chưa tham chiếu không được giả thành source đã upload; cleanup chỉ file staging/orphan do app tạo theo ownership rõ. Không xóa originals/history đang được sử dụng. Lỗi/source thiếu được lưu/hiển thị, không đổi thành report complete.

Integer VND strict, reject bool/float ở fields số quyết định/sự kiện đã chuẩn hóa; giữ nguồn amount chưa rõ dưới dạng observation chưa đủ. Gross event không đổi dấu/clip để khớp approval; signed S là kết quả suy ra. Source quantities/prices/currency/rounding theo contract/rule, không thêm tỷ giá hoặc financial cap ngầm.

## 5. Trạng thái lưu và Stop

Run execution tách report/business stage:

```mermaid
stateDiagram-v2
    [*] --> QUEUED
    QUEUED --> RUNNING: Được slot và guards còn đúng
    RUNNING --> SUCCEEDED: Outputs được lưu
    RUNNING --> FAILED: Lỗi kỹ thuật
    RUNNING --> TIMED_OUT: Hết deadline hoặc budget
    QUEUED --> TIMED_OUT: Hết deadline khi chờ
    QUEUED --> STOPPED: Stop được persist
    RUNNING --> STOPPED: Stop được persist
    QUEUED --> SUPERSEDED: Input đã thay thế
    RUNNING --> SUPERSEDED: Input đã thay thế
    QUEUED --> INTERRUPTED: Process ngừng
    RUNNING --> INTERRUPTED: Process ngừng
```

SUCCEEDED là execution có report được lưu; report có thể COMPLETE hoặc INCOMPLETE với FACT/POLICY/AUTHORITY issues. Partial step outputs của FAILED/TIMED_OUT vẫn giữ, không gọi đủ job result. Status terminal không trở về RUNNING; retry/resume tạo run mới liên kết, không giả run cũ chưa lỗi. Hết call budget có reasonBUDGET_EXHAUSTED, không giả source unreadable.

Business stage tối thiểu: CHECKING, ACCOUNTING_REVIEW, AWAITING_DECISION, AWAITING_MONEY, AWAITING_WORK_SETTLEMENT, RESOLVING_OBLIGATIONS, REJECTED_REQUEST_ENDED, SETTLEMENT_CLOSED. Issues/Stop/decision validity/fulfillment riêng; không tạo một enum cho mọi tổ hợp. Stage là projection của records/gates, không field client tùy ý PATCH.

Stop được ack sau khi control epoch/flag/audit được commit; từ đó không publish current output/handoff/đóng/action mới bằng run cũ. Lúc callback về, kiểm tra epoch/revision/current_run và policy/control cần thiết trong điểm ghi. Kết quả đến muộn có thể giữ historical step output, không ghi vào current. Provider có thể vẫn xử lý bên ngoài; không claim ngân hàng/provider đã hủy.

Trong Stop vẫn tiếp nhận và giữ sources/observations tiền thật đã xảy ra; không dùng chúng để tự mở action/đóng. RESUME chỉ gỡ control và tăng epoch, yêu cầu re-check trước bước tiếp. Normal fulfillment có căn cứ không tự là inputchange làm mất quyền gốc; nguyên tắc §2 vẫn áp dụng.

## 6. Giới hạn nguồn v0 cần kiểm tra trước release

Đề xuất hỗ trợ JPEG/PNG, PDF không mã hóa đọc được; CSV UTF-8/BOM qua schema nguồn tài chính đã định; TXT/Markdown UTF-8 cho nguồn văn bản và demo. Native form là JSON API có contract, không nhận arbitraryJSON và auto coi policy/approval thật. DOCX/XLSX/ZIP/HEIC và PDF có password chưa trong đường đọc v0; giữ capability issue/đường cung cấp nguồn phù hợp, không gọi là từ chối chi phí.

| Giới hạn kỹ thuật | Giá trị đề xuất |
| --- | --- |
| Một file |20MiB |
| Active originals trong run |20files,80MiB tổng |
| PDF |20pages/file,40PDF/imagepages tổng/run; ảnh một file tính1page |
| Ảnh/render |24megapixels/representation; giữ original, không downsample mất field rồi ghi READ |
| CSV |1000data rows/file, mỗi row có namespace/ref và fields theo import contract; headers không tính row |

Các giá trị là envelope pilot để đo, không tiêu chuẩn doanh nghiệp hoặc bằng chứng đã hỗ trợ. Inventory20packetdevelopment hiện tối đa9initial source files theo corpus audit/manifests; nó không xác nhận page/size/reader quality thực tế. Policy/coverage inputs vẫn giữ nguồn và tham chiếu, không coi quota ảnh bằng toàn bộ context.

Kiểm tra size/type/page/pixel/row trước xử lý tốn tài nguyên; không tin extension hoặc chỉ Content-Length. Khi vượt limit, báo rõ phần chưa xử lý và kết quả bị chặn; không cắt20pages/1000rows đầu rồi khẳng định full coverage/không có tiền trước. Không tự cộng các lần đọc một phần thành hồ sơ complete nếu phạm vi bắt buộc còn thiếu. File rejected không là source đã đọc; source bên ngoài giới hạn vẫn có thể được ghi nhận metadata và issue, không gửi provider vô điều kiện.

CSV nguồn tài chính đề xuất columns: source_record_ref, event_kind, payer_ref, payee_ref, gross_amount_vnd, currency, event_at, reported_status; booking/work/employee refs và memo nếu nguồn có. Cells nguồn giữ raw; một dòng chưa đủ amount/outcome không được đoán thành received. Empty file header chỉ chứng minh file không có dòng, không absence toànscope; coverage/owner/method/side/time range còn cần nguồnR4.

Package/version, OCR model pin, tài khoản/quota, locator/score capabilities và quality calibration còn phải xác minh trong bring-up/measurement. Spec đã đặt limits để code/test, chưa cam kết mọi input bên trong limits đều đọc đúng hoặc xong trong240giây.

## 7. Acceptance dùng cho plan và review code

Mỗi dòng cần actual result/refs/run/mode và outcome; không chỉ checklist. Fake/replay kiểm tra wiring/logic, live kiểm tra reader/model, người thật kiểm tra effort/value. Các case IDs là refs evaluator, không vào production branching.

| ID | Hành vi phải chứng minh | Liên hệ với nguồn đánh giá/UI |
| --- | --- | --- |
| SYS-01 | Nộp/import giữ originals, provenance/revision và reload mở được; refs không gắn nhầm document | UI source intake; integration source/storage |
| SYS-02 | Duplicate/extra IDs, truncated output, bool/float money, source/locator sai bị phát hiện; không aggregation mất dữ liệu | Unit/contract tests; extraction malformed/coverage cases |
| SYS-03 | B7 đủ nguồn lưu components/proposed/checks/refs đúng; chưa approved/received | Q01,Q03; UI bảng đối chiếu |
| SYS-04 | Amount/payer/history/coverage chưa rõ giữ null/issues đúng owner; knownsubtotal không thành whole net | Q08–Q12; UI source bên cạnh field/question |
| SYS-05 | Split/companydirect/personal/duplicates đúng portions/refs, không chỉ net tình cờ đúng | Q05–Q07; link-level evaluator |
| SYS-06 | VượtB/chưaB/quyền khác scope chuyển đúng decision; không clip/nângB/rolepicker waiver | Q13–Q15; combined exception+approval re-check không duplicate decision |
| SYS-07 | B3 mới/import riêng; forecast khác actual; approval đang xin không là thiếu giấy; source quyết định hợp lệ được dùng lại | A01–A05; UI form và import |
| SYS-08 | Answer received riêng; sai owner/nguồn/scope không resolve, bổ sung đủ re-check đúng revision/ảnh hưởng | C06; UI question→answer→report và audit |
| SYS-09 | Review của kế toán không là approval; approval không biến thành receipt hoặc sửa facts/S tùy ý | Decision endpoints + source/math/authority guards |
| SYS-10 | Actual partial/wrongrecipient/overpay/rawPaid giữ gross/history/issue; remaining đúng và không đóng/tự chi bù | C02,C03; UI approved/actual/remaining |
| SYS-11 | Stop ack rồi output muộn không publish current/action/close; resume không hồi sinh run/quyền cũ | C04; integration race và UI Stop/restart |
| SYS-12 | Materialchange re-check validity; đúng fulfillment giữ quyền tổng/phần còn lại; timestamp sauasof không vào run cũ | C05,C07; revision/decision/history |
| SYS-13 | Doubleclick/retry cùng command trả cùngrecord; khácpayload bị chặn; rerun/copy không tạo nghĩa vụ/chi lại | C01; Q04 và DB unique/transaction race |
| SYS-14 | Closure cần decisions/sources/money/scope đủ, không Stop/pending/incident; refusals giữ duties; zero không tạo giao dịch0 | Q04; falseclose/refusal/pending/zero UI E2E |
| SYS-15 | Limits không truncate để pass;5phiên không trộncase, stalewrite không overwrite, active runs/calls/deadline hữu hạn | Boundarytests, admission/control race và pilot runtime; fake không quality/load live |
| SYS-16 | UI/runner cùng application path, gold tách input, failures/assisted/mode/usage provenance có trong actualreport | Evalintegration và trialplan; không metric từ source fixturechecks |
| SYS-17 | Report unit tự hoàn thành routine; A không tự tạo payment entity củaB; controls/actionB chấm riêng khi mở | R3 boundary, releaseflag/spec rõ; BTC compatibility chưa tự được xác nhận |

Mẫu test cho actionguards phải kiểm tra state/entity thực lưu, không chỉ text; mọi testcase critical có oracle đọc nguồn/policy độc lập. Professionaltrial ít nhất3người làm nghiệp vụ thật vẫn riêng với5phiên kỹ thuật. B1freeze phải có revision/config/dataset/expected/actual/log/mode; spec được đồng ý chưa là baseline đã đo.

## 8. Tự phản biện và điều kiện sang R8

Tám bảng/IDs/guards là dữ liệu tối thiểu để phân biệt nguồn, run, quyền và tiền trong workflow đã chốt; không thêm hệ thống job phân tán hoặc engine kế toán tổng quát. Cắt chúng đến mức chỉ giữ final S sẽ làm mất khả năng chứng minh output đúng/không chi trùng.

Spec không thể thay bài toán đánh giá: phải đo đọc/ghép semantic trên sources đa dạng, calibrate signals thật và chấm holdout, rồi đo công sức người dùng. Route/config R7.4 là ứng viên, không model thắng đã được chứng minh. Scope routine check/report vs ChallengeA vẫn là rủi ro công bố tạiR3; không đổi mẫu số để che checkpoint người.

Nếu chủ dự án đồng ý specR7.5, chuyển **R8 đối chiếu code trong bounded scope** và lập ledger SYS-ID→source/runtime→giữ/sửa/thay→checks. Chốt canonical spec/AGENTS khác contract cũ theo quyết định mới, rồi plan các lát cắt UI+logic+eval. Không code, install, live calls, Git history actions hoặc deployment trong lượt này.

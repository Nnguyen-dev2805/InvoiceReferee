# R5.1 — Thiết kế đánh giá hệ thống trước khi code

Ngày: 09/10/2026 · Trạng thái: **CHỦ DỰ ÁN ĐỒNG Ý THIẾT KẾ ĐƯỢC TRÌNH BÀY VÀ CHO DỰNG CASE; CHƯA THỰC HIỆN ĐÁNH GIÁ HOẶC FREEZE B1**.

Chủ dự án đồng ý tiếp tục sau trình bày R5.1. [R5.2 bốn packet đầu](eval_development/b7_core_01/README.md) đã dựng input/expected nháp và sourcepolicy/hash; chưa goldadjudication, pipeline/OCR/livequality hoặc professionaltrial. Bốn snapshot thuộc3businessstories cùng1templatefamily, không holdout độc lập.

Sau khi chủ dự án đồng ý tiếp tục từ R5.2, [R5.3 bốn case thiếu/mâu thuẫn](eval_development/b7_uncertainty_01/README.md) đã dựng Q09/Q10/Q11/Q12 với initialinput/followup/expected tách nhau; allinitial finalSunknown, partialfacts được giữ. Chưa có application xửlý question/answer hoặc goldadjudication; tất cả vẫn development cùngtemplatefamily, không độc lập.

[R5.4 policy/authority](eval_development/b7_policy_authority_01/README.md) tiếp theo dựngQ13 T9/B8 cóquyềnngoạilệ rõ vàQ14 trongB nhưngquyềnfinalsettlement không bao phủwork. Q13 có2nhánhdecisioneligibilitytoàn/phần, Q14 thêmnguồnquyền đúngtime chưaapprovalchi. Bảnpolicy/numericgates không đổi, khôngship/runtime/eval. Tổng10caseconditionsdevelopment, không đếmfollowup/clones thành độclập.

[R5.5 allocation/duplicates](eval_development/b7_allocation_duplicates_01/README.md) dựngQ05 bill5company2/employee3/A1→S2, Q06 bill7work6/private1/A2→S4 vớirawpaid7 giữnguyên, Q07 copies/aliases cùngtransfer vàrecordkhácworkbooking cùngamount/date→S3. Nguồncompany/employee đủtừngphần, purposeprivate rõ, bankrawPOSTED khôngthayvendorreceipt; matchinglinks chấm ngoàiS. Tổng13caseconditionsdevelopment, vẫn cùngfamily vàsingleauthorexpected chưaruntime/independentgold.

[R5.6 ngân sách/ảnh](eval_development/b7_missing_budget_image_01/README.md) hoàn thiệnQ15 chưaB nhưng đủquyềnxét sauphátsinh vàQ08 cóPNG tổngtiềnbịche thực sự, khôngbackupamount tronginitialsources. Q15 saudecision E5/S5 vẫnBtrướckhôngtồn tại; Q08 bảnPNG rõchohotel3/E5/S3 vẫnassisted/chưaapproval. Đã kiểmtraảnh trựcquan, chưaOCR/provider hoặcgoldadjudication. Đủ15B7packetconditionsdevelopment, cùngfamily; chưa5B3/lifecycle/fullmeasurement/holdout.

[R5.7 B3](eval_development/b3_advance_01/README.md) dựng5packet A01nativecheck/A02importreuseB/A03estimateconflict/A04historymissing/A05authoritywrongwork; không futureinvoice/currentreceiptgate hoặc B7settlement. [Corpus index](eval_development/CORPUS_INDEX.md) có đủ20conditions15B7+5B3, cùngfamily,9routinecheck/11needs goldnháp, chưaoutputs/runs/independentadjudication/Verify/B1 hoặcprofessionaltrial.

Căn cứ [brief gốc](../Challenge_Brief_OrganizationAI_VN.docx.md), [R3](R3_MVP_SCOPE_DRAFT.md), [policy ngân sách tổng](R4_WORK_BUDGET_POLICY.md), [ba vai](R4_ROLES_HANDOFF_POLICY.md), [nguồn R4.4](R4_SOURCE_INTAKE_CONTRACT.md) và [packet01](examples/work_budget_01/README.md). Không dùng source/output hệ thống hiện tại làm gold; chưa đối chiếu code tới R8. Lead tự review, không subagent. Catalogue hiện đã có20packetdevelopment theo [index](eval_development/CORPUS_INDEX.md); chưa20runspass/gold thẩmđịnh độc lập. [R5.8 rà soát/gates](R5_CORPUS_REVIEW_AND_GATES.md) cụ thể hóa điều kiện để tiếpR6, không runtimeacceptance.

## EV-01 — Hai điều phải chứng minh riêng

1. **Đúng:** dữ kiện/nguồn và liên kết đúng; đủ điều kiện và tính tiền đúng; dừng đúng khi chưa đủ; quyết định, chi/thu, đóng và history đúng theo policy/scope.
2. **Có ích:** giảm tổng công sức tìm/chuẩn bị/ghép/đọc nguồn và xử lý hồ sơ, đồng thời giữ chất lượng quyết định. Nhanh hơn ở LLM không tự chứng minh kế toán làm ít hơn.

B7 kiểm tra/đối chiếu sau chi là job chính; B3 kiểm tra ứng được đánh giá riêng. Checkpoint kế toán rà soát/người duyệt quyết định không gọi là lỗi chuyển tiếp thừa. Nhưng phải đo cả hai trong toàn lifecycle và công bố routine boundary; BTC chưa xác nhận job report-ready này đủ nghĩa routine tự động hoàn toàn. Không coi đổi denominator là cách giải quyết rủi ro.

## EV-02 — Đơn vị chấm và kết quả

- Một run: input manifest của một job tại một mốc/phiên bản rõ. Một hồ sơ có nhiều run trước/sau bổ sung/receipt giữ quan hệ.
- Gold routine: job có đủ căn cứ để lưu report/kết luận trong phạm vi mà không cần người giải quyết thêm fact/policy/quyền. Kết luận không chấp nhận phần chi cá nhân theo rule rõ vẫn có thể là routine; không chỉ chọn case toàn khoản hợp lệ.
- Gold cần giải quyết: fact còn bất định, ngoài policy hoặc quyền cần bổ sung. Có thể nhiều issue cùng case; chấm đủ các issue material, không chỉ một cờ NEEDS_HUMAN.
- Kết quả kỹ thuật/capability và Stop là trục riêng; không giả thành nhân viên thiếu bill, không bỏ khỏi tổng số lần chạy.
- B7 hoàn tất khác B8 phê duyệt, khác B9 thực nhận/đóng. Chấm số tiền, trạng thái/quyền/action/history riêng; amount đúng nhưng đóng sớm hoặc tạo request sai vẫn fail.

First-pass routine completion tính từ lúc submit tới report được lưu, không có người chọn đúng giao dịch/sửa fact/trả lời giữa chừng. Chạy lại sau bổ sung có thể đúng nhưng là assisted trong lifecycle, không đổi case ban đầu thành routine. Upload/import nguồn nguyên trạng là input, công sức chuẩn bị vẫn phải đo; handmatched source không dùng để tuyên bố automatic rawmatching.

## EV-03 — Gold từ nguồn, không từ output

Mỗi case hoàn chỉnh cần: family/job/mốc, manifest input tách expected; policy snapshot và source giao quyền; original documents/events/coverage; facts critical có value/unknown và refs; quan hệ expense–payment/portion/sameevent; checks áp dụng; issues và owner/câu trả lời đủ; E/A/RA/P/RP/S hoặc kết luận chưa xác định; hành động được phép/cấm và điều kiện đóng.

Số không xác định không ghi0. Căn cứ proof theo attestation khác bankverified. Expected diễn đạt câu hỏi theo ý nghĩa/owner/source, không một câu văn duy nhất. Gold không yêu cầu mọi field trên mọi bill, chỉ fact thật ảnh hưởng check.

Người lập đáp án đọc input và rule trước khi xem output. Một lượt đối chiếu nguồn/phép tính khác, không dùng productionpolicy để sinh đáp án cho chính nó. [Expected packet01](examples/work_budget_01/expected_walkthrough.md) hiện chỉ là draft do lead tạo cùng nguồn, chưa độc lập thẩm định. Agent review thiết kế có thể phát hiện bất nhất nhưng không tự xác lập sự thật của tài liệu mờ hoặc thay professionalusers.

Case bất đồng về source/rule phải làm rõ hoặc giữ trạng thái chưa xác định và reason; không sửa nhãn theo output để có green. Muốn thay policy thì version mới, ghi expected thay đổi vì rule nào và tái lập dataset comparison tương ứng; không coi nới rule là tăng năng lực AI.

## EV-04 — Bảy trục đánh giá

| Trục | Cách chấm chính | Điều phải báo |
| --- | --- | --- |
| Đọc dữ kiện | Critical known fields đúng value/type/meaning và source/locator; abstention khi source thật không đọc được | Tử/mẫu knowncriticalfields, sai/thiếu/abstain; unknown đúng riêng. Provider abstain trên field nguồn rõ không thành đúng |
| Liên kết/đối chiếu | Đúng nghĩa vụ/phần/payer, phân biệt sameevent nhiều source với events khác; không gộp chỉ do cùng amount/date | Requiredlinks đúng/thiếu và extrawronglinks. Một extra link có thể đổi tiền làm case fail |
| Policy và tiền | Check applicability đúng; E và mọi thành phần source đúng; S nguyênVND đúng số và chiều hoặc unknown đúng | Exact-result cases / toàn cases có gold số tương ứng; thiếu output/lỗi kỹ thuật không được loại để tăng accuracy |
| Chuyển tiếp | Bỏ sót issue, chuyển routine thừa, đúng loại fact/policy/authority và đúng owner | Tử/mẫu theo từng job và nhóm; technical/capability/unjudged riêng, không chỉ một tỷ lệ tổng |
| Câu hỏi và tiếp tục | Nêu khoản/ref/vướng/đã biết, đúng người, yêu cầu trả lời được; answer đủ thì re-check đúng phần/phiên bản | Số câu đạt rubric và số vòng/human touches; câu hỏi đúng nhưng không dùng được câu trả lời vẫn fail workflow |
| Kiểm soát/lifecycle | Approval≠receipt, Stop/stale/revision/duplicate và đóng theo scope; lưu original/source/decision/grosshistory | Action/request/storage/history thực tế theo mode, không chỉ text hiển thị |
| Vận hành/tác động | Latency run/calls/retries/tokens/cost nếu đo được; effort chuẩn bị→review→decision→reconciliation và chất lượng cuối | Từng run/participant, N, mode, failures; thời gian chủ động và chờ riêng; onboarding/khó khăn mới |

Exact S đúng không bù được fact sai hoặc source ref giả. Gold unknown không cho model điền số rồi thêm disclaimer để pass. Check độc lập có thể đúng dù S cuối chưa chốt; report phải phân biệt rõ phần đó.

## EV-05 — Mẫu số và lỗi kỹ thuật

Cho một tập độc lập, N_need là tất cả case gold cần giải quyết thêm, N_routine là tất cả case gold routine. Cố định tập trước run; không lọc input khó/thiếu từ denominator.

- FN: gold cần giải quyết nhưng output nghiệp vụ tự kết luận hoàn tất không chuyển tiếp. FP: gold routine nhưng output đòi người giải quyết thêm issue không có thật. Checkpoint tài chính cố định không là FP.
- U_need/U_routine: không có output nghiệp vụ chấm được vì technical failure/timeout/capability mismatch, không gán nhãn false business uncertainty.
- Báo FN/N_need và FP/N_routine **cùng U/N và khoảng bảo thủ**: [FN/N_need,(FN+U_need)/N_need], [FP/N_routine,(FP+U_routine)/N_routine]. Một lần escalation với wrongreason/owner chấm detection riêng và fail reason/question; không gọi là xử lý đúng toàn case.
- N bằng0: metric N/A, không100%. Không gọi FN=0 là tốt khi toànN bị lỗi kỹ thuật; report interval và completion sẽ cho thấy chưa có bằng chứng.

First-pass routinecompletion: số goldroutine có job result đúng được lưu không cần fact intervention / N_routine, lỗi kỹ thuật/thiếu output là không hoàn thành. Case có nhiều materialissues báo issue recall riêng, không che bỏ sót một issue bằng việc đã hỏi issue khác. M1/M2 cùngfamily không là hai hồ sơ độc lập để suy ra hiệu quả thực tế.

## EV-06 — Catalogue20case nghiệp vụ đề xuất

Đây là **15B7 +5B3** cho vòng development đầu tiên. Sources/manifests/expected nháp đã được dựng cho20dòng; vẫn cần adjudication và execution evidence trước khi gọi bộtest đủ/đạt theo brief. Các con số gắn nguồn/quyền/scope của từngpacket, không cấu hình chung hoặc metric đo được.

| ID | Job / tình huống | Expected hướng kiểm tra, chưa là gold đã freeze |
| --- | --- | --- |
| Q01 | B7, packet01M1 đủ nguồn | T8/E5/A2/S+3; reportready, chưaPaid/close |
| Q02 | B7, tự chi có ngân sách, xác nhận không ứng/hoàn trước | E5/A0/P0/S+5; không khoản ứng giả |
| Q03 | B7, ứng lớn hơn chi được chấp nhận | E3,3/A4/S-0,7, đúng quyền/scope cho số ứng4; không defaultthu toàn4 |
| Q04 | B7, đã thực hoàn đủ | E5/A2/P3/S0; không chi lại, close còn phụ thuộc toàn nghĩa vụ |
| Q05 | B7, một bill5 companytrả2/employee3 có proof từng phần, A1 | E3/S+2; không suy employee từ phần còn lại chưa có nguồn |
| Q06 | B7, bill7 có phần cá nhân1 xác định rõ, employee trả, A2 | T/E6/S+4 theoB đủ; loại rõ không hỏi ngoại lệ vô ích |
| Q07 | B7, cùng invoice/event qua nhiều sources/copy | Không cộng invoice+receipt+copy/event lần2; giữ refs/history |
| Q08 | B7, criticalamount ảnh nguồn bị che/không đọc được, không alternative đủ | Factuncertainty đúng owner/source; không finalS đoán. Packet hiện tại PNG giả lập cótotalopaque, chưa mọi loại blur/scan |
| Q09 | B7, receiptcash đãpaid nhưng khôngpayer/attestation | Payerunknown, hỏi đúng phần; không tinPERSONAL hoặc cấmcash |
| Q10 | B7, historycompany chỉ phủ một phần mốc cần xét | Coverageunknown; khôngP0/chưatừngtrả từ emptysearch |
| Q11 | B7, approvalứng nhưng chưa proofactualreceipt | Aunknown; không lấy approvedamount làm actual |
| Q12 | B7, employeeclaimPERSONAL và companypaid cùng nghĩa vụ | Làm rõ payer/portion/contradiction; khôngautofraud/chi thêm |
| Q13 | B7, T9/B8, fact rõ và quyền ngoại lệ9 được giao rõ | Ngoài budget, hỏi quyết định cụ thể; authority đủ để cô lập lỗi policy, không tựclip8 |
| Q14 | B7, sources đủ nhưng người duyệt không có quyền công việc này | Beyondauthority, giữ dữ kiện rõ; không rolepicker cho qua |
| Q15 | B7, tự chi chưaB/quyết định chấp nhận sau phát sinh | Chuyển quyết định trong quyền, không mặc định từ chối hoặc biến số khai thànhB |
| A01 | B3, formxinứng2/dựtoánemployee5, company3, scope/history đủ | Report đề nghịroutine để người duyệt quyết định; không đòi hóa đơn sauchi/approval đangxin |
| A02 | B3, nhập hồ sơ ngoàiapp có căn cứ công việc/B còn hiệu lực | Dùng lại căn cứ, không bắt xin lại/import thànhapproval khác |
| A03 | B3, dự toán tổng mâu thuẫn các phần | Hỏi nhân viên làm rõ field/ref; không tự chọn số có lợi |
| A04 | B3, nguồn lịch sử ứng/pending thiếu để kiểm tra nghĩa vụ | Hỏi kế toán/chủ nguồn đúng scope, không suy chưaứng/nochitrùng |
| A05 | B3, quyền chỉ cho công việc khác/phạm vi khác | Beyondauthority, không dùng sốứngnhỏ để bỏ qua quyền |

Nhóm routine/needs phía trên là hướng lập dữ liệu, có thể cần làm rõ lại trước freeze nếu nguồn khác làm outcome đổi. Q13 phải có source quyền ngoại lệ riêng phù hợp; không dùng nguồn packet01 chỉchoB8 rồi tự gọi case này chỉoutpolicy. Q06 cần rule/source xác định phần cá nhân, không model phán theo tênmón. Q08 cần original không đọc được hoặc representation phù hợp mode, không textmarkerBLUR để giả đã testOCR; packet hiện dùng PNG total bị che thật, không ảnh giấy thật hoặc toàn bộ blur/scan.

Thêm các traces kiểm soát riêng: trảlạisửa→re-check; saiowner answer; pending/partial/wrongrecipient; duplicate rerun; Stop/lateprovider; stale decision sau đổi nguồn; receiptM2 không vàoM1; supplementaryadvance ngoàiroutine. Chưa tạo hoặc chạy các traces này, không ép mọi limitation thành ba nhóm bất định. Phủ refund đúngemployeeportion sau khi case/source/expected rõ; crossrecipient exception giữ ngoài auto theoB7, không mở engine kế toán tổngquát.

## EV-07 — Development, calibration, holdout và Verify

20casecatalogue là development để hoàn thiện contract, không independentholdout. Sau đó dựng calibration và holdout mới theo cùng strata/policy; số lượng chốt khi có packet đủ, không tự tuyên bố20 là đủ cho độtin cậy thực tế. Không chia các clones/M1M2 cùngfamily sangtrain/calibration/holdout như dữ liệu độc lập. Thay number/layout cùng template không tự làm holdout khó/độc lập.

Gold/input/policy/inputsourcehash và phiên bản model/config được giữ trước khi đo. Holdout không dùng để chọn prompt/ngưỡng; lỗi phát hiện rồi sửa trên nó khiến bản đó thành feedback/development, cần freshholdout cho tuyên bố độc lập sau thay đổi. B2 soB1 trên bộ so sánh chung đủ policy/scope, đồng thời dùng bộ mới phù hợp để tránh chỉ nhớ lỗi đã thấy.

VerifyEscalation5 đề xuất chọn3B7routine và2needs từ các packet hoàn chỉnh: basic+3, surplus-0,7, đãhoànS0; thiếuactualreceipt, vượtB có quyền ngoại lệ rõ. Một Verify5 này chưa phủauthoritygroup, vì vậy bộ đầy đủ phải cóQ14/Q15 và input mới. Core4/runbook/Stop/Override/audit theo brief là suite riêng; không thay requirement chỉ bằng catalogue này. Expected/actual/pass-fail/timestamp và source/policyversion của mỗi case được hiển thị; runner sequential theo brief, chưa có harness đã chạy từ tài liệu này.

## EV-08 — Gates: đo baseline khác cho phép hành động

| Cổng | Điều kiện đề xuất |
| --- | --- |
| Đủ để đo baseline | Fullpackets/expected/sourcepolicy rõ và đã ràsoát; run được cùngapplicationpath, log mọicase/failure/version/mode; kết quả xấu vẫn ghi để cải tiến |
| Đủ để gọi report đúng trên suite | Không vi phạm critical money/source/unknown gates trên tập đã công bố; đủ all gold checks/actions và kỹ thuật. Sai hoặc không hoàn thành một case là chưa đạt cổng trên suite đó |
| Đủ để mở hành động B | Ngoài chất lượngA cần evidence integration củaquyền/version/Stop/stale/idempotency/audit/actionguards; testfinite không đảm bảo an toàn mọiinput tươnglai; vẫn humanapproval/no bankexecution |
| Đủ để chứng minh giá trị thật/Sprint2 | Trial ít nhất3professionalusers theo brief, before/after cùng scope, số liệu chất lượng/effort và cải tiến từ feedback; nguồn fake/agent/selftest không thay |

Freeze B1 có thể ghi trung thực baseline chưa đạtgate, không gọi đãsẵn sàng actionB hoặc satisfiedrubric. Không đặt một95% cho toàn hệ thống. Mục tiêu không có vi phạm critical trên suite là criterion hữu hạn, không tuyên bố tài chính luôn đúng ngoài mẫu. Miss/FP/latency/efforttargets thực nghiệm sẽ chọn sau số đo cócăn cứ, chưa hứa giảm80% hoặc95% quality.

Adaptation Sprint2 chỉ điều chỉnh escalationquality/linkage ngưỡng đã định saufeedback/calibration, không nới ngân sách/quyền/evidence/unknown hardgates. Không cần chọnframework/model trước khi có định nghĩa what-to-measure này.

## EV-09 — Đo công sức trước/sau

Đối chiếu manualworkflow và assistedworkflow cùng phạm vi nguồn/policy, giữ checkpoint kếtoán/sếp trong cảhai. Đo chuẩn bị/tìm/export/upload/import/handmatching; đọc/đốichiếu; trảlờibổsung; review/decision; đốichiếu thực hiện/đóng. Activeeffort tách waiting/onboarding; thời gian đã đưa nguồn chuẩn vào packet không là0 nếu người làm đã chuẩn bị ngoài app.

Pilot nội bộ trước bằng cùngoperator có đảo thứ tự/cases tương đương để giảm nhớ; không gọi là professionalusertrial. Thửngười thật sau cần permission và dữ liệu synthetic/redacted phù hợp, feedback do người thật đưa ra. Báo từng người/case N nhỏ, outcomeerror/corrections và thời gian; không suy từ3người ra mọi doanh nghiệp hoặc chỉ chọnhappycases. Nếu appnhanh hơn nhưng người chuẩn bị nguồn/làmquenchậm hơn, báo cả phần đó.

## Bước tiếp theo

[R5.8](R5_CORPUS_REVIEW_AND_GATES.md) ràsoát corpus và điều kiện kếtluận/dừng/phêduyệt/receipt/đóng, ghi rõ giới hạn nguồn mộtfamily và cáccontroltraces chưa thựcthi. Có thể tiếpR6workflow/state từ thiết kếđánhgiá này; goldđộc lập, datasetđa dạng/calibration/holdout, runtime/trial/measurement vàB1freeze vẫn chưa hoànthành. Không dùng output sửa expected hoặc xem việc chủdựán cho tiếp tục là adjudicationđộc lập. Kiếntrúc/spec/đốichiếu code vẫn theoR6–R8.

# Review thiết kế — R2, Bước 3 kiểm tra đề nghị tạm ứng

Ngày: 08/10/2026 · Verdict của reviewer và lead: **Cần chỉnh sửa**.

Target: [walkthrough](../../discovery/R2_CASE_WALKTHROUGH.md), Mục 2.3, dòng 76–102. [Snapshot được review](TARGET_R2_CASE_WALKTHROUGH.md) giữ nguyên. Review logic nghiệp vụ từ số 0; không đọc code, sửa target, chạy pipeline/test hoặc xác nhận chính sách doanh nghiệp thật.

## 1. Phương pháp và bằng chứng

- Reviewer độc lập: `chatgpt-web/gpt-5.6-sol`, **High**, Ramanujan, ID `01a11bd5-8509-7413-983e-cae5da9be251`; hoàn thành và đã đóng. Không đổi model/mức; không fork lịch sử hội thoại hoặc gửi nhận xét lead.
- [Nhận xét riêng của lead](LEAD_PRE_REVIEW.md) được lưu và ghi hash trước khi đọc kết quả reviewer. [Evidence](review-evidence.json) ghi model/mức yêu cầu, target hash và trạng thái thực hiện.
- Nguồn yêu cầu: [brief gốc](../../Challenge_Brief_OrganizationAI_VN.docx.md), Mục 2.A: dòng 47–59, 63–67 và 73–83. Brief yêu cầu phân loại chuyển tiếp, câu hỏi cụ thể và routine tự động; đây là yêu cầu phải chứng minh, không chỉ tên nhãn.
- Lead đã mở lại [hướng dẫn MISA](https://helpamis.misa.vn/amis-quy-trinh/kb/misa-ket-noi-voi-amis-cham-cong-tu-dong-chay-quy-trinh-phe-duyet-tam-ung-di-cong-tac/), cập nhật 25/03/2024, có các bước duyệt công tác, duyệt ứng và kế toán chi; [UW approvals](https://finance.uw.edu/travel/reimbursementsystemapprovals) tách trách nhiệm kiểm tra tuân thủ và nguồn kinh phí. Đây là mẫu workflow tham khảo, không quy định bắt buộc cho mọi doanh nghiệp Việt Nam và không chứng minh phù hợp cuộc thi.

## 2. Finding ledger — nhận xét reviewer và phán định của lead

Năm nhận xét dưới đây là tóm tắt kết quả reviewer, không phải transcript nguyên văn. Mức đánh giá là mức thiết kế walkthrough, không khẳng định có lỗi vận hành trong code.

| ID / mức | Reviewer nhận xét | Phán định độc lập của lead | Sửa tối thiểu / điều kiện kiểm tra |
| --- | --- | --- | --- |
| S3-R01 / Quan trọng | Dòng 90, 98–99 gộp ngoài policy và vượt quyền; sai routing khác hai lý do này. | Đồng ý. Target đã phân biệt vi phạm rõ ở dòng 99, không thiếu toàn bộ taxonomy; cần làm rõ nguyên nhân/người nhận/action riêng. Brief dòng 51 yêu cầu ba nhóm phân loại. | Fact thiếu → người nắm nguồn; chưa có quy tắc/loại ngoài phạm vi → người sở hữu quy định; vượt quyền → người có quyền tương ứng; sai người nhưng có route xác định → tự điều phối. Cấm rõ và không có ngoại lệ áp dụng → không đủ điều kiện. Bốn tình huống chỉ khác nguyên nhân phải có action phù hợp. |
| S3-R02 / Quan trọng | Dòng 82, 89, 97, 102 đã nhận diện quan hệ đề nghị nhưng chưa có bảng hành động cho mới/sửa/bổ sung/đã duyệt/lệnh chờ/đã nhận. | Đồng ý mạnh. Đây là nội dung cốt lõi chống xử lý trùng, không phải yêu cầu xây ERP. Cùng chuyến và cùng số tiền chưa chứng minh cùng phần nghĩa vụ. | Thêm bảng nhỏ ghép quan hệ đề nghị với trạng thái phê duyệt/chi, ghi hành động và giới hạn. Đã duyệt nhưng chưa chi tiếp tục đúng đề nghị nếu còn hiệu lực; lệnh chi chờ/không rõ thì xác minh trạng thái, không tự tạo lệnh khác cho cùng phần. Đã trả đúng phần thì ghi đã xử lý, không cáo buộc gian lận. |
| S3-R03 / Vừa | Dòng 94–100 chưa tách làm rõ fact và trả lại để sửa nội dung đề nghị. | Đồng ý phân biệt; phản biện ví dụ reviewer: dự toán nhân viên còn 1,5 triệu và xin ứng 2 triệu CHƯA tự chứng minh bắt buộc sửa nếu chưa có quy tắc ràng buộc số ứng. Dòng 87 đã cảnh báo không suy quy tắc đó. | Bổ sung nguồn không ngầm đổi số yêu cầu/phạm vi. Nếu người nộp sửa nội dung, giữ bản cũ và tạo bản mới, kiểm tra phần ảnh hưởng. Chỉ yêu cầu thay đổi do vi phạm khi có quy tắc áp dụng; không tự cắt 2 thành 1,5 triệu. |
| S3-R04 / Vừa | Dòng 94–100 chưa rõ unknown nào chặn kết luận đủ căn cứ. | Đồng ý. Các kiểm tra riêng đạt không đủ cho kết luận tổng thể nếu lịch sử tiền liên quan còn unknown. Không bắt mọi field thiếu phải escalated. Không coi thiếu schema ở R2 là defect cần code ngay. | Đạt kiểm tra khi mọi điều kiện bắt buộc áp dụng có căn cứ và đạt; không còn unresolved ảnh hưởng kết quả. Optional không ảnh hưởng → không bắt hỏi; chưa xác định được ảnh hưởng → chưa kết luận ready. Giữ rõ các phần chưa kiểm tra dù có một căn cứ đủ cho kết luận vi phạm rõ. |
| S3-R05 / Quan trọng, rủi ro chưa xác minh | Dòng 80, 96 có human financial approval cho mọi case; có thể xung đột routine tự động ở brief 47, 55, 73, 80 tùy boundary BTC chấp nhận. | Đồng ý giữ rủi ro, không kết luận chắc chắn fail. Target đã nói boundary cần chứng minh; reviewer củng cố điều đó, không phát hiện omission hoàn toàn mới. Không đổi quyết định giữ con người duyệt tiền chỉ để thuận metric. | Công bố task hệ thống tự hoàn tất và output/action; routine không cần câu hỏi hay sửa thủ công để hoàn tất task đó. Báo riêng sự can thiệp vì bất định, checkpoint tài chính cố định và tổng thời gian con người trên toàn workflow. Giả thuyết BTC chấp nhận boundary còn chưa xác nhận; 3 routine/2 escalation đúng trên task đã công bố chưa tự giải quyết rủi ro này. |

## 3. Bổ sung riêng của lead

### S3-L01 — Phân biệt nguồn mờ/thiếu với lỗi dịch vụ

Target dòng 100 và phép thử “không đọc được nguồn” tại dòng 102 còn quá rộng. Ảnh mờ số tiền bắt buộc là bất định dữ kiện: hỏi người có thể cung cấp/xác minh nguồn đó. OCR timeout là lỗi xử lý: retry/báo lỗi, không đòi nhân viên chụp lại ảnh tốt. Hai trường hợp không được khẳng định đủ điều kiện; nhưng hành động khôi phục và cách báo cáo phải khác. AI không tự nâng dữ kiện mờ thành chắc chắn.

### S3-L02 — Kết quả chỉ đúng với phiên bản và mốc nguồn đã kiểm tra

Target có lưu phiên bản/quy định và hiệu lực công tác (dòng 86, 94), đây là điểm đúng. Cần nối vòng trả lời và việc dùng báo cáo ở Bước 4/5: câu trả lời được ghi cùng nguồn/phạm vi; kiểm tra lại phần ảnh hưởng rồi phát hành kết quả mới. Nếu giữa lần kiểm tra và duyệt/chi xuất hiện ứng/lệnh chi mới, báo cáo cũ không bảo đảm chống trùng.

MVP chỉ cần version/mốc dữ liệu và kiểm tra phần liên quan trước hành động; không cần bank feed hoặc distributed infrastructure. Giao dịch ngoài hệ thống không được cung cấp thì chưa thể biết. Source contract phải nêu rõ giới hạn đó, không dùng timestamp để giả vờ biết toàn bộ lịch sử tiền.

### S3-L03 — Câu hỏi cụ thể chưa chắc đạt tiêu chí cao nhất của đề thi

Ví dụ hỏi tài chính tại dòng 97 nêu đúng người/chuyến nhưng còn yêu cầu tra toàn bộ lịch sử và cung cấp nguồn. Brief dòng 81 chấm cao nhất khi người nhận có thể quyết định bằng một câu trả lời mà không phải tra hồ sơ gốc. Nếu dữ kiện đã có trong bảng nguồn, hệ thống phải tổng hợp chúng trước khi hỏi; routine không bắt kế toán xác nhận lại từng lần.

Khi có hai nguồn mâu thuẫn, câu hỏi mang các giá trị/ref và phần cần xác nhận, chẳng hạn một lệnh chi ứng viên thuộc cùng phần đề nghị hay khoản khác. Không tạo ref hoặc lựa chọn số tiền khi nguồn không cung cấp. Nếu nguồn thật sự chưa được cung cấp, yêu cầu tìm/cung cấp nguồn có thể cần thiết nhưng không hứa đạt chất lượng “không tra cứu thêm”. Chuẩn bị dữ liệu trước/import phạm vi nhỏ là đề xuất MVP, chưa là khả năng đã triển khai.

## 4. Phản ví dụ số tiền xin ứng

Giả định đã thực nhận 2 triệu đúng công việc và các điều kiện/quy định khác đã rõ. Một bản mới ghi “xin ứng 3 triệu” có ít nhất ba nghĩa:

| Nghĩa được người nộp/nguồn xác định | Xử lý đề xuất |
| --- | --- |
| Xin thêm 3 triệu ngoài 2 triệu đã nhận | Kiểm tra khoản bổ sung 3 triệu cùng tổng/lịch sử theo quy định; không tự trừ 2 thành 1. |
| Đề nghị tổng ứng thành 3 triệu | Trong giả định không có phần chi/chờ/hoàn khác ảnh hưởng, phần xin thêm là 1 triệu; cần xác định nghĩa tổng và policy trước khi tính. |
| Gửi lại/sửa chính đề nghị đã cấp 2 triệu | Liên kết với đề nghị cũ; phần đã chi không biến thành yêu cầu chi mới. Xác định nội dung thay đổi và việc xử lý bổ sung nếu có. |

Nếu nghĩa chưa rõ, giữ câu hỏi cụ thể cho người nộp về “xin thêm hay tổng mong muốn”, đồng thời dùng nguồn tài chính để xác định tiền đã xảy ra. Không để nhân viên tự khai số đã nhận trở thành bằng chứng duy nhất; không gộp mọi khoản cùng chuyến.

## 5. Hướng chỉnh gọn trước khi chốt walkthrough

1. Một bảng quan hệ đề nghị × trạng thái phê duyệt/chi × hành động kế tiếp. New/revision/supplement là quan hệ; approved/pending/paid là trạng thái khác trục, không tạo một enum độc quyền trộn chúng.
2. Tách nguyên nhân kiểm tra và hành động: làm rõ, sửa đề nghị, route đúng người, chuyển vấn đề policy/quyền, không đủ điều kiện hoặc lỗi xử lý. Không bắt mỗi nguyên nhân phải thành một màn hình/state riêng.
3. Một điều kiện đủ căn cứ, kèm giới hạn/source/phiên bản và vòng nhận câu trả lời/kiểm tra lại. Có thể lưu nhiều vấn đề cùng lúc; không chỉ dùng label cuối che mất chúng.
4. Công bố công việc tự động hóa và đo cả kiểm tra lẫn tổng công sức con người. Giữ rủi ro chấm thi chưa xác minh, không đổi nhãn để tuyên bố compliance.

Phép thử thiết kế đề xuất: routine đủ nguồn không hỏi; tổng ứng vs xin thêm; đã duyệt-chưa chi; lệnh chi chờ; cùng phần đã trả; bổ sung hợp lệ; policy gap vs cấm rõ vs sai route vs vượt quyền; dữ kiện bắt buộc vs ghi chú tùy chọn; ảnh mờ vs OCR timeout; trả lời bổ sung vs sửa amount; nguồn đổi sau kiểm tra. Đây là test scenarios chưa có gold/schema/pipeline thực thi, không báo PASS phần mềm.

Giữ hướng hiện tại: phân biệt 8/5/3/2 triệu và dự kiến/thực tế; AI đề xuất có nguồn, chương trình tính và áp dụng rule; không đòi hóa đơn hậu kiểm trước chuyến đi; nguồn thiếu không thành 0; human approval/chi giữ ý nghĩa riêng. Chưa cần ERP, ngân hàng, auth doanh nghiệp hay framework AI mới.

# Review R4.1 — Lõi dữ kiện và nguồn

Ngày: 09/10/2026. Reviewer và lead: **Có thể chốt ở mức lõi dữ kiện**, sau khi làm rõ ba semantics để trình chủ dự án. Chưa chốt evidenceacceptance/quality/authority R4 tiếp theo; không schema/code/runtime verified.

Target [draft](../../discovery/R4_DATA_SOURCE_DRAFT.md); [snapshot được review](TARGET_R4_DATA_SOURCE_DRAFT.md). Các ràng buộc đã bổ sung vào draft riêng, không sửa snapshot; chưa independentrereview bản chỉnh.

## Phương pháp

Reviewer `chatgpt-web/gpt-5.6-sol`, **High**, James, ID `01a11e26-d4b2-7190-a9fe-532e2f3ae059`; context riêng không parenthistory/leadnotes/oldreviews/code. Một lượt hoàn thành, đã đóng. [Raw response](REVIEWER.md), [pre-review](LEAD_PRE_REVIEW.md) ghi/hash trước reviewer; [evidence](review-evidence.json) ghi trước/sau.

## Phán định

| ID / mức reviewer | Nhận xét | Lead phán định/bổ sung |
| --- | --- | --- |
| R4D-R01 / Quan trọng | Snapshot dòng24/25/52: uploader, issuer/source system, coverageowner chưa đủ tách. | Đồng ý, bổ sung3vai. Uploader không tự đổi sourceauthority; cùng provenance đủ/contents giống thì operator vsNV upload không tự đổi check. Phảnbiện mởrộngquá: cùng bytes không chứng minh issuer/provenance thật nếu chưa có căn cứ; uploadchannel có thể là metadata, không là proof toàn nội dung. |
| R4D-R02 / Quan trọng | Dòng23/25/29: factquality, sourcepaymentstate, technicalprocessing cần3trục. | Đồng ý mạnh. PAID rõ nhưng amountmờ không finalmoney. Techsuccess không factverified; techfailure khôngsourcebusinessban. Fact đủ cho một check khônggenericVerifiedallcase. |
| R4D-R03 / Vừa | Dòng16/38: confirmedreading khácactualfact/approval, genericconfirmed cóthểnângpayerproof. | Đồng ý, confirmation cótarget field/type/question/source/role/scope. Khôngbỏ mọi humanconfirmation vì chỉlàhuman; rulebook quyết định điều kiện chấpnhận cho từng check. Khôngcho câu “đúng3” đơnđộc tạoactualreceipt. |

## Bổ sung riêng và phạm vi

Lead làm rõ internalCase/Doc/Row IDs được sinh, không thay unknownexternalinvoice/bank/personidentity. Moneyrelatedattempt cóknownamount/rawstate nhưng chưareceipt; dateupload/issue/attempt/receipt/asof khácýnghĩa. Sourcecoveragezeroabsence khôngfakeevent0.

Giữ4lớp/6nhómdữkiện ởmứcconcept, mỗi check chỉ yêu cầufactcầnthiết; nhiềubillkhácfields vẫncócommon decisioncore. Employee/caseaffected khácpayer/payeevendor. KhôngcầnERP bankstatementforeverycase hoặc hugeschemaallbilltypes.

Điểm tiếp R4.2 là applicability vàacceptableevidence theo loại/phương thức, quality/confirmation/authority trước tiền/limits cụthể; không để gate “đủ source” thành tự chứng thực circular. Reviewer đã xác định phần này là contract tiếp theo cóthểkiểmchứng, không lỗi thiếucodeR4.1.

Ví dụ sourcePAID/amountmờ, sameexportdifferentuploader/provenance, confirmedOCR vsconfirmedmoney, generatedDocID vsrealbankref, ownercoverage vsunknownhistory dùng để chốt semantics; chưa runproductiontests. R3accepted scope được ghi; actualcompetitionfit/trial còn chưa xác minh.

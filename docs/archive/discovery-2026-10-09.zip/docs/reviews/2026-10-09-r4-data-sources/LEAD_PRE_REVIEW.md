# R4.1 — Nhận xét riêng trước reviewer

Ngày: 09/10/2026. Target [snapshot](TARGET_R4_DATA_SOURCE_DRAFT.md), dòng1–66. Ghi trước khi đọc reviewer, không code/test/luật hoặc source thật verified. Verdict ban đầu: **Có thể chốt ở mức lõi dữ kiện**, với định nghĩa/concept, evidenceacceptance vàquality/authority tiếpR4 sau mớichốt.

Điểm giữ:4lớp táchstatement/source/proposalfact/useforcheck, employee/actualpayee khác, eventreference namespace khácdocID, financialdatasetcovered vừađủMVP, numericmissing không0, policy/notallfieldrequired trướcđọcparts. Không có ngưỡngfake/readablealone waiver hoặc sourcefinancePaidđồngnghĩareceipt.

Các semantics muốn kiểmtra thêm:

- Dòng29 khôngdùngIDnhântạo đểthay unknownexternalfact, nhưngcase/document/row IDs nội bộ cóthể sinh. Không cấmnewworkcase nếu khôngcóloan/bookingref và không đểinternalIDs làmproof externalidentity.
- Dòng25 pendingattempt/sourcepaymentrecord là monetaryrelatedrecord có amount/rawstatus rõ nhưng chưaActualReceived. Fieldquality và paymentstate tách; actualdate/sourceissue/export asof cóýnghĩakhác. Không bắt accountdebited→actualpaidpoint.
- Dòng14 fact sufficient ispercheck/version/rule, khônggenericVerifiedBoolean để reuse toàncase. Giá trịnormalize money cầncurrency/unit/locale khicầntheorule; VNDscope không tựconvertunknowncurrency hoặc sửa raw3 thành cap2.
- Dòng42/52 nguồncoverageownerconfirmation chỉvalidđúngscope/policy đãđịnh. Zeroabsence cần provenance cảdataset/query/scope/mốc, khôngmột money event0. As-of21 nhưngdatachỉ1–15chưacover16–21khôngkếtkhôngP. Nguồn fieldtrue/selectedfinanceRole khôngauthenticity/bankproof.
- Dòng50 allocation đúngportion vàkhôngoverlaptheosource, chưađưa policy/schemafuture thànhengineglobalcrosscompany. Khôngcoi10receipts=10payments hoặc2differentIDsfrom2systems=2events.

Mụcchốtlà concept vàcác field liênquan, không tuyênbố đãđủ bằngchứng chi phí thực tế. Qualitygates/sourceacceptancepolicy vàallowedconfirmroles cầnởR4phầntiếptheo; người chủdựán hiểu đangfactcheck nào beforecode. Nguồn nhập/import cầngiữrecordgốcmetadata/version đểmap tự động hoặcquestion, inputcleanup/humanmap đoassistednhưR3.

Phép thử semantics: invoicecompany≠payercompany; fieldamountclear/datemissing; Paidpending source/rawstatus; derivedabsence0withsourcecoverage vsactualevent0; internalDocIDkhácbanktxnref; newworknoexternalID; directpayvendor cùngaffectedemployee; receivedgross2/returned2net0≠neveradvance. Chưa test/harness.

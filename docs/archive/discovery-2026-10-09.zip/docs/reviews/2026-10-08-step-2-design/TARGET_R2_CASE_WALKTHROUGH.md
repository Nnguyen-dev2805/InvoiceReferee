# R2 — Đi một hồ sơ công tác bằng tay

Ngày: 08/10/2026 · Trạng thái: **WALKTHROUGH GIẢ LẬP ĐỂ THẢO LUẬN**.

Căn cứ: [khung R1](../DISCOVERY_ROADMAP.md). Không đọc/chạy/sửa code; không có thử người dùng hay dữ liệu doanh nghiệp thật. R2 cần phân biệt quy trình khả dĩ từ research với hiện trạng thực đo. Case này làm rõ công việc và phụ thuộc trước khi thiết kế rulebook/gold.

## 1. Bối cảnh và giả định

Một nhân viên đi gặp khách hàng trong hai ngày. Công ty trả vé máy bay trực tiếp; nhân viên đề nghị ứng một phần cho khách sạn, ăn phục vụ công việc và di chuyển.

- Tất cả số tiền là VND; các vai/người/chứng từ dưới đây giả lập.
- Giả định chuyến đi, dự toán và các khoản đáp ứng quy định giả lập của case. Chưa đặt hạn mức/điều khoản thành policy thật.
- Giả định nguồn đủ rõ, liên kết đúng người/công việc và đủ điều kiện bằng chứng sẽ được rulebook định nghĩa. Không coi giả định đó là proof nguồn hay chất lượng OCR đã verified.
- Phạm vi tài chính được xác nhận đầy đủ tại mốc đối chiếu: không có khoản chi khác, hoàn tiền, hoàn trả trước đó hoặc giao dịch chờ ảnh hưởng kết quả, trừ biến thể ghi riêng.

## 2. Trước chuyến đi

| Bước | Vai thực hiện | Dữ liệu/căn cứ | Công việc và kết quả kỳ vọng |
| --- | --- | --- | --- |
| 1. Nộp đề nghị | Nhân viên | Mục đích, thời gian, dự toán phần nhân viên thanh toán 5 triệu; xin ứng 2 triệu. | Hệ thống kiểm tra thông tin để xem xét và vướng mắc ban đầu. Xin ứng 2 không có nghĩa đã nhận 2. |
| 2. Cho phép công tác | Người có quyền | Đề xuất và căn cứ công việc. | Ghi phạm vi công tác được phép. Nếu đã có quyết định bên ngoài đủ căn cứ, dùng quyết định đó, không xin phép lại. |
| 3. Kiểm tra ứng | Hệ thống, với nguồn người phụ trách cung cấp | Đề nghị, căn cứ công tác, quy định, lịch sử cần thiết. | Báo cáo kiểm tra đủ căn cứ theo giả định, hoặc câu hỏi nếu có vướng mắc. Không tự phê duyệt tiền. |
| 4. Duyệt ứng | Người có quyền tài chính | Báo cáo, dữ kiện, nguồn và quy định. | Trong case, duyệt 2 triệu. Nếu trả lại/từ chối thì đi nhánh tương ứng, không mặc định đã chi. |
| 5. Cấp và ghi nhận tiền | Người thực hiện chi/người phụ trách tài chính | Khoản ứng 2 triệu và căn cứ thực tế. | Ghi 2 triệu thực nhận, đúng nhân viên và công việc, không còn khoản ứng chờ xử lý. |

Các bước có thể do một người kiêm nhiều vai nhưng quyết định/nguồn vẫn khác nhau. Chi tiền diễn ra do con người, không phải hành động ngân hàng của InvoiceReferee.

### 2.1. Bước 1 — Nộp bằng form, đã chỉnh sau review

Chủ dự án đồng ý hướng chỉnh trong [review bước 1](../reviews/2026-10-08-step-1-design/REVIEW.md) và cho chuyển bước 2. Bản gốc review được giữ tại [snapshot](../reviews/2026-10-08-step-1-design/TARGET_R2_CASE_WALKTHROUGH.md); thay đổi dưới đây là thiết kế sau review, không phải code đã thực hiện.

Case giả lập được xem tại thời điểm lập đề nghị trước chuyến đi: nhân viên A (NV-DEMO-01), công việc CT-DEMO-01, đi Hà Nội ngày 05–06/10/2026 để trao đổi yêu cầu dự án giả lập với khách hàng KH-DEMO-01. Người nhận bước kế tiếp là Quản lý B, giả định có quyền xét công tác trong case; lựa chọn này không chứng minh quyền/danh tính công ty thật.

| Dữ kiện kế hoạch | Số tiền VND |
| --- | --- |
| Khách sạn + ăn phục vụ công việc + di chuyển, dự kiến nhân viên thanh toán | 3.000.000 + 1.000.000 + 1.000.000 = 5.000.000 |
| Vé, dự kiến công ty trả trực tiếp | 3.000.000 |
| Tổng dự toán trong case | 8.000.000 |
| Xin ứng | 2.000.000 |

Đủ thông tin để xem xét trong case nghĩa là biết người/công việc, địa điểm/ngày đi-về, mục đích có thể hiểu, các nghĩa tiền và vai/người nhận phù hợp. Định dạng/schema, tài liệu bắt buộc theo loại và ngưỡng policy vẫn chốt ở R4. Hệ thống nhận/lưu khai báo và nguồn, kiểm tra dữ liệu và phép cộng, ghi vấn đề thiếu/sai/mâu thuẫn. Không tự cắt tiền, không đối trừ 2 triệu khỏi dự toán để biến tổng thành 6 triệu.

Giữ hai nguồn khi form và giấy khác nhau; không overwrite. Nộp lại đúng đề nghị giữ một quan hệ hồ sơ với lịch sử/phiên bản. Cùng người/chuyến hoặc cùng tệp chưa đủ để gộp/từ chối, vì có thể là sửa, bổ sung nguồn hoặc đề nghị bổ sung theo policy; chưa rõ quan hệ thì hỏi.

Ba kết quả: **đã tiếp nhận nhưng cần bổ sung/làm rõ**; **đã tiếp nhận nhưng chưa xác định nơi xử lý**; hoặc **đủ thông tin ban đầu để chuyển tới người xét công tác**. Kết quả cuối chưa là đủ điều kiện ứng, công tác đã được phép, vé đã trả hay tiền đã nhận. Chưa có dữ liệu thực chi không tự thành ứng 0; không đòi hóa đơn sau chi hay phê duyệt chính đề nghị đang xin ở intake.

AI có thể đọc/đề xuất liên kết căn cứ có nguồn, báo mismatch; không sửa ngầm khai báo hoặc phê duyệt. Số học rõ dùng chương trình. Checkpoint cho phép công tác được trình bày là quyết định con người trong workflow; độ tự chủ vẫn phải chứng minh trên đơn vị công việc công bố trước, không chỉ bằng cách đổi nhãn metric.

### 2.2. Bước 2 đang thảo luận — Xem xét và cho phép công tác

Trạng thái: **ĐỀ XUẤT LOGIC CHO WALKTHROUGH, CHƯA CHỐT MỌI QUYỀN/POLICY**.

Quản lý B nhận đề nghị đã đủ dữ kiện ban đầu, dự toán tổng 8 triệu với các phần tách riêng, xin ứng 2 triệu và căn cứ kèm nếu có. Nhiệm vụ là quyết định công việc có được phép thực hiện, với phạm vi nào; không xác nhận đã cấp ứng hoặc mặc nhiên duyệt khoản ứng 2 triệu.

| Kết quả | Ví dụ trong case | Bước tiếp theo |
| --- | --- | --- |
| Cho phép đúng phạm vi đã đề nghị | Đồng ý A gặp KH-DEMO-01 tại Hà Nội ngày 05–06/10. | Ghi quyết định/phạm vi/nguồn, chuyển kiểm tra đề nghị ứng ở bước 3. |
| Yêu cầu sửa/bổ sung hoặc chỉ chấp thuận phạm vi khác | Chỉ cho phép làm việc một ngày, không lưu trú; hoặc cần lịch hẹn để xem xét. | Ghi nội dung quyết định/yêu cầu cụ thể; nhân viên cập nhật, hệ thống kiểm tra lại phần bị ảnh hưởng, người có quyền xác nhận phạm vi phù hợp trước khi đi tiếp. Không tự giữ dự toán hai ngày như đã được chấp thuận. |
| Từ chối | Chuyến đi không được cho phép theo quyết định của người có quyền. | Lưu lý do, kết thúc đề nghị mới chưa chi. Tiền đã cấp từ trước nếu có được theo dõi/xử lý riêng, không bị xóa. |

Nguồn quyết định cần thể hiện ai/vai nào quyết định, thời điểm, phiên bản đề nghị, nội dung/phạm vi và điều kiện/lý do khi có. Không dùng riêng chữ “Approved” để suy toàn bộ ngân sách/khoản ứng đã duyệt. Nếu muốn có quyết định ngân sách tại đây phải nêu rõ và có đúng quyền; case thường quy đang đi chưa giả định bước này duyệt tiền.

Hệ thống chuẩn bị dữ kiện, chỉ rõ vướng mắc, chuyển đúng nơi và lưu quyết định. AI có thể hỗ trợ tóm tắt căn cứ nhưng không thay người quản lý quyết định chuyến đi đáng thực hiện. Căn cứ cho phép bên ngoài đủ theo policy được sử dụng, không thêm vòng xin phép lại; nếu nguồn/quyền/phạm vi chưa rõ thì xác minh, không tự đánh dấu được phép.

Đường thường quy đang theo: quản lý cho phép đúng đề nghị → lưu phạm vi → bước 3 kiểm tra ứng. Chưa có kết luận tiền được duyệt/đã nhận ở cuối bước 2. Nội dung cụ thể cần để xét, việc chấp thuận có điều kiện và quyền từng loại quyết định còn phải chốt trong rulebook.

## 3. Sau chuyến đi: gói dữ liệu cần đối chiếu

| Khoản chi | Giá trị | Nguồn thanh toán trong case | Ai cung cấp nguồn ứng viên? |
| --- | --- | --- | --- |
| Vé máy bay | 3.000.000 | Công ty trả trực tiếp, đúng booking/chứng từ. | Người phụ trách tài chính cung cấp bản ghi và căn cứ; nhân viên có thể cung cấp vé. |
| Khách sạn | 3.000.000 | Nhân viên thanh toán. | Nhân viên cung cấp chứng từ và dấu vết thanh toán phù hợp. |
| Ăn phục vụ công việc | 1.000.000 | Nhân viên thanh toán. | Nhân viên cung cấp chứng từ/nội dung cần theo quy định giả lập. |
| Di chuyển | 1.000.000 | Nhân viên thanh toán. | Nhân viên cung cấp chứng từ và căn cứ liên quan. |

Bản ghi tài chính kèm theo: ứng thực nhận/phân bổ cho case 2 triệu; chưa có hoàn trả chi phí cho nhân viên, hoàn tiền hoặc khoản chi/thu khác ảnh hưởng. Dữ liệu “chưa có” ở đây là giả định đã được xác nhận đủ phạm vi, không phải kết quả tìm kiếm không thấy.

## 4. Đi từng kiểm tra bằng tay

| Kiểm tra | Câu hỏi cần trả lời | Kết quả kỳ vọng theo giả định |
| --- | --- | --- |
| Công việc và phạm vi | Chứng từ/khoản chi có thuộc người/công việc/phạm vi đã được phép không? | Khớp. Không chỉ dựa vào tên file. |
| Chất lượng và nội dung | Các dữ kiện cần dùng có rõ, đủ và đúng nguồn không? | Đủ theo giả định; R4 mới chốt nguồn tối thiểu. |
| Quy định | Mục đích và khoản chi có đáp ứng rulebook không? | Đủ điều kiện trong case giả lập; không tự tạo quy định để khớp kết quả. |
| Liên kết thanh toán | Giao dịch thuộc khoản nào, đã trả bao nhiêu, có phần chưa rõ không? | Công ty 3 triệu vé; nhân viên 5 triệu phần còn lại. |
| Ứng | Số thực nhận là bao nhiêu và thuộc phạm vi nào? | 2 triệu, không dùng số xin ứng thay sự kiện tiền thật. |
| Lịch sử | Phần đang yêu cầu đã được xử lý, hoàn trả hay có giao dịch chờ chưa? | Chưa có theo phạm vi xác nhận; không bỏ qua kiểm tra vì hóa đơn mới. |
| Tính toán | Số còn cần chi/thu là gì? | Nhân viên thanh toán đủ điều kiện 5 triệu − ứng 2 triệu = đề xuất công ty trả thêm 3 triệu. |

## 5. Báo cáo và việc còn lại của con người

Báo cáo: chi phí đủ điều kiện đã đối chiếu 8 triệu; công ty trả trực tiếp 3 triệu; nhân viên thanh toán 5 triệu, đã nhận ứng 2 triệu; chưa có hoàn trả trước đó; đề xuất trả thêm 3 triệu. Giữ nguồn, phép tính và trạng thái của từng phần.

Kế toán rà soát trên báo cáo, người có quyền quyết định tài chính. Nếu duyệt và thực hiện chi thêm 3 triệu, phải ghi nhận/đối chiếu căn cứ thực tế rồi mới xem điều kiện đóng. Nếu trả lại hoặc từ chối, giữ nhánh và lịch sử tương ứng; không tự xóa khoản ứng hoặc suy toàn bộ chi phí bằng 0.

## 6. Ba biến thể để kiểm tra cách hiểu

| Chỉ thay dữ kiện này | Kết quả kỳ vọng |
| --- | --- |
| Xác nhận không nhận ứng, giữ các khoản/nguồn khác và không có lịch sử đã hoàn | Cùng lõi sau chi; đề xuất trả thêm 5 triệu. Không tạo khoản ứng giả hoặc bắt qua đề nghị ứng. |
| Giữ ứng 2 triệu, nhưng xác minh đã hoàn đúng phần này 3 triệu cho nhân viên | Số còn phải trả thêm 0. Cùng chứng từ xuất hiện lại không tự là gian lận. |
| Chứng từ di chuyển không đọc rõ dữ kiện tiền bắt buộc, chưa có nguồn thay thế đủ căn cứ | Giữ phần đã kiểm tra và khoản chưa rõ; hỏi đúng người/căn cứ cụ thể; chưa chốt quyết toán cuối hoặc chi phần đã biết. |

## 7. Điều cần làm rõ tiếp ở R2

Case thường quy đã cho thấy cần hai nhóm nguồn: khai báo/chứng từ nhân viên và dữ liệu tài chính/phê duyệt trong phạm vi. Bước kế tiếp đi một case thiếu/mâu thuẫn: nguồn nào thiếu, ai thực sự có thể trả lời, câu trả lời làm hồ sơ đi tiếp ra sao. Chưa cần schema, API, thuật toán khớp hay corpus chạy tự động; những phần đó thuộc R4–R7.

# Review thiết kế — R2, bước 2 cho phép công tác

Ngày: 08/10/2026 · Verdict cuối của lead: **Cần chỉnh sửa**.

Target: [bước 2](../../discovery/R2_CASE_WALKTHROUGH.md), Mục 2.2; [snapshot nguyên văn được review](TARGET_R2_CASE_WALKTHROUGH.md). Target/code không được sửa trong lượt này. Review đánh giá logic thiết kế, không phải implementation hoặc luật doanh nghiệp.

## 1. Phương pháp và nguồn

Reviewer `chatgpt-web/gpt-5.6-sol`, **High**, Singer, ID `01a11bbe-3559-7343-bfde-83200746f528`, đã hoàn thành nhiệm vụ độc lập read-only và kết luận **Cần chỉnh sửa**. Không đổi model/mức. [Nhận xét riêng của lead](LEAD_PRE_REVIEW.md) được ghi trước khi đọc kết quả subagent.

Lead đã mở lại nguồn: [MISA công tác/tạm ứng](https://helpamis.misa.vn/amis-quy-trinh/kb/misa-ket-noi-voi-amis-cham-cong-tu-dong-chay-quy-trinh-phe-duyet-tam-ung-di-cong-tac/) tách duyệt công tác, duyệt ứng và kế toán chi; [UW approvals](https://finance.uw.edu/travel/reimbursementsystemapprovals) phân biệt trách nhiệm người duyệt theo vai. Chúng hỗ trợ phân tách quyết định, không xác định bắt buộc mọi công ty phải có quy trình hoặc schema giống vậy. Quyền/policy cụ thể còn ở R4.

## 2. Finding ledger của lead

Reviewer gọi ba điểm đầu P0 và các điểm sau P1. Lead dùng mức thiết kế dưới đây: điều cần sửa trước khi chốt nhánh, khác với lỗi vận hành thực tế.

| ID / mức | Nhận xét reviewer | Phán định và phản ví dụ của lead | Sửa tối thiểu / điều kiện kiểm tra |
| --- | --- | --- | --- |
| S2-01 / Quan trọng | Quyền phải gắn phạm vi, không chỉ chức danh quản lý. | Đồng ý nguyên tắc; không coi bản hiện tại bỏ sót hoàn toàn, vì case đã giả định B có quyền. Cần thể hiện kết quả khi quyền chưa rõ/sai phạm vi. | Ghi nguồn/quyền và phạm vi nhân viên/công việc. Demo dùng ánh xạ vai/phạm vi công bố, không đòi SSO/HRMS. Người không có quyền không tạo phép chỉ từ “Approved”; chưa rõ quyền thì giữ chờ đúng người. |
| S2-02 / Quan trọng | Gộp yêu cầu bổ sung với cho phép có điều kiện. | Đồng ý mạnh. “Cần lịch hẹn mới xét” chưa có quyết định; “đồng ý một ngày, không lưu trú” có thể là phép đã xác định. | Tách trạng thái logic. Còn thiếu để ra quyết định: chờ. Đã cấp phép theo phạm vi/điều kiện: kiểm tra đề nghị đáp ứng. Không tự coi mọi câu chứa “đồng ý nếu” là đủ; điều kiện phải rõ và cách xác định đã thỏa được policy chấp nhận. |
| S2-03 / Quan trọng | Quyết định phải gắn version và scope; revision cần kiểm tra ảnh hưởng. | Đồng ý, nhưng không yêu cầu mọi revision phải duyệt lại. Bản hiện tại đã lưu version/scope; cần thêm quy tắc dùng cho bản sửa. | Giữ version đã xét và nội dung đã cho phép. Bản mới đáp ứng chính phạm vi/điều kiện và không thay phần liên quan: kiểm tra và ghi quan hệ dùng quyết định, không tự chuyển approval boolean. Đổi Hà Nội thành TP.HCM/ngày ngoài phạm vi: quyết định cũ chưa đủ. |
| S2-04 / Vừa | External permission cần vòng đời; im lặng/hủy/thu hồi không là có phép. | Đồng ý. Nguyên tắc còn hiệu lực phải áp dụng cả quyết định trong app và bên ngoài. Không giả vờ app biết lịch sử ngoài app không được cung cấp. | Giữ nguồn, người, scope, trạng thái/hiệu lực theo dữ liệu có; cần làm rõ thì chờ. No response không chuyển tiếp như đã được phép; thu hồi giữ lịch sử và tiền đã xảy ra. |
| S2-05 / Giữ nguyên, làm rõ cách trình bày | Công tác, ngân sách/ứng và chi tiền độc lập. | Đây đã là điểm đúng, không phải lỗi cần viết lại. Có thể một người kiêm vai/cùng lượt thao tác nhưng nội dung cấp quyền phải tách. | “Cho phép công tác” không tự duyệt tổng dự toán 8 triệu hoặc ứng 2 triệu. Nếu có quyền/đồng ý tài chính rõ, ghi quyết định tương ứng riêng. Không thêm hai màn hình/chữ ký chỉ để tách logic. |
| S2-06 / Vừa | Người duyệt cần context/evidence, không chỉ AI summary/Yes-No. | Đồng ý. Tóm tắt bỏ conflict khiến con người không biết đang cho phép gì. | Thể hiện đề nghị/phiên bản/phạm vi, nghĩa tiền, nguồn, vấn đề chưa rõ và thay đổi. AI không che source khác nhau, không sửa scope hoặc tự quyết định sự cần thiết chuyến đi. |

## 3. Ranh giới không được suy rộng

- Không cần toàn bộ quyền doanh nghiệp hay thuật toán xác thực chữ ký để review case logic; nhưng demo role selection không chứng minh danh tính/quyền công ty thật.
- Không hứa tự động xử lý mọi điều kiện bằng ngôn ngữ tự nhiên. “Đi nếu khách hàng xác nhận lịch” cần căn cứ; “đi nếu hợp lý” chưa đủ điều kiện để chương trình tự đánh dấu đạt.
- Không làm rơi liên kết version: v1 được xét và approved scope phải được giữ; kiểm tra v2 và lý do tiếp tục dùng quyết định cần được ghi. Không chỉ copy trạng thái Approved.
- Không dùng tuổi của quyết định để tự suy thu hồi, cũng không dùng không thấy thu hồi trong nguồn thiếu để khẳng định còn hiệu lực. Điều kiện đủ để sử dụng và độ bao phủ nguồn chốt ở rulebook.
- Approval bình thường không tự là escalation do bất định; nhưng đổi nhãn không chứng minh tự chủ. Cần [đề gốc](../../Challenge_Brief_OrganizationAI_VN.docx.md), đơn vị công việc công bố và evidence phù hợp.

## 4. Bước 2 chỉnh ở mức logic — đề xuất chưa thay target

1. Nhận đề nghị đủ dữ kiện để xét; xác định người/vai phù hợp theo phạm vi đã công bố.
2. Người đó quyết định: cho phép đúng đề nghị; cho phép phạm vi/điều kiện khác đã xác định; yêu cầu bổ sung trước khi quyết định; hoặc từ chối. Các trạng thái có thể trình bày gọn nhưng không mất nghĩa.
3. Lưu ai, nguồn quyền, thời điểm, version đã xét, nội dung/phạm vi, điều kiện và hiệu lực/lý do cần thiết.
4. Nếu cần bổ sung để xét, trả người nộp rồi vẫn cần quyết định. Nếu đã cho phép phạm vi khác, cập nhật đề nghị và kiểm tra đáp ứng; chỉ xin lại/làm rõ khi điều kiện/quyền/scope chưa đủ hoặc thay đổi vượt quyết định cũ.
5. Quyết định đủ căn cứ, còn phù hợp với đề nghị hiện tại: chuyển bước 3 kiểm tra ứng. Chưa phản hồi/chưa xác định quyền hoặc scope: giữ chờ. Từ chối: kết thúc đề nghị mới; tiền thực tế từ trước nếu có vẫn theo dõi riêng.

## 5. Case để review sau chỉnh

| Case | Kỳ vọng |
| --- | --- |
| Đúng người/quyền cho phép đúng v1 | Lưu scope và chuyển bước 3; tiền xin chưa thành tiền được duyệt/nhận. |
| “Bổ sung lịch hẹn rồi tôi xét” | Chưa có phép; bổ sung xong cần quyết định. |
| “Cho phép 05/10, không lưu trú”; bản sửa đáp ứng, quyền rõ | Kiểm tra và ghi dùng quyết định theo phạm vi; không mặc định xin duyệt lại. |
| Cùng câu trên nhưng v2 đổi nơi hoặc tăng ngày | Chưa được dùng quyết định cũ cho phần thay đổi. |
| Điều kiện “nếu hợp lý” hoặc nguồn/điều kiện chưa xác định được | Hỏi cụ thể, không tự đạt điều kiện bằng AI summary. |
| Wrong authority/no response/revoked | Không chuyển bước 3 như đã có phép; giữ vấn đề/trạng thái phù hợp. |
| Có external permission rõ, đúng scope và đủ điều kiện nguồn | Dùng căn cứ đó, không reapprove chỉ vì import. |
| Có actual money rồi hủy/thu hồi work permission | Giữ tiền đã xảy ra và xử lý khoản đó; không xóa lịch sử hoặc suy hoàn hết. |

Đây là điều kiện review thiết kế, không phải test thực thi.

## 6. Kết luận

**Cần chỉnh sửa** vì trạng thái điều kiện/bổ sung và áp dụng phép cho version mới còn chưa đủ rõ. Hướng tách công tác khỏi tiền là đúng. Cần bổ sung vòng đời/quyền/context ở mức nghĩa, không xây thêm enterprise infrastructure. Source/policy exactness và implementation vẫn chưa chốt/verified. Target bước 2 giữ nguyên để chủ dự án đánh giá đề xuất trước khi cập nhật.

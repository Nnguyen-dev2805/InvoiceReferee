# Bước 5 — Nhận xét riêng của lead trước kết quả reviewer

Ngày: 08/10/2026. Target: [snapshot](TARGET_R2_CASE_WALKTHROUGH.md), Mục 2.5, dòng 167–213. Ghi trước khi đọc kết quả reviewer. Chỉ review thiết kế; không có chuyển tiền, pipeline hoặc xác thực nguồn thật.

Verdict ban đầu: **Cần chỉnh sửa** ở một số cách phân loại/điểm nối; không thiếu toàn bộ kiểm soát tiền. Bước này đã tách approval/sent/received, giữ pending, chống double-count, nguồn phù hợp phương thức, không coi paid UI là thực nhận, không tự chuyển/hủy tiền và giữ history. Thiếu schema/source contract cụ thể ở R2 không phải lỗi code.

1. **Hoàn lại/đảo/sửa fact khác nghĩa — dòng 199, 203.** Hoàn 1 triệu sau thực nhận 2 là có nhận rồi trả một phần. Lệnh 2 triệu bị ngân hàng trả lại trước khi A nhận có thể là chưa từng thực nhận. Sửa một record nhập sai từ 2 xuống 1 là sửa dữ kiện, không là sự kiện A hoàn 1. Giữ lịch sử của mỗi loại và nguồn liên kết; không biến tất cả thành số âm trong cùng bucket ứng. Ví dụ chi đủ điều kiện 5, thực nhận 2, hoàn lại 1, không có lịch sử/giao dịch khác: số cần xử lý khác case chưa nhận ứng; cách biểu diễn tổng đã nhận/net/hoàn phải tránh trừ hai lần. R4 chốt source/type, R2 cần phản ví dụ rõ.

2. **Thay đổi tiền sau kết quả quyết toán — dòng 203–205.** Quyết toán dùng số đã đối chiếu là đúng nhưng cần nói nguồn/sự kiện mới ảnh hưởng kết quả đã phát hành. Không sửa âm thầm báo cáo/quyết định/chi đã có để khớp dữ liệu mới; giữ phiên bản và xử lý bổ sung/phần nghĩa vụ còn lại. Phản ví dụ báo cáo dùng ứng 2, sau đó có nguồn xác định hoàn lại 1 hoặc lệnh ứng đang chờ trở thành đã nhận: cần kiểm tra phần ảnh hưởng, không sử dụng nguyên trạng kết quả cũ.

3. **Bảng chưa thực hiện vs chưa rõ có thực hiện — dòng 193–197.** Row196 nói “phần còn lại chưa thực hiện rõ” dễ đọc hai nghĩa. Chỉ tính còn được thực hiện 1 khi xác định chưa thực hiện và không có phần chờ/khác ảnh hưởng. Nhận 1 nhưng chưa rõ lệnh 1 còn lại đã gửi hay chưa: giữ unknown/pending, không chỉ phép trừ 2−1. Đối chiếu ngân quỹ đã chi và nhân viên thực nhận là hai việc, không dùng số bị trừ thay thực nhận.

4. **Sai người/sai loại không chỉ mismatch số — dòng 183, 198.** Một giao dịch 2 triệu gửi cho nhà cung cấp vé không phải A thực nhận ứng 2, dù cùng CT-DEMO-01 và tổng đúng. Người nhận, vai trò giao dịch và nguồn/công việc cần được xác định. Source contract cụ thể để R4, nhưng thêm case đổi beneficiary/type để tránh mô hình chỉ match amount+trip. Ghi tiền thật bị sai, không phân bổ cho A hoặc xóa khỏi lịch sử company.

5. **Nguồn cũ/pending rồi trả lời thiếu căn cứ — dòng 175–185, 194, 209.** Target đã có nguồn/mốc/rulebook. Cần trình bày đường một lời trả lời làm gì: lời xác nhận của người phụ trách được ghi thành source/human-confirmation với vai/phạm vi; chỉ trở thành fact đủ dùng nếu policy chấp nhận, không xóa flag nhờ role hoặc chữ “đã chi”. Không bắt mọi case employee screenshot/ledger mới mỗi lần nếu nguồn đã đủ. Không hứa chứng thực ngân hàng hoặc ảnh không bị giả mạo chỉ vì đọc được.

6. **Stop không xóa thực tế ngoài app — dòng 177.** Guard trước bước trong app là đúng, nhưng Stop sau handoff không chứng minh tiền ngoài app dừng. Sự kiện tiền đến muộn vẫn cần được ghi nhận/xác minh theo quyền; không dùng Stop để biến giao dịch đã xảy ra thành không có. Không đồng nhất việc ghi nhận fact sau Stop với cho phép chi mới. Chưa cần race/concurrency implementation ở R2.

Phạm vi MVP đề xuất: một người/một công việc/VND và nguồn phân bổ rõ, cùng lõi để ghi sự kiện đã xảy ra, pending cần đối chiếu và sai lệch. Không thành cổng ngân hàng/đối soát toàn công ty hoặc AI forensic mọi ảnh. Giao dịch gộp/chưa có quy tắc cần câu hỏi rõ hoặc xử lý ngoài phạm vi, không giả vờ tự khớp mọi trường hợp.

Phép thử thiết kế: thực nhận2; xác nhận chưa nhận0 vs nguồnthiếu; nhận1+phầnchờ1; nhận2 rồi hoàn1; ngân hàng trả lại trước nhận; sửa record nhập sai; nguồn mới sau báo cáo; trả vendor2 thay nhân viên2; cùngtransaction hai evidence vs hai transaction cùngamount; Stop trước/ sauhandoff. Không báo các phép thử này là PASS phần mềm.

# Review thiết kế — R2, Bước 5 chi và đối chiếu tiền thực nhận

Ngày: 08/10/2026. Verdict reviewer: **Có thể chốt ở mức walkthrough**. Verdict cuối của lead: **Cần chỉnh sửa**, giới hạn ở nghĩa sự kiện tiền/đầu ra bàn giao sang quyết toán; giữ bộ khung B5.

Target: [walkthrough](../../discovery/R2_CASE_WALKTHROUGH.md), Mục 2.5, dòng 167–213; [snapshot bất biến](TARGET_R2_CASE_WALKTHROUGH.md). B4 được chỉnh theo đồng ý của chủ dự án trước khi viết B5; B5 giữ nguyên trong lượt review. Không đọc code, chạy pipeline/test, chuyển tiền hoặc xác thực policy/quyền/nguồn tài chính thật.

## 1. Phương pháp và nguồn

- Reviewer độc lập `chatgpt-web/gpt-5.6-sol`, **High**, Mill, ID `01a11bfb-04eb-7021-80d5-b37253e2c34b`; context không fork history, không đọc lead notes/review các bước trước. Hoàn thành một lượt, đã đóng. [Bản trả lời](REVIEWER.md) và [evidence](review-evidence.json) được lưu.
- [Nhận xét riêng của lead](LEAD_PRE_REVIEW.md) được ghi/hash trước khi đọc reviewer. Hai người phân tích cùng thiết kế không phải hai chứng cứ vận hành hoặc thử người dùng thật.
- [Brief gốc](../../Challenge_Brief_OrganizationAI_VN.docx.md), Mục 2.A, vẫn là yêu cầu cuộc thi. Boundary routine tự động vs human financial checkpoint chưa được BTC xác nhận; review này không biến nó thành đã đạt.
- Nguồn tham khảo lead đã tìm và đọc: [UW Payment Options & Tracking](https://finance.uw.edu/travel/WDpaymentoptions), phần Payment Returns and Rejections nêu nhãn Paid/Reconciled có thể cùng xuất hiện với thông báo thanh toán bị trả/từ chối, không đủ xác định tiền đã vào tài khoản người nhận. Đây là ví dụ ở UW/Workday, không phải quy tắc ngân hàng Việt Nam hoặc source contract đã kích hoạt cho MVP.

## 2. Ledger — reviewer và phán định của lead

| ID / mức reviewer | Reviewer nêu | Phán định độc lập của lead | Sửa/phép thử tối thiểu |
| --- | --- | --- | --- |
| S5-R01 / Vừa | Dòng 193–203 chưa gom các nghĩa approved/received/in-flight-or-blocked/executable thành cách hiểu nhất quán. | Đồng ý cần từ điển tiền; không dùng một công thức trừ cho mọi chuỗi. In-flight là sự kiện/phần tiền, blocked có thể là điều kiện chưa rõ cho cả phần xử lý, không nhất thiết có một số tiền xác định. Actual received và được phép chi tiếp khác nhau. | Duyệt 2, nhận 1, lệnh 1 chờ: không cho thực hiện thêm cho cùng phần. Lệnh đó xác định failed chỉ cho đánh giá lại, không tự mở quyền chi. Số còn được cấp có thể chưa xác định dù việc cho chi tiếp bị chặn. |
| S5-R02 / Vừa | Dòng 177, 198–201 cần rõ outcome khi chuyển sai người hoặc vượt mức. | Đồng ý block sự cố và giữ actual outflow. Phản biện ví dụ reviewer: gửi nhầm 2 cho B chưa tự chứng minh A_received=0 nếu nguồn không bao phủ việc A có nhận qua giao dịch khác. Chỉ ghi 0 khi đủ nguồn xác định A không nhận. | Duyệt cho A, chi sang B: ghi tiền công ty đã chi sai và không phân bổ thành ứng A. Chưa tự cho chi mới cho A kể cả xác định A chưa nhận; người phụ trách phải xử lý sự cố/quyền hiện áp dụng. Nhận vượt duyệt ghi đúng số thực tế và flag, không clip. |
| S5-R03 / Vừa | Dòng 201 cần tiêu chuẩn nhận diện giao dịch theo nguồn ở R4. | Đồng ý, đây không phải thiếu schema/code ở R2. Phản biện cách lấy ID: ID khác nhau trong hai hệ thống có thể mô tả cùng một giao dịch; ID giống nhau ngoài phạm vi phát hành cũng chưa đủ là cùng giao dịch. | Một transfer có bank reference và finance record ID khác nhau vẫn có thể là 1 event/2 evidence khi quan hệ đủ rõ. Hai transaction IDs độc lập trong cùng namespace được nguồn xác nhận là khác thì giữ riêng. Cùng amount/date không tự gộp; ID ambiguous cần xác minh. |
| S5-R04 / Nhỏ | Dòng 195, 199–205 cần completion as-of/version và sự kiện đến sau. | Đồng ý. Khi ảnh hưởng kết quả quyết toán đã phát hành, mức của lead là Vừa vì có thể đổi tiền, không chỉ wording. Target đã giữ history; cần nói ảnh hưởng tới báo cáo/quyết định phía sau. | Theo nguồn T1 đã nhận đủ 2; nguồn T2 thay đổi có căn cứ: ghi kết quả mới và kiểm tra downstream bị ảnh hưởng, không xóa kết quả T1 hoặc dùng báo cáo T1 như vẫn hiện hành. Không tự mở lại quyền chi. |

## 3. Điểm riêng của lead cần làm rõ trước khi bàn giao số tiền

### S5-L01 — Hoàn ứng, giao dịch bị trả và sửa dữ kiện không phải cùng một sự kiện

Target dòng 199/203 đã giữ sự kiện gốc và điều chỉnh riêng, nhưng đang nhắc chung “hoàn/đảo”. Cần ba phản ví dụ để tránh agent triển khai mọi trường hợp thành một số âm:

| Chuỗi nguồn xác định | Dữ kiện tiền cần giữ | Hệ quả theo giả định riêng |
| --- | --- | --- |
| A thực nhận 2, rồi hoàn cho công ty 1 | Đã nhận 2 và đã hoàn 1, có quan hệ/nguồn; phần ứng ròng cho đối chiếu là 1 | Nếu phần nhân viên thanh toán đủ điều kiện 5 và không có chi/thu khác ảnh hưởng, đề xuất công ty trả thêm 4. Có thể tính 5−2+1 hoặc 5−(2−1), không vừa net ứng vừa cộng hoàn lần nữa. |
| Lệnh 2 bị trả trước khi A nhận, đủ nguồn xác định A không nhận khoản ứng khác | Giữ attempt/tiền bên công ty và việc bị trả; A thực nhận 0 có căn cứ | Với chi nhân viên đủ điều kiện 5 và không có chi/thu khác ảnh hưởng, đề xuất trả thêm 5. Không tạo lịch sử A nhận 2 rồi hoàn 2 nếu thực tế không xảy ra. |
| Bản ghi 2 là nhập/trích sai, nguồn đủ xác định thực tế A nhận 1 | Giữ dữ kiện/phiên bản đã sửa và nguồn; fact hiện dùng là nhận 1 | Không tạo sự kiện A hoàn 1 chỉ để làm số dư đúng. Quyết toán dùng dữ kiện đã sửa và kiểm tra phần ảnh hưởng. |

Số trên là phép tính walkthrough với giả định công khai, chưa là gold/test/policy công ty. Không suy số 0 khi chỉ có notification ngân hàng/ledger thiếu phạm vi. Quan hệ khoản hoàn/đảo cần xác định đúng trước tính; không coi tiền hoàn nhà cung cấp là hoàn ứng của A.

### S5-L02 — Đầu ra B5 là gói tiền có căn cứ, không chỉ một ô “đã nhận”

Gói bàn giao đề xuất gồm: quyết định/số được duyệt; các sự kiện chi/nhận/phần chờ có nguồn và phân bổ; hoàn/điều chỉnh đúng loại; phần chưa rõ/vấn đề; phiên bản/mốc đối chiếu. Chỉ từ gói đó phần quyết toán mới chọn thành phần để tính. Giữ actual received không thay bằng số duyệt hoặc số tiền công ty bị trừ.

Khi có sự kiện/nguồn mới ảnh hưởng sau báo cáo/quyết định hoặc chi quyết toán, giữ history và kiểm tra kết quả liên quan; không sửa ngầm báo cáo cũ hoặc giả vờ thu hồi được tiền đã trả. B5 không đóng công việc chỉ vì cấp đủ ứng; Stop/thu hồi không làm mất khả năng ghi/xác minh tiền đã xảy ra theo quyền, nhưng không cho phép chi mới.

## 4. Phạm vi và thứ tự tiếp tục đề xuất

Lead đồng ý reviewer rằng khung B5 đủ tốt để giữ: trước chi kiểm tra quyền/điều kiện/tiền liên quan; người chi bên ngoài; hệ thống đọc/đối chiếu nguồn; pending/failure/partial/overpayment không thành paid chắc chắn; tiền thật không bị xóa hoặc clip; không bắt nhân viên xác nhận/sao kê cho mọi phương thức.

Khác biệt verdict: reviewer xem các điểm mở là làm rõ contract trước R4 và cho chốt walkthrough. Lead muốn thêm ba chuỗi số ở S5-L01 cùng gói bàn giao S5-L02 trước khi coi đầu ra tiền đủ rõ để đi sâu quyết toán. Không yêu cầu schema/API/bank integration hoặc đóng mọi nguồn R4 ngay tại R2.

Đề xuất chỉnh nhỏ: tách nghĩa event và trạng thái xác minh; thêm bảng approved/received/pending/cho đi tiếp có điều kiện thay cho một công thức toàn cục; bổ sung ba phản ví dụ trên và quan hệ phiên bản báo cáo. Sau khi chủ dự án đồng ý mới cập nhật B5, giữ snapshot được review.

Phạm vi MVP: một nhân viên/một công việc/VND với nguồn đã cung cấp và phân bổ rõ; gặp giao dịch gộp/sự cố ngoài quy tắc thì ghi và hỏi/chuyển đúng nơi. Chưa xây cổng ngân hàng, đối soát toàn công ty hoặc xác thực pháp chứng mọi ảnh. Đo cả công sức nhập/tập hợp nguồn và các câu hỏi phát sinh, không chỉ tốc độ OCR.

Bản này chỉ là review thiết kế. Không có runtime test, giao dịch thật, trial người dùng hoặc chứng nhận đạt cuộc thi.

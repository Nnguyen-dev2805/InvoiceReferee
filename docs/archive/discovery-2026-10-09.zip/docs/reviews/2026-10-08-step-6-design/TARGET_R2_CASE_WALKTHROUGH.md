# R2 — Đi một hồ sơ công tác bằng tay

Ngày: 08/10/2026 · Trạng thái: **WALKTHROUGH GIẢ LẬP ĐỂ THẢO LUẬN**.

Căn cứ: [khung R1](../DISCOVERY_ROADMAP.md). Không đọc/chạy/sửa code; không có thử người dùng hay dữ liệu doanh nghiệp thật. R2 cần phân biệt quy trình khả dĩ từ research với hiện trạng thực đo. Case này làm rõ công việc và phụ thuộc trước khi thiết kế rulebook/gold.

## 1. Bối cảnh và giả định

Một nhân viên đi gặp khách hàng trong hai ngày. Công ty trả vé máy bay trực tiếp; nhân viên đề nghị ứng một phần cho khách sạn, ăn phục vụ công việc và di chuyển.

- Tất cả số tiền là VND; các vai/người/chứng từ dưới đây giả lập.
- Giả định chuyến đi, dự toán và các khoản đáp ứng quy định giả lập của case. Chưa đặt hạn mức/điều khoản thành policy thật.
- Giả định nguồn đủ rõ, liên kết đúng người/công việc và đủ điều kiện bằng chứng sẽ được rulebook định nghĩa. Không coi giả định đó là proof nguồn hay chất lượng OCR đã verified.
- Phạm vi tài chính được xác nhận đầy đủ tại mốc đối chiếu: không có khoản chi khác, hoàn tiền, hoàn trả trước đó hoặc giao dịch chờ ảnh hưởng kết quả, trừ biến thể ghi riêng.

## 2. Trước chuyến đi

| Bước | Vai thực hiện | Dữ liệu/căn cứ | Công việc và kết quả kỳ vọng |
| --- | --- | --- | --- |
| 1. Nộp đề nghị | Nhân viên | Mục đích, thời gian, dự toán phần nhân viên thanh toán 5 triệu; xin ứng 2 triệu. | Hệ thống kiểm tra thông tin để xem xét và vướng mắc ban đầu. Xin ứng 2 không có nghĩa đã nhận 2. |
| 2. Cho phép công tác | Người có quyền | Đề xuất và căn cứ công việc. | Ghi phạm vi công tác được phép. Nếu đã có quyết định bên ngoài đủ căn cứ, dùng quyết định đó, không xin phép lại. |
| 3. Kiểm tra ứng | Hệ thống, với nguồn người phụ trách cung cấp | Đề nghị, căn cứ công tác, quy định, lịch sử cần thiết. | Báo cáo kiểm tra đủ căn cứ theo giả định, hoặc câu hỏi nếu có vướng mắc. Không tự phê duyệt tiền. |
| 4. Duyệt ứng | Người có quyền tài chính | Báo cáo, dữ kiện, nguồn và quy định. | Trong case, duyệt 2 triệu. Nếu trả lại/từ chối thì đi nhánh tương ứng, không mặc định đã chi. |
| 5. Cấp và ghi nhận tiền | Người thực hiện chi/người phụ trách tài chính | Khoản ứng 2 triệu và căn cứ thực tế. | Ghi 2 triệu thực nhận, đúng nhân viên và công việc, không còn khoản ứng chờ xử lý. |

Các bước có thể do một người kiêm nhiều vai nhưng quyết định/nguồn vẫn khác nhau. Chi tiền diễn ra do con người, không phải hành động ngân hàng của InvoiceReferee.

### 2.1. Bước 1 — Nộp bằng form, đã chỉnh sau review

Chủ dự án đồng ý hướng chỉnh trong [review bước 1](../reviews/2026-10-08-step-1-design/REVIEW.md) và cho chuyển bước 2. Bản gốc review được giữ tại [snapshot](../reviews/2026-10-08-step-1-design/TARGET_R2_CASE_WALKTHROUGH.md); thay đổi dưới đây là thiết kế sau review, không phải code đã thực hiện.

Case giả lập được xem tại thời điểm lập đề nghị trước chuyến đi: nhân viên A (NV-DEMO-01), công việc CT-DEMO-01, đi Hà Nội ngày 05–06/10/2026 để trao đổi yêu cầu dự án giả lập với khách hàng KH-DEMO-01. Người nhận bước kế tiếp là Quản lý B, giả định có quyền xét công tác trong case; lựa chọn này không chứng minh quyền/danh tính công ty thật.

| Dữ kiện kế hoạch | Số tiền VND |
| --- | --- |
| Khách sạn + ăn phục vụ công việc + di chuyển, dự kiến nhân viên thanh toán | 3.000.000 + 1.000.000 + 1.000.000 = 5.000.000 |
| Vé, dự kiến công ty trả trực tiếp | 3.000.000 |
| Tổng dự toán trong case | 8.000.000 |
| Xin ứng | 2.000.000 |

Đủ thông tin để xem xét trong case nghĩa là biết người/công việc, địa điểm/ngày đi-về, mục đích có thể hiểu, các nghĩa tiền và vai/người nhận phù hợp. Định dạng/schema, tài liệu bắt buộc theo loại và ngưỡng policy vẫn chốt ở R4. Hệ thống nhận/lưu khai báo và nguồn, kiểm tra dữ liệu và phép cộng, ghi vấn đề thiếu/sai/mâu thuẫn. Không tự cắt tiền, không đối trừ 2 triệu khỏi dự toán để biến tổng thành 6 triệu.

Giữ hai nguồn khi form và giấy khác nhau; không overwrite. Nộp lại đúng đề nghị giữ một quan hệ hồ sơ với lịch sử/phiên bản. Cùng người/chuyến hoặc cùng tệp chưa đủ để gộp/từ chối, vì có thể là sửa, bổ sung nguồn hoặc đề nghị bổ sung theo policy; chưa rõ quan hệ thì hỏi.

Ba kết quả: **đã tiếp nhận nhưng cần bổ sung/làm rõ**; **đã tiếp nhận nhưng chưa xác định nơi xử lý**; hoặc **đủ thông tin ban đầu để chuyển tới người xét công tác**. Kết quả cuối chưa là đủ điều kiện ứng, công tác đã được phép, vé đã trả hay tiền đã nhận. Chưa có dữ liệu thực chi không tự thành ứng 0; không đòi hóa đơn sau chi hay phê duyệt chính đề nghị đang xin ở intake.

AI có thể đọc/đề xuất liên kết căn cứ có nguồn, báo mismatch; không sửa ngầm khai báo hoặc phê duyệt. Số học rõ dùng chương trình. Checkpoint cho phép công tác được trình bày là quyết định con người trong workflow; độ tự chủ vẫn phải chứng minh trên đơn vị công việc công bố trước, không chỉ bằng cách đổi nhãn metric.

### 2.2. Bước 2 — Xem xét và cho phép công tác, đã chỉnh sau review

Trạng thái: **ĐÃ THỐNG NHẤT HƯỚNG CHỈNH LOGIC; QUYỀN/POLICY CHI TIẾT CÒN Ở R4**.

Chủ dự án đồng ý các đề xuất trong [review bước 2](../reviews/2026-10-08-step-2-design/REVIEW.md) và yêu cầu chuyển bước tiếp theo. [Snapshot được review](../reviews/2026-10-08-step-2-design/TARGET_R2_CASE_WALKTHROUGH.md) giữ nguyên; nội dung dưới đây là thiết kế sau review, không phải implementation đã verified.

Quản lý B nhận đề nghị đã đủ dữ kiện ban đầu, dự toán tổng 8 triệu với các phần tách riêng, xin ứng 2 triệu và căn cứ kèm nếu có. Nhiệm vụ là quyết định công việc có được phép thực hiện, với phạm vi nào; không xác nhận đã cấp ứng hoặc mặc nhiên duyệt khoản ứng 2 triệu.

| Kết quả | Ví dụ trong case | Bước tiếp theo |
| --- | --- | --- |
| Cho phép đúng phạm vi đã đề nghị | Đồng ý A gặp KH-DEMO-01 tại Hà Nội ngày 05–06/10. | Ghi quyết định/phạm vi/nguồn, chuyển kiểm tra đề nghị ứng ở bước 3. |
| Cho phép trong phạm vi/điều kiện xác định | Cho phép ngày 05/10, không lưu trú. | Giữ nội dung đã cho phép; nhân viên sửa đề nghị và hệ thống kiểm tra phần bị ảnh hưởng. Nếu bản sửa đáp ứng phạm vi/điều kiện và cách xác định đáp ứng được policy chấp nhận, ghi liên hệ với quyết định rồi đi tiếp, không mặc định phải xin phép lại. |
| Chưa quyết định, cần bổ sung/xác minh | Cần lịch hẹn khách hàng rồi mới xem xét. | Hỏi rõ thông tin/nguồn/người trả lời, nhận bổ sung rồi chuyển người có quyền xem xét. Không coi yêu cầu bổ sung là đã cho phép. |
| Từ chối | Chuyến đi không được cho phép theo quyết định của người có quyền. | Lưu lý do, kết thúc đề nghị mới chưa chi. Tiền đã cấp từ trước nếu có được theo dõi/xử lý riêng, không bị xóa. |

Nguồn quyết định cần thể hiện ai/vai nào quyết định, thời điểm, phiên bản đề nghị, nội dung/phạm vi và điều kiện/lý do khi có. Không dùng riêng chữ “Approved” để suy toàn bộ ngân sách/khoản ứng đã duyệt. Nếu muốn có quyết định ngân sách tại đây phải nêu rõ và có đúng quyền; case thường quy đang đi chưa giả định bước này duyệt tiền.

Hệ thống chuẩn bị dữ kiện, chỉ rõ vướng mắc, chuyển đúng nơi và lưu quyết định. AI có thể hỗ trợ tóm tắt căn cứ nhưng không thay người quản lý quyết định chuyến đi đáng thực hiện. Căn cứ cho phép bên ngoài đủ theo policy được sử dụng, không thêm vòng xin phép lại; nếu nguồn/quyền/phạm vi chưa rõ thì xác minh, không tự đánh dấu được phép.

Người duyệt thấy đề nghị/phiên bản, mục đích/lịch trình, bốn nghĩa tiền 8/5/3/2 triệu, nguồn, mâu thuẫn và thay đổi cần chú ý, không chỉ AI summary. Quyền chưa rõ thì xác minh; sai người thì chuyển đúng người; vượt phạm vi quyền thì chuyển người có quyền tương ứng. Demo dùng ánh xạ vai/phạm vi công bố, chưa chứng minh quyền/danh tính công ty thật.

Sửa ghi chú không ảnh hưởng phạm vi không mặc định cần duyệt lại. Sửa đúng phạm vi một ngày/không lưu trú có thể dùng quyết định đã xác định sau kiểm tra; đổi địa điểm Hà Nội thành TP.HCM hoặc thêm ngày ngoài phạm vi cần xem xét phần thay đổi. Giữ phiên bản đã được xét, phạm vi quyết định, bản sửa và căn cứ tiếp tục sử dụng; không copy một boolean Approved sang mọi bản mới. Điều kiện mơ hồ như “đi nếu hợp lý” chưa đủ cho AI tự đánh dấu đáp ứng.

Chưa phản hồi không là đồng ý. Khi có căn cứ thu hồi/hủy hoặc hiệu lực chưa rõ, cập nhật phần liên quan và giữ lịch sử; không tự giả định biết mọi thay đổi ở nguồn bên ngoài. Hủy công việc/thu hồi phép không xóa sự kiện tiền đã cấp. Một người có thể kiêm vai và quyết định công tác/tài chính cùng lượt nếu có quyền và nội dung rõ, nhưng ghi tách ý nghĩa quyết định, không bắt buộc hai màn hình/chữ ký.

Đường thường quy đang theo: quản lý cho phép đúng đề nghị → lưu phạm vi → bước 3 kiểm tra ứng. Chưa có kết luận tiền được duyệt/đã nhận ở cuối bước 2. Quyền, điều kiện, nguồn và cách xác định hiệu lực chi tiết còn phải chốt trong rulebook.

### 2.3. Bước 3 — Kiểm tra đề nghị tạm ứng, đã chỉnh sau review

Trạng thái: **ĐÃ THỐNG NHẤT HƯỚNG CHỈNH LOGIC; POLICY, NGƯỠNG VÀ SOURCE CONTRACT CÒN Ở R4**.

Chủ dự án đồng ý hướng chỉnh trong [review bước 3](../reviews/2026-10-08-step-3-design/REVIEW.md) và yêu cầu chuyển bước 4. [Snapshot được review](../reviews/2026-10-08-step-3-design/TARGET_R2_CASE_WALKTHROUGH.md) giữ nguyên. Bản chỉnh chưa được review độc lập lại và không là kết quả pipeline đã verified.

Đơn vị công việc đề xuất: tự kiểm tra đề nghị ứng và chuẩn bị kết quả có căn cứ, hoặc hỏi đúng người về vướng mắc. Quyết định tài chính ở bước 4 và chi thực tế ở bước 5. Tách hai checkpoint đó khỏi câu hỏi phát sinh khi kiểm tra; vẫn phải chứng minh mức tự chủ đối với yêu cầu Challenge A trên đơn vị công việc công bố, không chỉ đổi tên metric.

Theo đường thường quy, công tác hai ngày đã được phép, phần dự kiến nhân viên thanh toán là 5 triệu, công ty trả vé dự kiến 3 triệu, xin ứng 2 triệu. Chưa có hóa đơn sau chuyến đi. Với walkthrough này giả định quy định giả lập cho phép khoản ứng 2 triệu, quyền xử lý rõ, lịch sử liên quan được cung cấp/xác nhận đủ và không có khoản ứng hay lệnh chi chờ cho cùng phần đề nghị. Đây là giả định để đi case, không phải policy công ty hoặc kết quả tìm kiếm không thấy giao dịch.

| Nhóm kiểm tra | Câu hỏi cụ thể | Nguồn/giới hạn |
| --- | --- | --- |
| Công việc và phép còn áp dụng | Đề nghị ứng có thuộc người/công việc và phạm vi đã được phép không? Có thay đổi/thu hồi đã biết ảnh hưởng không? | Quyết định và phiên bản/phạm vi; có mâu thuẫn thì chưa kết luận. |
| Số tiền và nhu cầu ứng | Xin ứng bao nhiêu, phục vụ phần nào nhân viên dự kiến chi? Dự toán/đề nghị có nhất quán theo quy định không? | Khai báo/dự toán được dùng đúng ý nghĩa; tổng 8 triệu không tự thành số được ứng. Không mặc định cấm ứng lớn hơn một phần dự toán nếu chưa có quy tắc. |
| Quy định áp dụng | Điều kiện, hạn mức, hạn quyết toán, nguồn bắt buộc nào thực sự áp dụng? | Policy giả lập có phiên bản/hiệu lực; chưa có quy tắc là thiếu phạm vi quy định, không để AI tự đặt mức. Chưa đòi hóa đơn hậu kiểm trước chuyến đi. |
| Quan hệ và lịch sử tài chính | Đề nghị mới, sửa hay bổ sung? Có ứng/lệnh chi chờ hoặc nghĩa vụ chưa xử lý nào liên quan theo policy? | Nguồn phụ trách tài chính cùng bằng chứng và phạm vi xác nhận; không coi thiếu nguồn là 0, không cấm mọi ứng mới chỉ vì có ứng chưa quyết toán. |
| Người có quyền xử lý tiền | Ai có quyền duyệt nội dung/giá trị này? | Bảng quyền demo/nguồn căn cứ. Quyền cho phép công tác không tự là quyền duyệt tiền. |

AI đề xuất dữ kiện, liên kết nguồn và nội dung câu hỏi khi cách diễn đạt khác nhau; kết quả phải kiểm tra được. Chương trình thực hiện số học, áp dụng quy tắc đã chốt và kiểm tra quyền; không sửa ngầm số xin ứng, tự đặt policy hay quyết định chi tiền.

Đầu ra đề xuất gồm bảng từng kiểm tra/căn cứ, số xin ứng và các nghĩa tiền, vấn đề chưa giải quyết, người nhận, phiên bản đầu vào/quy định và kết luận trong phạm vi kiểm tra:

- **Đủ căn cứ theo quy định:** các điều kiện bắt buộc áp dụng có căn cứ và đạt, không còn vướng mắc có thể thay đổi kết quả; chuẩn bị hồ sơ cho người có quyền duyệt ứng ở bước 4. Chưa là tiền đã duyệt/đã nhận. Thiếu field tùy chọn không ảnh hưởng không bắt hỏi; chưa rõ mức ảnh hưởng thì chưa được đánh dấu sẵn sàng.
- **Chưa rõ dữ kiện:** hỏi nguồn/người cụ thể và giữ phần đã kiểm tra. Khi nguồn đã có, tổng hợp giá trị/ref/mâu thuẫn trước khi hỏi; không bắt tài chính xác nhận lại lịch sử ở mọi hồ sơ. Khi nguồn thật sự chưa được cung cấp, yêu cầu đúng người cung cấp nguồn/phạm vi, không hứa câu trả lời sẽ không cần tra cứu thêm. Không hỏi nhân viên xác nhận thay nguồn chỉ tài chính nắm.
- **Cần sửa đề nghị:** nêu nội dung và căn cứ cần sửa; người nộp tạo bản mới khi đổi số tiền/phạm vi. Bổ sung fact/source không tự biến thành sửa yêu cầu. Xin ứng lớn hơn một phần dự toán không tự là vi phạm nếu chưa có quy tắc ràng buộc; không cắt tiền ngầm.
- **Ngoài phạm vi quy định:** nêu loại/điều kiện chưa được policy bao phủ, chuyển người phụ trách quy định; không dùng câu hỏi phê duyệt tiền để tự tạo quy tắc.
- **Vượt thẩm quyền:** nêu quyền còn thiếu và chuyển người có quyền tương ứng. Nếu chỉ gửi nhầm người và bảng quyền đã xác định nơi nhận đúng, tự điều phối theo bảng đó; không coi mọi sai routing là một câu hỏi bất định.
- **Không đủ điều kiện với căn cứ rõ, không có nhánh ngoại lệ áp dụng:** ghi kết luận không đủ điều kiện ứng/lý do/nguồn theo quy tắc. Kết luận trong phạm vi kiểm tra không tự hủy phép công tác hay xóa tiền đã cấp.
- **Lỗi kỹ thuật/dịch vụ không truy cập được:** báo chưa hoàn thành kiểm tra, giữ dữ kiện và retry khi phù hợp; không suy thành đủ điều kiện hoặc từ chối nghiệp vụ. Ảnh mờ dữ kiện bắt buộc là bất định fact, cần nguồn rõ/xác minh; OCR timeout không tự yêu cầu chụp lại ảnh tốt.

Một hồ sơ có thể có nhiều vấn đề; giữ từng vấn đề, nguồn và hành động, không để một label che phần chưa rõ. Có căn cứ đủ để kết luận vi phạm rõ thì không bắt làm rõ dữ kiện không ảnh hưởng kết luận đó, nhưng phải ghi chúng chưa được kiểm tra. Kết quả tổng thể không khẳng định phần bị nghi vấn.

#### Quan hệ đề nghị và trạng thái tiền

“Mới/sửa/bổ sung” là quan hệ giữa đề nghị; “đã duyệt/lệnh chờ/đã nhận” là trạng thái phê duyệt/chi. Hai trục có thể kết hợp, không gộp thành một enum loại trừ nhau.

| Quan hệ/trạng thái trong phạm vi nguồn đã xác định | Hành động ở Bước 3 |
| --- | --- |
| Đề nghị mới, chưa xử lý đúng phần này | Kiểm tra các điều kiện áp dụng, tới Bước 4 khi đủ căn cứ. |
| Sửa nội dung đề nghị trước | Giữ bản trước/bản mới và tiền đã xảy ra; kiểm tra phần ảnh hưởng, xác định quyết định nào còn áp dụng. Không tạo khoản chi mới chỉ vì nộp lại. |
| Bổ sung khoản ứng cho cùng công việc | Xác định phần xin thêm hoặc tổng mong muốn; kiểm tra quan hệ với phần đã duyệt/chi/chờ và quy tắc áp dụng, không tự coi cùng chuyến là duplicate. |
| Chính đề nghị đã được duyệt, chưa chi | Tiếp tục đúng đề nghị tới phần thực hiện chi nếu quyết định còn hiệu lực và không có thay đổi ảnh hưởng; không buộc xin duyệt lại chỉ vì nhập bản sao. |
| Có lệnh chi chờ hoặc trạng thái chưa rõ cho cùng phần | Đối chiếu trạng thái/nguồn trước khi tiếp tục; chưa coi đã thực nhận và không tạo lệnh mới cho cùng phần. |
| Đã trả đúng phần đang yêu cầu | Ghi phần đã xử lý cùng nguồn; không cấp lại. Nếu có thay đổi/bổ sung, xác định phần đó riêng, không cáo buộc gian lận từ file/trip giống nhau. |
| Quan hệ hoặc dữ liệu tài chính còn thiếu | Hỏi đúng người theo nguồn còn thiếu, giữ kiểm tra đã rõ; không suy số 0 hay tự gộp hồ sơ. |

Ví dụ đã nhận 2 triệu, bản mới ghi “xin ứng 3 triệu”: xin thêm 3 khác với muốn tổng thành 3. Trường hợp tổng thành 3 chỉ ra phần tăng 1 triệu khi các nguồn xác nhận không có phần chi/chờ/hoàn khác ảnh hưởng và policy cho cách xử lý đó. Nghĩa chưa rõ thì hỏi người nộp; sự kiện tiền dựa nguồn tài chính có căn cứ, không chỉ tự khai của nhân viên.

Câu trả lời bổ sung được ghi cùng nguồn/phạm vi, kiểm tra lại phần ảnh hưởng rồi phát hành kết quả mới. Báo cáo gắn phiên bản đề nghị/quy định và mốc dữ liệu tài chính. Có thay đổi sau kiểm tra thì không dùng báo cáo cũ như bảo đảm trước duyệt/chi; kiểm tra phần ảnh hưởng. Chỉ bảo đảm trong dữ liệu được cung cấp/kiểm soát, không giả vờ biết giao dịch ngoài hệ thống chưa được cung cấp.

Phép thử thiết kế chưa chạy phần mềm: routine đủ nguồn không hỏi; tổng ứng vs xin thêm; đã duyệt-chưa chi; lệnh chi chờ; cùng phần đã trả; bổ sung hợp lệ; policy gap vs cấm rõ vs sai route vs vượt quyền; thiếu fact bắt buộc vs ghi chú tùy chọn; ảnh mờ vs OCR timeout; trả lời fact vs sửa amount; nguồn đổi sau kiểm tra. Gold/source contract/ngưỡng sẽ chốt trước khi chuyển thành bộ test.

Giữ rủi ro Challenge A chưa xác minh: routine hoàn tất kiểm tra tự động nhưng vẫn có checkpoint duyệt tài chính. Công bố task/output, đo câu hỏi phát sinh, checkpoint cố định và tổng công sức con người; chưa coi đổi nhãn hoặc 3 routine/2 escalation ở một task là chứng minh BTC chấp nhận toàn bộ boundary.

### 2.4. Bước 4 — Quyết định khoản ứng, đã chỉnh sau review

Trạng thái: **ĐÃ THỐNG NHẤT HƯỚNG CHỈNH LOGIC; QUYỀN, POLICY VÀ SOURCE CONTRACT CHI TIẾT CÒN Ở R4**.

Chủ dự án đồng ý hướng chỉnh trong [review bước 4](../reviews/2026-10-08-step-4-design/REVIEW.md) và yêu cầu sang Bước 5. [Snapshot được review](../reviews/2026-10-08-step-4-design/TARGET_R2_CASE_WALKTHROUGH.md) giữ nguyên. Bản chỉnh chưa được review độc lập lại và không là kiểm chứng runtime.

Đi đường thường quy: đề nghị mới xin 2 triệu đã qua kiểm tra Bước 3, chưa có khoản duyệt/chi/chờ cho cùng phần theo nguồn giả định. Người duyệt C giả định có quyền quyết định khoản ứng này. C nhận hồ sơ và quyết định có cấp ứng không, số được duyệt và điều kiện/phạm vi nào; không xác nhận tiền đã chuyển, không mặc nhiên chấp nhận toàn bộ chi phí sau chuyến đi.

Gói rà soát có người/công việc/phạm vi công tác, số xin ứng 2 triệu cùng các nghĩa dự toán 8/5/3 triệu, quan hệ đề nghị, kết quả từng kiểm tra/nguồn, quy định áp dụng, lịch sử ứng/lệnh chi liên quan, phiên bản/mốc kiểm tra và những thay đổi cần chú ý. Người duyệt có thể mở mọi nguồn; không phải tự tìm/ghép từ đầu. Hệ thống không giả định biết mọi yếu tố quyết định ngân quỹ ngoài dữ liệu được cung cấp.

| Quyết định hoặc yêu cầu của người có quyền | Kết quả và đường tiếp theo đề xuất |
| --- | --- |
| Duyệt đúng 2 triệu đang xin | Ghi quyết định cụ thể và kiểm tra điều kiện còn áp dụng; sang Bước 5 thực hiện chi. Chưa ghi đã chi/thực nhận. |
| Duyệt 1,5 triệu như quyết định cuối, nếu quyền/policy cho phép duyệt khác số xin | Giữ số xin 2 triệu và số duyệt 1,5 triệu, lý do/phạm vi riêng; ghi việc xét đề nghị hiện tại kết thúc với mức này. Phần chênh 0,5 triệu không tự thành khoản chờ chi; xin thêm cần đề nghị bổ sung có liên kết và kiểm tra. Kiểm tra phần ảnh hưởng trước khi quyết định đủ điều kiện sử dụng. Việc có cần nhân viên xác nhận hoặc bản sửa theo policy, không tự thêm/bỏ bước. Không sửa yêu cầu cũ thành 1,5 triệu. |
| Đề nghị nhân viên sửa thành 1,5 triệu rồi mới xét | Chưa có quyết định chi cuối. Trả lại với nội dung/căn cứ cần sửa; nhận bản mới và kiểm tra phần ảnh hưởng trước khi xét tiếp. |
| Phát hiện số tiền/nguồn/lịch sử còn mâu thuẫn | Ghi vấn đề cụ thể; trở lại kiểm tra phần ảnh hưởng ở Bước 3, bổ sung từ đúng người khi cần. Không dùng nút Approve để xóa uncertainty. |
| Từ chối cấp ứng | Lưu quyết định/lý do, kết thúc việc cấp mới của đề nghị này. Không tự hủy công tác hay xóa khoản ứng đã cấp trong lịch sử. |
| Chưa phản hồi hoặc quyết định chưa đủ rõ | Giữ chờ; không suy đồng ý. “1,5 triệu” đơn độc chưa thể suy là đã duyệt hay yêu cầu sửa. |

“Duyệt có điều kiện” cần nội dung rõ, người có quyền và cách chứng minh điều kiện; ghi quyết định cùng điều kiện, chỉ sang thực hiện chi khi điều kiện tiền chi được đáp ứng. Điều kiện không xác định được thì làm rõ. Không dùng conditional approval để cho qua dữ kiện bắt buộc chưa xác minh, phép tính sai hoặc vi phạm không có ngoại lệ.

Mỗi điều kiện nêu fact cần chứng minh, nguồn/vai có quyền xác nhận và cách xác định đạt theo policy. Có căn cứ đáp ứng bằng cách kiểm tra đã quy định thì đi tiếp, không mặc định phải xin duyệt lại. Chưa rõ hoặc nguồn mơ hồ/sai phạm vi thì giữ chờ. Ghi nội dung người duyệt đề xuất khác với chấp nhận thành quyết định có thể dùng: số mới phải được kiểm tra số/quyền/quy tắc trước khi đủ để chi.

Nếu người duyệt muốn tăng số được cấp hoặc đổi công việc/phạm vi, ghi rõ nội dung và kiểm tra lại phần liên quan tới đề nghị/quy định/quyền/căn cứ trước khi tạo quyết định có thể sử dụng. Không coi quyền duyệt tiền là quyền tự viết lại khai báo. Mọi cơ chế ngoại lệ chỉ áp dụng khi policy cho phép và đúng người quyết định; giữ kết quả kiểm tra gốc cùng quyết định ngoại lệ, không xóa hard gates về dữ kiện/số học.

Ghi ai/vai/phạm vi quyền, thời điểm, đề nghị/phiên bản đã xét, phiên bản báo cáo và nguồn, số xin/số duyệt, nội dung, lý do và điều kiện khi có. Trước khi nhận quyết định cho bước chi, kiểm tra phiên bản/quyền còn áp dụng và thay đổi liên quan đã biết. Bản báo cáo cũ hoặc chọn vai demo không chứng minh quyết định hợp lệ ngoài công ty giả lập.

Nếu đã có quyết định tài chính bên ngoài đủ nguồn, quyền, phạm vi và hiệu lực theo policy, dùng quyết định đó; nhập hồ sơ không tự tạo một yêu cầu duyệt/chi mới. Quyết định thu hồi/thay đổi về sau phải giữ lịch sử; nếu tiền đã chi, xử lý nghĩa vụ phát sinh riêng, không biến giao dịch thật thành chưa từng xảy ra.

Hai quyết định cùng phạm vi mà trái nhau cần xác định quan hệ thay thế/quyền/hiệu lực; chưa rõ thì giữ cả hai nguồn và hỏi đúng người, không tự lấy mới nhất, ưu tiên trong app hoặc cộng số được duyệt. Trước chi phải xét cả lịch sử chi/lệnh chờ liên quan đã được cung cấp; quyết định duyệt 2 triệu không tạo quyền chi lại 2 triệu mỗi lần mở hồ sơ. Thay đổi vô hại không mặc định buộc duyệt lại; thay đổi ảnh hưởng phải kiểm tra phần tương ứng.

Thu hồi trước chi chặn sử dụng tiếp quyết định trong workflow. Thu hồi khi có lệnh bên ngoài chờ cần xử lý/đối chiếu kết quả thực tế; app không tự ghi đã hủy lệnh ngân hàng. Thu hồi sau chi một phần giữ tiền đã xảy ra, chặn thực hiện phần còn lại trong workflow và xử lý nghĩa vụ phát sinh riêng theo policy. Không tự tạo sự kiện hoàn tiền từ thao tác thu hồi.

Hệ thống chuẩn bị context, lưu quyết định và kiểm tra tính áp dụng; AI hỗ trợ đọc/tóm tắt có nguồn nhưng không suy quyết định từ câu mơ hồ hoặc thay người chịu trách nhiệm tài chính. Chương trình kiểm tra số/quyền/quy tắc; con người đưa ra quyết định trong quyền được giao. Ý định cấp ứng không chứng minh các chi phí thực tế sau này đủ điều kiện hoàn trả.

Đường thường quy giả lập: C duyệt 2 triệu rõ ràng, đúng quyền, đúng phiên bản/phạm vi và không còn điều kiện cản thực hiện → ghi **được duyệt 2 triệu, chưa chi** → Bước 5. Phép thử thiết kế đề xuất: đúng số; duyệt số thấp hơn vs yêu cầu sửa; phát hiện mismatch; từ chối; im lặng; điều kiện chưa đạt; wrong authority; bản cũ sau revision; quyết định bên ngoài đã có; thu hồi sau đã chi. Đây chưa là test pipeline hoặc policy kích hoạt.

### 2.5. Bước 5 — Chi và đối chiếu thực nhận, đã chỉnh sau review

Trạng thái: **ĐÃ ĐƯỢC CHỦ DỰ ÁN DUYỆT Ở MỨC WALKTHROUGH; SOURCE CONTRACT, QUYỀN VÀ POLICY CHI TIẾT CÒN Ở R4**.

Chủ dự án trả lời “Tôi duyệt Bước 5, tiếp tục đi” sau [review bước 5](../reviews/2026-10-08-step-5-design/REVIEW.md). Nội dung dưới đây đã bổ sung các điểm được thống nhất; [snapshot được review](../reviews/2026-10-08-step-5-design/TARGET_R2_CASE_WALKTHROUGH.md) và verdict gốc giữ nguyên. Chưa có review độc lập lại bản chỉnh hoặc runtime verification.

Mục tiêu: nối quyết định cấp ứng với những sự kiện tiền thực tế có căn cứ, để bước quyết toán sử dụng đúng số nhân viên đã nhận. Con người thực hiện chi tiền bên ngoài; InvoiceReferee chuẩn bị thông tin, kiểm tra quyền/điều kiện dùng quyết định trong workflow, đọc và đối chiếu nguồn cung cấp, lưu kết quả. Không gửi lệnh ngân hàng, bảo đảm giao dịch ngân hàng hoặc tự thực hiện thu hồi tiền.

#### Trước khi người thực hiện chi hành động

Case thường quy giả lập: quyết định hiện áp dụng cho NV-DEMO-01/CT-DEMO-01 duyệt 2 triệu, điều kiện đủ, chưa có phần chi/lệnh chờ ảnh hưởng theo nguồn đã xác định. Gói thực hiện có người nhận/công việc, số được duyệt và phần còn được thực hiện trong phạm vi, quyết định/phiên bản/điều kiện, nguồn tài chính và mốc kiểm tra. Người thực hiện chi giả định có quyền phù hợp; nếu không có thì điều phối đúng người, không dùng chọn vai demo làm bằng chứng quyền thực tế.

Trước khi cho đi tiếp trong app, kiểm tra các thay đổi ảnh hưởng, quyết định áp dụng, phần đã chi hoặc đang chờ và điều kiện/Stop/thu hồi đã biết. Có sai lệch hoặc nguồn chưa rõ thì dừng phần liên quan để đối chiếu, không tạo thêm phần thực hiện cho cùng nghĩa vụ. Các hành động trong app chỉ có hiệu lực trong workflow/dữ liệu được quản lý; tiền đã hoặc đang xử lý ở ngoài phải được con người xác minh, không giả vờ app kiểm soát được.

#### Thực hiện và nguồn đối chiếu

Người phụ trách tài chính chi bằng phương thức được policy cho phép, sau đó cung cấp bản ghi/sự kiện thực tế và căn cứ liên quan. Nhân viên có thể cung cấp bằng chứng nhận tiền khi có; không mặc định mọi giao dịch đều cần nhân viên xác nhận thêm nếu nguồn đã đủ theo rulebook. Tách người khai báo, raw evidence, dữ kiện trích xuất và kết quả đối chiếu; vai tài chính hoặc một nút “đã chi” đơn độc không đủ thay bằng chứng.

Ví dụ nguồn ứng viên, chưa là quy định pháp lý hay source contract đã kích hoạt: chuyển khoản có bản ghi giao dịch/trạng thái kết quả và căn cứ đúng người nhận; tiền mặt có bản ghi quỹ/chứng từ giao nhận phù hợp. Không bắt sao kê ngân hàng cho giao tiền mặt. Căn cứ phải xác định số tiền, người nhận, quan hệ với quyết định/công việc, thời điểm và tình trạng; giao dịch không đúng người hoặc chưa rõ quan hệ không được tự phân bổ vào khoản ứng của A.

Một bản ghi công ty đã lập lệnh hoặc bị trừ tiền chưa tự chứng minh A đã nhận đúng khoản. Dữ liệu có nguồn đủ điều kiện nào được công nhận là thực nhận phải do rulebook định nghĩa, không để AI tự quyết định từ một nhãn SUCCESS/PAID. Không suy ngày duyệt là ngày nhận tiền.

MVP đi đường một nhân viên/một công việc với giao dịch rõ; có thể ghi nhận nhiều sự kiện đã xảy ra để xử lý phần chi/nguồn trùng. Nếu một giao dịch gộp nhiều người/công việc hoặc quan hệ chưa rõ, lưu nguồn và phần đã xác định, yêu cầu phân bổ có căn cứ; chưa hứa tự phân bổ mọi giao dịch gộp.

#### Các kết quả và đường xử lý

| Sự kiện có căn cứ trong phạm vi | Hệ thống ghi nhận/đi tiếp |
| --- | --- |
| Được duyệt nhưng chưa thực hiện chi | Giữ quyết định và trạng thái chưa thực hiện. Chưa ghi thực nhận 2 triệu; không suy đã nhận hay số 0 từ thiếu nguồn. |
| Đã lập/thực hiện lệnh nhưng còn chờ hoặc chưa rõ kết quả | Giữ nguồn/lệnh và phần đang chờ; hỏi người phụ trách xác minh trạng thái khi cần. Chưa cộng thành thực nhận và chưa tạo thực hiện mới cho cùng phần. |
| Xác định nhân viên thực nhận đủ 2 triệu, đúng người/công việc | Ghi sự kiện thực nhận 2 triệu cùng nguồn/phân bổ và quyết định liên quan; chuyển theo dõi quyết toán. Việc cấp ứng hoàn tất trong case, hồ sơ công việc chưa đóng. |
| Thực nhận 1 triệu, nguồn xác định phần còn lại chưa thực hiện và không có phần chờ ảnh hưởng, quyết định vẫn áp dụng | Giữ 1 triệu đã nhận và phần chưa thực hiện. Chỉ còn 1 triệu được thực hiện tiếp trong giả định không có chi/hoàn/thay đổi khác ảnh hưởng; không cấp lại toàn bộ 2. Nhận 1 nhưng chưa rõ lệnh phần còn lại đã gửi hay chưa thì giữ unknown, không tự dùng phép trừ để cho chi tiếp. |
| Thực hiện thất bại/hủy với căn cứ đủ rõ về tiền liên quan | Giữ lần thực hiện và kết quả; đánh giá lại phần còn được thực hiện trước lần tiếp theo. Một nhãn lỗi chưa rõ tiền không tự chứng minh không chi/không nhận. App không tự hủy/retry chuyển khoản. |
| Sai người, sai số, không khớp công việc hoặc mâu thuẫn nguồn | Giữ sự kiện/raw source đã xảy ra và vấn đề, chuyển người phụ trách xử lý; không sửa quyết định, clip số thực chi về số duyệt hoặc tự nhận xét gian lận. |
| Có nguồn về hoàn lại/đảo giao dịch | Giữ sự kiện gốc và sự kiện điều chỉnh có nguồn/quan hệ riêng, kiểm tra phần ảnh hưởng. Hoàn/đảo không tự mở lại quyền chi cũ; không ghi đè lịch sử thực nhận thành chưa từng nhận. |

Cùng giao dịch được nhập lại qua hai tệp/bản ghi chỉ là một sự kiện tiền khi có căn cứ nhận diện đúng quan hệ; giữ nguồn nhưng không cộng hai lần. Cùng số tiền/ngày/người nhận chưa đủ để gộp vì có thể là hai giao dịch khác nhau. Chưa rõ trùng hay riêng thì hỏi/đối chiếu, không chọn cách cộng/gộp thuận tiện. Sai lệch tiền thật, kể cả thực nhận vượt số duyệt, vẫn phải được ghi đúng có nguồn và xử lý vấn đề riêng; không loại bỏ/giảm dữ kiện để khớp phê duyệt.

Mã giao dịch ngân hàng và số bản ghi kế toán có thể khác nhau nhưng cùng mô tả một lần chi; ID giống nhau ngoài phạm vi phát hành cũng chưa đủ chứng minh một giao dịch. Tiêu chuẩn nhận diện theo từng nguồn/phạm vi chốt ở R4. Chuyển nhầm cho B giữ outflow thực tế và chặn phần liên quan để xử lý; không ghi A nhận 0 nếu chưa đủ nguồn xác định A không nhận qua giao dịch khác. Xác định A chưa nhận cũng không tự mở quyền chi mới sau sự cố.

Trạng thái chi, số đã thực nhận, phần chờ/chưa rõ, phần chưa thực hiện và các sự kiện hoàn/đảo được giữ riêng. Với nguồn đủ phạm vi có thể xác định chưa nhận ứng là 0; thiếu nguồn không tự là 0. Số lịch sử đã nhận và số dư sau hoàn là hai nghĩa khác nhau; quyết toán dùng các thành phần đã đối chiếu, không trừ hoàn ứng hai lần.

#### Nghĩa tiền và gói bàn giao quyết toán

Giữ riêng số được duyệt theo quyết định đang áp dụng, số thực nhận có nguồn, giao dịch/phần tiền đang chờ và điều kiện cho phép thực hiện tiếp. Một vướng mắc có thể chặn hồ sơ mà chưa xác định được số tiền; không gộp “bị chặn” thành một số để trừ trong công thức toàn cục.

| Chuỗi sự kiện giả lập có nguồn đủ phạm vi | Tiền đã nhận / phần chờ | Điều kiện thực hiện tiếp |
| --- | --- | --- |
| Duyệt 2, nhận 1, lệnh 1 còn chờ | Đã nhận 1; giữ riêng lệnh chờ 1 | Chưa thực hiện thêm cho cùng phần. |
| Duyệt 2, nhận 1, xác định chưa có lệnh/chi khác, quyết định còn áp dụng và điều kiện đủ | Đã nhận 1; không có phần chờ theo nguồn xác nhận | Có thể thực hiện phần còn lại 1; không dùng lại toàn bộ 2. |
| Đã nhận 1, trạng thái phần còn lại chưa rõ | Đã nhận 1; phần chưa rõ giữ unknown | Chưa cho thực hiện tiếp phần ảnh hưởng, không dùng thiếu nguồn thành 0. |

Gói bàn giao có quyết định/số được duyệt, các sự kiện chi/nhận và phân bổ có nguồn, phần chờ/chưa rõ, hoàn/điều chỉnh đúng loại, vấn đề còn lại và phiên bản/mốc đối chiếu. “Hoàn tất cấp ứng” là kết quả theo nguồn/mốc đó, chưa đóng hồ sơ công việc và không tự bảo đảm lịch sử tiền sẽ không thay đổi.

| Ba loại thay đổi phải phân biệt | Dữ kiện giữ / hệ quả giả lập |
| --- | --- |
| A nhận 2 triệu rồi hoàn cho công ty 1 triệu | Giữ đã nhận 2 và đã hoàn 1 cùng nguồn/quan hệ. Nếu chi nhân viên đủ điều kiện 5 và không có chi/thu khác ảnh hưởng, đề xuất trả thêm 4 = 5−2+1; không vừa dùng ứng ròng 1 vừa cộng hoàn 1 lần nữa. |
| Lệnh 2 bị trả trước khi A nhận, đủ nguồn xác định A không nhận khoản ứng khác | Giữ attempt và kết quả bị trả; thực nhận 0 có căn cứ. Với chi nhân viên đủ điều kiện 5 và không có chi/thu khác ảnh hưởng, đề xuất trả thêm 5. Không tạo lịch sử A nhận 2 rồi hoàn 2 nếu không xảy ra. |
| Bản ghi nhận 2 bị nhập/trích sai, nguồn đủ xác định thực tế nhận 1 | Giữ phiên bản/dữ kiện cũ và căn cứ sửa; fact hiện dùng là nhận 1. Không tạo sự kiện hoàn 1 để làm số dư đúng. |

Nguồn/sự kiện đến sau làm thay đổi kết quả đã phát hành thì giữ phiên bản trước, kiểm tra báo cáo/quyết định/chi quyết toán bị ảnh hưởng và xử lý nghĩa vụ còn lại có căn cứ. Không sửa âm thầm báo cáo đã duyệt, tự mở quyền chi hoặc giả vờ thu hồi được tiền đã trả. Stop/thu hồi không xóa việc ghi nhận/xác minh tiền đã xảy ra theo quyền, nhưng không cho phép chi mới.

Sau công việc hoặc khi hủy cần xử lý tiền, nhân viên nộp hồ sơ sau chi với những sự kiện tiền đã rõ. Không bắt phải nhận đủ toàn bộ số được duyệt mới được nộp hồ sơ sau chi. Nếu lệnh chờ/số chưa rõ có thể làm thay đổi kết quả quyết toán thì chưa chốt kết quả cuối; giữ phần đã xác minh và hỏi đúng người. Chi ứng đầy đủ cũng không tự chứng minh chi phí sau công việc hợp lệ hay không còn nghĩa vụ quyết toán.

#### Vai trò AI và giới hạn kiểm tra

AI đề xuất trích xuất/liên kết chứng từ với sự kiện, phát hiện mismatch và câu hỏi có ref; không sửa số hoặc tự xác nhận tiền đã nhận. Chương trình kiểm tra số học/quan hệ đã xác định, quy tắc/quyền và phiên bản; người có quyền cung cấp/xác minh fact trong phạm vi được policy chấp nhận. Nhầm OCR, ảnh mờ và lỗi dịch vụ có đường xử lý phù hợp; không khẳng định thực nhận khi dữ liệu bắt buộc còn nghi vấn.

Đường thường quy giả lập: C duyệt 2 → người tài chính thực hiện chi → nguồn đủ theo rulebook xác định A thực nhận 2 đúng CT-DEMO-01 → ghi 2 thực nhận, giữ căn cứ → sau công việc quyết toán. Đây là walkthrough, chưa có giao dịch thật hoặc provider integration.

Phép thử thiết kế đề xuất: đủ 2; duyệt nhưng chưa chi; chờ không rõ rồi xác định kết quả; nhận 1 và phần chưa thực hiện; chi thất bại đủ căn cứ vs báo lỗi tiền chưa rõ; nhận sai người/số; nhập trùng một giao dịch; hai giao dịch khác nhau cùng số; hoàn/đảo; nhận vượt duyệt; Stop/thu hồi khi lệnh ngoài đang xử lý; hồ sơ sau chi khi chỉ nhận một phần. Chưa chạy test/gold/Verify; nguồn tối thiểu và tham số policy sẽ chốt trước khi thực thi.

## 3. Sau chuyến đi: gói dữ liệu cần đối chiếu

| Khoản chi | Giá trị | Nguồn thanh toán trong case | Ai cung cấp nguồn ứng viên? |
| --- | --- | --- | --- |
| Vé máy bay | 3.000.000 | Công ty trả trực tiếp, đúng booking/chứng từ. | Người phụ trách tài chính cung cấp bản ghi và căn cứ; nhân viên có thể cung cấp vé. |
| Khách sạn | 3.000.000 | Nhân viên thanh toán. | Nhân viên cung cấp chứng từ và dấu vết thanh toán phù hợp. |
| Ăn phục vụ công việc | 1.000.000 | Nhân viên thanh toán. | Nhân viên cung cấp chứng từ/nội dung cần theo quy định giả lập. |
| Di chuyển | 1.000.000 | Nhân viên thanh toán. | Nhân viên cung cấp chứng từ và căn cứ liên quan. |

Bản ghi tài chính kèm theo: ứng thực nhận/phân bổ cho case 2 triệu; chưa có hoàn trả chi phí cho nhân viên, hoàn tiền hoặc khoản chi/thu khác ảnh hưởng. Dữ liệu “chưa có” ở đây là giả định đã được xác nhận đủ phạm vi, không phải kết quả tìm kiếm không thấy.

### 3.1. Bước 6 đang thảo luận — Nhân viên nộp hồ sơ quyết toán / hoàn trả chi phí

Trạng thái: **ĐỀ XUẤT WALKTHROUGH; NGUỒN TỐI THIỂU, QUY ĐỊNH VÀ SCHEMA CHI TIẾT CÒN Ở R4**.

Bước 6 tiếp nhận lời khai/bảng kê và chứng từ sau công việc hoặc khi hủy cần xử lý tiền, xác định quan hệ với công việc và các khoản ứng/lịch sử đã có. Bước 7 mới đối chiếu nội dung, policy, người trả/phần tiền và tính kết quả; người có quyền quyết định tài chính sau đó. Tiếp nhận hồ sơ không chứng minh khoản chi hợp lệ hay số đề nghị đã được duyệt.

Đường thường quy: A nộp hồ sơ CT-DEMO-01. Bảng kê có vé 3 triệu, khách sạn 3 triệu, ăn phục vụ công việc 1 triệu, di chuyển 1 triệu; tổng chi phí khai báo 8 triệu. Trong walkthrough A khai công ty trả vé 3 triệu, A trả phần còn lại 5 triệu. Nguồn B5 xác định A đã nhận ứng 2 triệu; nguồn tài chính xác định công ty trả vé 3 triệu và không có chi/thu/lệnh chờ khác ảnh hưởng trong phạm vi. Đây là giả định cho case; tổng 8 chưa là chi phí được chấp nhận hoặc số công ty phải hoàn.

Đề xuất hai cách nộp dùng cùng lõi hồ sơ: form/bảng kê chính và tải chứng từ; hoặc nhập bảng kê/đề nghị đã lập ở ngoài rồi xác nhận phần trích xuất cần dùng. Nhập bản có sẵn không tự tạo hồ sơ/nghĩa vụ mới khi chỉ là bổ sung hoặc sửa hồ sơ đang xử lý. Không âm thầm sửa lời khai khi giấy/form khác nhau; giữ nguồn và làm rõ quan hệ/phiên bản.

| Nhóm thông tin | Người/nguồn cung cấp và ý nghĩa |
| --- | --- |
| Người/công việc, thời gian, mục đích và việc hoàn thành/hủy/thay đổi | Nhân viên khai, tham chiếu hồ sơ công tác nếu có. Chi tiết thay đổi có nguồn khi quy định yêu cầu, không dùng thời điểm chụp ảnh làm ngày chi/công tác. |
| Các khoản chi thực tế khai báo | Nội dung, số tiền/ngày đã biết, mục đích, người/phương thức trả theo khai báo và tài liệu liên quan. Chưa rõ giữ chưa rõ; không ép đoán số hoặc payer để nộp. |
| Chứng từ hỗ trợ | Nhân viên cung cấp hóa đơn/vé/bằng chứng phù hợp khoản chi và policy; một khoản có thể có nhiều nguồn. Một tài liệu có thể hỗ trợ nhiều dữ kiện; không coi mỗi file là một khoản chi độc lập. |
| Tạm ứng, công ty trả trực tiếp và lịch sử chi/thu liên quan | Dùng lại nguồn có căn cứ B5 hoặc dữ liệu tài chính được nhập/import theo phạm vi. Tài chính cung cấp nguồn còn thiếu; nhân viên có thể cung cấp bổ sung, nhưng lời tự khai không thay kết quả xác minh. Không bắt nhân viên nhập lại số đã biết để tạo bản thật mới. |
| Số tiền nhân viên đề nghị, nếu có trên đơn | Giữ riêng ý nghĩa của số đề nghị với tổng bảng kê, phần nhân viên khai trả và kết quả hệ thống sẽ tính. Không sửa số khai ngầm; không mặc định tổng hóa đơn là tiền phải hoàn. |

Căn cứ công tác/tiền đã có được dùng lại khi còn phù hợp. Một khoản chi khác lịch trình hoặc dự toán tạo vấn đề để kiểm tra theo policy; không tự coi lệch dự toán là bị cấm hoặc buộc xin phép lại mọi hóa đơn. Nguồn tối thiểu để từng khoản đi tiếp tùy quy định, không bắt mỗi hóa đơn luôn kèm sao kê ngân hàng.

Form chọn PERSONAL chỉ là lời khai. Nếu A khai trả vé 3 triệu trong khi có nguồn công ty trả, giữ cả hai và đánh dấu phần cần đối chiếu; không mặc định tin checkbox, cũng chưa tự kết luận cùng booking/nghĩa vụ chỉ vì tên/amount giống nhau. Việc khớp đúng khoản/phần và xác định có chi trả trước thuộc Bước 7.

Hệ thống nhận/lưu bản gốc, lời khai, nguồn tài chính và quan hệ/phiên bản; kiểm tra cấu trúc/thông tin để bắt đầu đối chiếu, phép cộng các số khai rõ và những thiếu/mâu thuẫn hiển nhiên. AI hỗ trợ đọc/phân loại/đề xuất liên kết có nguồn; không tự xác nhận payer, chất lượng số, tính hợp lệ hoặc chuyển số thiếu thành 0. Đề nghị sửa một khoản tạo bản mới với lịch sử; thêm chứng từ không tự làm chi phí tăng.

Ba kết quả tiếp nhận đề xuất: **đã nhận, cần nhân viên sửa/bổ sung phần cụ thể**; **đã nhận, thiếu nguồn do tài chính/người khác cung cấp**; hoặc **đủ thông tin ban đầu để bắt đầu đối chiếu ở Bước 7**. Giữ phần đã có để xử lý, câu hỏi có khoản/nguồn/người cần trả lời. Đây không là ba label loại trừ nhau cho mọi vấn đề: một hồ sơ có thể có nhiều thiếu sót và nhiều chủ sở hữu nguồn. Lỗi tải/đọc nguồn không biến thành vi phạm nghiệp vụ.

Không ứng nộp trực tiếp cùng lõi sau chi: số ứng 0 chỉ khi có căn cứ không nhận; chưa rõ vẫn giữ unknown. Không bắt có một đề nghị ứng hoặc nhận đủ tiền trước khi nộp. Khi hủy công việc cũng tiếp nhận chi phí/tiền đã xảy ra để xử lý; không tự yêu cầu hoàn toàn bộ ứng mà chưa xét chi phí và nguồn liên quan.

Điểm ra Bước 6 là hồ sơ có các khoản khai báo liên kết nguồn ứng viên, nguồn tiền/lịch sử trong phạm vi hoặc vấn đề cần bổ sung, đúng quan hệ/phiên bản để Bước 7 kiểm tra. Case thường quy sẽ dùng phần nhân viên khai trả 5 triệu, nguồn ứng thực nhận 2 triệu và vé công ty trả 3 triệu; số đề xuất 3 triệu chỉ có thể chốt ở Bước 7 khi khoản chi/nguồn và các điều kiện đã được xác minh theo giả định.

Phép thử thiết kế chưa chạy pipeline: đúng case 8/5/3/2; A khai vé PERSONAL; một khoản nhiều chứng từ; một tài liệu/bản kê nhiều khoản; nộp lại vs bổ sung thật; tổng khai khác nguồn; ứng unknown vs xác nhận0; thiếu ảnh do nhân viên vs thiếu lịch sử tài chính; hủy công việc có chi phí; thay đổi sau hồ sơ đã xét. Source/gold/schema sẽ chốt trước khi thực thi.

## 4. Đi từng kiểm tra bằng tay

| Kiểm tra | Câu hỏi cần trả lời | Kết quả kỳ vọng theo giả định |
| --- | --- | --- |
| Công việc và phạm vi | Chứng từ/khoản chi có thuộc người/công việc/phạm vi đã được phép không? | Khớp. Không chỉ dựa vào tên file. |
| Chất lượng và nội dung | Các dữ kiện cần dùng có rõ, đủ và đúng nguồn không? | Đủ theo giả định; R4 mới chốt nguồn tối thiểu. |
| Quy định | Mục đích và khoản chi có đáp ứng rulebook không? | Đủ điều kiện trong case giả lập; không tự tạo quy định để khớp kết quả. |
| Liên kết thanh toán | Giao dịch thuộc khoản nào, đã trả bao nhiêu, có phần chưa rõ không? | Công ty 3 triệu vé; nhân viên 5 triệu phần còn lại. |
| Ứng | Số thực nhận là bao nhiêu và thuộc phạm vi nào? | 2 triệu, không dùng số xin ứng thay sự kiện tiền thật. |
| Lịch sử | Phần đang yêu cầu đã được xử lý, hoàn trả hay có giao dịch chờ chưa? | Chưa có theo phạm vi xác nhận; không bỏ qua kiểm tra vì hóa đơn mới. |
| Tính toán | Số còn cần chi/thu là gì? | Nhân viên thanh toán đủ điều kiện 5 triệu − ứng 2 triệu = đề xuất công ty trả thêm 3 triệu. |

## 5. Báo cáo và việc còn lại của con người

Báo cáo: chi phí đủ điều kiện đã đối chiếu 8 triệu; công ty trả trực tiếp 3 triệu; nhân viên thanh toán 5 triệu, đã nhận ứng 2 triệu; chưa có hoàn trả trước đó; đề xuất trả thêm 3 triệu. Giữ nguồn, phép tính và trạng thái của từng phần.

Kế toán rà soát trên báo cáo, người có quyền quyết định tài chính. Nếu duyệt và thực hiện chi thêm 3 triệu, phải ghi nhận/đối chiếu căn cứ thực tế rồi mới xem điều kiện đóng. Nếu trả lại hoặc từ chối, giữ nhánh và lịch sử tương ứng; không tự xóa khoản ứng hoặc suy toàn bộ chi phí bằng 0.

## 6. Ba biến thể để kiểm tra cách hiểu

| Chỉ thay dữ kiện này | Kết quả kỳ vọng |
| --- | --- |
| Xác nhận không nhận ứng, giữ các khoản/nguồn khác và không có lịch sử đã hoàn | Cùng lõi sau chi; đề xuất trả thêm 5 triệu. Không tạo khoản ứng giả hoặc bắt qua đề nghị ứng. |
| Giữ ứng 2 triệu, nhưng xác minh đã hoàn đúng phần này 3 triệu cho nhân viên | Số còn phải trả thêm 0. Cùng chứng từ xuất hiện lại không tự là gian lận. |
| Chứng từ di chuyển không đọc rõ dữ kiện tiền bắt buộc, chưa có nguồn thay thế đủ căn cứ | Giữ phần đã kiểm tra và khoản chưa rõ; hỏi đúng người/căn cứ cụ thể; chưa chốt quyết toán cuối hoặc chi phần đã biết. |

## 7. Điều cần làm rõ tiếp ở R2

Case thường quy đã cho thấy cần hai nhóm nguồn: khai báo/chứng từ nhân viên và dữ liệu tài chính/phê duyệt trong phạm vi. Bước 1–5 đã chỉnh/được thống nhất ở mức walkthrough, chưa có review độc lập lại bản chỉnh. Bước 6 đang đề xuất tiếp nhận hồ sơ sau chi; tiếp đó Bước 7 đối chiếu/tính kết quả, Bước 8 quyết định tài chính và Bước 9 chi/thu thực tế/điều kiện đóng. Tiếp tục case thiếu/mâu thuẫn: nguồn nào thiếu, ai có thể trả lời, câu trả lời làm hồ sơ đi tiếp ra sao. Chưa cần schema, API, thuật toán khớp hay corpus chạy tự động; những phần đó thuộc R4–R7.

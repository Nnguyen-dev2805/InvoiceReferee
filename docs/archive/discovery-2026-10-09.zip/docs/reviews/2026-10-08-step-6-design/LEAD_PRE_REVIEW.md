# Bước 6 — Nhận xét riêng của lead trước kết quả reviewer

Ngày: 08/10/2026. Target: [snapshot](TARGET_R2_CASE_WALKTHROUGH.md), Mục 3.1, dòng 250–280. Ghi trước khi đọc reviewer; không đọc code, chạy pipeline hoặc xác nhận policy/nguồn thật.

Verdict ban đầu: **Cần chỉnh sửa** về phạm vi lời đề nghị và điều kiện bắt đầu kiểm tra. Khung tách lời khai/nguồn và B6 intake/B7 verify là đúng; các ngưỡng/schema/source contracts chưa chốt R4 không tự là lỗi triển khai.

1. **Không bắt tự tính tiền cuối vẫn cần biết người nộp muốn giải quyết khoản/phần nào — dòng 263–266/278.** Native form không cần NV tự tính net từ ứng/chi trước, nhưng tài liệu hỗ trợ không tự là khoản NV muốn yêu cầu hoàn. Ví dụ hóa đơn chung 3 triệu, phần công việc A đề nghị xử lý chỉ 1 triệu; hoặc vé công ty trả chỉ là nguồn bối cảnh. Tổng hóa đơn, phần chi công việc đang đề nghị và số trả/thu cuối khác nghĩa. Giữ phần/phạm vi đề nghị bên cạnh source/dữ kiện, không để AI tự mở rộng yêu cầu tới toàn bộ nội dung tìm thấy. Import giấy có số đề nghị cần giữ ý nghĩa không tự đổi thành tổng expense hay net.

2. **Nguồn tài chính thiếu không chặn mọi kiểm tra đọc chứng từ — dòng 274/278.** Đã tiếp nhận có vấn đề và chưa khẳng định result là đúng. Cần làm rõ “đủ thông tin ban đầu để bắt đầu” theo công việc kiểm tra: hotel có đủ source có thể đọc/kiểm tra dù tiền ứng còn thiếu. Thiếu lịch sử ảnh hưởng net thì chưa chốt số cuối, không buộc chờ để đọc tất cả bills. Tối thiểu liên kết người/công việc/phạm vi rõ để không đoán, dữ kiện khác đi partial khi không ảnh hưởng check đó. Một file chưa đủ để biết thuộc hồ sơ nào khác với một hồ sơ có một số source chưa rõ.

3. **Quan hệ khoản/tài liệu và phần tiền — dòng 264/272.** Target đã nói nhiều nguồn/khoản, không thiếu hoàn toàn. Cần phản ví dụ: invoice khách sạn 3 triệu + biên nhận deposit 1 triệu + xác nhận thanh toán còn lại 2 triệu không tự là expense 6; company trả 2/A trả 1 trên cùng invoice không biến thành toàn bộ 3 là A-paid từ một payer label. Tách giá trị chứng từ, phần khoản chi đề nghị, event trả và linkage. R4 schema để sau, R2 cần case này để tránh agent xây 1file=1expense/1payer.

4. **Intake sửa/bổ sung ở hồ sơ đã duyệt/chi — dòng 258/272/280.** Chưa có bảng next action cho draft/đang kiểm tra/đã duyệt/đã chi. Nộp lại hồ sơ cũ đã trả không là yêu cầu chi mới; bill bổ sung có thể là nghĩa vụ mới cần liên kết với lịch sử; sửa số sau đã chi không tự overwrite hồ sơ đã dùng. Không re-open mọi old case hoặc reuse approval cho revision, cũng không coi mọi file cùng trip là duplicate. Đề xuất bảng nghiệp vụ nhỏ, không engine lifecycle enterprise.

5. **Báo cáo đầy đủ không ép NV khai thay nguồn công ty — dòng 256/265.** Case 8/5/3/2 là giả định đã công khai, không business requirement mọi NV phải biết toàn bộ companycost. Form chính nên nhận phần NV biết/đề nghị và dùng source tài chính để bổ sung companydirectpayment/advance/history. Companycost chưa rõ không ép guess amount; không nhập lại số B5 đã biết để tạo source mới. Tổng 8 trong case không tự đủ nếu nguồn ngoài scope thiếu.

6. **Trách nhiệm AI và công sức nhập — dòng 258/272.** “Form chính” không đồng nghĩa nhập lại bằng tay mọi trường đã rõ trong chứng từ. AI có thể chuẩn bị dữ kiện/quan hệ có source; người nộp bổ sung purpose/phạm vi hoặc xác nhận phần thực sự cần, không xác nhận mọi số vì chỉ có OCR một cách máy móc. Chưa chứng minh tiết kiệm thời gian nếu nhập tay bảng kê rồi review toàn bộ OCR; đo cả nhập/chuẩn bị source và bổ sung. Không đề xuất extractionprovider implementation/UI mới ở lượt read-only này.

Phép thử thiết kế: invoice3/Aclaim1; một invoice3 + deposit1 + remaining2; payer split company2/A1; nguồn advance thiếu nhưng hotelreadable; attachmentbackground không là claim; no-advance confirmed0 vsunknown; nộp lại oldpaidcase vs newbill bổ sung; sửa số sau payment; companycostunknown; form/import cùng ý nghĩa cho kết quả intake tương đương. Chưa là test chạy hoặc gold policy.

Rủi ro Challenge A routineauto đã ghi, không tự biến intakecóquestion thành rulebookviolation hay tuyên bố đổi task denominator là compliant. Không dùng missing schema/tests ở R2 làm critical finding.

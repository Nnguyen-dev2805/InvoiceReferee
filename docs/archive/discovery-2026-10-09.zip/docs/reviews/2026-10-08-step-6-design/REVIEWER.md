Tôi review độc lập đúng snapshot frozen của Bước 6, chỉ dựa trên Mục 1, các bước trước 3.1, B5 và brief gốc Mục 2.A. Tôi không coi việc chưa có schema/source contract/ngưỡng R4 là lỗi thiết kế.

**S6-R01 — Quan trọng — Chưa chốt rõ “block toàn hồ sơ” và “block riêng một khoản”.**  
Chứng cứ: TARGET\_R2\_CASE\_WALKTHROUGH.md:268,274,278. B6 nói nguồn tối thiểu có thể theo từng khoản, giữ phần đã có để xử lý, nhưng “điểm ra B6” lại cho phép hồ sơ đi tiếp khi còn “vấn đề cần bổ sung”. Chưa rõ B7 được kiểm tra phần độc lập hay phải chờ toàn bộ hồ sơ.

Counterexample: khách sạn 3 triệu chưa rõ payer do nhân viên chưa trả lời, trong khi khoản di chuyển 1 triệu có đủ khai báo và chứng từ. Một implementation có thể block cả hồ sơ; implementation khác lại cho B7 chạy toàn bộ dù thông tin nhận diện hồ sơ/phiên bản còn sai.

Impact: dễ tạo hai cực: hỏi người quá nhiều, trái mục tiêu routine automation của brief (Challenge\_Brief...:47,53,55), hoặc cho tính toán tiếp trên context chưa đủ an toàn.

Sửa tối thiểu walkthrough: thêm nguyên tắc: thiếu **quan hệ hồ sơ/người/công việc/phiên bản cần thiết để biết đang xử lý cái gì** thì block toàn phần liên quan; thiếu dữ kiện của một khoản chỉ block khoản đó. B7 được kiểm tra các khoản độc lập đã đủ context, nhưng chưa phát hành kết quả tài chính cuối nếu blocker vật chất còn tồn tại.

Phép thử bác bỏ: một khoản thiếu ảnh + một khoản đầy đủ phải cho khoản đầy đủ tiến tới B7; nhưng thiếu CT-DEMO-01 hoặc chưa xác định revision nào đang hiệu lực phải chặn các kiểm tra phụ thuộc context đó.

**S6-R02 — Quan trọng — Quan hệ expense item ↔ document ↔ document line/fact chưa đủ để ngăn double count.**  
Chứng cứ: TARGET...:263-264,272,280. Thiết kế đã đúng khi nói một file không tương đương một khoản và một tài liệu có thể hỗ trợ nhiều dữ kiện. Tuy nhiên chưa nói rõ dòng được trích từ tài liệu là **một khoản chi mới** hay chỉ là evidence cho khoản nhân viên đã khai.

Counterexample: nhân viên khai “khách sạn 3 triệu”; hóa đơn 3 triệu chứa room 2,7 triệu + fee 0,3 triệu; bảng kê import ngoài cũng ghi tổng khách sạn 3 triệu. Nếu ba representation cùng được coi là expense item, B7 có thể thấy 6 hoặc 9 triệu.

Impact: đây là lỗi semantics có thể trực tiếp làm sai số tiền, dù arithmetic hoàn toàn đúng.

Sửa tối thiểu: ở walkthrough chỉ cần chốt ba khái niệm, chưa cần schema: **khoản chi nhân viên khai**, **tài liệu nguồn**, **dòng/fact trích từ tài liệu**. Dòng/fact hỗ trợ hoặc mâu thuẫn khoản khai; import không tự tạo thêm khoản cho tới khi quan hệ “mới / sửa / bổ sung / cùng khoản” được xác định.

Phép thử bác bỏ: một hóa đơn nhiều dòng không làm tăng tổng ngoài khoản khai; một bảng kê có nhiều khoản vẫn tạo được nhiều khoản; nộp lại cùng receipt không cộng lần hai; hai taxi receipt thật sự khác nhau cùng số tiền vẫn được giữ riêng.

**S6-R03 — Vừa — Revision sau khi hồ sơ đã được quyết định hoặc đã chi/thu chưa có boundary rõ.**  
Chứng cứ: TARGET...:258,272,280. B6 xử lý khá rõ revision của “hồ sơ đang xử lý”, nhưng phép thử đã nhắc “thay đổi sau hồ sơ đã xét” mà chưa nêu hậu quả khi B8 đã quyết định hoặc B9 đã thực hiện chi/thu.

Counterexample: B8 chấp nhận hoàn 3 triệu, B9 đã trả; sau đó nhân viên bổ sung một taxi 500.000. Không được sửa ngược bản cũ thành “đáng ra 3,5 triệu” rồi làm lịch sử thanh toán trở nên mơ hồ.

Sửa tối thiểu: hồ sơ còn mở → tạo revision và đánh dấu kết quả downstream bị ảnh hưởng; đã có quyết định/chi/thu → tiếp nhận thành revision/adjustment liên kết, giữ nguyên quyết định và tiền đã xảy ra, rồi đưa phần mới qua B7/B8 trước khi phát sinh nghĩa vụ mới.

Phép thử bác bỏ: bổ sung 500.000 sau khi đã trả 3 triệu phải vẫn giữ “đã trả 3 triệu” và chỉ tạo ứng viên điều chỉnh 500.000.

**S6-R04 — Vừa — “Xác nhận phần trích xuất” ở hai mode intake chưa khóa ý nghĩa nguồn.**  
Chứng cứ: TARGET...:258,265,270. Native form và paper import dùng cùng lõi là hợp lý, nhưng cần nói rõ employee xác nhận OCR/extraction chỉ xác nhận **hệ thống đã đọc đúng điều họ khai**, không nâng lời khai đó thành nguồn tài chính đã xác minh.

Counterexample: giấy ngoài ghi “công ty đã trả vé 3 triệu”; nhân viên xác nhận OCR đọc đúng. Điều đó vẫn là khai báo của nhân viên, không trở thành financial source ngang với dữ liệu B5/tài chính.

Sửa tối thiểu: xác nhận extraction không đổi loại/authority của source; bản gốc luôn giữ; sửa OCR tạo revision của extraction, không sửa source gốc.

Phép thử bác bỏ: employee xác nhận “COMPANY paid 3m” nhưng nguồn tài chính nói chưa trả → B7 vẫn thấy hai nguồn mâu thuẫn.

**S6-R05 — Vừa — Chưa bảo vệ ROI khỏi việc biến B6 thành bước nhập liệu tài chính thủ công thường xuyên.**  
Chứng cứ: TARGET...:256,265,274; brief yêu cầu routine tự động (Challenge\_Brief...:47,55,80). Thiết kế cho phép reuse/import dữ liệu, nhưng chưa nói routine path ưu tiên reuse trước khi hỏi tài chính.

Sửa tối thiểu: ghi rõ thứ tự: dùng lại B5/nguồn tài chính đã có → import nguồn sẵn có → chỉ hỏi người tài chính khi thiếu/mâu thuẫn vật chất. Sau này đo số lần con người phải chạm hồ sơ routine.

Phép thử bác bỏ: case 8/5/3/2 với đầy đủ B5 + nguồn import phải qua B6 mà không cần tài chính nhập/xác nhận lại; chỉ thiếu nguồn vé mới phát một câu hỏi cụ thể.

**Hai điểm nên giữ nguyên.** Thứ nhất, semantics tiền đang tốt: tổng chi phí 8 triệu, phần nhân viên khai trả 5 triệu, công ty trả 3 triệu, ứng đã nhận 2 triệu và số đề nghị hoàn nếu có được giữ riêng; B6 không tự tính/chốt net (TARGET...:256,266,278). Thứ hai, source boundary được giữ đúng: PERSONAL chỉ là lời khai, financial source có authority riêng, và unknown không bị biến thành 0 (TARGET...:263,265,270,276).

**Verdict: Cần chỉnh sửa.** Hai điểm S6-R01 và S6-R02 nên được khóa ngay ở walkthrough vì chúng quyết định B6 chuyển sang B7 như thế nào và tránh sai số/double count; các chỉnh sửa này vẫn hoàn toàn ở mức semantics, chưa cần kéo schema, policy hay implementation từ R4 vào sớm.

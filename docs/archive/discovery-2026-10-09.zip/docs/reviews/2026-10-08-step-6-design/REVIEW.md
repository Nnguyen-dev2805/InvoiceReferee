# Review thiết kế — R2, Bước 6 tiếp nhận hồ sơ sau công việc

Ngày: 08/10/2026. Verdict reviewer và verdict cuối của lead: **Cần chỉnh sửa**.

Target: [walkthrough](../../discovery/R2_CASE_WALKTHROUGH.md), Mục 3.1, dòng 250–280; [snapshot bất biến](TARGET_R2_CASE_WALKTHROUGH.md). B6 giữ nguyên trong review. Không đọc code, chạy pipeline/test hoặc thực hiện chi/thu. Policy/source contract/schema cụ thể chưa chốt ở R4 không tự là lỗi implementation ở R2.

## 1. Cách review và nguồn

- Reviewer độc lập `chatgpt-web/gpt-5.6-sol`, **High**, Poincare, ID `01a11c10-363b-7a00-aaf0-041ebc2f47ed`; context không fork lịch sử, không đọc review các bước trước/lead notes. Một lượt hoàn thành, đã đóng. [Trả lời reviewer](REVIEWER.md), [evidence](review-evidence.json).
- [Nhận xét riêng của lead](LEAD_PRE_REVIEW.md) được ghi/hash trước khi đọc kết quả reviewer. Hai phân tích cùng một văn bản không phải hai bằng chứng vận hành hoặc trial người làm kế toán thực tế.
- [Brief gốc](../../Challenge_Brief_OrganizationAI_VN.docx.md), Mục 2.A, là nguồn yêu cầu cuộc thi; boundary human approval/routine tự động chưa được BTC xác nhận. Không dùng việc một bước tiếp nhận tự động để tự tuyên bố đạt toàn quy trình.
- Lead đã đọc [Cornell Required Documentation](https://finance.cornell.edu/travel/expense-reporting/documentation): tách mục đích công việc và proof of payment, chấp nhận các loại nguồn khác nhau và có yêu cầu theo loại chi. Chỉ tham khảo cách phân loại dữ kiện/nguồn; không nhập ngưỡng hoặc bắt buộc giấy tờ của Cornell thành policy MVP/doanh nghiệp Việt Nam.

## 2. Ledger — nhận xét reviewer và phán định của lead

| ID / mức reviewer | Reviewer nêu | Phán định độc lập của lead | Sửa tối thiểu / phép thử |
| --- | --- | --- | --- |
| S6-R01 / Quan trọng | Dòng 268, 274, 278 chưa rõ thiếu context chặn hồ sơ vs thiếu một khoản chặn phần đó, và B7 có được kiểm tra độc lập không. | Đồng ý về dependency của phép kiểm tra. Nguồn tạm ứng thiếu không ngăn đọc/kiểm tra hóa đơn đã rõ, nhưng chặn số quyết toán bị ảnh hưởng. Cần giới hạn: chưa có một mã công tác/đề nghị ứng sẵn không tự làm hồ sơ tự chi không ứng bị loại; có thể xác định công việc mới. OCR/lưu nguồn có thể độc lập khi còn thiếu context để áp dụng policy/gộp hồ sơ. | Một khoản thiếu ảnh và một khoản đủ source/context: phần đủ được kiểm tra. Chưa biết hồ sơ/người/công việc/phiên bản nào: không gộp hoặc áp dụng kiểm tra phụ thuộc quan hệ đó. Chưa phát hành kết quả cuối/cho chi phần đã biết khi unresolved ảnh hưởng kết quả. |
| S6-R02 / Quan trọng | Dòng 263–264, 272, 280 chưa phân biệt khoản khai, tài liệu, dòng/fact trích xuất để ngăn double count. | Đồng ý mạnh; target đã nói không coi file là khoản, cần ví dụ về nhiều representation. Phản biện cách hiểu cực đoan: dòng trích có thể phát hiện khoản ứng viên mới hoặc chênh lệch, không chỉ bị ép khớp khoản đã khai. Tổng nhân viên khai không là trần đúng của dữ liệu chứng từ. | Hotel khai 3 + invoice total 3 + dòng 2,7/0,3 + bảng kê tổng 3 vẫn là các cách thể hiện cần liên kết, không tự thành 6/9 triệu. Invoice thực tế 4 và khai 3 phải giữ mismatch, không cắt facts về 3. Hai taxi receipts thật sự khác vẫn có thể là hai khoản. |
| S6-R03 / Vừa | Dòng 258, 272, 280 cần đường nhận revision/bổ sung sau quyết định/chi/thu. | Đồng ý. Giữ bản đã dùng, quyết định và tiền thực tế; phần mới qua kiểm tra/quyền, không tự reuse approval hay mở yêu cầu chi mới. Một file nộp lại không tự là bổ sung khoản mới. | Đã trả 3, thêm taxi khai 0,5: giữ đã trả 3 và ứng viên bổ sung; 0,5 chưa là số chắc chắn phải chi vì còn policy/trùng/lịch sử. Đối chiếu phần ảnh hưởng trước quyết định/chi bổ sung. |
| S6-R04 / Vừa | Dòng 258, 265, 270: xác nhận trích xuất không nâng lời khai thành nguồn tài chính đã xác minh. | Đồng ý nguyên tắc. Phân biệt xác nhận hệ thống đọc đúng với xác nhận factual đúng vai/phạm vi theo policy. Không suy employee confirmation luôn vô giá trị hoặc mọi fact phải có cùng loại chứng từ; rulebook quyết định lời khai/xác nhận nào đủ cho check nào. Giữ source type/authority và raw original. | Người nộp xác nhận giấy ghi company paid 3 vẫn không tự xóa mâu thuẫn với nguồn tài chính. Chỉnh OCR không sửa bản gốc; nếu có xác nhận fact được policy chấp nhận thì ghi riêng và re-check phần liên quan. |
| S6-R05 / Vừa | Dòng 256, 265, 274 cần routine ưu tiên nguồn đã có trước khi hỏi người, bảo vệ ROI. | Target đã yêu cầu dùng lại nguồn phù hợp/không nhập lại số đã biết, nên đây là củng cố đường thực hiện, không thiếu hoàn toàn reuse. Đồng ý ưu tiên dùng nguồn đã có rồi nhập/import nguồn sẵn khi cần, hỏi phần thiếu/mâu thuẫn có ảnh hưởng. Không giả vờ import/chuẩn bị nguồn không tốn công. | Case routine đủ B5/finance source không hỏi xác nhận lại lịch sử; case thiếu riêng nguồn vé hỏi đúng phần/người. Đo cả thời gian chuẩn bị/nhập nguồn, sửa và số lần chạm hồ sơ. |

## 3. Biện luận riêng của lead

### S6-L01 — Nhân viên không tự tính net nhưng vẫn cần xác định phạm vi đề nghị

Target dòng 263/266/278 đã giữ các nghĩa tiền; còn cần làm rõ phần chi mà người nộp muốn giải quyết. Hóa đơn chung 3 triệu, phần công việc A đề nghị 1 triệu; hoặc vé công ty trả là tài liệu bối cảnh. Không tự biến toàn bộ tài liệu đính kèm thành khoản A yêu cầu được hoàn. Có thể nhận toàn bộ nguồn và đề xuất các khoản ứng viên; xác định quan hệ/phạm vi trước khi tính entitlement.

Phân biệt giá trị tài liệu, phần công việc đang đề nghị, sự kiện thanh toán và số chi/thu cuối. Ví dụ invoice khách sạn 3, biên nhận deposit 1 và biên nhận còn lại 2 không là expense 6. Company trả 2/A trả 1 trên invoice 3 không thể biểu diễn đúng chỉ bằng payer label cho toàn bill. Không phải yêu cầu schema ngay; là phản ví dụ để chốt nghĩa trước khi giao coding agent.

Đề xuất native intake: người nộp xác định khoản/phần/mục đích muốn xử lý; hệ thống chuẩn bị dữ kiện có nguồn và tính số cuối ở B7 khi đủ căn cứ. Không bắt mọi số được nhập hai lần qua form rồi OCR, không xem tất cả giấy tờ công ty trả là trách nhiệm nhân viên phải tự khai đúng. Báo cáo tổng thể dùng nguồn tài chính để bổ sung những phần cần thiết theo phạm vi đã công bố.

### S6-L02 — Số trên giấy đề nghị có cả ý nghĩa và chiều chi/thu

Target dòng 266 nói giữ riêng ý nghĩa số đề nghị là đúng. Cần phản ví dụ cho nhãn “hoàn ứng” dễ hiểu khác nhau: giấy giả lập ghi đã nhận ứng 4 triệu, chi thực tế 3,3 triệu và “hoàn ứng 0,7 triệu”. Nếu mọi dữ kiện đủ điều kiện/đã xác minh và không có lịch sử chi/thu khác ảnh hưởng, kết quả là A hoàn cho công ty 0,7; không tự coi đó là A xin công ty trả 0,7 chỉ vì trường có tên số tiền đề nghị.

Intake giữ nguyên wording/số/nguồn và chiều đề nghị nếu đã rõ; chiều chưa rõ thì giữ chưa rõ. B7 tính theo dữ kiện/rulebook và đối chiếu, không để parser hoặc tên giấy quyết định chiều tiền. Đây là case giả lập để kiểm tra semantics, không là kết luận tài chính đối với một người/hồ sơ thật.

## 4. Hướng chỉnh tối thiểu trước Bước 7

1. Bảng dependency: điều gì đủ để tiếp nhận/lưu; điều gì cho phép đọc/kiểm tra khoản độc lập; điều gì chặn áp dụng policy/gộp/tính kết quả cuối. Intake không phải một boolean đã nhận = đủ mọi thứ.
2. Ba khái niệm khoản đề nghị–tài liệu nguồn–dòng/fact, cùng phạm vi phần tiền đề nghị. Dòng mới là ứng viên cần xác định, không tự cộng và không bị bỏ nếu khác lời khai.
3. Bảng tiếp nhận lại theo hồ sơ đang mở/đã quyết định/đã chi, giữ sự kiện và kiểm tra phần ảnh hưởng. Xác nhận extraction và xác nhận fact là hai hành động khác nghĩa.
4. Ưu tiên nguồn đã có và thao tác tối thiểu; thêm case giấy hoàn ứng có chiều thu, case payer split và case deposit/remaining. Scope/nguồn/quyền/gold chi tiết chốt R4–R7.

Giữ hai đường form/import chung lõi, PERSONAL là lời khai, tài chính cung cấp source đúng phạm vi, unknown khác 0, không bắt có đề nghị ứng cho hồ sơ tự chi. Review không đề xuất thêm ERP/auth/queue hoặc chi một phần hồ sơ còn unresolved ảnh hưởng số cuối.

Theo yêu cầu mới của chủ dự án, mỗi bước tiếp theo được viết, review độc lập **GPT 5.6 Sol Web — High**, lead biện luận rồi trình bày. Bản B6 hiện giữ nguyên; các sửa trên là đề xuất, chưa tự coi là đã được duyệt.

# Bước 4 — Nhận xét riêng của lead trước kết quả reviewer

Ngày: 08/10/2026. Target: [snapshot](TARGET_R2_CASE_WALKTHROUGH.md), Mục 2.4, dòng 130–157. Ghi trước khi đọc kết quả reviewer; không đọc code, chạy pipeline hoặc đưa ra quy định pháp lý.

Verdict ban đầu: **Cần chỉnh sửa**. Phân tách số xin/số duyệt/thực nhận, duyệt cuối vs yêu cầu sửa và điều kiện rõ là hướng tốt. Policy/quyền chi tiết chưa chốt ở R2 không tự là lỗi implementation. Các điểm cần chốt:

1. **Duyệt thấp hơn và phần chưa được duyệt — dòng 141.** Xin 2, duyệt cuối 1,5 thì phần 0,5 là kết thúc trong quyết định hiện tại, để chờ duyệt hay tự thành bổ sung? Không thể suy từ chênh lệch số. Đề xuất MVP: quyết định cuối ghi rõ xử lý toàn bộ đề nghị với số được cấp 1,5; phần chênh không tự thành yêu cầu chi. Muốn xin thêm cần đề nghị bổ sung có liên kết và kiểm tra riêng. Đây là đề xuất, không suy rằng nhân viên đã nhận 1,5, đã đồng ý mức đó hoặc đã tự chi 0,5.

2. **Đề xuất số mới cần kiểm tra trước khi thành quyền chi có thể sử dụng — dòng 140–141, 149, 151.** Target đã yêu cầu check phần ảnh hưởng và quyền; cần phân biệt ghi ý định/quyết định đề xuất với kết luận quyết định đã hợp lệ để chi. Ví dụ xin 2, người có quyền duyệt 2 muốn tăng lên 3: không gắn ngay Approved rồi để bước chi phát hiện vượt quyền. Duyệt số thấp hơn cũng không tự hết vấn đề nguồn đang chưa rõ. Duyệt có điều kiện đã được mô tả chặn thực hiện chi; không claim target thiếu hoàn toàn nhánh đó.

3. **Một phần tiền đã chi và quyết định đã được dùng — dòng 144, 153.** Target giữ tiền đã xảy ra là đúng. Cần điều kiện để tiếp tục sử dụng quyết định: duyệt 2, đã chi 1, phần 1 còn lại không thể thành một quyền chi 2 mới khi mở lại/import; lệnh chờ hoặc trạng thái không rõ không tự coi là đã nhận/chưa chi. Từ chối/thu hồi sau lệnh chờ hay một phần đã chi cần giữ giao dịch và xử lý phần chưa thực hiện/đối chiếu theo trạng thái thực tế, không tự thu hồi tiền từ một cờ UI. Không cần multi-user/bank integration để làm rõ invariant này.

4. **Quyết định thay thế/mâu thuẫn — dòng 151–153.** C duyệt 2 rồi đổi 1,5, hoặc một nguồn bên ngoài nói 2 còn một quyết định trong app nói từ chối. Không tự lấy bản mới nhất hoặc ưu tiên trong app nếu chưa có quan hệ thay thế/quyền/hiệu lực xác định. Giữ cả hai nguồn; xác định quyết định nào đang áp dụng cho cùng phần nghĩa vụ và phần đã dùng, không cộng các quyết định thành quyền chi 3,5. MVP chỉ cần quan hệ và lịch sử rõ, không cần distributed workflow.

5. **Phản hồi của người duyệt ≠ sửa fact tự động — dòng 143, 147, 149.** Target đã có hard gates và giữ ngoại lệ. Nếu C trả lời “hóa đơn/bằng chứng có số 2” trong lúc nguồn chưa rõ, xem đó là xác nhận factual với vai/nguồn/phạm vi được policy chấp nhận rồi re-check; không lấy financial approval làm proof thay tất cả nguồn. Không bắt mọi human confirmation đều cần cùng loại giấy/chữ ký hay cho phép mọi người xác nhận vì có quyền tiền.

6. **Các thay đổi vô hại vs ảnh hưởng — dòng 151.** Version check cần dựa phần ảnh hưởng, không hủy mọi approval khi đổi ghi chú hoặc quyền nhân sự thay đổi mà chưa có quy tắc hiệu lực. Quyền tại lúc quyết định, hiệu lực quyết định và quyền thực hiện hành động hiện tại cần policy rõ. Dữ liệu chỉ trong phạm vi được cung cấp; không hứa tự biết người duyệt bị thu hồi quyền ngoài app.

Ý kiến về scope: vẫn ủng hộ duyệt thấp hơn số xin theo policy demo rõ; không tự buộc nhân viên sửa đơn để hai số bằng nhau. Duyệt tăng, điều kiện tự do và ngoại lệ không nhất thiết thành tính năng đầy đủ trong MVP; có thể ghi và chuyển xử lý nếu chưa có quy tắc an toàn. Không bỏ checkpoint tài chính đã thống nhất chỉ để thuận metric Challenge A. Rủi ro routine-auto đã nêu ở Bước 3, cần giữ và đo trung thực nhưng không lặp như finding mới nếu không có counterexample mới.

Phép thử thiết kế: xin 2/duyệt cuối1,5 → không tự còn một chi0,5; xin2/đềnghịsửa1,5 → chưa có quyền chi; tăng3 ngoài quyền2 → chưa usable; duyệt2/chi1 → không dùng lại toàn bộ2; hai approval xung đột → không chọn theo thứ tự nhập; nguồn mới ảnh hưởng vs ghi chú vô hại → check tương ứng. Chưa là test thực thi/gold policy.

# Review thiết kế — R2, Bước 4 quyết định tiền ứng

Ngày: 08/10/2026 · Verdict của reviewer và lead: **Cần chỉnh sửa**.

Target: [walkthrough](../../discovery/R2_CASE_WALKTHROUGH.md), Mục 2.4, dòng 130–157; [snapshot bất biến](TARGET_R2_CASE_WALKTHROUGH.md). Chỉ review thiết kế từ số 0, không đọc code, sửa target, chạy test/pipeline hoặc xác nhận policy/luật thực tế.

## 1. Cách review và giới hạn chứng cứ

- Reviewer `chatgpt-web/gpt-5.6-sol`, **High**, Nietzsche, ID `01a11be8-9258-7b41-a928-ce32cc7f67a8`, context riêng không fork history/không đọc nhận xét lead.
- Lượt đầu lỗi `stream disconnected before completion: ChatGPT final DOM could not be aligned with text already streamed to Codex`. Lead không dùng kết quả dở dang. Một lượt thử lại bằng `send_input` tới cùng agent/model/mức đã hoàn thành, sau đó đóng agent. [Bản trả lời reviewer](REVIEWER.md) được lưu; [evidence](review-evidence.json) giữ cả lỗi và lượt thành công.
- [Nhận xét riêng của lead](LEAD_PRE_REVIEW.md) được ghi/hash trước khi đọc kết quả reviewer. Những nhận xét trùng không được xem là hai bằng chứng vận hành độc lập; đây là hai phân tích cùng một thiết kế.
- [Brief gốc](../../Challenge_Brief_OrganizationAI_VN.docx.md), Mục 2.A, vẫn yêu cầu routine tự động và phân loại chuyển tiếp cụ thể. Rủi ro boundary của human financial approval đã ghi ở Bước 3; không coi nó đã được BTC xác nhận chỉ vì review từng bước.
- Lead tham khảo [Oracle PeopleSoft — Approving Cash Advances](https://docs.oracle.com/cd/F52785_01/fscm92pbr43/eng/fscm/fexp/ApprovingCashAdvances-9f574d.html?pli=ul_d875e335_fexp): phân biệt approve, send back, hold, deny và save changes; phần approve phụ thuộc các người duyệt được cấu hình. Đây là ví dụ phần mềm, không xác lập quy trình bắt buộc hoặc quyền thay đổi số tiền ở công ty của chủ dự án. Không dùng trạng thái UI của sản phẩm khác làm bằng chứng tiền thực nhận.

## 2. Ledger phán định của lead

| ID / mức | Reviewer nêu | Phán định và sửa tối thiểu của lead | Phép thử thiết kế |
| --- | --- | --- | --- |
| S4-R01 / Quan trọng | Dòng 141 chưa rõ phần 0,5 triệu khi xin 2, duyệt cuối 1,5. | Đồng ý mạnh. Giữ hai số đã đúng; cần disposition của đề nghị/phần chưa được duyệt. Đề xuất MVP: quyết định cuối xử lý đề nghị hiện tại ở mức 1,5, phần chênh không tự thành chờ chi; xin thêm là đề nghị bổ sung có liên kết. Không tự suy chênh là nhân viên đã tự chi hoặc sẽ được hoàn sau. Employee consent/bản sửa nếu policy yêu cầu, không tự thêm/bỏ. | Gửi lại bản 2 triệu sau duyệt/cấp 1,5 không tạo quyền chi thêm 0,5 khi chưa có đề nghị/quyết định hợp lệ mới. |
| S4-R02 / Quan trọng | Dòng 147 đã chặn điều kiện chưa đạt nhưng chưa xác định ai/nguồn/cách chứng minh đạt. | Đồng ý; không claim target thiếu toàn bộ conditional gate. Mỗi điều kiện có fact cần chứng minh, nguồn/vai có quyền xác nhận và cách kiểm tra. Khi có quy tắc xác định đạt, có thể chuyển tới phần thực hiện chi; không buộc duyệt lại mọi điều kiện. Điều kiện mơ hồ/ngoài rulebook thì chưa đủ để chi. Không cần bộ máy diễn giải mọi câu điều kiện bằng AI. | Ảnh mơ hồ hoặc người xác nhận sai phạm vi không làm điều kiện đạt; đúng nguồn/cách kiểm tra mới cho đi tiếp. |
| S4-R03 / Quan trọng | Dòng 151 và invariant dòng 124 cần rõ dependency tài chính trước chi, không chỉ request/policy. | Đồng ý nguyên tắc, nhưng target đã có re-check thay đổi liên quan. Đây là cụ thể hóa bằng sự kiện tiền, không phát hiện omission hoàn toàn mới. Quyết định 2 triệu không là quyền chi lại toàn bộ 2 mỗi lần. Phần thực hiện phải xét chi/lệnh chờ liên quan đã được xác định. Chưa rõ trạng thái tiền thì không tự tính còn phải chi. | Chèn paid/pending liên quan giữa duyệt và chi: không tiếp tục nguyên trạng chỉ vì form/policy chưa đổi. |
| S4-R04 / Quan trọng | Dòng 153 chưa nói đủ pending và chi một phần khi thu hồi. | Đồng ý và giới hạn: dừng quyền thực hiện tiếp trong workflow không chứng minh ngân hàng/lệnh bên ngoài đã được hủy. Ghi yêu cầu xử lý và đối chiếu kết quả actual; giữ tiền đã xảy ra và pending chưa rõ. Không biến từ chối/thu hồi thành bút toán hoàn tiền. | Thu hồi trước chi, khi lệnh chờ và sau chi 1/2 triệu có hành động khác nhau; pending không tự thành canceled/paid. |
| S4-R05 / Vừa | Dòng 153 chưa rõ khi hai quyết định bên ngoài/trong app mâu thuẫn. | Đồng ý. Giữ nguồn và quan hệ quyết định áp dụng/thay thế. Không chọn latest hoặc ưu tiên trong app khi chưa có quy tắc/hiệu lực đúng. Một phần nghĩa vụ không được cộng hai phê duyệt thành quyền chi lớn hơn. Không cần multi-user approval engine cho MVP. | Hai quyết định 2 và 1,5 cùng phạm vi nhưng không rõ thay thế: giữ vướng mắc, chưa release. Khi có căn cứ thay thế rõ thì dùng quyết định đang áp dụng cùng lịch sử phần đã thực hiện. |

## 3. Biện luận riêng và đề xuất phạm vi MVP

### S4-L01 — Số mới cần được kiểm tra trước khi thành quyền chi sử dụng được

Target dòng 141, 149, 151 đã nói kiểm tra số/quyền/phần ảnh hưởng, nhưng cần làm rõ thứ tự. Ghi nhận người duyệt muốn cấp một số không đồng nghĩa hệ thống đã chấp nhận nó thành quyết định có thể dùng. Xin 2, đề xuất cấp 3 nhưng quyền chỉ tới 2: giữ ý định, kiểm tra và chuyển đúng người nếu cần, chưa đánh dấu đủ để chi. Số thấp hơn cũng không xóa một vướng mắc dữ kiện bắt buộc đang tồn tại.

Không cần sửa yêu cầu của nhân viên để xét số duyệt. Phân biệt ba ý nghĩa: nội dung đang xem xét; quyết định đã được ghi nhưng còn điều kiện; quyết định đang áp dụng và đủ điều kiện để sử dụng. Tên state/UI cụ thể chốt sau; không coi đây là yêu cầu thêm ba màn hình.

### S4-L02 — Kiểm tra thay đổi theo ảnh hưởng, không bắt duyệt lại mọi lần

Giữ request/báo cáo/decision version là cần thiết. Nhưng sửa một ghi chú không ảnh hưởng số, mục đích hoặc phạm vi không mặc định hủy phê duyệt. Thay đổi lịch sử tiền hoặc số/phạm vi cần kiểm tra tương ứng. Quyền của người duyệt tại thời điểm quyết định, hiệu lực quyết định và quyền người thực hiện hiện tại phải theo policy; không tự suy mọi thay đổi nhân sự thu hồi toàn bộ quyết định đã ký. Source contract có giới hạn, không giả vờ biết thay đổi ngoài app chưa cung cấp.

### Hướng nên giữ và hướng nên giới hạn

- Giữ hỗ trợ số duyệt thấp hơn số xin khi policy demo cho phép, số gốc không bị overwrite. Không bắt nhân viên sửa đơn chỉ để hai số giống nhau. Đây vẫn là đề xuất đang review, chưa là chính sách công ty được kích hoạt.
- Giữ ranh giới hệ thống chuẩn bị/kiểm tra, con người quyết định đúng quyền, AI đọc/tóm tắt có nguồn; approval khác tiền thực nhận và không chứng minh chi phí thực tế sau này hợp lệ.
- Giới hạn tăng số, điều kiện tự do và ngoại lệ: nếu chưa có quy tắc hỗ trợ thì ghi nội dung/chuyển xử lý, không hứa AI tự hoàn tất mọi trường hợp. Không dựng workflow enterprise để giải quyết các nhánh này.
- Giữ kiểm soát chi tiếp dựa quyền đang áp dụng và lịch sử tiền rõ. Ví dụ duyệt 2, thực nhận 1, không có lệnh chờ/hoàn/thay đổi khác và quyết định vẫn áp dụng thì phần chưa thực hiện là 1; đây là giả định có nguồn, không phép trừ khi dữ liệu thiếu.

## 4. Chỉnh tối thiểu trước khi sang Bước 5

1. Bảng kết quả quyết định nêu phạm vi/số được duyệt, việc xét đã kết thúc hay chờ và điều kiện sử dụng; làm rõ phần chênh chưa được duyệt.
2. Với điều kiện: fact/nguồn/người xác nhận/cách kiểm tra và ai xử lý nếu chưa đạt. Điều kiện đạt chỉ cho đi tiếp trong workflow, không tự chuyển tiền.
3. Nối quyết định với lịch sử phần đã chi/chờ, nguồn thay đổi và quan hệ thay thế; giữ vướng mắc khi quyết định xung đột hoặc tiền chưa rõ.

Phép thử chưa chạy pipeline: duyệt cuối 1,5 vs yêu cầu sửa 1,5; replay phần chênh; điều kiện rõ vs mơ hồ; tăng số vượt quyền; tiền thay đổi giữa duyệt/chi; thu hồi trước chi/khi pending/sau chi một phần; hai quyết định xung đột; sửa vô hại vs thay đổi ảnh hưởng. Đánh giá nguồn/quyền/schema/gold cụ thể còn ở R4–R7.

Không sửa walkthrough/code trong lượt review này. Verdict là kết luận thiết kế, không chứng nhận runtime, trách nhiệm pháp lý hoặc mức đạt cuộc thi.

## Review độc lập — BƯỚC 4

### S4-R01 — Quan trọng: phần 0,5 triệu còn lại sau “duyệt cuối 1,5/2 triệu” chưa có trạng thái rõ

**Snapshot:** TARGET\_R2\_CASE\_WALKTHROUGH.md:141

Target đã làm đúng khi giữ riêng **số xin 2 triệu** và **số duyệt 1,5 triệu**, không sửa ngược yêu cầu cũ. Nhưng nếu 1,5 triệu là “quyết định cuối”, phần 0,5 triệu còn lại chưa được xác định là đã đóng, bị từ chối, chờ sửa hay vẫn pending.

**Phản ví dụ:** C duyệt cuối 1,5 triệu, sau đó đã cấp 1,5 triệu. Nhân viên gửi lại bản đề nghị 2 triệu cũ. Nếu residual 0,5 triệu không có trạng thái, hệ thống có thể coi nó vẫn đang chờ xử lý.

**Sửa tối thiểu:** partial final approval phải ghi rõ disposition của phần chênh lệch theo policy. Không cần chốt ở R2 rằng luôn phải có employee consent hay luôn là từ chối.

**Phép thử bác bỏ:** replay đề nghị 2 triệu sau khi 1,5 triệu đã được duyệt/cấp; không được phát sinh quyền chi thêm 0,5 triệu nếu chưa có request/decision hợp lệ mới.

### S4-R02 — Quan trọng: conditional approval đã có hard gate, nhưng điều kiện được coi là “đã thỏa” chưa đủ chặt

**Snapshot:** TARGET\_R2\_CASE\_WALKTHROUGH.md:147

Target đã có guard tốt: điều kiện chưa đạt thì chưa sang chi; không được dùng conditional approval để vượt qua unknown bắt buộc, sai số học hay vi phạm không có ngoại lệ.

Thiếu ở đây là **ai/nguồn nào chứng minh condition đã đạt và việc đạt condition có tự release hay cần người duyệt xác nhận lại**.

**Phản ví dụ:** điều kiện là “có xác nhận đặt khách sạn”; nhân viên tải một ảnh mơ hồ và AI suy rằng condition đã hoàn tất.

**Sửa tối thiểu:** mỗi condition cần chỉ rõ fact phải chứng minh, nguồn/người có thẩm quyền cung cấp và cách xác định đạt. R4 mới quyết định loại condition nào được tự release sau deterministic check.

**Phép thử bác bỏ:** nguồn sai owner hoặc evidence mơ hồ phải giữ HOLD; chỉ đúng source contract mới được sang Bước 5.

### S4-R03 — Quan trọng: validity đã gắn version/policy/authority nhưng cần khóa rõ với trạng thái tài chính mới trước lúc chi

**Snapshot:** TARGET\_R2\_CASE\_WALKTHROUGH.md:151, invariant trước đó tại :124

Target đã có version, quyền, source và yêu cầu re-check khi có thay đổi. Tuy nhiên nên nói rõ rằng **financial-state snapshot cũng là dependency của quyết định**.

**Phản ví dụ:** lúc C duyệt 2 triệu thì chưa có giao dịch liên quan. Trước Bước 5, nguồn tài chính mới cho biết đã cấp 1 triệu cho đúng phần này. Request và policy không đổi, nhưng chi thêm đủ 2 triệu sẽ sai.

**Sửa tối thiểu:** trước payment phải revalidate các dependency có thể làm thay đổi số còn được thực hiện, gồm paid/pending/reversal liên quan và mốc dữ liệu tài chính.

**Phép thử bác bỏ:** chèn một paid/pending event giữa B4 và B5; approval cũ không được sử dụng nguyên trạng.

### S4-R04 — Quan trọng: thu hồi sau đã chi có xử lý, nhưng pending và partial real payment chưa được nói đủ

**Snapshot:** TARGET\_R2\_CASE\_WALKTHROUGH.md:153

Điểm đúng là target không xóa giao dịch tiền thật khi quyết định bị thu hồi. Nhưng còn hai trường hợp cần khóa: đang có lệnh chi pending và đã chi một phần.

**Phản ví dụ:** duyệt 2 triệu, đã thực nhận 1 triệu, sau đó approval bị thu hồi. Hệ thống phải giữ 1 triệu đã xảy ra và dừng phần 1 triệu chưa thực hiện.

**Sửa tối thiểu:** withdrawal/revocation chỉ tác động phần chưa thực hiện; pending phải được reconcile/hold, còn real payment luôn được giữ trong lịch sử.

**Phép thử bác bỏ:** revoke trước chi, khi pending, và sau khi đã chi 1/2 triệu phải cho ba kết quả khác nhau.

### S4-R05 — Vừa: quyết định tài chính bên ngoài được reuse đúng hướng, nhưng conflict giữa hai quyết định chưa có đường xử lý

**Snapshot:** TARGET\_R2\_CASE\_WALKTHROUGH.md:153

Reuse external financial permission là hợp lý. Vấn đề là nếu có hai quyết định có vẻ đều hợp lệ nhưng trái nhau, target chưa nói rõ hệ thống phải làm gì.

**Phản ví dụ:** nguồn ngoài ghi “approve 2 triệu”, sau đó nguồn khác ghi “final 1,5 triệu”, chưa rõ cái nào supersede cái nào.

**Sửa tối thiểu:** giữ cả hai decision event; nếu policy chưa định precedence hoặc hiệu lực chưa xác định thì tạo contradiction/HOLD, không để AI tự chọn nguồn thuận tiện hơn.

**Phép thử bác bỏ:** hai approval cùng scope nhưng khác amount/effect phải chặn release cho tới khi rule hoặc đúng người giải quyết.

Hai điểm nên giữ nguyên: thứ nhất, ranh giới **AI đề xuất/tóm tắt → deterministic validation → human financial decision** tại :155 đang rõ và đúng. Thứ hai, các guard về **version, authority, exception, unknown hard gate và approval ≠ payment** tại :147-157 đã có thực chất, không nên thiết kế lại từ đầu.

Với Challenge A, brief vừa yêu cầu routine được xử lý tự động hoàn toàn (Challenge\_Brief\_OrganizationAI\_VN.docx.md:47-55), vừa lấy ví dụ trường hợp vượt thẩm quyền cần người phê duyệt. Vì vậy checkpoint tài chính bắt buộc cho mọi routine vẫn là **một ambiguity thật**, và target đã thừa nhận ở :128. R2 nên giữ nó như rủi ro cần chứng minh bằng task definition/Verify sau này, không tự tuyên bố đạt hay thất bại bằng cách đổi denominator.

**Verdict: Cần chỉnh sửa.**

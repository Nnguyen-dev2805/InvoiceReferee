# Phân biệt đúng policy với giá trị workflow

Lead đối chiếu brief gốc trong lúc reviewer độc lập đánh giá target. Không sửa policy, không viết code/test hoặc coi ví dụ là gold.

## Căn cứ cuộc thi

Brief `docs/Challenge_Brief_OrganizationAI_VN.docx.md`: Challenge A dòng47–59 yêu cầu quy trình cụ thể/rulebook, ít nhất15case, factual uncertainty/outsidepolicy/authority, câu hỏi cụ thể và không chuyển mọi case. Dòng63–67 yêu cầu adaptation từ feedback, independent missed/unnecessary escalation và thử ít nhất3professionalusers; dòng21 yêu cầu đánh giá tác động thực tế chứ không chỉ tốc độ.

## Hai câu hỏi không được nhập làm một

- Có tính đúng theo policy demo đã chốt? Cần input raw, nguồn/căn cứ, expected độc lập, version và các case biên/thiếu/mâu thuẫn. Synthetic policy/dataset có thể giúp chứng minh câu này.
- Có giảm công sức của kế toán với một workflow sử dụng được? Cần đo tìm/chuẩn bị/nhập nguồn, trả lời câu hỏi, đọc báo cáo và quyết định; người làm thực tế không được thay bằng agent. Rulebook càng nghiêm chưa chắc càng có lợi.

## Những ca cần chuẩn bị cho R5 sau khi chốt policy

| Tình huống | Điều cần phân biệt |
| --- | --- |
| Hai phòng-đêm, tổng2,8 triệu, không có breakdown | Rule từng đêm không đủ cho pass chỉ từ bình quân; policy tổng kỳ là lựa chọn khác, không là nâng confidence |
| Tiếp khách 2 bill1,8 triệu, cùng event | Một trần cho tổng3,6 triệu, khác hai event độc lập có căn cứ |
| Taxi sử dụng trước0h, bill phát hành sau0h | Date contract phục vụ grouping; không mặc định ngày tải ảnh/phát hành |
| Đề nghị20 triệu, phần proposedeligible12, người muốn chỉ chấp nhận9 | Routing trước quyết định: việc giảm số sau không tự tạo quyền quyết định phần bị loại |
| Công ty trả tiền phòng, NV nộp bill ăn sáng cùng khách sạn | Chỉ yêu cầu nguồn công ty cần cho đúng khoản/nhóm, không toàn bộ chi công tác như gate chung |
| Xin ứng bổ sung sau khoản đã thực nhận | Thiếu evidence khác capability hỗ trợ lần đầu, khác pending/double instruction |

Đây là counterexamples minh họa cần chốt expected từ rulebook; chưa chạy, không tính vào >=15case/evalsuccess/usertrials. Chọn fix theo lỗi thực sự, không tạo bộ máy kế toán chung để xử lý mọi biến thể.

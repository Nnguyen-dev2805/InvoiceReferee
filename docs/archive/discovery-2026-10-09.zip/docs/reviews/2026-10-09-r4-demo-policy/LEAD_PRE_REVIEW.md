# Nhận xét riêng của lead trước khi nhận review

Ngày: 09/10/2026. Review thiết kế, không runtime hoặc người dùng thật.

1. Con số demo chưa được thực chứng: có thể chốt để kiểm tra đúng theo rule, nhưng không chứng minh policy phù hợp doanh nghiệp hoặc giảm công sức. Không gọi việc thay trần là cải tiến AI.
2. Giá phòng từng đêm đòi nguồn chi tiết: đề xuất cân nhắc trần bình quân kỳ lưu trú như một policy khác được công bố; nó không chứng minh mỗi đêm trong trần. Giữ nguồn không rõ hoặc ngoài kỳ/đổi phòng ở trạng thái cần làm rõ. Tránh xây kiểm soát nghiêm hơn bằng dữ liệu người dùng không có.
3. Quyền theo E trước đối trừ hợp lý hơn chỉ S, nhưng E sau quyết định có thể nhỏ hơn phạm vi đang được xét. Cần xác định quyền theo nội dung trước quyết định, không giảm E để người ít quyền tự quyết phần bị loại. Cũng phải xét chi/thu thực hiện theo quyết định, không coi báo cáo kiểm tra là quyền tiền.
4. Tạm ứng bổ sung không phải chi trùng nếu nghĩa vụ/nhu cầu khác có căn cứ. Giới hạn chỉ lần đầu là giới hạn MVP, không khẳng định nghiệp vụ bổ sung luôn nguy hiểm; cần lý do/metric riêng cho capability hạn chế và thực sự pending.
5. Tiếp khách cần định ranh giới sự kiện; taxi/ăn cần ngày thực hiện dịch vụ, không mặc định ngày phát hành bill. Vấn đề khó là liên kết và phân loại có nguồn, không thêm hạn mức cho thật nhiều nhóm.
6. Company-direct cùng nhóm có thể ảnh hưởng trần nhưng không cần toàn bộ lịch sử công ty cho mọi check. Cần yêu cầu nguồn đúng phạm vi ảnh hưởng để tránh tải nhập liệu xóa mất lợi ích đối chiếu.

Nhận xét trên là giả thuyết của lead, chưa là kết luận reviewer hoặc thay đổi policy. Hướng đánh giá song song: bảo vệ số tiền và giảm công sức chuẩn bị nguồn, không chỉ tăng số kiểm soát.

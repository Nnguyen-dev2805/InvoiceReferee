# Review R4.3 — Chính sách demo và hướng cải thiện

Ngày: 09/10/2026 · **Verdict của reviewer và lead cho bản target: Cần chỉnh sửa.**

Theo yêu cầu riêng của chủ dự án, reviewer **GPT 6.1 Sol — Medium** đã review độc lập [snapshot](TARGET_R4_DEMO_POLICY_PARAMETERS_DRAFT.md) của [bảng đề xuất](../../discovery/R4_DEMO_POLICY_PARAMETERS_DRAFT.md). Đây là ngoại lệ được yêu cầu cho bước này, không tự khôi phục quy trình subagent review mọi bước.

[Trả lời nguyên văn](REVIEWER_RESPONSE.md), [nhận xét lead trước review](LEAD_PRE_REVIEW.md), [ghi chú đánh giá](LEAD_EVALUATION_NOTES.md), [metadata](review-evidence.json). Không sửa target, con số hoặc hành vi policy trong đợt review. Các hướng chỉnh dưới đây là đề xuất chưa được chủ dự án chốt; không là policy runtime hoặc bằng chứng pipeline/trial thật.

## 1. Finding ledger và phán định lead

| ID | Nguồn / mức | Chứng cứ trong target | Phán định / trạng thái |
| --- | --- | --- | --- |
| DP-R01 | Reviewer / Cao | §1 dòng9, §2 dòng20–22: case một công việc nhưng đơn vị cộng là NV/ngày hoặc sự kiện, chưa xác định xuyên case | Đồng ý. Một ngày hai case ăn300k+300k cho ra hai kết quả khác nhau nếu scope khác. Cần chốt boundary trước gold; chưa giải quyết |
| DP-R02 | Reviewer / Trung bình | §3 dòng34–38: “đề nghị đầu tiên” chưa xác định submit hay nghĩa vụ/receipt | Đồng ý. Revision hoặc hủy trước chi không tự là ứng bổ sung. Cần làm rõ trạng thái và hiệu lực; chưa giải quyết |
| DP-L01 | Lead / làm rõ cần trước expected | §4 dòng45/53: E trước đối trừ nhưng thiếu ví dụ phân biệt rule rejection và discretionary reduction | Giữ cơ sở E, thêm guard quyền trước hành động giảm số; không đề xuất dùng mọi số nhân viên khai làm exposure. Chưa bổ sung target |
| DP-L02 | Lead / hợp đồng grouping còn mở | §2 ngày/người/event/phòng-đêm | Ngày dịch vụ khác ngày phát hành/upload; eventID nhân viên tự đặt không đủ chứng minh hai event khác nhau. Cần ghi ý nghĩa grouping và kiểm tra nguồn; format/matching thuộc R7 |

## 2. Đề xuất cộng gộp có phạm vi rõ, tránh nhập toàn công ty

Lead nghiêng về **ăn cá nhân/di chuyển theo nhân viên và ngày sử dụng dịch vụ, kể cả các công việc/hồ sơ liên quan; tiếp khách theo sự kiện, không theo case**. Mức không tăng vì tách hồ sơ. Chỉ cộng các khoản/phần thực sự riêng biệt, tránh cộng snapshot/revision, hóa đơn tổng, deposit và receipt nhiều lần.

Nguồn cần đúng nhân viên/ngày hoặc đúng sự kiện và phía tiền liên quan, với coverage/mốc có ý nghĩa. Nguồn case hiện tại, case liên quan trong tập quản lý và confirmation phù hợp có thể đáp ứng theo R4.2; không đòi toàn bộ ERP/sổ chi phí mọi người. Không tìm thấy case khác hoặc nhân viên khai “không có” không tự chứng minh absence của phần company-side.

Nếu coverage chưa đủ đúng đơn vị và ảnh hưởng check, lưu vấn đề/câu hỏi cụ thể; không khẳng định trong mức. Nếu có chứng cứ giới hạn hợp lệ đủ chứng minh kết quả mà không cần chi tiết hơn thì không hỏi vô ích. Trước code phải định test trường hợp đủ/thiếu nguồn cho phạm vi đó. Trường hợp nguồn tới mốc hiện tại chưa chứa khoản về sau không được giả bảo đảm vĩnh viễn; khoản đến muộn xử lý bằng version/điều chỉnh theo B8/B9, không sửa ngầm quyết định đã chi.

Tradeoff: cộng xuyên case tăng nhu cầu chuẩn bị nguồn. Nếu thử nghiệm cho thấy không khả thi, có thể đổi policy thành mức công việc/ngày một cách công khai; đó là thay mục tiêu kiểm soát, không gọi cách cộng hẹp là vẫn bảo đảm trần NV/ngày toàn phạm vi. Không xây hệ thống tài chính toàn công ty chỉ để giữ một câu trong policy.

Phản ví dụ tiếp khách của reviewer chỉ hợp lệ khi hai phần2 triệu là hai phần chi phí riêng của tổng4 triệu. Nếu invoice tổng4 triệu xuất hiện cùng deposit2 và balance2, expense vẫn4, không8. Finding đúng về boundary; không được biến minh họa thành quy tắc cộng mọi chứng từ.

## 3. Đề xuất sửa “ứng đầu tiên”

Thay cách đếm submit bằng phân loại nghĩa vụ và hiệu lực:

- Sửa/bổ sung cùng đề nghị chưa thực nhận: không tự là ứng bổ sung; re-check phần ảnh hưởng và hiệu lực approval cũ.
- Đề nghị cũ đã hủy, chưa chi, không còn approval/request/lệnh chi áp dụng: có thể xét đề nghị mới theo đường ban đầu. Từ chối còn hiệu lực vì công tác/policy không được vượt qua chỉ bằng tạo đề nghị mới.
- Có approval chưa chi: dùng/cập nhật đúng quyết định, không tạo nghĩa vụ ứng thứ hai; có lệnh pending thì phải đối chiếu trước, chưa xác minh hủy không là đã hủy.
- Đã thực nhận ứng và xin thêm: giữ ngoài routine trong MVP, đưa số đã nhận/nhu cầu còn lại/pending cho người có quyền xem xét. Đây là giới hạn xử lý, không khẳng định bị cấm hoặc là chi trùng.

Không tự động hóa bổ sung ứng hoặc retry chuyển tiền để đóng DP-R02. Đừng gọi lần chạy sau bổ sung fact là first-pass routine: vẫn ghi human touch của lifecycle.

## 4. Thẩm quyền: lead điều chỉnh nhận xét ban đầu

Lead trước review lo rằng E có thể bị giảm để lọt quyền. Reviewer đúng khi phân biệt **loại theo rule công bố** với **giảm tùy ý của người duyệt**. Không có cơ sở ép mọi đề nghị12 triệu lên cấp cao khi3 triệu chắc chắn bị loại theo rule, E đã xác định9 triệu và không còn ngoại lệ; đây là policy authority có thể chốt cho demo.

Ngược lại, E được kiểm tra là12 triệu và người có quyền10 triệu muốn chỉ chấp nhận9 triệu: không được dùng9 sau quyết định để hợp thức hóa quyền quyết định trước đó. Phải xử lý phạm vi/quyền theo B8; nếu phát hiện source/rule sai thật thì sửa có căn cứ và re-check, không “giảm số để duyệt”.

3 triệu còn tranh luận/ngoại lệ chưa giải quyết: E/S cuối chưa xác định, không làm E=9 rồi duyệt thường quy. Cấp cao chấp nhận cả12 thì quyền tổng tiền re-check. Quyết định có cả ngoại lệ và phê duyệt tiền trong cùng thao tác nếu đủ quyền/phạm vi, không yêu cầu hai lần bấm vô ích.

## 5. Khách sạn và hiệu quả workflow

Reviewer không coi mức từng đêm là lỗi logic; lead đồng ý. Bill3 triệu/2đêm không chứng minh từng đêm≤1,5 triệu: có thể1+2. Tuy vậy, policy nghiêm hơn có thể tăng công sức kiếm breakdown; mục tiêu sản phẩm là giảm tìm/ghép nguồn, không tối đa số trường bắt nhập.

Hai lựa chọn cần phân biệt: giữ trần từng đêm và nguồn đủ cho từng check; hoặc đổi rõ thành tổng ngân sách lưu trú≤1,5 triệu×phòng-đêm hợp lệ. Phương án sau cho2đêm tổng3 triệu đạt check ngân sách dù một đêm cao hơn, **không được ghi mỗi đêm đều đạt**. Lead đề nghị chưa tự đổi policy chỉ để làm happy case chạy; xem nguồn mẫu và human effort trước khi quyết định thay basis.

Có thể dùng proof bound đúng khi rule/nguồn cho phép: toàn bộ chi phí lưu trú không âm của2đêm tổng1,2 triệu đã đủ chứng minh không đêm nào vượt1,5 triệu về số tiền, không cần breakdown chỉ cho check đó; các check kỳ lưu trú/mục đích/payer vẫn phải đủ. Đây là suy luận có căn cứ, không lấy bình quân để kết luận mỗi đêm. Format và guard tính toán sẽ chốt ở R7, không runtime claim.

## 6. Kết luận và thứ tự cải thiện

Không có chứng cứ để đổi các con số chỉ vì cảm giác cao/thấp. Có thể dùng chúng làm policy demo sau khi chốt đủ đơn vị/phạm vi/hiệu lực. Không coi đúng trên policy giả lập là đã chứng minh hiệu quả kế toán.

Ưu tiên: (1) chốt boundary cộng gộp và nguồn đủ đúng scope; (2) làm rõ ứng ban đầu vs revision/pending/bổ sung, thêm ví dụ authority; (3) chủ dự án chốt bản rulebook/version rồi R5 lập expected độc lập và đo cả input preparation, questions, review, final quality. Brief Challenge A mục Sprint2 đòi missed/unnecessary escalation trên tập độc lập và ít nhất3professionalusers; review agent/synthetic cases không thay phần đó.

Giữ nghi vấn compatibility giữa job kiểm tra/báo cáo và routine hoàn toàn tự động theo brief đã công khai ở R3. Không đánh dấu đáp ứng cuộc thi chỉ từ policy rõ hoặc report cho người approve. Target hiện tại vẫn **Cần chỉnh sửa**, chưa closed finding và chưa activate.

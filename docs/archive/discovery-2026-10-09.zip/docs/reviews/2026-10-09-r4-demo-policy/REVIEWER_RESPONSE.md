**Verdict: Cần chỉnh sửa.**

Snapshot được kiểm tra có SHA256 đúng `88be013c24d74a7ba9e781908e9747ed910feaccc84023d015cb524362a8bcd3`. Review chỉ dựa trên target, ba tài liệu context được chỉ định và mục Challenge A/Sprint 2 của brief gốc; không đọc code, current specs, `LEAD_PRE_REVIEW.md` hoặc review lịch sử, không sửa file hay spawn agent. Đây là review thiết kế policy demo, không phải xác minh runtime, graph hoặc thử người dùng thật.

Target có nền tảng hợp lý: tách dự toán khỏi thực chi; áp hạn mức trước chia payer; company-direct không cộng vào E; không lấy tổng chia ngày/đêm để che vượt mức; vượt mức chuyển người có quyền thay vì tự cắt. Quyền ngoại lệ tách khỏi quyền tài chính, nhưng cho phép một quyết định chứa cả hai để giảm thao tác. Không có căn cứ trong phạm vi review để kết luận các con số demo quá cao hoặc quá thấp.

Hai finding dưới đây ảnh hưởng trực tiếp đến việc lập expected độc lập ở R5. Không cần mở rộng sang enterprise accounting để sửa.

**DP-R01 — Cao — Chưa xác định phạm vi cộng gộp khi ngày/sự kiện xuất hiện trong nhiều hồ sơ.**

**Vị trí:** §1 dòng 9: “mỗi case một nhân viên/một công việc”; §2 dòng 20: “Cộng các bữa của cùng nhân viên/ngày”; dòng 21: “Cộng các bill thuộc cùng sự kiện”; dòng 22: “cộng đúng ngày/người”.

**Phản ví dụ:** Nhân viên N có hai công việc được phép trong ngày 09/10. Hồ sơ X chứa tiền ăn 300.000; hồ sơ Y chứa tiền ăn 300.000. Hai receipt khác nhau, payer và nguồn công tác đều rõ, không có double payment. Nếu cộng trong từng case, cả hai đạt DP-02; nếu cộng theo nhân viên/ngày, tổng 600.000 vượt 100.000. Tương tự, một sự kiện tiếp khách có bill đặt cọc và bill thanh toán phần còn lại, mỗi phần chi phí 2 triệu, được nộp ở hai hồ sơ liên quan: tổng sự kiện là 4 triệu, nhưng từng hồ sơ dưới trần.

**Điều chưa quyết định:** Target quy định đơn vị cộng gộp nhưng chưa nói boundary có vượt case/công việc không, và nguồn nào đủ để xác nhận phần còn lại của đơn vị đó. History chống chi trùng không tự chứng minh đã có mọi khoản ăn cùng ngày hoặc mọi bill cùng sự kiện. Đây là quyết định policy; R7 có thể định format biểu diễn sau, nhưng không nên tự chọn boundary.

**Sửa tối thiểu:** Chốt rõ DP-02/04 cộng theo nhân viên/ngày trong phạm vi nào, DP-03 cộng theo sự kiện nào kể cả khi có hồ sơ liên quan. Nếu chọn xuyên hồ sơ, chỉ yêu cầu nguồn hoặc xác nhận có căn cứ cho đúng ngày/sự kiện bị ảnh hưởng; không yêu cầu toàn bộ sổ chi phí công ty. Nếu chọn giới hạn trong công việc, phải công bố đây là mức theo công việc/ngày và thừa nhận nhiều công việc có thể được hưởng nhiều mức.

**Tradeoff và tự phản biện:** Cộng xuyên hồ sơ chống chia nhỏ nhưng tăng công sức tìm nguồn. Nhân viên có thể khai purpose, ngày và quan hệ sự kiện; không cần mọi fact đều xuất hiện trên receipt. Tuy nhiên, lời khai ấy không tự chứng minh absence ở phần công ty nắm giữ. Ngược lại, không nên hỏi toàn bộ lịch sử khi nguồn hiện có đã đủ đúng scope. Finding yêu cầu một lựa chọn rõ, không mặc định phải triển khai kiểm soát toàn doanh nghiệp.

**DP-R02 — Trung bình — “Đề nghị đầu tiên” chưa phân biệt lần nộp với lịch sử nghĩa vụ ứng.**

**Vị trí:** §3 dòng 34: “Đề nghị ứng đầu tiên của công việc”; cùng dòng yêu cầu “không có ứng đã cấp hoặc yêu cầu/lệnh chi ứng còn hiệu lực”. Dòng 38 cho phép duyệt ít hơn số xin và giữ riêng số xin, số duyệt, thực nhận.

**Phản ví dụ:** Nhân viên xin ứng 2 triệu, sau đó hủy đề nghị trước approval; nguồn tài chính xác nhận chưa cấp ứng, không còn yêu cầu/lệnh chi hiệu lực. Dự toán được sửa có căn cứ thành 3 triệu và nhân viên nộp lại. Hồ sơ mới đáp ứng DP-06 và không có nguy cơ chi trùng đang tồn tại, nhưng không còn là “đề nghị đầu tiên”. Một trường hợp khác: đề nghị đầu được trả lại vì thiếu lịch trình, nhân viên bổ sung cùng hồ sơ. Literal hiện tại không cho biết đây là continuation thường quy hay một đề nghị bổ sung ngoài đường thường quy.

**Điều chưa quyết định:** “Đầu tiên” tính theo lần nộp, approval, lần cấp tiền hay một nghĩa vụ ứng đang hoạt động? Hai cách đọc tạo escalation khác nhau. R3 đã giữ revision/question–answer trong cùng lifecycle, nên không nên để số lần nộp tự trở thành lý do vượt policy.

**Sửa tối thiểu:** Định nghĩa ứng ban đầu theo nghĩa vụ ứng và trạng thái hiệu lực, không chỉ thứ tự submit. Bổ sung hoặc sửa cùng đề nghị chưa chi không tự thành supplementary advance. Nêu riêng cách xử lý đề nghị đã hủy/từ chối, approval chưa chi và tiền đã thực nhận; giữ kiểm tra pending/duplicate trước khi xét lại.

**Tradeoff và tự phản biện:** Giữ mọi ứng bổ sung sau thực nhận ngoài routine là lựa chọn demo hợp lý, không phải thiếu capability bắt buộc phải sửa. Ví dụ đã nhận 2 triệu, nhu cầu còn lại tăng thêm 1 triệu có thể chuyển người xem xét với số đã nhận, dự toán cập nhật và pending rõ. Không cần tự động hóa ứng bổ sung để đóng finding. Đổi lại, cần tránh chuyển tiếp chỉ vì nhân viên sửa một đề nghị chưa tạo nghĩa vụ tiền.

**Các lựa chọn tôi đã phản biện nhưng không coi là lỗi target**

Cơ sở quyền trên **E trước đối trừ** hợp lý hơn chỉ nhìn S. E=20 triệu, A=20 triệu, S=0 vẫn là quyết định chấp nhận 20 triệu. Kiểm tra thêm số hoàn lại cũng xử lý được E=0, A=20 triệu, S=-20 triệu.

Tuy nhiên, E đã là phần được chấp nhận. Với hồ sơ nhân viên đề nghị 12 triệu, 3 triệu bị loại bởi rule rõ, E còn 9 triệu, việc người phụ trách tài chính duyệt quyết toán trong quyền 10 triệu là một thiết kế có thể chấp nhận. Không có cơ sở mặc định buộc dùng 12 triệu để kiểm tra quyền. Nếu 3 triệu đang xin ngoại lệ thì người phụ trách không được tự xử lý ngoại lệ; nếu cấp cao chấp nhận toàn bộ, E thành 12 triệu và quyền phải kiểm tra lại. Nên ghi ví dụ này trước R5 để phân biệt **loại khoản đã xác định**, **ngoại lệ unresolved** và **số nhân viên đề nghị**; đây là làm rõ, không phải yêu cầu thay basis authority.

Company-direct phải được xét khi ảnh hưởng cùng đơn vị hạn mức. Bill tiếp khách 4 triệu, công ty trả 2,5 triệu và nhân viên trả 1,5 triệu vẫn vượt DP-03; không được chỉ xét 1,5 triệu. Ngược lại, nguồn company-direct không liên quan đơn vị đang kiểm tra không nên trở thành yêu cầu bổ sung mặc định. Hai bên cùng có bằng chứng trả tiền cũng chưa đủ kết luận double payment: có thể là hai phần hợp lệ, hoặc trả trùng thật. R4.2 đã yêu cầu làm rõ linkage/portion và chặn final S khi nghĩa vụ ảnh hưởng còn unresolved; target không cần thêm một công thức thu hồi tổng quát.

**Hiệu quả workflow và các contract còn mở**

Rule từng phòng-đêm có thể làm demo khó hơn, nhưng khó không đồng nghĩa sai. Bill 3 triệu cho hai đêm chưa chứng minh mỗi đêm trong mức: có thể là 1 triệu và 2 triệu. Ngược lại, nếu nguồn xác định hai đêm đều 1,5 triệu thì không cần hỏi lại. Target đã có nguyên tắc chỉ đòi chi tiết khi cần; R5 nên đo xem thực tế nguồn nào đủ và bao nhiêu lần phải bổ sung, thay vì biến mọi bill nhiều đêm thành escalation.

R5 cần đo cả chuẩn bị nguồn, khai purpose/event, ghép payer, số vòng bổ sung và thao tác của operator. Nếu operator đã chia ngày, ghép mọi bill và tìm đầy đủ lịch sử trước Run, kết quả kiểm tra đúng vẫn có giá trị, nhưng chưa chứng minh giảm công sức. Ngưỡng quality, format nguồn và cách đo chi tiết thuộc R5/R7, không phải lỗi thiếu của bảng tham số này.

Brief Challenge A yêu cầu routine tự động, đánh giá miss/unnecessary escalation độc lập và Sprint 2 thử ít nhất ba nhân sự nghiệp vụ thật. R3 đã công khai rủi ro boundary kiểm tra/báo cáo với financial approval của người. Bảng này không tự đóng rủi ro đó; golden synthetic hoặc thẩm định agent không thay professional-user trials.

**Ba ưu tiên trước R5:**

1. Chốt boundary cộng gộp và căn cứ đủ cho ngày/sự kiện liên quan.
2. Sửa nghĩa “ứng đầu tiên”, giữ supplementary advance ngoài routine nếu muốn.
3. Ghi ví dụ authority sau loại khoản/ngoại lệ, rồi chủ dự án duyệt rõ DP-01..07, bảng vai và phiên bản áp dụng.

Không cần thay toàn bộ hạn mức, thêm bank/ERP/payroll hay xây hệ thống quyền enterprise để giải quyết các điểm này.

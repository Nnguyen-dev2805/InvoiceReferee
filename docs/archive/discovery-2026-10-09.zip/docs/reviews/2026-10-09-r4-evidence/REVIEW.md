# Review R4.2 — Applicability và evidence được chấp nhận

Ngày: 09/10/2026. Reviewer: **Cần chỉnh sửa** trên [snapshot](TARGET_R4_EVIDENCE_RULES_DRAFT.md). Lead: **Có thể chốt ở mức đề xuất evidence** sau bổ sung hai guard; cashattestation là lựa chọn policy đang chờ chủ dự án, chưa active. [Draft hiện tại](../../discovery/R4_EVIDENCE_RULES_DRAFT.md) chưa có independent rereview hoặc runtime evidence.

## 1. Cách review và sự cố được ghi nhận

- Agent Beauvoir `01a11f14-b651-7be2-8577-9e1c41280ba2`, model `chatgpt-web/gpt-5.6-sol` **High**: lượt đầu lỗi `stream disconnected before completion: ChatGPT final DOM could not be aligned with text already streamed to Codex`. Sau send_input cùng agent, waiter vẫn trả cùng error, không có final hoàn chỉnh; không sử dụng nội dung dở dang hoặc coi retry chắc chắn đã tạo một review riêng. Agent đã đóng.
- Reviewer mới Mencius `01a11f1b-f004-7e41-8acb-4144c9165113`, cùng model/mức High, context không fork: trả [review hoàn chỉnh](REVIEWER.md), đã đóng. Không tự chuyển model.
- [Nhận xét riêng lead](LEAD_PRE_REVIEW.md) ghi/hash trước các kết quả. [Evidence](review-evidence.json) giữ lỗi/delivery observations, fresh retry, snapshot/pre/post hashes. Không đọc code/test/bank hoặc xác nhận nguồn thật.
- Primary sources lead đọc: [Cornell Required Documentation](https://finance.cornell.edu/travel/expense-reporting/documentation) tách mục đích, paymentproof và nhiều loại source; [UW Payment Tracking](https://finance.uw.edu/travel/WDpaymentoptions) Paid/Reconciled không bảo đảm tiền vào bên nhận. Chỉ tham khảo khái niệm, không suy Cornell/UW cho phép cashattestation cụ thể hoặc áp ngưỡng/luật của họ cho doanh nghiệp VN.

## 2. Phán định

Reviewer mới không gán severity trong final; mức dưới là lead đánh giá cho contract.

| ID / mức lead | Reviewer nhận xét | Đã bổ sung / giới hạn |
| --- | --- | --- |
| R4E-R01 / Quan trọng | Snapshot dòng52–54/66: absenceowner phải quan sát đúng loại event/mốc, NV không thay companysource. | Đồng ý. Source phía company + scope event/method/side/people/time và updates cần đủ; bank-only không tự proof absencecash/corporatecard. NV chỉ biết phạm vi thực sự quan sát, không từ rolepick/companylabel. Kiêm vai có source/observability rõ không tự bị cấm, nhưng không coi chức danh là proofcoverage. |
| R4E-R02 / Quan trọng | Dòng18–20/58: readingconfirmation không chuyển bản thật không đọc được thành số known bằng nhập tay. | Đồng ý. Human phải đọc được retainedsource rõ córef/value; nếusourcekhôngđọcđược cần alternative/factual source phù hợp. Số từngồndifferent/derivation giữ đúngmode/source, không giả đọc raoriginal hoặc waivedquality bằngfinancialapproval. |

## 3. Ý kiến riêng về cashattestation

Đề xuất hợp lý cho oneoperatorMVP nhưng là **policy acceptance**, không independenttruthverification. Giữ conditions: receiptactualcashpaid/amountclear, statementbound employee/part/vendor/time/ref, relationship/context rõ, corporatehistory/companydirect/duplicate coverage đủ và không materialcontradiction. PERSONAL đơnlẻ khôngpass. Nếupolicykhôngactivated thì anonymousreceipt chỉgiúpamount, payercầnsource/xácnhậnkhác.

Lead bổ sung scopeonlyexpenseemployee→vendor, không reuseweakattestation choactualA/P hoặccompanyreceivedRA/RP. Named cashhandover/paymentreceipts theo source/rule tươngứng cho fundevents. ReceiptmethodCash dựkiến không actualcashpaid. Điều kiệnnumericclaritykhôngđược giảmvìattestation, Paid hoặcapproval.

Hai mức căn cứ nên thểhiện trongreport: source-supported theo profile và accepted-by-specific-attestation-policy. Không đặt tên VerifiedPayerIndependent chocùngmode hoặc giấuphụthuộcfirstpartyassertion. R5 đánhgiápolicydecision phải theo frozenrule, vàtruth/assurance củapayerdata phải cóscope/mode/giới hạn; sourceprep/human answers ghi nhưR3. Strongerdocumentaryproof cũng khôngforensicguarantee ởMVP.

Thay vì bắt bankstatementcho mọicash, ownercóthể chọn điều kiệnboundedattestation; nếumuốnstrict thì khối chứngtừcần thêmsource payer tươngứng. Bảnchưađượcownerchốtnênkhôngtựbật modehoặc coiđềxuấtdemopolicy là realcompanypolicy.

## 4. Đầu ra để tiếp tục R4

Chốt profilebefore/after và sourcepercheck, những bộ receipt/value/history dùng được, ownerabsence vàconfirmation đúngnghĩa. Điểm cụthể cần userchọn là cashanonymous cóboundedattestation vs yêu cầunguồnpayerbổsung. R4tiếptheo cònmonetaryrules/limits/authority/activeversion, R5gold/qualitymetrics, R7sourceformats/providerimplementation.

Khôngruntimecases,testharness,trialngườithật, activation hoặcmoneyexecution. Targetoldsnapshot/rawreviewgốc giữ nguyên; hai guard và scopedattestation đã được lead kiểmtra trong bản gửi người dùng, reviewer chưareviewlại bản mới.

# R4.2 — Nhận xét riêng trước reviewer

Ngày: 09/10/2026. Target [snapshot](TARGET_R4_EVIDENCE_RULES_DRAFT.md), dòng1–70. Ghi trước khi đọc reviewer; khôngcode, data thật, luậtcompanyactive hoặcruntime. Verdict ban đầu: **Cần chỉnh sửa** về acceptance mode/consumer use để cashattestation không bị coi là proofindependent hoặc mở qua qualitygate.

1. **Cashattestation là lựa chọn risk rõ — dòng39/41/66.** ReceiptpaidCash + statementbound đúngNV/expense/part + financecoveragecomplete không cócontradictions có thểđược demo-companypolicy chấpnhận, nhưngkhông independentlyobservedpayer. Cần outcome/sourcebasis rõ percheck và activation/version rõ; người dùng chọn PERSONALkhông là statementđủ. Nếu khôngactivatemode, dữkiệnpayercònunknownneedsource. Statementđủđãởintake thì khônghỏi lần2 chỉđểđếmstrongerproof. Khôngcam kếtphát hiệnreceipt của người khác nếuvượtnguồn/trustmodel cungcấp.

2. **Mỗi profile cần scope áp dụng — dòng37–40/49–52.** Profileanonymouscashattest đềxuất choexpenseNVpaidvendor thôi, không giải ngânA/P hoặc companyreceivedRA/RP bằngdeclalone. Treasuryreceipt cần source phía bênnhận và sự kiện đúngquan hệ. Một nhãnpaid hoặcexpenseinvoicebuyercompany không đủ. Bằngchứng bank đầy đủ thế nào phải là mapping xácđịnh theo source cófieldsreal, không LLM tự choSUCCESS nghĩareceived.

3. **Confirmation thay thế số mờ phảicósource rõ — dòng20/58.** Financialownerclaim3 không tự làm bill3?0 readable. Humanreading nếusourcehumanthựcsựđọcđượccóref/rationale hoặcsourcephụđủ, giữreadingrolequalr4.1. Sourcepartialdetaillack alcoholpolicy chưa xong dùtotalclear. Khôngreceipt authenticforensic hoặcVATlegalvalidate ởMVP; receiptissuer/statementpayer matching stillcheck.

4. **Absence0 + financecoverage — dòng39/52/54.** Phạmvi eventtypes/methods/case/asof và updatescó nguồn rõ; khôngghépcase trước Run. Khôngtìm companydirectevent trongledgerchỉbankkhôngcovercash vẫnkhôngNoCompanyPaid. Sourcecoveragecomplete cócăn cứ khácfullbankworldcrypto-proof; baselinegoldsource coverage authoritativeinscenario nhưngnói rõtrustedassumptions/fakes.

5. **Beforeadvance vsafter profile + applicability — dòng11–14.** Loannew requestedactualreceipt notneeded; oldadvance/history stillcheck. Claimwithoutadvance nókhôngloanIDcasefake. NOTAPPLICABLEpercheck khôngapprovewholecase. Fieldsneededbyrule predicate chưachốtmonetarycapởR4.2đúngscope; lịchsử/correcttiming material gatewholefinancialreport nhưngqualdifferentcolumns maypartialcheck.

Ý kiến balance: khôngbắt sao kê vớicashvàkhôngtựcho mọi anonymousreceipt+PERSONALauto. Nếuownerchooseboundedattestation, reportnormativeacceptance vàactualindependencekhácmodes, auditrole_scope vàR5goldđánhpolicydecisionkháctruthvalidation; corrupted/contradictorysource vẫnstop. ĐoextraHumanactualconfirmation vsintakestatementy nguyên, khônglàmritualasks.

Probe: anonymouscashreceipt+checkboxalone; completeattestatintake; financecompanypaidcontradiction; rawpaymentSUCCESSsemanticsunmapped; readablePaidbutblurmoney; crop-date/sourcealiascollisions; cashabsencefrombankonlyhistory; actual1vsapproved2; companycash receivedRA evidencevsNVexpenseattest. Chưagold/testimplemented.

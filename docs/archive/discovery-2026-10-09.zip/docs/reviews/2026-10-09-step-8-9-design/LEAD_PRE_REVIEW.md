# B8/B9 — Nhận xét riêng của lead trước reviewer

Ngày: 09/10/2026. Target [snapshot](TARGET_B8_B9_MVP_PROPOSAL.md), B8 dòng15–41, B9 dòng43–75, handoff dòng9–13. Ghi trước khi đọc hai reviewer. Không code, tests hoặc actualmoney.

## B8 — Verdict ban đầu: Có thể chốt ở mức walkthrough

Giữ đầy đủ vs đã từng phần xảy ra là nghĩa khác: approvaltarget3 mới tạo nghĩa vụ thựchiện3; xin “duyệt2” không tự xóa1. TạmứngB4 có quyền chọn mức thấp hơn, quyếttoánB8 phải giữ nghĩa vụ hoặc re-check entitlement/policy trước sốkhác. Không âmthầm làm simpleMVP thành installmentapproval. Return/reject/hold khôngxóa ứng/actualpayment.

Các điểm muốn kiểm tra:

- Quyết định về acceptedexpense/cách tính và quyết định cho thựchiệnchi/thu không thay proof ofpayment/quality/khai báo. B8 đã hardgate, cần giữ scope/quyền confirmfact vs approval rõ ởR4.
- Điều kiện cuối chưa đạt chưausable; conditionaldecisionđã có, không claim thiếu hết. Decisionđổi amount/direction/scope đi B7 re-eval. Role demo notauth.
- Rejection/noresponse cónextowner/missingfacts khôngtự generatefullrefund. S0chỉ no-money khi toàn scope resolved; oldprocessedexactcopy khôngnew approval/payment chỉ vìinput.
- Ngoạiluồng chưaresolved chặn final; manualdecision khônginjectS đểcleartrách nhiệm. BoundaryChallengeA vẫnrủirođãcôngbố, khôngpolicycomplianceverified.

## B9 — Verdict ban đầu: Cần chỉnh sửa một điểm về permission sau reversal

Nhận3 hoànchiphí sauE5/adv2→net0; nhậnreturn0,7 sauE3,3/A4→net0 là kiểmtra gross/nets khácchiều, khôngclipactual. Người chi ngoàiapp, guardlatestcontext/Stopknown chỉlocalworkflow vàlateevent vẫnghi. Close cầnsource/mốc/obligationsallresolved, khôngnútPaid/S0 đơnđộc.

Điểm chính cần làm rõ: “đã fulfilled” tiêu dùng quyềnthựchiện của decision, khác “attemptfailed trước khi fulfilled”. Duyệt3, đãreceived3rồireturned/reversed3 khôngautomatically oldapproval3chochi lại. B9 nói re-checkB5/B7 đãđúng nhưng cầnthểhiện phải xét quyềnthựchiện/lầnquyếtđịnhmới hoặc rule tái dùng rõ. Nhữngfacts mới có thể làmnet thayđổi nhưngkhôngtự restoreauthorization.

Các kiểmtra handoff:

- Quyếtđịnh target3, actualreceived1, no pending/issues/changedentitlement thì remaining2 có thểtrongcùngpermission. Reportremaining2khôngđồngnghĩarevokepermission vìversionchangedfulfillment; sourcefinancialnewkhácoutstandingentitlementthì checkphần ảnhhưởng.
- Nếu pending2 chưaclear, actual1 khôngcho tạo execution2mới. Incidentwrongrecipient hoặc overpay làblock, chưa phép “bù” từ zeroA_received.
- Actualnet0 vàallknownhistoryscope chưađủđóng nếuoutscopeofcalc-but-inscopeofsettlementissue stillunresolved. Finalrefusalkhôngđịnhallrightfullyzero nếuadv/rightsremain.
- Close ởT1 và latefinancialsourceT2: giữT1/rerunaffected/reportcurrentstatus hoặc adjustment linked, khôngoverwriteorautopay. Thếgiớingoàiapp khôngbiếtthìdisclosecovereddata, khôngpollbankallfirm.

Phạmvi vàvídụ cầnchốtởwalkthrough, khôngyêucầuschema/concurrencyenginebank ngay. Hai reviewerfocus riêng; lead kiểmtra jointcontract mộtwriter. Phép thử proposed3vsapprove2, balancednonewtransfer, partial1/pending2, failedbeforefulfillment vsrefundafterfulfilled, actualpaybothdirections, rejectedwithoutstandingadvance. Chưatestharnessđãchạy.

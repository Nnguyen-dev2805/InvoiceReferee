**Verdict: Cần chỉnh sửa**

Phạm vi review chỉ gồm **Bước 9 và handoff B7→B8→B9**. Tôi không đánh giá lại policy quyết định của B8, không coi schema/source policy R4 chưa có là lỗi, và không giả định hệ thống có khả năng điều khiển ngân hàng. Brief yêu cầu hệ thống biết lúc nào phải dừng, chuyển đúng vấn đề cho con người và không khẳng định khi dữ liệu còn nghi vấn (Challenge\_Brief\_OrganizationAI\_VN.docx.md (line 43), dòng 53–57).

### B9-R01 — Quan trọng — Overpayment và wrong-recipient đang bị gom vào cùng semantics “chưa hoàn thành”

**Fact:** TARGET\_B8\_B9\_MVP\_PROPOSAL.md (line 60) gom “sai số/người/loại, vượt số quyết định” vào một nhánh rồi ghi “chưa ghi hoàn thành”.

**Counterexample:** quyết định chi A 3 triệu, nhưng A thực nhận 4 triệu. Đây khác căn bản với trường hợp 3 triệu chuyển nhầm sang B. Ở case 4 triệu đúng A, nghĩa vụ 3 triệu đã được thực hiện về phía A, đồng thời phát sinh **1 triệu overpayment chưa giải quyết**. Nếu toàn bộ vẫn là “chưa hoàn thành”, hệ thống có thể giữ nghĩa vụ 3 triệu như còn mở hoặc tạo tình trạng treo không rõ.

**Impact:** nguy cơ double payment hoặc không thể xác định closure chính xác.

**Minimal fix:** tách ít nhất hai trường hợp: đúng người nhưng vượt số → ghi toàn bộ money event, fulfillment của nghĩa vụ cũ chỉ tới số được quyết định, phần vượt thành ngoại lệ riêng chưa resolved; sai người → nghĩa vụ đối với người đúng vẫn chưa fulfilled, money event sai người giữ riêng. Không tự tạo recovery/cấn trừ.

**Negative probe:** approve A=3; receipt A=4 → không được tạo thêm payment 3, không được tự coi excess 1 là khoản A phải hoàn theo policy chưa xác định.

### B9-R02 — Vừa — Pending/unknown có thể bị giữ vô thời hạn mà chưa có trigger chuyển tiếp cụ thể

**Fact:** dòng 58 quy định giữ pending/unknown, “hỏi người có nguồn khi cần”, không cộng vào thực nhận và không tạo thực hiện trùng. Phần chống double-payment là tốt.

**Inference:** “khi cần” chưa xác định khi nào workflow chuyển từ chờ sang một escalation có owner/câu hỏi rõ. Điều này có thể biến case thành pending vô thời hạn, trong khi Challenge A chấm trực tiếp khả năng chuyển tiếp và chất lượng câu hỏi.

**Counterexample:** lệnh 2 triệu ở trạng thái pending, nguồn cuối cùng chỉ cập nhật đến ngày T; qua checkpoint đối chiếu vẫn không có kết quả. Operator không biết phải hỏi ai hoặc cần xác minh điều gì.

**Minimal fix:** thêm trigger nghiệp vụ trung tính, ví dụ khi tới mốc đối chiếu đã công bố mà source vẫn không đủ xác định receipt/outcome, chuyển thành câu hỏi cụ thể cho owner của nguồn. Không cần invent SLA hoặc luật ngân hàng.

**Negative probe:** pending không thay đổi qua checkpoint → hệ thống phải tạo escalation cụ thể, không tự coi failed/zero và cũng không nằm im mãi.

### B9-R03 — Vừa — Có khoảng trống stale-change sau handoff nhưng trước hành động tiền bên ngoài

**Fact:** dòng 47 re-check ngay trước khi **tạo/giao gói thực hiện** và thừa nhận app không bảo đảm dừng lệnh ngân hàng bên ngoài. Dòng 61 cũng đúng khi nói Stop/thu hồi không chứng minh tiền đã bị hủy.

**Counterexample:** 09:00 giao gói chi 3 triệu; 09:02 xuất hiện source mới làm entitlement đổi; 09:05 người tài chính vẫn thực hiện từ gói cũ.

**Minimal fix:** quy định handoff còn mở phải mang revision/mốc nguồn; source mới ảnh hưởng entitlement thì đánh dấu handoff đó stale/Stop trong workflow và yêu cầu re-check trước hành động tiếp theo. Nếu tiền đã đi, ghi sự kiện thật và xử lý ngoại lệ; không tuyên bố app đã hủy tiền bên ngoài.

**Negative probe:** entitlement đổi sau handoff, trước receipt → gói cũ không còn được coi là cơ sở cho hành động mới.

Hai điểm mạnh đáng giữ nguyên: thứ nhất, dòng 49–61 phân biệt đúng **người trả với người thực nhận**, receipt thực tế với nhãn Paid/Submitted, partial với pending/failure, và không giả khả năng auto-retry/cancel ngân hàng. Thứ hai, dòng 64 và 68–75 có nền closure khá chắc: cùng event không double-count, unknown không thành 0, closure có **as-of/source coverage**, nghĩa vụ/ngoại lệ khác phải resolved, exact replay không tạo tiền mới, và correction sau close tạo bổ sung liên kết thay vì sửa lịch sử.

**Phạm vi:** BƯỚC 8, Mục 1–2 của snapshot docs/reviews/2026-10-09-step-8-9-design/TARGET\_B8\_B9\_MVP\_PROPOSAL.md; B9 chỉ được đọc để kiểm tra contract đầu ra mà B8 giao xuống. Đây là review thiết kế walkthrough, không xác nhận tính hợp pháp tài chính hay policy thực tế.

### B8-R01 — Quan trọng — Fixed human financial checkpoint còn có rủi ro trực tiếp với Challenge A

**Snapshot:** TARGET\_B8\_B9\_MVP\_PROPOSAL.md:19-25. B8 yêu cầu người có quyền tài chính ra quyết định cho cả S=+3, S=-0,7 và S=0. Trong khi brief yêu cầu các trường hợp thường quy phải được “xử lý tự động hoàn toàn” và không được chuyển tiếp quá mức (Challenge\_Brief\_OrganizationAI\_VN.docx.md:47-59,79-83).

**Fact:** thiết kế hiện chủ động giữ B8 là checkpoint tài chính của con người. **Inference:** chưa đủ căn cứ để kết luận BTC sẽ coi checkpoint bắt buộc này là phù hợp với ba routine cases của Challenge A; đây là risk về competition fit, không phải lỗi nghiệp vụ đã được chứng minh.

**Counterexample:** hồ sơ +3 triệu hoàn toàn rõ nguồn, rule, số, authority và không có ngoại lệ nhưng vẫn luôn chờ một người bấm duyệt. Verify có thể nhìn thấy đây là một escalation ở routine case.

**Impact:** có thể mất tiêu chí “không can thiệp các trường hợp đơn giản”, dù B7 tự động hóa tốt.

**Minimal fix / negative probe:** không âm thầm bỏ B8. Ghi rõ risk này là chưa xác nhận và tạo probe gồm ba routine cases để kiểm tra cách BTC tính checkpoint tài chính bắt buộc. Chỉ đổi boundary sau khi có căn cứ.

### B8-R02 — Vừa — Conditional decision chưa tách đủ “điều kiện fact” khỏi một quyết định quyền lực khác

**Snapshot:** TARGET\_B8\_B9\_MVP\_PROPOSAL.md:35.

Thiết kế cho phép ghi quyết định có điều kiện và không yêu cầu duyệt lại nếu cách xác định điều kiện đã rõ. Điều này hợp lý với điều kiện thuần fact, nhưng câu hiện tại chưa khóa trường hợp điều kiện vẫn chứa judgment/authority.

**Counterexample:** “Duyệt 3 triệu nếu trưởng bộ phận đồng ý khoản này cần thiết.” Việc trưởng bộ phận “đồng ý” có thể là một quyết định nghiệp vụ tiếp theo, khác với fact kiểu “đã có biên nhận gốc”. Nếu cả hai cùng được xem là condition satisfaction, B9 có thể nhận một quyết định tưởng đã hoàn chỉnh.

**Impact:** ranh giới giữa factual confirmation và rightful financial decision bị mờ, ảnh hưởng trực tiếp tính audit được của handoff.

**Minimal fix:** quy định ở mức walkthrough: conditional approval chỉ được handoff khi phần còn lại là predicate có thể xác minh khách quan bằng source/role đã định. Nếu còn discretion hoặc approval của người khác thì B8 vẫn chưa complete. Negative probe: “approve if receipt exists” được tiếp tục khi receipt đủ; “approve if manager agrees” không được tự coi là fact completion.

### B8-R03 — Vừa — “Duyệt 2 trong đề xuất 3” cần tách rõ partial approval khỏi chỉ dẫn thực hiện theo đợt

**Snapshot:** TARGET\_B8\_B9\_MVP\_PROPOSAL.md:33 và contract B9 được tiêu thụ tại :41, :57.

Line 33 xử lý đúng việc không được tự biến “duyệt 2” thành final entitlement 2\. Tuy nhiên nó gom cả khả năng “đề nghị chi từng phần” vào luồng cần làm rõ/out-of-flow, trong khi line 41 đã cho phép một quyết định 3 được thực hiện thực tế 1 rồi tiếp tục 2 mà không mặc định duyệt lại.

**Counterexample:** approver nói rõ: “Tôi duyệt toàn bộ 3 triệu; hôm nay chỉ thực hiện 2 triệu.” Đây không phải partial financial approval 2/3 mà là full approval 3 cộng execution direction 2-now.

**Impact:** nếu không tách hai nghĩa, operator có thể re-approve không cần thiết hoặc sai hơn là sửa decision amount từ 3 xuống 2.

**Minimal fix:** thêm một rule ngắn: amount được quyết định và amount được phép thực hiện ở đợt hiện tại là hai ý nghĩa riêng. Probe cả ba câu: “duyệt 2”, “duyệt đủ 3 nhưng chi 2 trước”, “duyệt 3, thực nhận mới 1”.

### Hai điểm mạnh

Thứ nhất, :26-29 giữ đúng nghĩa của return/refusal: từ chối không xóa tiền đã xảy ra, advance hay nghĩa vụ còn tồn tại; sửa fact/số phải quay lại B7 thay vì người duyệt nhập một final number tùy ý.

Thứ hai, :37-41 xử lý khá chặt stale/reuse: thay đổi ảnh hưởng phải đánh giá lại, ghi chú vô hại không mặc định làm mất approval, decision bên ngoài không tự trở thành approval mới, conflict không được giải bằng “latest wins”, và actual fulfillment 1/3 không ép duyệt lại 2 còn lại. Đây là nền tốt cho audit và B9 handoff.

**Verdict: Cần chỉnh sửa**

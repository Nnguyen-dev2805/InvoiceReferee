# Review Bước 8–9 và bản đã bổ sung để chủ dự án review

Ngày: 09/10/2026. Hai reviewer kết luận **Cần chỉnh sửa** đối với [snapshot](TARGET_B8_B9_MVP_PROPOSAL.md). Lead đánh giá **Có thể chốt ở mức walkthrough** sau các bổ sung tại [proposal hiện tại](../../discovery/B8_B9_MVP_PROPOSAL.md); đang chờ chủ dự án review. Không gọi đây là reviewer PASS bản sau chỉnh hoặc runtime verified.

## 1. Phương pháp

- B8: `chatgpt-web/gpt-5.6-sol`, **High**, Faraday, ID `01a11e07-8ccc-7ea3-abb5-5c9078f55acb`; [trả lời](REVIEWER_B8.md).
- B9: cùng model/mức, Bohr, ID `01a11e07-8d32-7d33-9a93-dd3c9ed3e5c0`; [trả lời](REVIEWER_B9.md).
- Hai scope read-only, context không fork history, không đọc nhận xét lead hoặc review trước; target chung bất biến. Một lượt mỗi reviewer, hoàn thành và đóng. [Lead pre-review](LEAD_PRE_REVIEW.md) ghi/hash trước kết quả; [evidence](review-evidence.json) lưu trước/sau.
- Parent một writer cho handoff, tự đối chiếu hai bước. Không đọc code/chạy pipeline/Verify/live money. Ba ví dụ số integer-VND đúng arithmetic (receive3/return0,7/receive1), không xác minh nguồn/thực thi.
- [Brief gốc](../../Challenge_Brief_OrganizationAI_VN.docx.md) Mục2.A vẫn là authority. [UW Payment Options](https://finance.uw.edu/travel/WDpaymentoptions) là nguồn tham khảo Paid/Reconciled không chứng minh receipt thành công; không dùng ngưỡng/luật của UW cho công ty MVP.

## 2. Phán định B8

| ID / mức reviewer | Nhận xét | Phán định của lead / bổ sung |
| --- | --- | --- |
| B8-R01 / Quan trọng, rủi ro chưa xác minh | Dòng19–25 humanfinancialcheckpoint có thể bị BTC tính là escalation routine. | Giữ rủi ro và báo cáo toàn công sức con người; không sửa bỏ B8. Đã được công bố tại draft dòng83 và B7, nên không là omission mới. Chốt walkthrough không là chốt competition compliance; cần bằng chứng/đánh giá theo boundary đã công bố. |
| B8-R02 / Vừa | Dòng35 điều kiện fact khác quyết định quyền của một người khác còn thiếu. | Đồng ý. Bản bổ sung phân biệt receipt source với manager decision; chưa có quyết định quyền cần thiết thì chưa usable. Có quyết định thật đúng quyền/scope theo policy thì ghi/check quan hệ, không bắt người duyệt đầu bấm lại máy móc. Không thêm genericapprovalengine. |
| B8-R03 / Vừa | Dòng33/41/57: partialapproval khác fullapproval cộng chỉ dẫn chi2 trước. | Đồng ý về semantics; giữ tổng decision3 riêng với chỉ dẫn thực hiện2. Không thêm tính năng lịch chi/lệnh đợt. Actualreceived2 được ghi và nghĩa vụ1 chưa hoàn thành; không đổi totaldecision thành2 hoặc đóng. |

## 3. Phán định B9

| ID / mức reviewer | Nhận xét | Phán định của lead / bổ sung |
| --- | --- | --- |
| B9-R01 / Quan trọng | Dòng60 nhận vượt số khác chuyển nhầm người, không gom chưa hoàn thành. | Đồng ý mạnh. Khi nguồn rõ cùng nghĩa vụ và đúng A nhận4 cho quyết định3: giữ rawevent4, fulfillment của phần3 đã đủ, excess1 là ngoại lệ chưa resolved, không trả3 lần nữa hoặc clip4→3. Chuyển3 cho B giữ sai lệch, chưa fulfilled đối với A; chưa tự mở chi bù. Không tự đặt recovery quyền/legaldebt cho excess. |
| B9-R02 / Vừa | Dòng58 pending thiếu mốc hỏi owner cụ thể. | Đồng ý thêm trigger ở lần/mốc đối chiếu đã công bố: source vẫn thiếu outcome thì hỏi chủ nguồn về đúng event/quan hệ. Không tự đặt SLA ngân hàng hoặc scheduler cho MVP. Trigger có thể là operator gọi kiểm tra ở mốc cần thiết; không hứa backgroundmonitor đã triển khai. |
| B9-R03 / Vừa | Dòng47 gói có thể stale sau handoff trước physical action. | Đồng ý và giữ giới hạn. Version/mốc source trên gói, nguồn mới ảnh hưởng đánh dấu gói cần re-check trong app, người thực hiện kiểm tra trước hành động. Không bảo đảm người dùng bản giấy cũ bị ngân hàng chặn; lateactualevents giữ thật và xử lý. |

## 4. Bổ sung riêng và scope đã giữ

Lead thêm guard permission sau fulfilled rồi refund/reversal: facts/net có thể thay đổi nhưng approval đã dùng đủ không tự cấp quyền chi lại. Re-check B7/quyền và phần mới qua B8 theo policy. Failedattempt trước receipt khác fulfilled rồi return; không ép re-approve cho mọi lần thực hiện còn thiếu khi quyết định vẫn áp dụng.

MVP giữ complete financial decision/return/refusal/hold, xử lý actual partial receipt để không tạo thêm tiền, chưa biến thành plannedinstallmentapproval. Giữ S0 khôngtransfer0, refusal khôngxóa ứng hoặc tựfullrefund, closure onlysourceasof/allobligationsresolved. Raw facts, decision, actualevent và changehistory riêng.

Những guard được bổ sung là nghĩa nghiệp vụ/điểm nối, không policy mới về ai có quyền gì, bank execution hoặc production architecture. Source contracts/rulebook/realparticipant evidence còn phải chốt sau. Hai reviewer chưa review lại bản bổ sung; lead đã kiểm tra logic và tài liệu để trình chủ dự án.

## 5. Bản gửi chủ dự án

[Proposal B8/B9](../../discovery/B8_B9_MVP_PROPOSAL.md) là bản đọc chính, gồm case3, các nhánh và checklist đóng. [Walkthrough](../../discovery/R2_CASE_WALKTHROUGH.md) đã tích hợp B7 được đồng ý và liên kết proposal; B8/B9 chưa được người dùng chốt. Các snapshot/model/evidence gốc giữ nguyên. Không Git commit hoặc chỉnh code.

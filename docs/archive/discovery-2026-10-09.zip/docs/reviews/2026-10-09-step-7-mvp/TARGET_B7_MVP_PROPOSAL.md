# Bước 7 — Đề xuất thu gọn phạm vi tự động cho MVP

Ngày: 09/10/2026 · Trạng thái: **ĐỀ XUẤT ĐỂ REVIEW/THẢO LUẬN, CHƯA THAY BẢN WALKTHROUGH HIỆN TẠI**.

Mục tiêu: kiểm tra hồ sơ chi phí và chuẩn bị bảng đối chiếu/số quyết toán có căn cứ, hoặc hỏi/chuyển đúng phần chưa tự xử lý được. Một nhân viên/một công việc/VND trong phạm vi nguồn rõ; giữ B8 quyết định tài chính và B9 chi/thu bởi con người. Source contract/policy/quyền cụ thể chốt ở R4; chưa có code/Verify/trial chứng minh.

## 1. Luồng xử lý chính

1. **Xác định phạm vi và nguồn:** khoản/phần đang đề nghị, các khoản lịch sử liên quan và sự kiện tiền cùng phạm vi; raw source/lời khai/fact/xác nhận giữ riêng. Không lấy riêng bill mới trừ toàn bộ tiền ứng của công việc nếu chưa rõ quan hệ.
2. **Kiểm tra từng khoản/phần:** chất lượng dữ kiện bắt buộc, số học, công việc và quy tắc áp dụng, người trả/phần đã được công ty trả, trùng nghĩa vụ và lịch sử. Thiếu một nguồn không ngăn kiểm tra độc lập phần đã đủ, nhưng chặn kết luận cuối bị ảnh hưởng. Không suy PERSONAL/tên trên invoice là payer thật; không cộng các representation của cùng khoản.
3. **Tổng hợp các phần đủ căn cứ:** giữ số thực tế/khai báo, phần được chấp nhận/phần không đủ điều kiện và lý do. Cấm rõ/không có ngoại lệ áp dụng thì kết luận phần đó; không tự clip raw số về limit, chỉ tính eligible partial amount nếu rulebook quy định rõ.
4. **Đối chiếu tiền ứng/chi trả lịch sử và tính:** chỉ dùng sự kiện thực nhận theo nguồn phù hợp, không phải số xin/duyệt/nhãn Paid. Pending, quan hệ hoặc số chưa rõ không thành 0. Một phần event không đóng góp hai lần vào các nhóm tiền.
5. **Xuất báo cáo:** bảng đối chiếu và refs/rules; số chi/thu khi đủ căn cứ; phần còn vướng, người xử lý và câu hỏi cụ thể. Phiên bản/mốc nguồn được ghi; dữ liệu mới làm kiểm tra lại phần ảnh hưởng, giữ kết quả và tiền đã xảy ra. Chưa tạo giao dịch ngân hàng hoặc kết luận hồ sơ đã đóng.

## 2. Phạm vi được tự tính

| Hỗ trợ khi quan hệ/nguồn/quy định đủ rõ | Giới hạn |
| --- | --- |
| Khoản chi nhân viên đã thanh toán, được chấp nhận; phần công ty trả trực tiếp | Không đưa phần company-paid vào phần cần hoàn nhân viên; bill nhiều payer dùng phần có nguồn, không một label cả bill. |
| Tạm ứng thực nhận, hoàn ứng thực tế; hoàn chi phí trước đó và tiền nhân viên đã trả lại khoản hoàn chi phí | Giữ gross events và quan hệ, dùng số ròng đúng phạm vi. Không ứng là 0 khi có nguồn xác định; từng nhận rồi hoàn hết vẫn giữ lịch sử. |
| Nộp lại/bổ sung có quan hệ với hồ sơ và tiền đã xử lý | Một khoản tính một lần; bổ sung xét cùng khoản lịch sử/phạm vi, không tự reuse approval hoặc tạo tiền chi mới. |
| Vendor refund làm giảm phần nhân viên đã chịu, đúng khoản/phần, người thực nhận và cách xử lý rõ theo policy | Giữ khoản chi ban đầu và refund có nguồn. Ví dụ A trả hotel 3 rồi A nhận refund 1 đúng phần, toàn bộ phần còn lại hợp lệ: phần chi phí A thực chịu dùng cho đối chiếu là 2. Không dùng quy tắc này cho refund về bên khác/quyền hưởng chưa rõ. |

Đây là danh sách nghĩa nghiệp vụ, chưa cam kết tự khớp mọi bank statement, transaction gộp hoặc tình huống nhiều người. Không thay chuẩn bằng chứng để làm routine qua nhanh; không bắt hỏi lại mọi nguồn đã đủ.

## 3. Công thức hiển thị gọn, giữ lịch sử gốc

Khi cùng phạm vi đã đầy đủ và các thành phần ảnh hưởng đều rõ:

**Số đề xuất = Chi phí hợp lệ nhân viên thực chịu − Ứng ròng đã nhận − Hoàn chi phí ròng đã nhận trước đó.**

- Chi phí nhân viên thực chịu là phần đã thanh toán được policy chấp nhận, xét các điều chỉnh/refund thuộc phạm vi hỗ trợ; không phải whole-company cost hoặc chỉ con số NV tự gọi PERSONAL.
- Ứng ròng = ứng A thực nhận − tiền công ty thực nhận lại đúng khoản ứng. Hoàn chi phí ròng = khoản hoàn chi phí A thực nhận − tiền công ty thực nhận lại đúng khoản hoàn đó. Giữ từng gross event, không vừa dùng net vừa cộng return lần nữa.
- Nguồn/trạng thái/phân bổ còn chưa rõ, chờ có thể đổi kết quả, tiền trả lại vượt quan hệ đã xác định hoặc điều chỉnh ngoài phạm vi: chưa áp dụng công thức cuối. Không clip facts/giả refund để có net phù hợp.
- S dương: đề xuất công ty trả thêm; âm: đề xuất nhân viên hoàn trong nhóm quyết toán này; 0: nhóm thành phần đã đối chiếu cân bằng. Chưa là quyết định quyền thu/chi hoặc toàn hồ sơ không còn nghĩa vụ. Số thực thi integer VND.

Case giả lập nguồn đủ, không có điều chỉnh/lịch sử khác: tổng chi phí 8 triệu; company direct 3; phần A thực chịu hợp lệ 5; ứng ròng 2; hoàn chi phí trước đó 0 → S=3 triệu. Nếu đã thực hoàn chi phí 3 → S=0. Nếu sau đó bổ sung 0,5 hợp lệ cùng phạm vi → chi phí lũy kế 5,5 → S=0,5.

## 4. Các ngoại lệ cần chuyển xử lý

Vendor refund về bên khác hoặc quyền hưởng chưa rõ; thu hồi phần cá nhân công ty trả trực tiếp; double payment/vượt nghĩa vụ hoặc phân bổ phức tạp chưa có quy tắc tự động: giữ nguồn/sự kiện, nêu rõ phần tiền/quan hệ/điều cần giải quyết và chuyển người có quyền. Không tăng E, chèn khoản vào công thức hay tự cấn trừ chỉ để ra một net toàn cục.

Ví dụ A trả hotel 3 nhưng vendor refund 1 về công ty: giữ sự kiện và hỏi/xử lý quyền hưởng/quan hệ có căn cứ. Không tự giảm phần A còn được hoàn xuống 2 hoặc tăng chi phí công việc về 3 để bỏ qua khoản công ty đang giữ. Nếu ngoại lệ có thể đổi số cuối/nghĩa vụ hồ sơ thì **chưa đưa kết quả cuối đủ để chi/thu hoặc đóng hồ sơ**; phần đã kiểm tra vẫn hiển thị. Trường hợp đã xác định chỉ ảnh hưởng phần độc lập không liên quan đến phép tính hiện tại thì ghi riêng, không coi S=0 là hết mọi nghĩa vụ.

Người có quyền xử lý ngoại lệ trong quy trình thích hợp và cung cấp kết quả/nguồn. Một nút “đã xử lý” hay câu “tôi duyệt” không tự biến ngoại lệ thành số A/P/E mới. Chỉ quay lại luồng tự tính khi có dữ kiện/cách biểu diễn và rule phù hợp; hoặc giữ kết quả xử lý ngoài luồng cùng căn cứ và giới hạn. MVP không tự định đoạt quyền giữa ba bên, cưỡng chế thu hồi/cấn trừ hoặc kiểm soát ngân hàng.

## 5. Kết quả và vai trò AI

- **Đủ căn cứ trong phạm vi:** lập báo cáo/số đề xuất cho B8, routine không có câu hỏi thừa; B8 vẫn là checkpoint tài chính đã thống nhất.
- **Chưa rõ fact:** hỏi đúng người với refs/phần cần xác minh; câu trả lời được ghi cùng nguồn/vai, kiểm tra lại phần ảnh hưởng.
- **Ngoài phạm vi quy định/tự động hoặc vượt quyền:** nêu nguyên nhân riêng và người có quyền; không giả missing fact hay bỏ sự kiện để tiếp tục.
- **Không đủ điều kiện rõ:** ghi phần bị loại và rule/ref; chưa tự từ chối mọi khoản. **Lỗi dịch vụ:** báo chưa kiểm tra xong, không gán approval hoặc refusal nghiệp vụ.

AI đề xuất đọc/liên kết nguồn và câu hỏi; chương trình áp dụng rule/quality/số học/guard. Không tự nới hạn mức/quyền/nguồn vì confidence. Boundary routine của Challenge A vẫn cần chứng minh/xác nhận; bản thu gọn không tự làm thay đổi metric hoặc bảo đảm đạt thi.

Phép thử thiết kế: case3; already-paid0; supplement0,5; ứngunknown/pending; payer split có nguồn; một expense nhiều documents; hotel3/refund1 tới A vscompany; company-paid personal recovery; một event gắn hai nhóm; nguồn mới sau kết quả. Chưa là gold/harness/runtime evidence.

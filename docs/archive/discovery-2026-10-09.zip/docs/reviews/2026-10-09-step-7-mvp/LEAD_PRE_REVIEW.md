# Nhận xét riêng trước reviewer — B7 MVP thu gọn

Ngày: 09/10/2026. Target [snapshot](TARGET_B7_MVP_PROPOSAL.md), dòng 1–56. Ghi trước khi đọc reviewer, không code/test/luật hay money execution.

Verdict ban đầu: **Có thể chốt ở mức đề xuất MVP**. Luồng chính vẫn giữ nguồn/quality/rule/cumulative scope và thực nhận mỗi chiều, không bỏ sự kiện tiền để đơn giản. Ngoại lệ cross-recipient/recovery được ghi với financial materiality gate, không ép engine tự định quyền hưởng. Các contract chi tiết chốt R4, không cần hoàn tất ở proposal này.

Những điểm muốn kiểm tra/chỉnh wording nếu cần:

- Dòng 22: same-recipient không tự đủ. Cần đúng khoản/phần, nguồn thực nhận và cách xử lý được policy chấp nhận; target đã có các điều kiện này. Refund nhiều phần/người không tự giảm toàn E. Không bắt mọi hồ sơ tìm dấu phủ định refund khi nguồn theo phạm vi/policy đã đủ, cũng không giả biết giao dịch ngoài nguồn cung cấp.
- Dòng 30–35: ba số net để giải thích vẫn giữ gross events. Ví dụ E5/A2/RA1/P0/RP0 → netA1, S4; E5/A2/P3/RP1 → netP2, S1 khi quan hệ đủ rõ. Không suy RA/RP là refund vendor hoặc dùng negative net khi return vượt quan hệ đã xác định. Thiếu thành phần không0.
- Dòng 41–45: không được biến external resolution thành manual P/E bất kỳ. Giữ outcome nguồn/vai/phạm vi và quan hệ cần kiểm tra, chỉ về auto khi có rule/representation đủ. Nếu không có thì giữ là kết quả ngoài luồng, chưa gọi S bằng0 là closure. Đây là path bàn giao, không bank/recoveryengine.
- Dòng 51: ngoài phạm vi tự động khác ngoài businesspolicy khác vượt authority. Việc tiền company-held đã biết nhưng processor chưa hỗ trợ không phải factuncertain. Cần reason riêng để hỏi đúng người và đo escalation không sai taxonomy.
- Dòng 49/54: routinecheck output chưa là financialapproval/payment. BoundaryChallengeA vẫn mở, khôngclaim thu gọn khiến compliance tự đúng hoặc bỏ humancheckpoint.

Giữ proposal khoảng một trang ý chính cho người dùng: đối chiếu → phân phần đủ/không đủ/cần rõ → net trong scope → báo cáo. Chỉ thêm ràng buộc có counterexample thực sự phá kết quả, tránh mỗi review mở thêm nghiệp vụ rồi biến MVP thành kế toán toàn công ty. Bản cũ và snapshot review gốc không sửa.

# Review bản đề xuất B7 MVP thu gọn

Ngày: 09/10/2026. Reviewer: **Cần chỉnh sửa** trên snapshot trước bổ sung. Lead: **Có thể chốt ở mức đề xuất MVP** sau ba bổ sung rõ nghĩa, đang chờ chủ dự án quyết định; không phải reviewer PASS bản đã chỉnh hoặc policy đã hoạt động.

Target hiện tại: [B7 MVP proposal](../../discovery/B7_MVP_PROPOSAL.md); [snapshot được review](TARGET_B7_MVP_PROPOSAL.md). Bản walkthrough chính giữ nguyên. Chỉ tài liệu thiết kế, không đọc code/test/live payment/trial.

## Phương pháp

Reviewer độc lập `chatgpt-web/gpt-5.6-sol`, **High**, Aquinas, ID `01a11df9-baa1-7fd0-afe9-c9b069ccc5d7`, một lượt hoàn thành và đã đóng. Không fork lịch sử hoặc đọc lead notes/old reviews. [Kết quả reviewer](REVIEWER.md), [nhận xét riêng của lead](LEAD_PRE_REVIEW.md) lưu/hash trước khi đọc reviewer, [evidence](review-evidence.json) giữ hash trước/sau và requested model/effort.

## Phán định ba nhận xét

| ID / mức reviewer | Chứng cứ và nhận xét | Phán định của lead / đã bổ sung vào proposal |
| --- | --- | --- |
| B7M-R01 / Quan trọng | Snapshot dòng12/28–34: nguồn chưa đủ coverage không chứng minh event=0. | Đồng ý. Chốt 0 cần scope người/công việc/loại sự kiện/thời gian tới mốc đối chiếu theo policy. Ledger chỉ tới15/10 nhưng đang đối chiếu giả lập21/10 không chứng minh không có khoản hoàn20/10. Tại mốc15/10 không đòi dữ liệu tương lai. Nguồn chưa đủ → unknown/hỏi phần ảnh hưởng, không ask-all hay default0. |
| B7M-R02 / Vừa | Dòng22: cùng invoice và refund vào A chưa chứng minh thuộc employee-borne portion. | Đồng ý; target đã nêu đúng phần/policy, thêm counterexample làm guard cụ thể hơn. Hotel3/A2/company1, refund1 vào A nhưng thuộc company-paid fee thì không tự giảm E_A từ2 xuống1. Refund phải thuộc phần employee-borne đang xét và phân bổ không vượt phần tương ứng. Chưa rõ → ngoại lệ, không thêm bộ máy quyết định quyền ba bên. |
| B7M-R03 / Quan trọng | Dòng41–45: nghĩa vụ ngoài auto-path trong cùng settlement không được thành footnote không chặn cuối. | Đồng ý. Auto-scope khác settlement boundary. Có componentS3 và company-paid recovery1 chưa xử lý trong cùng boundary: giữ hai phần, chưa final-action ready; không tự net2/chi3. Quan hệ thực sự ngoài boundary mới không block check này; chưa rõ thì chờ. |

Ba điểm là ràng buộc áp dụng/safety đã thống nhất từ các bước trước, không tạo tính năng tài chính mới. Lead đã cập nhật vào bản đề xuất riêng, giữ snapshot và phản biện gốc; chưa chạy lại reviewer trên bản sau bổ sung.

## Ý kiến riêng

Giữ năm công việc: xác định nguồn/phạm vi → kiểm tra khoản → phân phần được chấp nhận → tính trong scope đủ căn cứ → báo cáo/câu hỏi. Hiển thị công thức ba số net là cách giải thích, không xóa gross events; 5 ví dụ integer-VND đã được kiểm tra arithmetic, không chứng minh trích xuất/policy/phân bổ đúng.

Lead làm rõ thêm thuật ngữ chi phí nhân viên thực chịu: gồm phần NV đã thanh toán bằng tiền ứng và tự bù, sau refund đúng phần; không chỉ là tiền tự bỏ túi. Nếu trừ tiền ứng trong E rồi trừ ứng ròng nữa sẽ đếm hai lần. Đây là giữ nghĩa E đã thống nhất, không thêm nhóm nghĩa vụ.

Hỗ trợ routine chi phí, company direct, ứng/hoàn ứng, lịch sử hoàn chi phí và refund thuộc đúng employee portion với nguồn/policy rõ. Ngoại lệ cross-recipient, recovery company-paid, double payment và phân bổ phức tạp được ghi/bàn giao với nguồn. Không tự giải quyết mọi quyền hưởng/thu hồi và không bỏ các ngoại lệ khỏi hồ sơ để có net đẹp.

Kết quả lead đã thay đổi so với review B7 gốc: phạm vi tự động nay gọn và explicit exception guard giữ các nghĩa vụ; không cần mở rộng công thức kế toán để xử lý mọi case. Nếu rulebook/source contracts vẫn chưa rõ ở R4, không xem khung được chốt là bằng chứng nguồn đã đủ hoặc routine đã đạt Challenge A. Human approval B8 và actualmoney B9 giữ riêng.

Không tự dùng nhãn outside-automation thay business-policy gap/fact uncertainty/authority exceeded. Điều phối người đúng vẫn dựa loại vấn đề thật; câu trả lời/ngoại lệ không tự xóa hard gate. Phạm vi chưa rõ không được tự chuyển thành các số của công thức.

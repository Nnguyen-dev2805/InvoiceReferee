Mình review **độc lập từ snapshot Bước 7**, chỉ dùng target R2, giả định/case context B5–B6 cần thiết và brief gốc Mục 2.A. Không đọc current code, review 1–6 hay lead notes; không chạy test và không ghi file.

**S7-R01 — Quan trọng — Vendor refund chưa gắn đủ với “ai thực nhận tiền hoàn”.**  
Snapshot: TARGET\_R2\_CASE\_WALKTHROUGH.md (line 328), TARGET\_R2\_CASE\_WALKTHROUGH.md (line 335).

E nói đã xét vendor refund và dòng 335 cho phép refund làm giảm E, nhưng chưa ràng buộc người nhận refund. Counterexample: A tự trả khách sạn 3 triệu; vendor hoàn 1 triệu **vào tài khoản công ty**. Nếu giảm E từ 3 xuống 2 thì A chỉ được hoàn 2 dù A vẫn thực bỏ ra 3; công ty lại đang giữ 1 triệu vendor hoàn. Kết quả thiếu A 1 triệu.

Tác động: sai entitlement và sai S dù mọi nguồn đều “rõ”. Sửa tối thiểu: vendor refund phải có recipient/payer relation. Chỉ giảm E khi refund thực sự làm giảm số tiền nhân viên đã chịu; refund vào công ty phải đi vào company-cost/history riêng, không tự giảm employee entitlement. Phép thử bác bỏ: cùng expense 3 triệu, chạy hai case refund 1 triệu cho A và refund 1 triệu cho công ty; S phải khác nhau đúng chiều.

**S7-R02 — Quan trọng — Công thức S chưa bao phủ nghĩa vụ thu hồi phát sinh từ khoản công ty trả trực tiếp.**  
Snapshot: TARGET\_R2\_CASE\_WALKTHROUGH.md (line 318), TARGET\_R2\_CASE\_WALKTHROUGH.md (line 328), TARGET\_R2\_CASE\_WALKTHROUGH.md (line 333).

Thiết kế đúng khi tách E khỏi whole-company cost, nhưng có một lỗ biên. Ví dụ công ty trả trực tiếp hotel 3 triệu, sau kiểm tra xác định 1 triệu là phần cá nhân và policy yêu cầu A hoàn lại công ty. Vì phần này không nằm trong E, và A=P=RA=RP=0, công thức cho S=0. Nếu B7 gọi đây là kết quả quyết toán cuối thì nghĩa vụ thu 1 triệu biến mất.

Sửa tối thiểu không cần thêm ERP/schema: xác định rõ **S chỉ là net employee reimbursement/advance settlement**, còn khoản company-paid cần recovery phải được xuất thành nghĩa vụ/vấn đề riêng cho B8; hoặc nếu R2 cố ý loại recovery này khỏi MVP thì phải nói rõ và không gọi S=0 là toàn bộ hồ sơ cân bằng. Phép thử: company-direct 3 triệu với 1 triệu recoverable phải không cho kết luận “không còn nghĩa vụ”.

**S7-R03 — Vừa — P/RA/RP cần cùng chuẩn “actual receipt” như A.**  
Snapshot: TARGET\_R2\_CASE\_WALKTHROUGH.md (line 329), TARGET\_R2\_CASE\_WALKTHROUGH.md (line 331). B5 đã có guard mạnh tại TARGET\_R2\_CASE\_WALKTHROUGH.md (line 187).

A rất rõ là tiền nhân viên **thực nhận**. P/RA/RP dùng chữ “đã thực hoàn trả/trả lại”, và pending đã bị loại, nhưng chưa tái khẳng định chuẩn nhận tiền ở phía người nhận. Counterexample: công ty ghi reimbursement 3 triệu là PAID/outflow, sau đó giao dịch bị trả lại trước khi A nhận. Nếu P=3, case E=5,A=2 cho S=0 thay vì còn phải trả 3.

Sửa tối thiểu: định nghĩa P là reimbursement A thực nhận; RA/RP là tiền công ty thực nhận lại, theo source contract R4. Initiated/debited/pending/ambiguous giữ ngoài công thức. Đây là làm rõ semantic, chưa cần chốt schema.

**S7-R04 — Vừa — Chưa khóa invariant “không tự clip về hạn mức”.**  
Snapshot: TARGET\_R2\_CASE\_WALKTHROUGH.md (line 312), TARGET\_R2\_CASE\_WALKTHROUGH.md (line 320).

E là “phần được chấp nhận”, nhưng chưa nói rõ một expense vượt limit không được mặc định biến thành min(actual, limit). Ví dụ hotel 3 triệu, limit giả định 2 triệu: tùy rule thật, phần vượt có thể bị loại, cần exception, hoặc rule mới cho phép partial 2 triệu. Nếu implementation tự đặt E=2 thì có thể biến case cần hỏi thành routine tự động.

Sửa tối thiểu: thêm một câu rằng partial eligibility/capping chỉ được áp dụng khi rulebook **nói rõ cách xử lý phần vượt**; nếu không thì giữ policy/authority issue. Phép thử: cùng 3 triệu nhưng ba rule khác nhau phải cho ba đường xử lý khác nhau.

Hai điểm mình đề nghị **giữ nguyên**. Thứ nhất, phần cumulative settlement khá chắc: old + new expense, A/RA/P/RP, pending, duplicate và revision đều được giữ theo lịch sử thay vì tính riêng submission mới (324–345 (line 324)). Thứ hai, tài liệu đang rất đúng khi không giả vờ rằng B7 tự tính được S là đã chứng minh Challenge A: snapshot tự ghi boundary B8-human còn phải được BTC chấp nhận (302 (line 302)), trong khi brief yêu cầu routine xử lý tự động hoàn toàn (brief:55 (line 55)). Không nên bỏ checkpoint hoặc đổi denominator chỉ để làm metric đẹp.

**Verdict duy nhất: Cần chỉnh sửa.** Hai finding Quan trọng đều có counterexample khiến số tiền/nghĩa vụ cuối sai dù dữ liệu đủ rõ; các sửa cần thiết vẫn chỉ ở mức walkthrough, chưa đòi chốt R4 schema/source contract.

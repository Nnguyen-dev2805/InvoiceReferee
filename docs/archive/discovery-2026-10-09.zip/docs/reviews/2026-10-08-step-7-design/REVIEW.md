# Review thiết kế — R2, Bước 7 đối chiếu và tính quyết toán

Ngày: 08/10/2026. Verdict reviewer và verdict cuối của lead: **Cần chỉnh sửa**.

Target: [walkthrough](../../discovery/R2_CASE_WALKTHROUGH.md), Mục 3.2, dòng 298–361; [snapshot bất biến](TARGET_R2_CASE_WALKTHROUGH.md). B6 được chỉnh theo đồng ý của chủ dự án trước khi viết B7; B7 giữ nguyên từ khi review bắt đầu. Không đọc code, chạy pipeline/Verify, kích hoạt policy hoặc chi/thu thật.

## 1. Phương pháp và chứng cứ

- Reviewer độc lập `chatgpt-web/gpt-5.6-sol`, **High**, Mendel, ID `01a11c21-a0e2-7223-b1ea-ac92c0706e91`. Context không fork lịch sử, không đọc review trước/lead notes. Một lượt hoàn thành, đã đóng. [Trả lời nguyên văn](REVIEWER.md), [evidence](review-evidence.json).
- [Nhận xét riêng của lead](LEAD_PRE_REVIEW.md) được ghi/hash trước khi đọc kết quả reviewer. Hai nhận xét trên cùng văn bản không chứng minh runtime hoặc trial người dùng thực.
- [Brief gốc](../../Challenge_Brief_OrganizationAI_VN.docx.md), Mục 2.A, vẫn là authority cuộc thi. Kiểm tra routine tự hoàn tất chưa tự chứng minh BTC chấp nhận human financial checkpoint B8 trong boundary công bố.
- Lead đọc [UW Advances & Pre-trip Reimbursement](https://finance.uw.edu/travel/traveladvances), có reconciliation và trả lại phần ứng chưa dùng; [UW Payment Options & Tracking](https://finance.uw.edu/travel/WDpaymentoptions), có thanh toán bị trả/từ chối dù trạng thái Paid/Reconciled. Chỉ dùng để tham khảo phân tách nghiệp vụ và nghĩa nguồn; không nhập ngưỡng/hạn của UW thành policy doanh nghiệp Việt Nam.
- Kiểm tra tài liệu bằng Python số nguyên VND: sáu ví dụ literal trong B7 có kết quả 3.000.000 / 5.000.000 / 0 / 500.000 / 4.000.000 / −700.000 khi các thành phần còn lại được xác định 0 và không có pending/ngoài scope. Đây chỉ là kiểm tra số học giả lập; chưa xác minh cách trích nguồn, phân bổ hay policy và không là PASS hệ thống.

## 2. Ledger — reviewer và phán định của lead

| ID / mức reviewer | Reviewer nêu | Phán định độc lập của lead | Sửa tối thiểu / phép thử |
| --- | --- | --- | --- |
| S7-R01 / Quan trọng | Dòng 328, 335: vendor refund chưa gắn người thực nhận. A trả hotel 3, vendor hoàn 1 cho công ty; giảm E về 2 có thể bỏ mất phần tiền cần trả A. | Đồng ý vấn đề, nhưng không mặc định giữ E=3 nếu chi phí công việc sau điều chỉnh thực tế là 2. Cần tách chi phí đủ điều kiện và khoản refund công ty đang giữ có quyền hưởng thuộc ai. Chỉ recipient chưa đủ xác định quyền nếu policy/quan hệ tiền chưa rõ. | Giả định chi phí được chấp nhận sau refund 2, A từng trả 3 và có quyền nhận lại refund 1: vendor trả A thì employee cost exposure 2; vendor trả công ty thì khoản refund cần trả A giữ riêng cùng E=2. Không drop 1 hoặc tăng business cost về 3 chỉ để S ra đúng. Nếu chưa có policy/nguồn cho khoản này: giữ vấn đề, chưa gọi S là kết quả toàn bộ nghĩa vụ. |
| S7-R02 / Quan trọng | Dòng 318, 328, 333: company-paid personal part recoverable không có trong S. | Đồng ý giới hạn công thức. Target đã nói S chỉ cân bằng các thành phần đối chiếu, không closed, nhưng output cần thể hiện nghĩa vụ khác đủ rõ. Không thêm mọi debt vào công thức hoặc tự suy được cấn trừ/khấu trừ từ policy yêu cầu thu hồi. | Company trực tiếp trả 3, trong đó 1 là phần cá nhân và policy giả lập yêu cầu thu hồi: E/A/P/RA/RP có thể 0, S=0 ở nhóm hoàn chi phí/ứng, nhưng báo cáo giữ riêng khoản/vấn đề thu hồi 1 và người có quyền xử lý. Không kết luận hồ sơ không còn nghĩa vụ; khoản này không thành RA/RP giả. |
| S7-R03 / Vừa | Dòng 329–331: P/RA/RP cần cùng chuẩn thực nhận như A. | Đồng ý; “đã thực trả” và exclude pending đã có, cần nêu phía người nhận rõ. Nút Paid/outflow không tự là received. Không bắt mọi phía đều cung cấp sao kê nếu rulebook chấp nhận nguồn phù hợp. | P là tiền A thực nhận để hoàn chi phí; RA/RP là công ty thực nhận lại đúng loại/phạm vi. Lệnh P=3 bị trả trước nhận không được đưa P=3 vào S; khi trạng thái còn unknown thì chưa final, không dùng P=0 theo default. |
| S7-R04 / Vừa | Dòng 312, 320: “phần chấp nhận” có thể bị triển khai thành tự clip về hạn mức. | Đồng ý làm rõ. Raw invoice/actual payment/lời khai vẫn giữ đúng. Rulebook có thể quy định eligible partial amount, nhưng không tự min(actual, limit) khi chưa có quy tắc xử lý phần vượt. | Cùng hotel3 và mức2: rule cho hoàn tối đa2, rule cấm/không ngoại lệ, rule yêu cầu người có quyền xét ngoại lệ phải cho outcome khác nhau. Không sửa facts từ3 thành2 để làm pass. |

## 3. Hai bổ sung độc lập của lead

### S7-L01 — Một sự kiện/phần tiền không đóng góp hai lần vào các nhóm

Target đã chống duplicate expenses và netrefund double count; cần cùng guard cho classification/amount allocation. Transfer nhân viên trả công ty 1 triệu bị hai nguồn gọi hoàn ứng và trả lại hoàn chi phí không tự cho RA=1 và RP=1. Xác định loại/phân bổ có nguồn; nếu một transfer thực sự bao gồm nhiều mục đích, tổng phần phân bổ không vượt amount tương ứng. Chưa rõ thì giữ vấn đề, không chọn nhãn theo công thức thuận tiện. Source schema cụ thể để R4, invariant nghiệp vụ chốt ở walkthrough.

### S7-L02 — Payer split bình thường khác thanh toán vượt nghĩa vụ

Invoice3, company2/A1 là hai phần nếu source đủ rõ. Invoice3, company3/A3 là actual outflow6 cho một nghĩa vụ3, cần sự cố/credit/refund được xử lý; không tự coi cả hai là eligible cost hoặc chọn một bên để kết luận. Target dòng318 đã yêu cầu đối chiếu khi có cả hai nguồn, nên đây là thêm counterexample/outcome tối thiểu. Người trả đầu, người nhận refund và việc khoản nào thuộc quyền của ai phải được xác định; không tự mở quyền hoàn3 cho A từ payment proof đơn lẻ.

## 4. Hướng chỉnh trước Bước 8

1. Giới hạn **S** là kết quả nhóm hoàn chi phí nhân viên/tạm ứng trong phạm vi đủ nguồn. Báo cáo có bảng riêng nghĩa vụ/vấn đề khác như company-held vendor refund hoặc company-paid recovery; không tự gộp/cấn trừ hoặc nói S=0 là toàn hồ sơ cân bằng.
2. Với refund/correction/recovery, ghi người trả/người thực nhận, nguồn, liên kết khoản và quyền hưởng/nghĩa vụ theo policy. Trường hợp chưa có quy tắc tự động thì chuyển đúng người, chưa mở rộng thành engine kế toán tổng quát.
3. Nêu chuẩn thực nhận ở mỗi chiều, không double-count phân loại/phân bổ. Thực hiện lại hoặc nguồn mới vẫn cần version/mốc/ảnh hưởng; không xóa tiền đã xảy ra.
4. Khóa việc giữ raw facts và chỉ tính eligible part theo rulebook rõ. Vi phạm rõ/ngoại lệ/policy gap/uncertainty có outcome cụ thể, không đưa về một công thức cap mặc định.

Giữ những điểm đã làm tốt: phạm vi cumulative E lịch sử+mới với A/P đúng phạm vi; đã trả3 + bổ sung0,5 không thành debt giả; company direct giữ riêng; partial/pending/unknown không là0; nhiều representation không tăng E; S là đề xuất không paid/closed; AI đề xuất source/links/questions, chương trình tính và áp dụng rule.

Phép thử bổ sung chưa chạy phần mềm: vendor refund tới A vs company với policy quyền rõ; company-paid personal recovery; transfer1 nhãn RA/RP mâu thuẫn; company/A cùng thanh toán trọn invoice; reimbursement/repayment lệnh bị trả hoặc còn pending; ba rule xử lý vượt mức. Policy/nguồn/gold độc lập phải chốt trước implementation/evaluation.

B7 hiện giữ nguyên; chỉnh trên là đề xuất đang chờ chủ dự án chốt. Reviewer verdict không thay quyết định lead hoặc chứng minh đạt cuộc thi.

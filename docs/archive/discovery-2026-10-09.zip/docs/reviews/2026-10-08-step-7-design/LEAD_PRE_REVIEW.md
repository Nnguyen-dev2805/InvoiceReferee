# Bước 7 — Nhận xét riêng của lead trước reviewer

Ngày: 08/10/2026. Target [snapshot](TARGET_R2_CASE_WALKTHROUGH.md), Mục 3.2, dòng 298–361. Ghi trước khi đọc reviewer. Review nghĩa nghiệp vụ/số giả lập, không code, pipeline, giao dịch hoặc luật thật.

Verdict ban đầu: **Cần chỉnh sửa** một số nghĩa phân bổ/bàn giao; giữ khung kiểm tra và công thức có điều kiện. Rulebook/source contract chưa chốt R4 không tự là lỗi implementation.

1. **Scope/cumulative đã có, nhưng cần khóa sự kiện không bị phân bổ hai lần — dòng 324–335.** Target đã định nghĩa E/A/RA/P/RP cùng phạm vi và chống netrefund double count. Một transfer 1 triệu không tự là vừa RA=1 vừa RP=1 vì hai nguồn đặt nhãn khác nhau. Cùng expense được kê hai lần không tăng E; một sự kiện tiền chỉ đóng góp đúng phần nguồn xác định vào nhóm thích hợp, hoặc phân bổ có tổng đúng, không theo từng field riêng lẻ. Nguồn ngoài scope không tùy tiện trừ/cộng. R4 schema sau, R2 cần phản ví dụ classification conflict và điều kiện số trước S.

2. **Payer split bình thường khác double payment — dòng 313/318.** Invoice3, company2/A1 là coverage theo phần nếu nguồn rõ. Invoice3, company3/A3 là total actualoutflow6 cho obligation3, không coi cả hai là eligiblecosts hoặc tự chọn một payer. Target đã yêu cầu đối chiếu khi cả hai có nguồn; cần rõ outcome xử lý sự cố/credit/refund và gate số cuối, không coi càng có nhiều proof thì càng chắc được hoàn. Nếu có vendorrefund, phải biết ai nhận/quan hệ nào để điều chỉnh đúng E/companycost, không vừa giảm E vừa đưa vào RA/RP trùng.

3. **Net số học đúng chưa tự đủ quyền chi/thu — dòng 333/357.** Target đã nói S không paid/closed là đúng. S âm là đề xuất trong policy/dữ kiện rõ, không tự quy trách nhiệm nhân viên cho giao dịch sai người hoặc khoản chưa quy định thu hồi. S=0 cần route phù hợp: balanced chưa tự đóng; nộp lại case đã quyết toán không tạo approval/paymentrequest mới chỉ vì B7 chạy lại. Decision B8 cần chỉ rõ nội dung/phạm vi, không biến nguồn dữ kiện/qualityunknown thành tiền đủ duyệt.

4. **Mỗi check độc lập nhưng materialunknown còn chặn tổng — dòng 306/310/320/351–355.** Guard đã hiện hữu, cần làm rõ câu trả lời đọc lại ảnh vs xác nhận sự kiện tài chính, chủ sở hữu và nguồn được rulebook chấp nhận. Một số chắc trên hóa đơn không chứng minh NV paid; một financial confirmation không thay mọi qualitygate. Câu hỏi không bắt routine xác nhận lại nguồn đã đủ và không hứa một câu trả lời xử lý hết mọi nguồn thiếu.

5. **E và phần chi phí không đủ điều kiện không là rawinvoice bị sửa — dòng 312/320/328.** E là accepted employee-paid cost theo policy, giữ số thực tế/khai báo và phần bị loại. Không tự clip raw amount về hạn mức để đạt check. Nếu policy cụ thể cho eligiblepartial amount thì giữ riêng cách tính/rule/authority; thiếu policy không inventcap. Khoản đã chi trong lịch sử không bị reprice bởi policy mới nhất nếu hiệu lực không quy định.

Điểm đáng giữ: fullcase8/direct3/employee5/advance2 → S3; P3 cùngscope → S0; supplemental0,5 dùng E5,5/A2/P3 → S0,5; nhận2/hoàn1 không vừa netadv rồi cộngreturn; ứngunknown/pending không dùng0; factuncertainty/policygap/authority/knownban/technical tách; chương trình số học/rule, AI đề xuất refs; no partialpay với unresolved ảnh hưởng.

Phép thử thiết kế: transfer1 bị nhận diện RA vàRP; invoice3 cócompany2/A1 vscompany3/A3; vendorrefund tới NV vstới company; sourceclaimduplicate nhưngfinancialtransaction khác; nộp lại closedcase E5/A2/P3; supplemental0,5; nguồn mới sauhumanapproval; policyoldvsnew; rejectedexpense rõ vsmissingfact; paymentunknown không0. Chưa là gold/harness đã thực thi.

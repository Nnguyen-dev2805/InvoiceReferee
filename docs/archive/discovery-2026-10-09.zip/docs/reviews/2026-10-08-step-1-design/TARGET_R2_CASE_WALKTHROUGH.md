# R2 — Đi một hồ sơ công tác bằng tay

Ngày: 08/10/2026 · Trạng thái: **WALKTHROUGH GIẢ LẬP ĐỂ THẢO LUẬN**.

Căn cứ: [khung R1](../DISCOVERY_ROADMAP.md). Không đọc/chạy/sửa code; không có thử người dùng hay dữ liệu doanh nghiệp thật. R2 cần phân biệt quy trình khả dĩ từ research với hiện trạng thực đo. Case này làm rõ công việc và phụ thuộc trước khi thiết kế rulebook/gold.

## 1. Bối cảnh và giả định

Một nhân viên đi gặp khách hàng trong hai ngày. Công ty trả vé máy bay trực tiếp; nhân viên đề nghị ứng một phần cho khách sạn, ăn phục vụ công việc và di chuyển.

- Tất cả số tiền là VND; các vai/người/chứng từ dưới đây giả lập.
- Giả định chuyến đi, dự toán và các khoản đáp ứng quy định giả lập của case. Chưa đặt hạn mức/điều khoản thành policy thật.
- Giả định nguồn đủ rõ, liên kết đúng người/công việc và đủ điều kiện bằng chứng sẽ được rulebook định nghĩa. Không coi giả định đó là proof nguồn hay chất lượng OCR đã verified.
- Phạm vi tài chính được xác nhận đầy đủ tại mốc đối chiếu: không có khoản chi khác, hoàn tiền, hoàn trả trước đó hoặc giao dịch chờ ảnh hưởng kết quả, trừ biến thể ghi riêng.

## 2. Trước chuyến đi

| Bước | Vai thực hiện | Dữ liệu/căn cứ | Công việc và kết quả kỳ vọng |
| --- | --- | --- | --- |
| 1. Nộp đề nghị | Nhân viên | Mục đích, thời gian, dự toán phần nhân viên thanh toán 5 triệu; xin ứng 2 triệu. | Hệ thống kiểm tra thông tin để xem xét và vướng mắc ban đầu. Xin ứng 2 không có nghĩa đã nhận 2. |
| 2. Cho phép công tác | Người có quyền | Đề xuất và căn cứ công việc. | Ghi phạm vi công tác được phép. Nếu đã có quyết định bên ngoài đủ căn cứ, dùng quyết định đó, không xin phép lại. |
| 3. Kiểm tra ứng | Hệ thống, với nguồn người phụ trách cung cấp | Đề nghị, căn cứ công tác, quy định, lịch sử cần thiết. | Báo cáo kiểm tra đủ căn cứ theo giả định, hoặc câu hỏi nếu có vướng mắc. Không tự phê duyệt tiền. |
| 4. Duyệt ứng | Người có quyền tài chính | Báo cáo, dữ kiện, nguồn và quy định. | Trong case, duyệt 2 triệu. Nếu trả lại/từ chối thì đi nhánh tương ứng, không mặc định đã chi. |
| 5. Cấp và ghi nhận tiền | Người thực hiện chi/người phụ trách tài chính | Khoản ứng 2 triệu và căn cứ thực tế. | Ghi 2 triệu thực nhận, đúng nhân viên và công việc, không còn khoản ứng chờ xử lý. |

Các bước có thể do một người kiêm nhiều vai nhưng quyết định/nguồn vẫn khác nhau. Chi tiền diễn ra do con người, không phải hành động ngân hàng của InvoiceReferee.

### 2.1. Bước 1 đang đi cùng chủ dự án — Nộp bằng form

Tại thời điểm lập đề nghị trước chuyến đi, nhân viên giả lập A khai: gặp khách hàng cho công việc được mô tả, địa điểm/thời gian hai ngày, dự toán khách sạn 3 triệu + ăn phục vụ công việc 1 triệu + di chuyển 1 triệu = 5 triệu; xin ứng 2 triệu. Vé 3 triệu dự kiến công ty trả trực tiếp là thông tin kế hoạch/khai báo ở bước này, chưa phải xác nhận công ty đã trả. Field bắt buộc cụ thể và tài liệu cần kèm vẫn chốt ở R4.

Hệ thống nhận và lưu khai báo/tài liệu với nguồn, kiểm tra thông tin ban đầu, số tiền/tiền tệ và phép cộng dự toán. Khi thiếu thông tin cần xem xét, báo thiếu cụ thể và để bổ sung. Không tự điều chỉnh số xin ứng về tổng dự toán/hạn mức; trường hợp khác biệt phải xử lý theo rulebook sau này.

Kết quả kỳ vọng của riêng bước 1 trong case không có lỗi đầu vào: **đã tiếp nhận đề nghị, sẵn sàng để người có quyền xem xét công tác**. Chưa khẳng định công tác đã được phép, tiền ứng đã duyệt/đã nhận hay khoản vé đã được công ty thanh toán. Chưa có dữ liệu thực chi không tự trở thành ứng thực nhận 0; không yêu cầu hóa đơn sau chuyến đi hoặc phê duyệt chính đề nghị đang xin như điều kiện tiếp nhận trước chi.

AI chưa cần được gọi để đọc lại các con số form đã rõ chỉ để tạo thêm bước. Nếu có căn cứ đính kèm cần đọc/đối chiếu, AI có thể hỗ trợ; vai trò và cơ chế cụ thể sẽ thiết kế sau. Bước kế tiếp là người có quyền quyết định cho phép công tác, với các kết quả đồng ý, yêu cầu sửa/bổ sung hoặc từ chối.

## 3. Sau chuyến đi: gói dữ liệu cần đối chiếu

| Khoản chi | Giá trị | Nguồn thanh toán trong case | Ai cung cấp nguồn ứng viên? |
| --- | --- | --- | --- |
| Vé máy bay | 3.000.000 | Công ty trả trực tiếp, đúng booking/chứng từ. | Người phụ trách tài chính cung cấp bản ghi và căn cứ; nhân viên có thể cung cấp vé. |
| Khách sạn | 3.000.000 | Nhân viên thanh toán. | Nhân viên cung cấp chứng từ và dấu vết thanh toán phù hợp. |
| Ăn phục vụ công việc | 1.000.000 | Nhân viên thanh toán. | Nhân viên cung cấp chứng từ/nội dung cần theo quy định giả lập. |
| Di chuyển | 1.000.000 | Nhân viên thanh toán. | Nhân viên cung cấp chứng từ và căn cứ liên quan. |

Bản ghi tài chính kèm theo: ứng thực nhận/phân bổ cho case 2 triệu; chưa có hoàn trả chi phí cho nhân viên, hoàn tiền hoặc khoản chi/thu khác ảnh hưởng. Dữ liệu “chưa có” ở đây là giả định đã được xác nhận đủ phạm vi, không phải kết quả tìm kiếm không thấy.

## 4. Đi từng kiểm tra bằng tay

| Kiểm tra | Câu hỏi cần trả lời | Kết quả kỳ vọng theo giả định |
| --- | --- | --- |
| Công việc và phạm vi | Chứng từ/khoản chi có thuộc người/công việc/phạm vi đã được phép không? | Khớp. Không chỉ dựa vào tên file. |
| Chất lượng và nội dung | Các dữ kiện cần dùng có rõ, đủ và đúng nguồn không? | Đủ theo giả định; R4 mới chốt nguồn tối thiểu. |
| Quy định | Mục đích và khoản chi có đáp ứng rulebook không? | Đủ điều kiện trong case giả lập; không tự tạo quy định để khớp kết quả. |
| Liên kết thanh toán | Giao dịch thuộc khoản nào, đã trả bao nhiêu, có phần chưa rõ không? | Công ty 3 triệu vé; nhân viên 5 triệu phần còn lại. |
| Ứng | Số thực nhận là bao nhiêu và thuộc phạm vi nào? | 2 triệu, không dùng số xin ứng thay sự kiện tiền thật. |
| Lịch sử | Phần đang yêu cầu đã được xử lý, hoàn trả hay có giao dịch chờ chưa? | Chưa có theo phạm vi xác nhận; không bỏ qua kiểm tra vì hóa đơn mới. |
| Tính toán | Số còn cần chi/thu là gì? | Nhân viên thanh toán đủ điều kiện 5 triệu − ứng 2 triệu = đề xuất công ty trả thêm 3 triệu. |

## 5. Báo cáo và việc còn lại của con người

Báo cáo: chi phí đủ điều kiện đã đối chiếu 8 triệu; công ty trả trực tiếp 3 triệu; nhân viên thanh toán 5 triệu, đã nhận ứng 2 triệu; chưa có hoàn trả trước đó; đề xuất trả thêm 3 triệu. Giữ nguồn, phép tính và trạng thái của từng phần.

Kế toán rà soát trên báo cáo, người có quyền quyết định tài chính. Nếu duyệt và thực hiện chi thêm 3 triệu, phải ghi nhận/đối chiếu căn cứ thực tế rồi mới xem điều kiện đóng. Nếu trả lại hoặc từ chối, giữ nhánh và lịch sử tương ứng; không tự xóa khoản ứng hoặc suy toàn bộ chi phí bằng 0.

## 6. Ba biến thể để kiểm tra cách hiểu

| Chỉ thay dữ kiện này | Kết quả kỳ vọng |
| --- | --- |
| Xác nhận không nhận ứng, giữ các khoản/nguồn khác và không có lịch sử đã hoàn | Cùng lõi sau chi; đề xuất trả thêm 5 triệu. Không tạo khoản ứng giả hoặc bắt qua đề nghị ứng. |
| Giữ ứng 2 triệu, nhưng xác minh đã hoàn đúng phần này 3 triệu cho nhân viên | Số còn phải trả thêm 0. Cùng chứng từ xuất hiện lại không tự là gian lận. |
| Chứng từ di chuyển không đọc rõ dữ kiện tiền bắt buộc, chưa có nguồn thay thế đủ căn cứ | Giữ phần đã kiểm tra và khoản chưa rõ; hỏi đúng người/căn cứ cụ thể; chưa chốt quyết toán cuối hoặc chi phần đã biết. |

## 7. Điều cần làm rõ tiếp ở R2

Case thường quy đã cho thấy cần hai nhóm nguồn: khai báo/chứng từ nhân viên và dữ liệu tài chính/phê duyệt trong phạm vi. Bước kế tiếp đi một case thiếu/mâu thuẫn: nguồn nào thiếu, ai thực sự có thể trả lời, câu trả lời làm hồ sơ đi tiếp ra sao. Chưa cần schema, API, thuật toán khớp hay corpus chạy tự động; những phần đó thuộc R4–R7.

# Review thiết kế — R2, bước 1 nộp đề nghị công tác/tạm ứng

Ngày: 08/10/2026 · Verdict của lead: **Cần chỉnh sửa**.

Phạm vi: [bước 1](../../discovery/R2_CASE_WALKTHROUGH.md), Mục 2.1 và lời giải thích trong chat. Đây là review thiết kế/nghiệp vụ; không đọc code, không chạy pipeline, không kết luận mức hoàn thiện implementation. Tài liệu bước 1 được giữ nguyên trong lượt review.

## 1. Phương pháp

- Reviewer được tạo bằng `chatgpt-web/gpt-5.6-sol`, mức **High**, tên Pasteur, ID `01a11ba2-c587-7730-bdbd-deae5b1f1cb8`; nhiệm vụ độc lập read-only, không nhận toàn bộ lịch sử, có nguyên văn bước 1 và các ràng buộc đã chốt.
- Reviewer đã hoàn thành, verdict **Cần chỉnh sửa**. Không có thay model hoặc mức reasoning trong lượt này.
- Lead ghi nhận xét riêng trước khi đọc kết quả reviewer, sau đó kiểm tra các nhận xét với nguyên văn và nguồn gốc. Severity bên dưới là đánh giá cuối của lead, không sao chép mọi mức High của reviewer.
- Căn cứ cuộc thi: [đề gốc](../../Challenge_Brief_OrganizationAI_VN.docx.md), Mục 2.A. Bước 1 riêng lẻ không chứng minh toàn bộ tự chủ hoặc đáp ứng đề bài.
- Nguồn nghiệp vụ: [UW tạo Travel Advance](https://finance.uw.edu/travel/traveladvances) nêu người nhận, ngày đi/về, mô tả, lý do và thông tin ứng; [MISA nối công tác/tạm ứng](https://helpamis.misa.vn/amis-quy-trinh/kb/misa-ket-noi-voi-amis-cham-cong-tu-dong-chay-quy-trinh-phe-duyet-tam-ung-di-cong-tac/) nêu thời gian, địa điểm, mục đích, người duyệt và thông tin ứng. Lead đã mở lại nguồn. Đây là ví dụ tổ chức/sản phẩm, không phải field pháp lý bắt buộc chung cho mọi doanh nghiệp.

## 2. Finding ledger của lead

| ID / mức | Nhận xét reviewer | Phán định của lead | Sửa tối thiểu đề xuất và điều kiện đạt |
| --- | --- | --- | --- |
| S1-01 / Quan trọng | “Kiểm tra thông tin ban đầu” và “sẵn sàng” chưa có nghĩa tối thiểu rõ. | Đồng ý. Số học đúng chưa làm một đề nghị đủ để quản lý xem xét. Ví dụ rút gọn thiếu chi tiết không chứng minh app thiếu field, nhưng nếu dùng làm hợp đồng thì chưa đủ rõ. | Trong case, nêu người/công việc, địa điểm, ngày đi/về, mục đích có thể hiểu, phạm vi dự toán/ứng và vai/người nhận bước sau. Thiếu phần cần xét hoặc chưa có người nhận: được tiếp nhận nhưng chưa chuyển như hồ sơ đầy đủ. Không cần schema/HRMS. |
| S1-02 / Vừa | Cần tách khai báo, phê duyệt và sự kiện tài chính. Reviewer chấm High. | Nguyên tắc đúng; **không đồng ý gọi bản trước đã biến khai báo thành fact**. Bản trước đã nói rõ vé chưa trả và xin ứng không phải đã nhận. Khoảng cần bổ sung là cách bảo toàn nghĩa/source ở bản biểu diễn sau này. | Giữ trường/nghĩa và nguồn riêng; không thêm số thực nhận chỉ từ chữ “tạm ứng 2 triệu” trên giấy. Test thiết kế: câu “xin 2 triệu” không đi vào thực nhận. |
| S1-03 / Vừa | Bốn con số kế hoạch cần tách. | Đồng ý. Phần 5 triệu đã được gọi đúng là phần nhân viên dự kiến thanh toán, nhưng tổng dự toán cả chuyến chưa được trình bày trực tiếp. | Tổng dự kiến 8 triệu; phần nhân viên dự kiến thanh toán 5; công ty dự kiến trả trực tiếp 3; xin ứng 2. Không đối trừ ứng khỏi dự toán tại intake; không coi kế hoạch là thực chi. |
| S1-04 / Quan trọng | Thiếu hành vi nộp lặp, sửa và xung đột form/tài liệu. | Đồng ý cần làm rõ; **không gộp chỉ vì cùng người/cùng chuyến**. Có thể là sửa, bổ sung nguồn hoặc đề nghị bổ sung hợp lệ; chỉ triển khai nếu scope/policy cho phép, nếu chưa rõ phải hỏi. | Giữ hai giá trị khi form 2 triệu/giấy 3 triệu, giữ lịch sử; không overwrite hoặc tự tạo hai nghĩa vụ. Cùng đề nghị được xác định rõ thì nhận bản sửa/nguồn mới, không khởi tạo trùng. Chưa xác định quan hệ thì hỏi người nộp. Cùng file hoặc cùng chuyến chưa đủ chứng minh trùng tài chính. |
| S1-05 / Vừa | Phê duyệt bình thường khác escalation do bất định. | Đồng ý phân biệt, nhưng **đổi cách đếm không tự chứng minh đạt Challenge A**. Đơn vị công việc phải công bố trước khi đánh giá, không chọn lại để làm chỉ số đẹp. | Tách việc tự kiểm tra/chuẩn bị và quyết định con người. Ghi đủ mọi can thiệp; định nghĩa scope và kết quả hoàn thành, rồi chấm routine/uncertainty theo gold độc lập. Cần demo toàn phần công việc đã cam kết. |
| S1-06 / Vừa | Phạm vi “AI có thể đọc căn cứ” còn rộng. | Đồng ý bổ sung bảo toàn nguồn; giữ lựa chọn không gọi AI cho phép cộng rõ. Không bắt Step1 có AI chỉ để chứng minh sản phẩm AI. | AI đọc/đề xuất liên kết/dữ kiện có nguồn. Form 5 triệu, giấy 3 triệu: báo mâu thuẫn, không sửa ngầm thành 3. AI không tự cho phép công tác hoặc duyệt tiền. |

## 3. Những điểm giữ nguyên

Khai báo/kế hoạch không phải đã trả/đã nhận; trước chuyến đi không mặc nhiên phải có hóa đơn sau chi; chưa có dữ liệu không biến thành 0; số học rõ bằng chương trình; không tự cắt tiền về giới hạn; phê duyệt công tác, phê duyệt tiền và chi tiền khác nhau. Đây là hướng đúng đã có trong bản trước, không cần viết lại chỉ để đồng ý reviewer.

## 4. Bước 1 sửa ở mức logic — đề xuất, chưa thay target

1. **Tiếp nhận:** lưu đề nghị và nguồn, nhận diện quan hệ với đề nghị trước nếu có; nhân viên chọn form hay nhập giấy không quyết định trạng thái phê duyệt.
2. **Chuẩn bị dữ kiện đủ để xem xét:** ai, công việc/mục đích gì, ở đâu/khi nào, dự toán gồm phần nào, xin ứng bao nhiêu; người/vai nhận bước tiếp có xác định được không? Đây là nhóm dữ kiện theo nghĩa; định dạng/field bắt buộc theo profile sẽ chốt ở R4.
3. **Kiểm tra ban đầu:** tính hợp lệ dữ liệu, phép cộng, quan hệ nguồn, mâu thuẫn và nộp lặp rõ ràng. Không suy loại bỏ hoặc gộp các đề nghị chưa biết quan hệ, không đòi phê duyệt chính đề nghị đang xin.
4. **Kết quả phân biệt:** đã tiếp nhận nhưng cần bổ sung/làm rõ; đã tiếp nhận nhưng cần xác định nơi xử lý; hoặc đủ thông tin ban đầu để chuyển tới bước người có quyền xét công tác. Kết quả cuối chưa phải đủ điều kiện ứng hay đã duyệt.
5. **Lưu vấn đề/câu hỏi/nguồn:** nếu thiếu ngày về thì hỏi ngày về; nếu tiền hai nguồn khác nhau thì trích hai giá trị và hỏi quan hệ/giá trị cập nhật. Khi có thay đổi, giữ phiên bản và kiểm tra lại phần ảnh hưởng.

Không dùng “gặp khách hàng hai ngày, xin 2 triệu” làm ví dụ hồ sơ đầy đủ nếu chưa có dữ kiện cần ra quyết định. Có thể dùng nó làm ví dụ hồ sơ mới tiếp nhận và cần bổ sung; hoặc điền chi tiết giả lập để tiếp tục walkthrough thường quy.

## 5. Case để kiểm tra thiết kế sau chỉnh

- Thiếu ngày về hoặc địa điểm cần xét: tiếp nhận, báo đúng thiếu; chưa gửi như đề nghị đủ thông tin.
- Đủ dữ kiện nhưng chưa xác định người nhận: vấn đề routing riêng, không tự đoán người có quyền hoặc gọi hồ sơ invalid tài chính.
- Form xin 2 triệu, tài liệu cùng đề nghị xin 3 triệu: giữ nguồn, chưa tự chọn giá trị; câu hỏi cụ thể.
- Nộp lại đúng đề nghị, cùng nguồn: không tạo workflow tài chính thứ hai.
- Cùng người/chuyến nhưng tuyên bố là đề nghị bổ sung: kiểm tra scope/quan hệ, không auto merge/refuse chỉ do giống nhau.
- Đề nghị mới đủ dữ kiện: tới checkpoint cho phép công tác; tiền thực nhận vẫn chưa có dữ kiện, không gán bằng tiền xin.
- Dữ kiện kế hoạch 5 + 3, xin ứng 2: giữ tổng 8 và các nghĩa riêng.

Đây là case review bằng tay, không phải test đã thực thi.

## 6. Kết luận và giới hạn

**Cần chỉnh sửa**, chủ yếu để xác định rõ điều kiện đi tiếp, các nghĩa tiền, xung đột và quan hệ nộp lại. Không cần mở rộng sang auth doanh nghiệp, ERP, engine matching tổng quát hay thêm AI cho số học.

Reviewer không phải người dùng kế toán thực và nguồn công khai không thay cho user study. Không kết luận phù hợp cuộc thi được giám khảo xác nhận. Bản sửa là đề xuất cần chủ dự án review; source minimum/policy/schema/thuật toán chi tiết chưa bị tự chốt. Target bước 1 và code không được sửa trong lượt này.

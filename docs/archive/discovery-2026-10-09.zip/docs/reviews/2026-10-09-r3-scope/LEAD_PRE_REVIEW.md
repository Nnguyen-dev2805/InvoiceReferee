# R3 — Nhận xét riêng của lead trước reviewer

Ngày: 09/10/2026. Target [snapshot](TARGET_R3_MVP_SCOPE_DRAFT.md), dòng1–74. Ghi trước khi đọc reviewer; không currentcode/test/runtime/realuser. Verdict ban đầu: **Cần chỉnh sửa** để tách releasecontract A/B, giữ định nghĩa routine và phạm vi case; không cần R4 schemas/ngưỡng ở đây.

1. **Báo cáo và gói sau approval — dòng26/28/72.** Nếu nói A chưa tự tạo request nhưng sauapprovalMVP “chuẩn bịgói” tự sinh một paymentrequest entity, đó là scope B đãlọtvào A. Cần định nghĩa góiA là report/decision hiệnáp dụng và source links, còn request tạo riêng theo quyền/số/phiên bản là actionB vớigates/metric riêng. Không loại bỏ wrapper9steps đãapproved haynghiệp vụ ứng chỉ vì đoAfirst.

2. **Task bắt đầu phải nhận cả input chưa đủ — dòng17/18/20.** Routine có nguồn đủ là một caseclass, không phải filtertiềnxửlý loại bỏ người/case mà hệthốngphảipháthiệnthiếu. Chính jobcheck vẫn nhận inputthiếuđểtạo đúngquestion/error. Intake/logging/sourceprep manual phải đo, không tạo điểmstart sau mọi người đã giải mơhồ rồi chỉ đo phần thuận lợi.

3. **Scope hiện đúng hướng nhưng cần releaseproof hữu hạn — dòng34–42/66.** Một operator, eachcaseoneemployee/work, multiplecases/sourcehistoryVND và 4 loại chi hợp lýđểchốt R3. Ảnh/PDF/form/import không camkết mọi template. R4 chốt format contract/gold cases; R3 cần nêu rõ primarylive/demo capability vs planned để không đóngđăngbản có profile chỉ fake. Sprint2adaptivefeedback/usertrials là obligations dự kiến, không giấu thành futureproductidea; modelagentreviews không trial.

4. **Humanfinancialcheckpoint vs ChallengeA — dòng68.** Risk đã mở và không được giải bởi owneragreement về sản phẩm. Định task rõ+routine complete+materialquestions/reportstates+manualeffortwholeworkflow và probe3routine/2escalation là cần, không là xác nhận BTC. Giữ userdecision conngườiapprove/pay; không lặp warningrủiro như lỗi cần codebankautosolve.

5. **Defining unsupportedbusiness vs automationlimit — dòng46–58.** Outsideauto cófact vàpolicy rõ vẫn là capabilitylimitation riêng, không nhãnOUTSIDE_POLICY sai để fakebenchmark. Chưađủscopehistory làunknown, không default0. Unknownmaterial giữ check độc lập nhưng không tạo payoutknownpart; clearban mộtpart giữrestevaleligibility.

Ý kiến banđầu: đềxuất cả tạmứng/vàafterexpense workflow nhưngprimaryjudgingdemo unit nên nêu 1job (B7) để khônglàm harness3routine/2humanthànhmixmẫu số mà user/giámkhảo chưahiểu. B3 cũng cầnđo/checkgates riêng, khôngvứtkhỏiMVP hayhidefails; R5chốt strata/mẫu số trước tuning. Hai workunits khôngphải cùng một rulebookbefore/afterinvoicecầnthiếu khác.

Điểm giữ: baselinetheo source/rule khôngcode-driven, noERPauthbank; privatepaymentevents/grosshistorymaterialgatecaseclosure đúng; outputreport persisted/chuyển đúngsourceowner córeturnloop khônghỏi allcases; đo sourceprep vàallhumanwork.
